(function(modules){var installedModules={};function __webpack_require__(moduleId){if(installedModules[moduleId]){return installedModules[moduleId].exports}var module=installedModules[moduleId]={i:moduleId,l:!1,exports:{}};modules[moduleId].call(module.exports,module,module.exports,__webpack_require__);module.l=!0;return module.exports}__webpack_require__.m=modules;__webpack_require__.c=installedModules;__webpack_require__.d=function(exports,name,getter){if(!__webpack_require__.o(exports,name)){Object.defineProperty(exports,name,{enumerable:!0,get:getter})}};__webpack_require__.r=function(exports){if('undefined'!==typeof Symbol&&Symbol.toStringTag){Object.defineProperty(exports,Symbol.toStringTag,{value:'Module'})}Object.defineProperty(exports,'__esModule',{value:!0})};__webpack_require__.t=function(value,mode){if(1&mode)value=__webpack_require__(value);if(8&mode)return value;if(4&mode&&'object'===typeof value&&value&&value.__esModule)return value;var ns=Object.create(null);__webpack_require__.r(ns);Object.defineProperty(ns,'default',{enumerable:!0,value:value});if(2&mode&&'string'!=typeof value)for(var key in value)__webpack_require__.d(ns,key,function(key){return value[key]}.bind(null,key));return ns};__webpack_require__.n=function(module){var getter=module&&module.__esModule?function(){return module['default']}:function(){return module};__webpack_require__.d(getter,'a',getter);return getter};__webpack_require__.o=function(object,property){return Object.prototype.hasOwnProperty.call(object,property)};__webpack_require__.p='/frontend_latest/';return __webpack_require__(__webpack_require__.s=150)})([function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'d',function(){return matchesSelector});__webpack_require__.d(__webpack_exports__,'b',function(){return dom});var _utils_boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_utils_settings_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(7),_utils_flattened_nodes_observer_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(55),_utils_flush_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(16);__webpack_require__.d(__webpack_exports__,'c',function(){return _utils_flush_js__WEBPACK_IMPORTED_MODULE_3__.b});__webpack_require__.d(__webpack_exports__,'a',function(){return _utils_flush_js__WEBPACK_IMPORTED_MODULE_3__.a});__webpack_require__(14);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const p=Element.prototype,normalizedMatchesSelector=p.matches||p.matchesSelector||p.mozMatchesSelector||p.msMatchesSelector||p.oMatchesSelector||p.webkitMatchesSelector,matchesSelector=function(node,selector){return normalizedMatchesSelector.call(node,selector)};class DomApi{constructor(node){this.node=node}observeNodes(callback){return new _utils_flattened_nodes_observer_js__WEBPACK_IMPORTED_MODULE_2__.a(this.node,callback)}unobserveNodes(observerHandle){observerHandle.disconnect()}notifyObserver(){}deepContains(node){if(this.node.contains(node)){return!0}let n=node,doc=node.ownerDocument;while(n&&n!==doc&&n!==this.node){n=n.parentNode||n.host}return n===this.node}getOwnerRoot(){return this.node.getRootNode()}getDistributedNodes(){return'slot'===this.node.localName?this.node.assignedNodes({flatten:!0}):[]}getDestinationInsertionPoints(){let ip$=[],n=this.node.assignedSlot;while(n){ip$.push(n);n=n.assignedSlot}return ip$}importNode(node,deep){let doc=this.node instanceof Document?this.node:this.node.ownerDocument;return doc.importNode(node,deep)}getEffectiveChildNodes(){return _utils_flattened_nodes_observer_js__WEBPACK_IMPORTED_MODULE_2__.a.getFlattenedNodes(this.node)}queryDistributedElements(selector){let c$=this.getEffectiveChildNodes(),list=[];for(let i=0,l=c$.length,c;i<l&&(c=c$[i]);i++){if(c.nodeType===Node.ELEMENT_NODE&&matchesSelector(c,selector)){list.push(c)}}return list}get activeElement(){let node=this.node;return node._activeElement!==void 0?node._activeElement:node.activeElement}}class EventApi{constructor(event){this.event=event}get rootTarget(){return this.event.composedPath()[0]}get localTarget(){return this.event.target}get path(){return this.event.composedPath()}}DomApi.prototype.cloneNode;DomApi.prototype.appendChild;DomApi.prototype.insertBefore;DomApi.prototype.removeChild;DomApi.prototype.replaceChild;DomApi.prototype.setAttribute;DomApi.prototype.removeAttribute;DomApi.prototype.querySelector;DomApi.prototype.querySelectorAll;DomApi.prototype.parentNode;DomApi.prototype.firstChild;DomApi.prototype.lastChild;DomApi.prototype.nextSibling;DomApi.prototype.previousSibling;DomApi.prototype.firstElementChild;DomApi.prototype.lastElementChild;DomApi.prototype.nextElementSibling;DomApi.prototype.previousElementSibling;DomApi.prototype.childNodes;DomApi.prototype.children;DomApi.prototype.classList;DomApi.prototype.textContent;DomApi.prototype.innerHTML;(function(proto,methods){for(let i=0,method;i<methods.length;i++){method=methods[i];proto[method]=function(){return this.node[method].apply(this.node,arguments)}}})(DomApi.prototype,['cloneNode','appendChild','insertBefore','removeChild','replaceChild','setAttribute','removeAttribute','querySelector','querySelectorAll']);(function(proto,properties){for(let i=0,name;i<properties.length;i++){name=properties[i];Object.defineProperty(proto,name,{get:function(){const domApi=this;return domApi.node[name]},configurable:!0})}})(DomApi.prototype,['parentNode','firstChild','lastChild','nextSibling','previousSibling','firstElementChild','lastElementChild','nextElementSibling','previousElementSibling','childNodes','children','classList']);(function(proto,properties){for(let i=0,name;i<properties.length;i++){name=properties[i];Object.defineProperty(proto,name,{get:function(){return this.node[name]},set:function(value){this.node[name]=value},configurable:!0})}})(DomApi.prototype,['textContent','innerHTML']);const dom=function(obj){obj=obj||document;if(!obj.__domApi){let helper;if(obj instanceof Event){helper=new EventApi(obj)}else{helper=new DomApi(obj)}obj.__domApi=helper}return obj.__domApi}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return html});__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/class LiteralString{constructor(string){this.value=string.toString()}toString(){return this.value}}function literalValue(value){if(value instanceof LiteralString){return value.value}else{throw new Error(`non-literal value passed to Polymer's htmlLiteral function: ${value}`)}}function htmlValue(value){if(value instanceof HTMLTemplateElement){return value.innerHTML}else if(value instanceof LiteralString){return literalValue(value)}else{throw new Error(`non-template value passed to Polymer's html function: ${value}`)}}const html=function(strings,...values){const template=document.createElement('template');template.innerHTML=values.reduce((acc,v,idx)=>acc+htmlValue(v)+strings[idx+1],strings[0]);return template}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'d',function(){return isPath});__webpack_require__.d(__webpack_exports__,'g',function(){return root});__webpack_require__.d(__webpack_exports__,'b',function(){return isAncestor});__webpack_require__.d(__webpack_exports__,'c',function(){return isDescendant});__webpack_require__.d(__webpack_exports__,'i',function(){return translate});__webpack_require__.d(__webpack_exports__,'e',function(){return matches});__webpack_require__.d(__webpack_exports__,'f',function(){return normalize});__webpack_require__.d(__webpack_exports__,'a',function(){return get});__webpack_require__.d(__webpack_exports__,'h',function(){return set});__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/function isPath(path){return 0<=path.indexOf('.')}function root(path){let dotIndex=path.indexOf('.');if(-1===dotIndex){return path}return path.slice(0,dotIndex)}function isAncestor(base,path){return 0===base.indexOf(path+'.')}function isDescendant(base,path){return 0===path.indexOf(base+'.')}function translate(base,newBase,path){return newBase+path.slice(base.length)}function matches(base,path){return base===path||isAncestor(base,path)||isDescendant(base,path)}function normalize(path){if(Array.isArray(path)){let parts=[];for(let i=0,args;i<path.length;i++){args=path[i].toString().split('.');for(let j=0;j<args.length;j++){parts.push(args[j])}}return parts.join('.')}else{return path}}function split(path){if(Array.isArray(path)){return normalize(path).split('.')}return path.toString().split('.')}function get(root,path,info){let prop=root,parts=split(path);for(let i=0;i<parts.length;i++){if(!prop){return}let part=parts[i];prop=prop[part]}if(info){info.path=parts.join('.')}return prop}function set(root,path,value){let prop=root,parts=split(path),last=parts[parts.length-1];if(1<parts.length){for(let i=0,part;i<parts.length-1;i++){part=parts[i];prop=prop[part];if(!prop){return}}prop[last]=value}else{prop[path]=value}return parts.join('.')}},function(module,__webpack_exports__,__webpack_require__){'use strict';var legacy_element_mixin=__webpack_require__(36),polymer_fn=__webpack_require__(4),templatizer_behavior=__webpack_require__(86),boot=__webpack_require__(6),property_effects=__webpack_require__(27),mutable_data=__webpack_require__(20),gesture_event_listeners=__webpack_require__(43),settings=__webpack_require__(7);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const domBindBase=Object(gesture_event_listeners.a)(Object(mutable_data.b)(Object(property_effects.a)(HTMLElement)));class dom_bind_DomBind extends domBindBase{static get observedAttributes(){return['mutable-data']}constructor(){super();if(settings.f){throw new Error(`strictTemplatePolicy: dom-bind not allowed`)}this.root=null;this.$=null;this.__children=null}attributeChangedCallback(){this.mutableData=!0}connectedCallback(){this.style.display='none';this.render()}disconnectedCallback(){this.__removeChildren()}__insertChildren(){this.parentNode.insertBefore(this.root,this)}__removeChildren(){if(this.__children){for(let i=0;i<this.__children.length;i++){this.root.appendChild(this.__children[i])}}}render(){let template;if(!this.__children){template=template||this.querySelector('template');if(!template){let observer=new MutationObserver(()=>{template=this.querySelector('template');if(template){observer.disconnect();this.render()}else{throw new Error('dom-bind requires a <template> child')}});observer.observe(this,{childList:!0});return}this.root=this._stampTemplate(template);this.$=this.root.$;this.__children=[];for(let n=this.root.firstChild;n;n=n.nextSibling){this.__children[this.__children.length]=n}this._enableProperties()}this.__insertChildren();this.dispatchEvent(new CustomEvent('dom-change',{bubbles:!0,composed:!0}))}}customElements.define('dom-bind',dom_bind_DomBind);var dom_repeat=__webpack_require__(66),dom_if=__webpack_require__(67),polymer_element=__webpack_require__(10),mixin=__webpack_require__(5),array_splice=__webpack_require__(46),element_mixin=__webpack_require__(26);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let array_selector_ArraySelectorMixin=Object(mixin.a)(superClass=>{let elementBase=Object(element_mixin.a)(superClass);class ArraySelectorMixin extends elementBase{static get properties(){return{items:{type:Array},multi:{type:Boolean,value:!1},selected:{type:Object,notify:!0},selectedItem:{type:Object,notify:!0},toggle:{type:Boolean,value:!1}}}static get observers(){return['__updateSelection(multi, items.*)']}constructor(){super();this.__lastItems=null;this.__lastMulti=null;this.__selectedMap=null}__updateSelection(multi,itemsInfo){let path=itemsInfo.path;if('items'==path){let newItems=itemsInfo.base||[],lastItems=this.__lastItems,lastMulti=this.__lastMulti;if(multi!==lastMulti){this.clearSelection()}if(lastItems){let splices=Object(array_splice.a)(newItems,lastItems);this.__applySplices(splices)}this.__lastItems=newItems;this.__lastMulti=multi}else if('items.splices'==itemsInfo.path){this.__applySplices(itemsInfo.value.indexSplices)}else{let part=path.slice('items.'.length),idx=parseInt(part,10);if(0>part.indexOf('.')&&part==idx){this.__deselectChangedIdx(idx)}}}__applySplices(splices){let selected=this.__selectedMap;for(let i=0,s;i<splices.length;i++){s=splices[i];selected.forEach((idx,item)=>{if(idx<s.index){}else if(idx>=s.index+s.removed.length){selected.set(item,idx+s.addedCount-s.removed.length)}else{selected.set(item,-1)}});for(let j=0,idx;j<s.addedCount;j++){idx=s.index+j;if(selected.has(this.items[idx])){selected.set(this.items[idx],idx)}}}this.__updateLinks();let sidx=0;selected.forEach((idx,item)=>{if(0>idx){if(this.multi){this.splice('selected',sidx,1)}else{this.selected=this.selectedItem=null}selected.delete(item)}else{sidx++}})}__updateLinks(){this.__dataLinkedPaths={};if(this.multi){let sidx=0;this.__selectedMap.forEach(idx=>{if(0<=idx){this.linkPaths('items.'+idx,'selected.'+sidx++)}})}else{this.__selectedMap.forEach(idx=>{this.linkPaths('selected','items.'+idx);this.linkPaths('selectedItem','items.'+idx)})}}clearSelection(){this.__dataLinkedPaths={};this.__selectedMap=new Map;this.selected=this.multi?[]:null;this.selectedItem=null}isSelected(item){return this.__selectedMap.has(item)}isIndexSelected(idx){return this.isSelected(this.items[idx])}__deselectChangedIdx(idx){let sidx=this.__selectedIndexForItemIndex(idx);if(0<=sidx){let i=0;this.__selectedMap.forEach((idx,item)=>{if(sidx==i++){this.deselect(item)}})}}__selectedIndexForItemIndex(idx){let selected=this.__dataLinkedPaths['items.'+idx];if(selected){return parseInt(selected.slice('selected.'.length),10)}}deselect(item){let idx=this.__selectedMap.get(item);if(0<=idx){this.__selectedMap.delete(item);let sidx;if(this.multi){sidx=this.__selectedIndexForItemIndex(idx)}this.__updateLinks();if(this.multi){this.splice('selected',sidx,1)}else{this.selected=this.selectedItem=null}}}deselectIndex(idx){this.deselect(this.items[idx])}select(item){this.selectIndex(this.items.indexOf(item))}selectIndex(idx){let item=this.items[idx];if(!this.isSelected(item)){if(!this.multi){this.__selectedMap.clear()}this.__selectedMap.set(item,idx);this.__updateLinks();if(this.multi){this.push('selected',item)}else{this.selected=this.selectedItem=item}}else if(this.toggle){this.deselectIndex(idx)}}}return ArraySelectorMixin}),baseArraySelector=array_selector_ArraySelectorMixin(polymer_element.a);class ArraySelector extends baseArraySelector{static get is(){return'array-selector'}}customElements.define(ArraySelector.is,ArraySelector);var custom_style=__webpack_require__(85),mutable_data_behavior=__webpack_require__(87),html_tag=__webpack_require__(1);__webpack_require__.d(__webpack_exports__,'a',function(){return Base});__webpack_require__.d(__webpack_exports__,'b',function(){return polymer_fn.a});__webpack_require__.d(__webpack_exports__,'c',function(){return html_tag.a});/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const Base=Object(legacy_element_mixin.a)(HTMLElement).prototype},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return Polymer});var _class_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(62),_utils_boot_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const Polymer=function(info){let klass;if('function'===typeof info){klass=info}else{klass=Polymer.Class(info)}customElements.define(klass.is,klass);return klass};Polymer.Class=_class_js__WEBPACK_IMPORTED_MODULE_0__.a},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return dedupingMixin});__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let dedupeId=0;function MixinFunction(){}MixinFunction.prototype.__mixinApplications;MixinFunction.prototype.__mixinSet;const dedupingMixin=function(mixin){let mixinApplications=mixin.__mixinApplications;if(!mixinApplications){mixinApplications=new WeakMap;mixin.__mixinApplications=mixinApplications}let mixinDedupeId=dedupeId++;function dedupingMixin(base){let baseSet=base.__mixinSet;if(baseSet&&baseSet[mixinDedupeId]){return base}let map=mixinApplications,extended=map.get(base);if(!extended){extended=mixin(base);map.set(base,extended)}let mixinSet=Object.create(extended.__mixinSet||baseSet||null);mixinSet[mixinDedupeId]=!0;extended.__mixinSet=mixinSet;return extended}return dedupingMixin}},function(){'use strict';/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/window.JSCompiler_renameProperty=function(prop){return prop}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'g',function(){return useShadow});__webpack_require__.d(__webpack_exports__,'c',function(){return rootPath});__webpack_require__.d(__webpack_exports__,'d',function(){return sanitizeDOMValue});__webpack_require__.d(__webpack_exports__,'b',function(){return passiveTouchGestures});__webpack_require__.d(__webpack_exports__,'e',function(){return setPassiveTouchGestures});__webpack_require__.d(__webpack_exports__,'f',function(){return strictTemplatePolicy});__webpack_require__.d(__webpack_exports__,'a',function(){return allowTemplateFromDomModule});var _boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_resolve_url_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(11);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const useShadow=!window.ShadyDOM,useNativeCSSProperties=!!(!window.ShadyCSS||window.ShadyCSS.nativeCss),useNativeCustomElements=!window.customElements.polyfillWrapFlushCallback;let rootPath=void 0||Object(_resolve_url_js__WEBPACK_IMPORTED_MODULE_1__.a)(document.baseURI||window.location.href);let sanitizeDOMValue=window.Polymer&&window.Polymer.sanitizeDOMValue||void 0;let passiveTouchGestures=!1;const setPassiveTouchGestures=function(usePassive){passiveTouchGestures=usePassive};let strictTemplatePolicy=!1;let allowTemplateFromDomModule=!1},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'d',function(){return timeOut});__webpack_require__.d(__webpack_exports__,'a',function(){return animationFrame});__webpack_require__.d(__webpack_exports__,'b',function(){return idlePeriod});__webpack_require__.d(__webpack_exports__,'c',function(){return microTask});__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let microtaskCurrHandle=0,microtaskLastHandle=0,microtaskCallbacks=[],microtaskNodeContent=0,microtaskNode=document.createTextNode('');new window.MutationObserver(function(){const len=microtaskCallbacks.length;for(let i=0,cb;i<len;i++){cb=microtaskCallbacks[i];if(cb){try{cb()}catch(e){setTimeout(()=>{throw e})}}}microtaskCallbacks.splice(0,len);microtaskLastHandle+=len}).observe(microtaskNode,{characterData:!0});const timeOut={after(delay){return{run(fn){return window.setTimeout(fn,delay)},cancel(handle){window.clearTimeout(handle)}}},run(fn,delay){return window.setTimeout(fn,delay)},cancel(handle){window.clearTimeout(handle)}},animationFrame={run(fn){return window.requestAnimationFrame(fn)},cancel(handle){window.cancelAnimationFrame(handle)}},idlePeriod={run(fn){return window.requestIdleCallback?window.requestIdleCallback(fn):window.setTimeout(fn,16)},cancel(handle){window.cancelIdleCallback?window.cancelIdleCallback(handle):window.clearTimeout(handle)}},microTask={run(callback){microtaskNode.textContent=microtaskNodeContent++;microtaskCallbacks.push(callback);return microtaskCurrHandle++},cancel(handle){const idx=handle-microtaskLastHandle;if(0<=idx){if(!microtaskCallbacks[idx]){throw new Error('invalid async handle: '+handle)}microtaskCallbacks[idx]=null}}}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'c',function(){return nativeShadow});__webpack_require__.d(__webpack_exports__,'a',function(){return cssBuild});__webpack_require__.d(__webpack_exports__,'b',function(){return nativeCssVariables});/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const nativeShadow=!(window.ShadyDOM&&window.ShadyDOM.inUse);let nativeCssVariables_;function calcCssVariables(settings){if(settings&&settings.shimcssproperties){nativeCssVariables_=!1}else{nativeCssVariables_=nativeShadow||!!(!navigator.userAgent.match(/AppleWebKit\/601|Edge\/15/)&&window.CSS&&CSS.supports&&CSS.supports('box-shadow','0 0 0 var(--foo)'))}}let cssBuild;if(window.ShadyCSS&&window.ShadyCSS.cssBuild!==void 0){cssBuild=window.ShadyCSS.cssBuild}if(window.ShadyCSS&&window.ShadyCSS.nativeCss!==void 0){nativeCssVariables_=window.ShadyCSS.nativeCss}else if(window.ShadyCSS){calcCssVariables(window.ShadyCSS);window.ShadyCSS=void 0}else{calcCssVariables(window.WebComponents&&window.WebComponents.flags)}const nativeCssVariables=nativeCssVariables_},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return PolymerElement});var _lib_mixins_element_mixin_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(26),_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const PolymerElement=Object(_lib_mixins_element_mixin_js__WEBPACK_IMPORTED_MODULE_0__.a)(HTMLElement)},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'c',function(){return resolveUrl});__webpack_require__.d(__webpack_exports__,'b',function(){return resolveCss});__webpack_require__.d(__webpack_exports__,'a',function(){return pathFromUrl});__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let CSS_URL_RX=/(url\()([^)]*)(\))/g,ABS_URL=/(^\/)|(^#)|(^[\w-\d]*:)/,workingURL,resolveDoc;function resolveUrl(url,baseURI){if(url&&ABS_URL.test(url)){return url}if(workingURL===void 0){workingURL=!1;try{const u=new URL('b','http://a');u.pathname='c%20d';workingURL='http://a/c%20d'===u.href}catch(e){}}if(!baseURI){baseURI=document.baseURI||window.location.href}if(workingURL){return new URL(url,baseURI).href}if(!resolveDoc){resolveDoc=document.implementation.createHTMLDocument('temp');resolveDoc.base=resolveDoc.createElement('base');resolveDoc.head.appendChild(resolveDoc.base);resolveDoc.anchor=resolveDoc.createElement('a');resolveDoc.body.appendChild(resolveDoc.anchor)}resolveDoc.base.href=baseURI;resolveDoc.anchor.href=url;return resolveDoc.anchor.href||url}function resolveCss(cssText,baseURI){return cssText.replace(CSS_URL_RX,function(m,pre,url,post){return pre+'\''+resolveUrl(url.replace(/["']/g,''),baseURI)+'\''+post})}function pathFromUrl(url){return url.substring(0,url.lastIndexOf('/')+1)}},,function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'c',function(){return VAR_ASSIGN});__webpack_require__.d(__webpack_exports__,'b',function(){return MIXIN_MATCH});__webpack_require__.d(__webpack_exports__,'a',function(){return MEDIA_MATCH});/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const VAR_ASSIGN=/(?:^|[;\s{]\s*)(--[\w-]*?)\s*:\s*(?:((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};{])+)|\{([^}]*)\}(?:(?=[;\s}])|$))/gi,MIXIN_MATCH=/(?:^|\W+)@apply\s*\(?([^);\n]*)\)?/gi,VAR_CONSUMED=/(--[\w-]+)\s*([:,;)]|$)/gi,ANIMATION_MATCH=/(animation\s*:)|(animation-name\s*:)/,MEDIA_MATCH=/@media\s(.*)/,IS_VAR=/^--/,BRACKETED=/\{[^}]*\}/g},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return Debouncer});var _boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_mixin_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(5),_async_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(8);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/class Debouncer{constructor(){this._asyncModule=null;this._callback=null;this._timer=null}setConfig(asyncModule,callback){this._asyncModule=asyncModule;this._callback=callback;this._timer=this._asyncModule.run(()=>{this._timer=null;this._callback()})}cancel(){if(this.isActive()){this._asyncModule.cancel(this._timer);this._timer=null}}flush(){if(this.isActive()){this.cancel();this._callback()}}isActive(){return null!=this._timer}static debounce(debouncer,asyncModule,callback){if(debouncer instanceof Debouncer){debouncer.cancel()}else{debouncer=new Debouncer}debouncer.setConfig(asyncModule,callback);return debouncer}}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'b',function(){return dashToCamelCase});__webpack_require__.d(__webpack_exports__,'a',function(){return camelToDashCase});__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const caseMap={},DASH_TO_CAMEL=/-[a-z]/g,CAMEL_TO_DASH=/([A-Z])/g;function dashToCamelCase(dash){return caseMap[dash]||(caseMap[dash]=0>dash.indexOf('-')?dash:dash.replace(DASH_TO_CAMEL,m=>m[1].toUpperCase()))}function camelToDashCase(camel){return caseMap[camel]||(caseMap[camel]=camel.replace(CAMEL_TO_DASH,'-$1').toLowerCase())}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return enqueueDebouncer});__webpack_require__.d(__webpack_exports__,'b',function(){return flush});var _boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_utils_debounce_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(14);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let debouncerQueue=[];const enqueueDebouncer=function(debouncer){debouncerQueue.push(debouncer)};function flushDebouncers(){const didFlush=!!debouncerQueue.length;while(debouncerQueue.length){try{debouncerQueue.shift().flush()}catch(e){setTimeout(()=>{throw e})}}return didFlush}const flush=function(){let shadyDOM,debouncers;do{shadyDOM=window.ShadyDOM&&ShadyDOM.flush();if(window.ShadyCSS&&window.ShadyCSS.ScopingShim){window.ShadyCSS.ScopingShim.flush()}debouncers=flushDebouncers()}while(shadyDOM||debouncers)}},,function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return IronControlState});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(0);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronControlState={properties:{focused:{type:Boolean,value:!1,notify:!0,readOnly:!0,reflectToAttribute:!0},disabled:{type:Boolean,value:!1,notify:!0,observer:'_disabledChanged',reflectToAttribute:!0},_oldTabIndex:{type:String},_boundFocusBlurHandler:{type:Function,value:function(){return this._focusBlurHandler.bind(this)}}},observers:['_changedControlState(focused, disabled)'],ready:function(){this.addEventListener('focus',this._boundFocusBlurHandler,!0);this.addEventListener('blur',this._boundFocusBlurHandler,!0)},_focusBlurHandler:function(event){this._setFocused('focus'===event.type)},_disabledChanged:function(disabled){this.setAttribute('aria-disabled',disabled?'true':'false');this.style.pointerEvents=disabled?'none':'';if(disabled){this._oldTabIndex=this.getAttribute('tabindex');this._setFocused(!1);this.tabIndex=-1;this.blur()}else if(this._oldTabIndex!==void 0){if(null===this._oldTabIndex){this.removeAttribute('tabindex')}else{this.setAttribute('tabindex',this._oldTabIndex)}}},_changedControlState:function(){if(this._controlStateChanged){this._controlStateChanged()}}}},function(module,__webpack_exports__,__webpack_require__){'use strict';var _StringfromCharCode=String.fromCharCode;__webpack_require__.d(__webpack_exports__,'a',function(){return IronA11yKeysBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),KEY_IDENTIFIER={"U+0008":'backspace',"U+0009":'tab',"U+001B":'esc',"U+0020":'space',"U+007F":'del'},KEY_CODE={8:'backspace',9:'tab',13:'enter',27:'esc',33:'pageup',34:'pagedown',35:'end',36:'home',32:'space',37:'left',38:'up',39:'right',40:'down',46:'del',106:'*'},MODIFIER_KEYS={shift:'shiftKey',ctrl:'ctrlKey',alt:'altKey',meta:'metaKey'},KEY_CHAR=/[a-z0-9*]/,IDENT_CHAR=/U\+/,ARROW_KEY=/^arrow/,SPACE_KEY=/^space(bar)?/,ESC_KEY=/^escape$/;/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/function transformKey(key,noSpecialChars){var validKey='';if(key){var lKey=key.toLowerCase();if(' '===lKey||SPACE_KEY.test(lKey)){validKey='space'}else if(ESC_KEY.test(lKey)){validKey='esc'}else if(1==lKey.length){if(!noSpecialChars||KEY_CHAR.test(lKey)){validKey=lKey}}else if(ARROW_KEY.test(lKey)){validKey=lKey.replace('arrow','')}else if('multiply'==lKey){validKey='*'}else{validKey=lKey}}return validKey}function transformKeyIdentifier(keyIdent){var validKey='';if(keyIdent){if(keyIdent in KEY_IDENTIFIER){validKey=KEY_IDENTIFIER[keyIdent]}else if(IDENT_CHAR.test(keyIdent)){keyIdent=parseInt(keyIdent.replace('U+','0x'),16);validKey=_StringfromCharCode(keyIdent).toLowerCase()}else{validKey=keyIdent.toLowerCase()}}return validKey}function transformKeyCode(keyCode){var validKey='';if(+keyCode){if(65<=keyCode&&90>=keyCode){validKey=_StringfromCharCode(32+keyCode)}else if(112<=keyCode&&123>=keyCode){validKey='f'+(keyCode-112+1)}else if(48<=keyCode&&57>=keyCode){validKey=keyCode-48+''}else if(96<=keyCode&&105>=keyCode){validKey=keyCode-96+''}else{validKey=KEY_CODE[keyCode]}}return validKey}function normalizedKeyForEvent(keyEvent,noSpecialChars){if(keyEvent.key){return transformKey(keyEvent.key,noSpecialChars)}if(keyEvent.detail&&keyEvent.detail.key){return transformKey(keyEvent.detail.key,noSpecialChars)}return transformKeyIdentifier(keyEvent.keyIdentifier)||transformKeyCode(keyEvent.keyCode)||''}function keyComboMatchesEvent(keyCombo,event){var keyEvent=normalizedKeyForEvent(event,keyCombo.hasModifiers);return keyEvent===keyCombo.key&&(!keyCombo.hasModifiers||!!event.shiftKey===!!keyCombo.shiftKey&&!!event.ctrlKey===!!keyCombo.ctrlKey&&!!event.altKey===!!keyCombo.altKey&&!!event.metaKey===!!keyCombo.metaKey)}function parseKeyComboString(keyComboString){if(1===keyComboString.length){return{combo:keyComboString,key:keyComboString,event:'keydown'}}return keyComboString.split('+').reduce(function(parsedKeyCombo,keyComboPart){var eventParts=keyComboPart.split(':'),keyName=eventParts[0],event=eventParts[1];if(keyName in MODIFIER_KEYS){parsedKeyCombo[MODIFIER_KEYS[keyName]]=!0;parsedKeyCombo.hasModifiers=!0}else{parsedKeyCombo.key=keyName;parsedKeyCombo.event=event||'keydown'}return parsedKeyCombo},{combo:keyComboString.split(':').shift()})}function parseEventString(eventString){return eventString.trim().split(' ').map(function(keyComboString){return parseKeyComboString(keyComboString)})}const IronA11yKeysBehavior={properties:{keyEventTarget:{type:Object,value:function(){return this}},stopKeyboardEventPropagation:{type:Boolean,value:!1},_boundKeyHandlers:{type:Array,value:function(){return[]}},_imperativeKeyBindings:{type:Object,value:function(){return{}}}},observers:['_resetKeyEventListeners(keyEventTarget, _boundKeyHandlers)'],keyBindings:{},registered:function(){this._prepKeyBindings()},attached:function(){this._listenKeyEventListeners()},detached:function(){this._unlistenKeyEventListeners()},addOwnKeyBinding:function(eventString,handlerName){this._imperativeKeyBindings[eventString]=handlerName;this._prepKeyBindings();this._resetKeyEventListeners()},removeOwnKeyBindings:function(){this._imperativeKeyBindings={};this._prepKeyBindings();this._resetKeyEventListeners()},keyboardEventMatchesKeys:function(event,eventString){for(var keyCombos=parseEventString(eventString),i=0;i<keyCombos.length;++i){if(keyComboMatchesEvent(keyCombos[i],event)){return!0}}return!1},_collectKeyBindings:function(){var keyBindings=this.behaviors.map(function(behavior){return behavior.keyBindings});if(-1===keyBindings.indexOf(this.keyBindings)){keyBindings.push(this.keyBindings)}return keyBindings},_prepKeyBindings:function(){this._keyBindings={};this._collectKeyBindings().forEach(function(keyBindings){for(var eventString in keyBindings){this._addKeyBinding(eventString,keyBindings[eventString])}},this);for(var eventString in this._imperativeKeyBindings){this._addKeyBinding(eventString,this._imperativeKeyBindings[eventString])}for(var eventName in this._keyBindings){this._keyBindings[eventName].sort(function(kb1,kb2){var b1=kb1[0].hasModifiers,b2=kb2[0].hasModifiers;return b1===b2?0:b1?-1:1})}},_addKeyBinding:function(eventString,handlerName){parseEventString(eventString).forEach(function(keyCombo){this._keyBindings[keyCombo.event]=this._keyBindings[keyCombo.event]||[];this._keyBindings[keyCombo.event].push([keyCombo,handlerName])},this)},_resetKeyEventListeners:function(){this._unlistenKeyEventListeners();if(this.isAttached){this._listenKeyEventListeners()}},_listenKeyEventListeners:function(){if(!this.keyEventTarget){return}Object.keys(this._keyBindings).forEach(function(eventName){var keyBindings=this._keyBindings[eventName],boundKeyHandler=this._onKeyBindingEvent.bind(this,keyBindings);this._boundKeyHandlers.push([this.keyEventTarget,eventName,boundKeyHandler]);this.keyEventTarget.addEventListener(eventName,boundKeyHandler)},this)},_unlistenKeyEventListeners:function(){var keyHandlerTuple,keyEventTarget,eventName,boundKeyHandler;while(this._boundKeyHandlers.length){keyHandlerTuple=this._boundKeyHandlers.pop();keyEventTarget=keyHandlerTuple[0];eventName=keyHandlerTuple[1];boundKeyHandler=keyHandlerTuple[2];keyEventTarget.removeEventListener(eventName,boundKeyHandler)}},_onKeyBindingEvent:function(keyBindings,event){if(this.stopKeyboardEventPropagation){event.stopPropagation()}if(event.defaultPrevented){return}for(var i=0;i<keyBindings.length;i++){var keyCombo=keyBindings[i][0],handlerName=keyBindings[i][1];if(keyComboMatchesEvent(keyCombo,event)){this._triggerKeyHandler(keyCombo,handlerName,event);if(event.defaultPrevented){return}}}},_triggerKeyHandler:function(keyCombo,handlerName,keyboardEvent){var detail=Object.create(keyCombo);detail.keyboardEvent=keyboardEvent;var event=new CustomEvent(keyCombo.event,{detail:detail,cancelable:!0});this[handlerName].call(this,event);if(event.defaultPrevented){keyboardEvent.preventDefault()}}}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return MutableData});__webpack_require__.d(__webpack_exports__,'b',function(){return OptionalMutableData});var _utils_mixin_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(5);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/function mutablePropertyChange(inst,property,value,old,mutableData){let isObject;if(mutableData){isObject='object'===typeof value&&null!==value;if(isObject){old=inst.__dataTemp[property]}}let shouldChange=old!==value&&(old===old||value===value);if(isObject&&shouldChange){inst.__dataTemp[property]=value}return shouldChange}const MutableData=Object(_utils_mixin_js__WEBPACK_IMPORTED_MODULE_0__.a)(superClass=>{return class extends superClass{_shouldPropertyChange(property,value,old){return mutablePropertyChange(this,property,value,old,!0)}}}),OptionalMutableData=Object(_utils_mixin_js__WEBPACK_IMPORTED_MODULE_0__.a)(superClass=>{class OptionalMutableData extends superClass{static get properties(){return{mutableData:Boolean}}_shouldPropertyChange(property,value,old){return mutablePropertyChange(this,property,value,old,this.mutableData)}}return OptionalMutableData});MutableData._mutablePropertyChange=mutablePropertyChange},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'c',function(){return updateNativeProperties});__webpack_require__.d(__webpack_exports__,'b',function(){return getComputedStyleValue});__webpack_require__.d(__webpack_exports__,'a',function(){return detectMixin});var _common_regex_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(13);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/function updateNativeProperties(element,properties){for(let p in properties){if(null===p){element.style.removeProperty(p)}else{element.style.setProperty(p,properties[p])}}}function getComputedStyleValue(element,property){const value=window.getComputedStyle(element).getPropertyValue(property);if(!value){return''}else{return value.trim()}}function detectMixin(cssText){const has=_common_regex_js__WEBPACK_IMPORTED_MODULE_0__.b.test(cssText)||_common_regex_js__WEBPACK_IMPORTED_MODULE_0__.c.test(cssText);_common_regex_js__WEBPACK_IMPORTED_MODULE_0__.b.lastIndex=0;_common_regex_js__WEBPACK_IMPORTED_MODULE_0__.c.lastIndex=0;return has}},,function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'b',function(){return IronButtonStateImpl});__webpack_require__.d(__webpack_exports__,'a',function(){return IronButtonState});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_iron_control_state_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(18),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(19),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(0);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronButtonStateImpl={properties:{pressed:{type:Boolean,readOnly:!0,value:!1,reflectToAttribute:!0,observer:'_pressedChanged'},toggles:{type:Boolean,value:!1,reflectToAttribute:!0},active:{type:Boolean,value:!1,notify:!0,reflectToAttribute:!0},pointerDown:{type:Boolean,readOnly:!0,value:!1},receivedFocusFromKeyboard:{type:Boolean,readOnly:!0},ariaActiveAttribute:{type:String,value:'aria-pressed',observer:'_ariaActiveAttributeChanged'}},listeners:{down:'_downHandler',up:'_upHandler',tap:'_tapHandler'},observers:['_focusChanged(focused)','_activeChanged(active, ariaActiveAttribute)'],keyBindings:{"enter:keydown":'_asyncClick',"space:keydown":'_spaceKeyDownHandler',"space:keyup":'_spaceKeyUpHandler'},_mouseEventRe:/^mouse/,_tapHandler:function(){if(this.toggles){this._userActivate(!this.active)}else{this.active=!1}},_focusChanged:function(focused){this._detectKeyboardFocus(focused);if(!focused){this._setPressed(!1)}},_detectKeyboardFocus:function(focused){this._setReceivedFocusFromKeyboard(!this.pointerDown&&focused)},_userActivate:function(active){if(this.active!==active){this.active=active;this.fire('change')}},_downHandler:function(){this._setPointerDown(!0);this._setPressed(!0);this._setReceivedFocusFromKeyboard(!1)},_upHandler:function(){this._setPointerDown(!1);this._setPressed(!1)},_spaceKeyDownHandler:function(event){var keyboardEvent=event.detail.keyboardEvent,target=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(keyboardEvent).localTarget;if(this.isLightDescendant(target))return;keyboardEvent.preventDefault();keyboardEvent.stopImmediatePropagation();this._setPressed(!0)},_spaceKeyUpHandler:function(event){var keyboardEvent=event.detail.keyboardEvent,target=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(keyboardEvent).localTarget;if(this.isLightDescendant(target))return;if(this.pressed){this._asyncClick()}this._setPressed(!1)},_asyncClick:function(){this.async(function(){this.click()},1)},_pressedChanged:function(){this._changedButtonState()},_ariaActiveAttributeChanged:function(value,oldValue){if(oldValue&&oldValue!=value&&this.hasAttribute(oldValue)){this.removeAttribute(oldValue)}},_activeChanged:function(active){if(this.toggles){this.setAttribute(this.ariaActiveAttribute,active?'true':'false')}else{this.removeAttribute(this.ariaActiveAttribute)}this._changedButtonState()},_controlStateChanged:function(){if(this.disabled){this._setPressed(!1)}else{this._changedButtonState()}},_changedButtonState:function(){if(this._buttonStateChanged){this._buttonStateChanged()}}},IronButtonState=[_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a,IronButtonStateImpl]},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'b',function(){return templatize});__webpack_require__.d(__webpack_exports__,'a',function(){return modelForElement});var _boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_mixins_property_effects_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(27),_mixins_mutable_data_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(20),_utils_settings_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(7);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let newInstance=null;function HTMLTemplateElementExtension(){return newInstance}HTMLTemplateElementExtension.prototype=Object.create(HTMLTemplateElement.prototype,{constructor:{value:HTMLTemplateElementExtension,writable:!0}});const DataTemplate=Object(_mixins_property_effects_js__WEBPACK_IMPORTED_MODULE_1__.a)(HTMLTemplateElementExtension),MutableDataTemplate=Object(_mixins_mutable_data_js__WEBPACK_IMPORTED_MODULE_2__.a)(DataTemplate);function upgradeTemplate(template,constructor){newInstance=template;Object.setPrototypeOf(template,constructor.prototype);new constructor;newInstance=null}const base=Object(_mixins_property_effects_js__WEBPACK_IMPORTED_MODULE_1__.a)(class{});class TemplateInstanceBase extends base{constructor(props){super();this._configureProperties(props);this.root=this._stampTemplate(this.__dataHost);let children=this.children=[];for(let n=this.root.firstChild;n;n=n.nextSibling){children.push(n);n.__templatizeInstance=this}if(this.__templatizeOwner&&this.__templatizeOwner.__hideTemplateChildren__){this._showHideChildren(!0)}let options=this.__templatizeOptions;if(props&&options.instanceProps||!options.instanceProps){this._enableProperties()}}_configureProperties(props){let options=this.__templatizeOptions;if(options.forwardHostProp){for(let hprop in this.__hostProps){this._setPendingProperty(hprop,this.__dataHost['_host_'+hprop])}}for(let iprop in props){this._setPendingProperty(iprop,props[iprop])}}forwardHostProp(prop,value){if(this._setPendingPropertyOrPath(prop,value,!1,!0)){this.__dataHost._enqueueClient(this)}}_addEventListenerToNode(node,eventName,handler){if(this._methodHost&&this.__templatizeOptions.parentModel){this._methodHost._addEventListenerToNode(node,eventName,e=>{e.model=this;handler(e)})}else{let templateHost=this.__dataHost.__dataHost;if(templateHost){templateHost._addEventListenerToNode(node,eventName,handler)}}}_showHideChildren(hide){let c=this.children;for(let i=0,n;i<c.length;i++){n=c[i];if(!!hide!=!!n.__hideTemplateChildren__){if(n.nodeType===Node.TEXT_NODE){if(hide){n.__polymerTextContent__=n.textContent;n.textContent=''}else{n.textContent=n.__polymerTextContent__}}else if('slot'===n.localName){if(hide){n.__polymerReplaced__=document.createComment('hidden-slot');n.parentNode.replaceChild(n.__polymerReplaced__,n)}else{const replace=n.__polymerReplaced__;if(replace){replace.parentNode.replaceChild(n,replace)}}}else if(n.style){if(hide){n.__polymerDisplay__=n.style.display;n.style.display='none'}else{n.style.display=n.__polymerDisplay__}}}n.__hideTemplateChildren__=hide;if(n._showHideChildren){n._showHideChildren(hide)}}}_setUnmanagedPropertyToNode(node,prop,value){if(node.__hideTemplateChildren__&&node.nodeType==Node.TEXT_NODE&&'textContent'==prop){node.__polymerTextContent__=value}else{super._setUnmanagedPropertyToNode(node,prop,value)}}get parentModel(){let model=this.__parentModel;if(!model){let options;model=this;do{model=model.__dataHost.__dataHost}while((options=model.__templatizeOptions)&&!options.parentModel);this.__parentModel=model}return model}dispatchEvent(){return!0}}TemplateInstanceBase.prototype.__dataHost;TemplateInstanceBase.prototype.__templatizeOptions;TemplateInstanceBase.prototype._methodHost;TemplateInstanceBase.prototype.__templatizeOwner;TemplateInstanceBase.prototype.__hostProps;const MutableTemplateInstanceBase=Object(_mixins_mutable_data_js__WEBPACK_IMPORTED_MODULE_2__.a)(TemplateInstanceBase);function findMethodHost(template){let templateHost=template.__dataHost;return templateHost&&templateHost._methodHost||templateHost}function createTemplatizerClass(template,templateInfo,options){let base=options.mutableData?MutableTemplateInstanceBase:TemplateInstanceBase,klass=class extends base{};klass.prototype.__templatizeOptions=options;klass.prototype._bindTemplate(template);addNotifyEffects(klass,template,templateInfo,options);return klass}function addPropagateEffects(template,templateInfo,options){let userForwardHostProp=options.forwardHostProp;if(userForwardHostProp){let klass=templateInfo.templatizeTemplateClass;if(!klass){let base=options.mutableData?MutableDataTemplate:DataTemplate;klass=templateInfo.templatizeTemplateClass=class extends base{};let hostProps=templateInfo.hostProps;for(let prop in hostProps){klass.prototype._addPropertyEffect('_host_'+prop,klass.prototype.PROPERTY_EFFECT_TYPES.PROPAGATE,{fn:createForwardHostPropEffect(prop,userForwardHostProp)});klass.prototype._createNotifyingProperty('_host_'+prop)}}upgradeTemplate(template,klass);if(template.__dataProto){Object.assign(template.__data,template.__dataProto)}template.__dataTemp={};template.__dataPending=null;template.__dataOld=null;template._enableProperties()}}function createForwardHostPropEffect(hostProp,userForwardHostProp){return function(template,prop,props){userForwardHostProp.call(template.__templatizeOwner,prop.substring('_host_'.length),props[prop])}}function addNotifyEffects(klass,template,templateInfo,options){let hostProps=templateInfo.hostProps||{};for(let iprop in options.instanceProps){delete hostProps[iprop];let userNotifyInstanceProp=options.notifyInstanceProp;if(userNotifyInstanceProp){klass.prototype._addPropertyEffect(iprop,klass.prototype.PROPERTY_EFFECT_TYPES.NOTIFY,{fn:createNotifyInstancePropEffect(iprop,userNotifyInstanceProp)})}}if(options.forwardHostProp&&template.__dataHost){for(let hprop in hostProps){klass.prototype._addPropertyEffect(hprop,klass.prototype.PROPERTY_EFFECT_TYPES.NOTIFY,{fn:createNotifyHostPropEffect()})}}}function createNotifyInstancePropEffect(instProp,userNotifyInstanceProp){return function(inst,prop,props){userNotifyInstanceProp.call(inst.__templatizeOwner,inst,prop,props[prop])}}function createNotifyHostPropEffect(){return function(inst,prop,props){inst.__dataHost._setPendingPropertyOrPath('_host_'+prop,props[prop],!0,!0)}}function templatize(template,owner,options){if(_utils_settings_js__WEBPACK_IMPORTED_MODULE_3__.f&&!findMethodHost(template)){throw new Error('strictTemplatePolicy: template owner not trusted')}options=options||{};if(template.__templatizeOwner){throw new Error('A <template> can only be templatized once')}template.__templatizeOwner=owner;const ctor=owner?owner.constructor:TemplateInstanceBase;let templateInfo=ctor._parseTemplate(template),baseClass=templateInfo.templatizeInstanceClass;if(!baseClass){baseClass=createTemplatizerClass(template,templateInfo,options);templateInfo.templatizeInstanceClass=baseClass}addPropagateEffects(template,templateInfo,options);let klass=class extends baseClass{};klass.prototype._methodHost=findMethodHost(template);klass.prototype.__dataHost=template;klass.prototype.__templatizeOwner=owner;klass.prototype.__hostProps=templateInfo.hostProps;klass=klass;return klass}function modelForElement(template,node){let model;while(node){if(model=node.__templatizeInstance){if(model.__dataHost!=template){node=model.__dataHost}else{return model}}else{node=node.parentNode}}return null}},function(module,__webpack_exports__,__webpack_require__){'use strict';var _Mathabs=Math.abs;__webpack_require__.d(__webpack_exports__,'b',function(){return addListener});__webpack_require__.d(__webpack_exports__,'e',function(){return removeListener});__webpack_require__.d(__webpack_exports__,'f',function(){return setTouchAction});__webpack_require__.d(__webpack_exports__,'d',function(){return prevent});__webpack_require__.d(__webpack_exports__,'c',function(){return findOriginalTarget});__webpack_require__.d(__webpack_exports__,'a',function(){return add});var _boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_async_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(8),_debounce_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(14),_settings_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(7);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let HAS_NATIVE_TA='string'===typeof document.head.style.touchAction,GESTURE_KEY='__polymerGestures',HANDLED_OBJ='__polymerGesturesHandled',TOUCH_ACTION='__polymerGesturesTouchAction',TAP_DISTANCE=25,TRACK_DISTANCE=5,MOUSE_EVENTS=['mousedown','mousemove','mouseup','click'],MOUSE_WHICH_TO_BUTTONS=[0,1,4,2],MOUSE_HAS_BUTTONS=function(){try{return 1===new MouseEvent('test',{buttons:1}).buttons}catch(e){return!1}}();function isMouseEvent(name){return-1<MOUSE_EVENTS.indexOf(name)}let SUPPORTS_PASSIVE=!1;(function(){try{let opts=Object.defineProperty({},'passive',{get(){SUPPORTS_PASSIVE=!0}});window.addEventListener('test',null,opts);window.removeEventListener('test',null,opts)}catch(e){}})();function PASSIVE_TOUCH(eventName){if(isMouseEvent(eventName)||'touchend'===eventName){return}if(HAS_NATIVE_TA&&SUPPORTS_PASSIVE&&_settings_js__WEBPACK_IMPORTED_MODULE_3__.b){return{passive:!0}}else{}}let IS_TOUCH_ONLY=navigator.userAgent.match(/iP(?:[oa]d|hone)|Android/);const clickedLabels=[],labellable={button:!0,input:!0,keygen:!0,meter:!0,output:!0,textarea:!0,progress:!0,select:!0},canBeDisabled={button:!0,command:!0,fieldset:!0,input:!0,keygen:!0,optgroup:!0,option:!0,select:!0,textarea:!0};function canBeLabelled(el){return labellable[el.localName]||!1}function matchingLabels(el){let labels=Array.prototype.slice.call(el.labels||[]);if(!labels.length){labels=[];let root=el.getRootNode();if(el.id){let matching=root.querySelectorAll(`label[for = ${el.id}]`);for(let i=0;i<matching.length;i++){labels.push(matching[i])}}}return labels}let mouseCanceller=function(mouseEvent){let sc=mouseEvent.sourceCapabilities;if(sc&&!sc.firesTouchEvents){return}mouseEvent[HANDLED_OBJ]={skip:!0};if('click'===mouseEvent.type){let clickFromLabel=!1,path=mouseEvent.composedPath&&mouseEvent.composedPath();if(path){for(let i=0;i<path.length;i++){if(path[i].nodeType===Node.ELEMENT_NODE){if('label'===path[i].localName){clickedLabels.push(path[i])}else if(canBeLabelled(path[i])){let ownerLabels=matchingLabels(path[i]);for(let j=0;j<ownerLabels.length;j++){clickFromLabel=clickFromLabel||-1<clickedLabels.indexOf(ownerLabels[j])}}}if(path[i]===POINTERSTATE.mouse.target){return}}}if(clickFromLabel){return}mouseEvent.preventDefault();mouseEvent.stopPropagation()}};function setupTeardownMouseCanceller(setup){let events=IS_TOUCH_ONLY?['click']:MOUSE_EVENTS;for(let i=0,en;i<events.length;i++){en=events[i];if(setup){clickedLabels.length=0;document.addEventListener(en,mouseCanceller,!0)}else{document.removeEventListener(en,mouseCanceller,!0)}}}function hasLeftMouseButton(ev){let type=ev.type;if(!isMouseEvent(type)){return!1}if('mousemove'===type){let buttons=ev.buttons===void 0?1:ev.buttons;if(ev instanceof window.MouseEvent&&!MOUSE_HAS_BUTTONS){buttons=MOUSE_WHICH_TO_BUTTONS[ev.which]||0}return!!(1&buttons)}else{let button=ev.button===void 0?0:ev.button;return 0===button}}function isSyntheticClick(ev){if('click'===ev.type){if(0===ev.detail){return!0}let t=_findOriginalTarget(ev);if(!t.nodeType||t.nodeType!==Node.ELEMENT_NODE){return!0}let bcr=t.getBoundingClientRect(),x=ev.pageX,y=ev.pageY;return!(x>=bcr.left&&x<=bcr.right&&y>=bcr.top&&y<=bcr.bottom)}return!1}let POINTERSTATE={mouse:{target:null,mouseIgnoreJob:null},touch:{x:0,y:0,id:-1,scrollDecided:!1}};function firstTouchAction(ev){let ta='auto',path=ev.composedPath&&ev.composedPath();if(path){for(let i=0,n;i<path.length;i++){n=path[i];if(n[TOUCH_ACTION]){ta=n[TOUCH_ACTION];break}}}return ta}function trackDocument(stateObj,movefn,upfn){stateObj.movefn=movefn;stateObj.upfn=upfn;document.addEventListener('mousemove',movefn);document.addEventListener('mouseup',upfn)}function untrackDocument(stateObj){document.removeEventListener('mousemove',stateObj.movefn);document.removeEventListener('mouseup',stateObj.upfn);stateObj.movefn=null;stateObj.upfn=null}document.addEventListener('touchend',function(e){if(!POINTERSTATE.mouse.mouseIgnoreJob){setupTeardownMouseCanceller(!0)}POINTERSTATE.mouse.target=e.composedPath()[0];POINTERSTATE.mouse.mouseIgnoreJob=_debounce_js__WEBPACK_IMPORTED_MODULE_2__.a.debounce(POINTERSTATE.mouse.mouseIgnoreJob,_async_js__WEBPACK_IMPORTED_MODULE_1__.d.after(2500),function(){setupTeardownMouseCanceller();POINTERSTATE.mouse.target=null;POINTERSTATE.mouse.mouseIgnoreJob=null})},SUPPORTS_PASSIVE?{passive:!0}:!1);const gestures={},recognizers=[];function deepTargetFind(x,y){let node=document.elementFromPoint(x,y),next=node;while(next&&next.shadowRoot&&!window.ShadyDOM){let oldNext=next;next=next.shadowRoot.elementFromPoint(x,y);if(oldNext===next){break}if(next){node=next}}return node}function _findOriginalTarget(ev){if(ev.composedPath){const targets=ev.composedPath();return 0<targets.length?targets[0]:ev.target}return ev.target}function _handleNative(ev){let handled,type=ev.type,node=ev.currentTarget,gobj=node[GESTURE_KEY];if(!gobj){return}let gs=gobj[type];if(!gs){return}if(!ev[HANDLED_OBJ]){ev[HANDLED_OBJ]={};if('touch'===type.slice(0,5)){ev=ev;let t=ev.changedTouches[0];if('touchstart'===type){if(1===ev.touches.length){POINTERSTATE.touch.id=t.identifier}}if(POINTERSTATE.touch.id!==t.identifier){return}if(!HAS_NATIVE_TA){if('touchstart'===type||'touchmove'===type){_handleTouchAction(ev)}}}}handled=ev[HANDLED_OBJ];if(handled.skip){return}for(let i=0,r;i<recognizers.length;i++){r=recognizers[i];if(gs[r.name]&&!handled[r.name]){if(r.flow&&-1<r.flow.start.indexOf(ev.type)&&r.reset){r.reset()}}}for(let i=0,r;i<recognizers.length;i++){r=recognizers[i];if(gs[r.name]&&!handled[r.name]){handled[r.name]=!0;r[type](ev)}}}function _handleTouchAction(ev){let t=ev.changedTouches[0],type=ev.type;if('touchstart'===type){POINTERSTATE.touch.x=t.clientX;POINTERSTATE.touch.y=t.clientY;POINTERSTATE.touch.scrollDecided=!1}else if('touchmove'===type){if(POINTERSTATE.touch.scrollDecided){return}POINTERSTATE.touch.scrollDecided=!0;let ta=firstTouchAction(ev),shouldPrevent=!1,dx=_Mathabs(POINTERSTATE.touch.x-t.clientX),dy=_Mathabs(POINTERSTATE.touch.y-t.clientY);if(!ev.cancelable){}else if('none'===ta){shouldPrevent=!0}else if('pan-x'===ta){shouldPrevent=dy>dx}else if('pan-y'===ta){shouldPrevent=dx>dy}if(shouldPrevent){ev.preventDefault()}else{prevent('track')}}}function addListener(node,evType,handler){if(gestures[evType]){_add(node,evType,handler);return!0}return!1}function removeListener(node,evType,handler){if(gestures[evType]){_remove(node,evType,handler);return!0}return!1}function _add(node,evType,handler){let recognizer=gestures[evType],deps=recognizer.deps,name=recognizer.name,gobj=node[GESTURE_KEY];if(!gobj){node[GESTURE_KEY]=gobj={}}for(let i=0,dep,gd;i<deps.length;i++){dep=deps[i];if(IS_TOUCH_ONLY&&isMouseEvent(dep)&&'click'!==dep){continue}gd=gobj[dep];if(!gd){gobj[dep]=gd={_count:0}}if(0===gd._count){node.addEventListener(dep,_handleNative,PASSIVE_TOUCH(dep))}gd[name]=(gd[name]||0)+1;gd._count=(gd._count||0)+1}node.addEventListener(evType,handler);if(recognizer.touchAction){setTouchAction(node,recognizer.touchAction)}}function _remove(node,evType,handler){let recognizer=gestures[evType],deps=recognizer.deps,name=recognizer.name,gobj=node[GESTURE_KEY];if(gobj){for(let i=0,dep,gd;i<deps.length;i++){dep=deps[i];gd=gobj[dep];if(gd&&gd[name]){gd[name]=(gd[name]||1)-1;gd._count=(gd._count||1)-1;if(0===gd._count){node.removeEventListener(dep,_handleNative,PASSIVE_TOUCH(dep))}}}}node.removeEventListener(evType,handler)}function register(recog){recognizers.push(recog);for(let i=0;i<recog.emits.length;i++){gestures[recog.emits[i]]=recog}}function _findRecognizerByEvent(evName){for(let i=0,r;i<recognizers.length;i++){r=recognizers[i];for(let j=0,n;j<r.emits.length;j++){n=r.emits[j];if(n===evName){return r}}}return null}function setTouchAction(node,value){if(HAS_NATIVE_TA&&node instanceof HTMLElement){_async_js__WEBPACK_IMPORTED_MODULE_1__.c.run(()=>{node.style.touchAction=value})}node[TOUCH_ACTION]=value}function _fire(target,type,detail){let ev=new Event(type,{bubbles:!0,cancelable:!0,composed:!0});ev.detail=detail;target.dispatchEvent(ev);if(ev.defaultPrevented){let preventer=detail.preventer||detail.sourceEvent;if(preventer&&preventer.preventDefault){preventer.preventDefault()}}}function prevent(evName){let recognizer=_findRecognizerByEvent(evName);if(recognizer.info){recognizer.info.prevent=!0}}register({name:'downup',deps:['mousedown','touchstart','touchend'],flow:{start:['mousedown','touchstart'],end:['mouseup','touchend']},emits:['down','up'],info:{movefn:null,upfn:null},reset:function(){untrackDocument(this.info)},mousedown:function(e){if(!hasLeftMouseButton(e)){return}let t=_findOriginalTarget(e),self=this;trackDocument(this.info,function(e){if(!hasLeftMouseButton(e)){downupFire('up',t,e);untrackDocument(self.info)}},function(e){if(hasLeftMouseButton(e)){downupFire('up',t,e)}untrackDocument(self.info)});downupFire('down',t,e)},touchstart:function(e){downupFire('down',_findOriginalTarget(e),e.changedTouches[0],e)},touchend:function(e){downupFire('up',_findOriginalTarget(e),e.changedTouches[0],e)}});function downupFire(type,target,event,preventer){if(!target){return}_fire(target,type,{x:event.clientX,y:event.clientY,sourceEvent:event,preventer:preventer,prevent:function(e){return prevent(e)}})}register({name:'track',touchAction:'none',deps:['mousedown','touchstart','touchmove','touchend'],flow:{start:['mousedown','touchstart'],end:['mouseup','touchend']},emits:['track'],info:{x:0,y:0,state:'start',started:!1,moves:[],addMove:function(move){if(this.moves.length>2){this.moves.shift()}this.moves.push(move)},movefn:null,upfn:null,prevent:!1},reset:function(){this.info.state='start';this.info.started=!1;this.info.moves=[];this.info.x=0;this.info.y=0;this.info.prevent=!1;untrackDocument(this.info)},mousedown:function(e){if(!hasLeftMouseButton(e)){return}let t=_findOriginalTarget(e),self=this,movefn=function(e){let x=e.clientX,y=e.clientY;if(trackHasMovedEnough(self.info,x,y)){self.info.state=self.info.started?'mouseup'===e.type?'end':'track':'start';if('start'===self.info.state){prevent('tap')}self.info.addMove({x:x,y:y});if(!hasLeftMouseButton(e)){self.info.state='end';untrackDocument(self.info)}if(t){trackFire(self.info,t,e)}self.info.started=!0}};trackDocument(this.info,movefn,function(e){if(self.info.started){movefn(e)}untrackDocument(self.info)});this.info.x=e.clientX;this.info.y=e.clientY},touchstart:function(e){let ct=e.changedTouches[0];this.info.x=ct.clientX;this.info.y=ct.clientY},touchmove:function(e){let t=_findOriginalTarget(e),ct=e.changedTouches[0],x=ct.clientX,y=ct.clientY;if(trackHasMovedEnough(this.info,x,y)){if('start'===this.info.state){prevent('tap')}this.info.addMove({x:x,y:y});trackFire(this.info,t,ct);this.info.state='track';this.info.started=!0}},touchend:function(e){let t=_findOriginalTarget(e),ct=e.changedTouches[0];if(this.info.started){this.info.state='end';this.info.addMove({x:ct.clientX,y:ct.clientY});trackFire(this.info,t,ct)}}});function trackHasMovedEnough(info,x,y){if(info.prevent){return!1}if(info.started){return!0}let dx=_Mathabs(info.x-x),dy=_Mathabs(info.y-y);return dx>=TRACK_DISTANCE||dy>=TRACK_DISTANCE}function trackFire(info,target,touch){if(!target){return}let secondlast=info.moves[info.moves.length-2],lastmove=info.moves[info.moves.length-1],dx=lastmove.x-info.x,dy=lastmove.y-info.y,ddx,ddy=0;if(secondlast){ddx=lastmove.x-secondlast.x;ddy=lastmove.y-secondlast.y}_fire(target,'track',{state:info.state,x:touch.clientX,y:touch.clientY,dx:dx,dy:dy,ddx:ddx,ddy:ddy,sourceEvent:touch,hover:function(){return deepTargetFind(touch.clientX,touch.clientY)}})}register({name:'tap',deps:['mousedown','click','touchstart','touchend'],flow:{start:['mousedown','touchstart'],end:['click','touchend']},emits:['tap'],info:{x:NaN,y:NaN,prevent:!1},reset:function(){this.info.x=NaN;this.info.y=NaN;this.info.prevent=!1},mousedown:function(e){if(hasLeftMouseButton(e)){this.info.x=e.clientX;this.info.y=e.clientY}},click:function(e){if(hasLeftMouseButton(e)){trackForward(this.info,e)}},touchstart:function(e){const touch=e.changedTouches[0];this.info.x=touch.clientX;this.info.y=touch.clientY},touchend:function(e){trackForward(this.info,e.changedTouches[0],e)}});function trackForward(info,e,preventer){let dx=_Mathabs(e.clientX-info.x),dy=_Mathabs(e.clientY-info.y),t=_findOriginalTarget(preventer||e);if(!t||canBeDisabled[t.localName]&&t.hasAttribute('disabled')){return}if(isNaN(dx)||isNaN(dy)||dx<=TAP_DISTANCE&&dy<=TAP_DISTANCE||isSyntheticClick(e)){if(!info.prevent){_fire(t,'tap',{x:e.clientX,y:e.clientY,sourceEvent:e,preventer:preventer})}}}const findOriginalTarget=_findOriginalTarget,add=addListener},function(module,__webpack_exports__,__webpack_require__){'use strict';var boot=__webpack_require__(6),settings=__webpack_require__(7),mixin=__webpack_require__(5),style_gather=__webpack_require__(35),resolve_url=__webpack_require__(11),dom_module=__webpack_require__(30),property_effects=__webpack_require__(27),properties_changed=__webpack_require__(45);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/function normalizeProperties(props){const output={};for(let p in props){const o=props[p];output[p]='function'===typeof o?{type:o}:o}return output}const properties_mixin_PropertiesMixin=Object(mixin.a)(superClass=>{const base=Object(properties_changed.a)(superClass);function superPropertiesClass(constructor){const superCtor=Object.getPrototypeOf(constructor);return superCtor.prototype instanceof PropertiesMixin?superCtor:null}function ownProperties(constructor){if(!constructor.hasOwnProperty(JSCompiler_renameProperty('__ownProperties',constructor))){let props=null;if(constructor.hasOwnProperty(JSCompiler_renameProperty('properties',constructor))){const properties=constructor.properties;if(properties){props=normalizeProperties(properties)}}constructor.__ownProperties=props}return constructor.__ownProperties}class PropertiesMixin extends base{static get observedAttributes(){const props=this._properties;return props?Object.keys(props).map(p=>this.attributeNameForProperty(p)):[]}static finalize(){if(!this.hasOwnProperty(JSCompiler_renameProperty('__finalized',this))){const superCtor=superPropertiesClass(this);if(superCtor){superCtor.finalize()}this.__finalized=!0;this._finalizeClass()}}static _finalizeClass(){const props=ownProperties(this);if(props){this.createProperties(props)}}static get _properties(){if(!this.hasOwnProperty(JSCompiler_renameProperty('__properties',this))){const superCtor=superPropertiesClass(this);this.__properties=Object.assign({},superCtor&&superCtor._properties,ownProperties(this))}return this.__properties}static typeForProperty(name){const info=this._properties[name];return info&&info.type}_initializeProperties(){this.constructor.finalize();super._initializeProperties()}connectedCallback(){if(super.connectedCallback){super.connectedCallback()}this._enableProperties()}disconnectedCallback(){if(super.disconnectedCallback){super.disconnectedCallback()}}}return PropertiesMixin});__webpack_require__.d(__webpack_exports__,'a',function(){return ElementMixin});/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const ElementMixin=Object(mixin.a)(base=>{const polymerElementBase=properties_mixin_PropertiesMixin(Object(property_effects.a)(base));function propertyDefaults(constructor){if(!constructor.hasOwnProperty(JSCompiler_renameProperty('__propertyDefaults',constructor))){constructor.__propertyDefaults=null;let props=constructor._properties;for(let p in props){let info=props[p];if('value'in info){constructor.__propertyDefaults=constructor.__propertyDefaults||{};constructor.__propertyDefaults[p]=info}}}return constructor.__propertyDefaults}function ownObservers(constructor){if(!constructor.hasOwnProperty(JSCompiler_renameProperty('__ownObservers',constructor))){constructor.__ownObservers=constructor.hasOwnProperty(JSCompiler_renameProperty('observers',constructor))?constructor.observers:null}return constructor.__ownObservers}function createPropertyFromConfig(proto,name,info,allProps){if(info.computed){info.readOnly=!0}if(info.computed&&!proto._hasReadOnlyEffect(name)){proto._createComputedProperty(name,info.computed,allProps)}if(info.readOnly&&!proto._hasReadOnlyEffect(name)){proto._createReadOnlyProperty(name,!info.computed)}if(info.reflectToAttribute&&!proto._hasReflectEffect(name)){proto._createReflectedProperty(name)}if(info.notify&&!proto._hasNotifyEffect(name)){proto._createNotifyingProperty(name)}if(info.observer){proto._createPropertyObserver(name,info.observer,allProps[info.observer])}proto._addPropertyToAttributeMap(name)}function processElementStyles(klass,template,is,baseURI){const templateStyles=template.content.querySelectorAll('style'),stylesWithImports=Object(style_gather.c)(template),linkedStyles=Object(style_gather.b)(is),firstTemplateChild=template.content.firstElementChild;for(let idx=0,s;idx<linkedStyles.length;idx++){s=linkedStyles[idx];s.textContent=klass._processStyleText(s.textContent,baseURI);template.content.insertBefore(s,firstTemplateChild)}let templateStyleIndex=0;for(let i=0;i<stylesWithImports.length;i++){let s=stylesWithImports[i],templateStyle=templateStyles[templateStyleIndex];if(templateStyle!==s){s=s.cloneNode(!0);templateStyle.parentNode.insertBefore(s,templateStyle)}else{templateStyleIndex++}s.textContent=klass._processStyleText(s.textContent,baseURI)}if(window.ShadyCSS){window.ShadyCSS.prepareTemplate(template,is)}}function getTemplateFromDomModule(is){let template=null;if(is&&(!settings.f||settings.a)){template=dom_module.a.import(is,'template');if(settings.f&&!template){throw new Error(`strictTemplatePolicy: expecting dom-module or null template for ${is}`)}}return template}class PolymerElement extends polymerElementBase{static get polymerElementVersion(){return'3.0.5'}static _finalizeClass(){super._finalizeClass();if(this.hasOwnProperty(JSCompiler_renameProperty('is',this))&&this.is){register(this.prototype)}const observers=ownObservers(this);if(observers){this.createObservers(observers,this._properties)}let template=this.template;if(template){if('string'===typeof template){console.error('template getter must return HTMLTemplateElement');template=null}else{template=template.cloneNode(!0)}}this.prototype._template=template}static createProperties(props){for(let p in props){createPropertyFromConfig(this.prototype,p,props[p],props)}}static createObservers(observers,dynamicFns){const proto=this.prototype;for(let i=0;i<observers.length;i++){proto._createMethodObserver(observers[i],dynamicFns)}}static get template(){if(!this.hasOwnProperty(JSCompiler_renameProperty('_template',this))){this._template=this.prototype.hasOwnProperty(JSCompiler_renameProperty('_template',this.prototype))?this.prototype._template:getTemplateFromDomModule(this.is)||Object.getPrototypeOf(this.prototype).constructor.template}return this._template}static set template(value){this._template=value}static get importPath(){if(!this.hasOwnProperty(JSCompiler_renameProperty('_importPath',this))){const meta=this.importMeta;if(meta){this._importPath=Object(resolve_url.a)(meta.url)}else{const module=dom_module.a.import(this.is);this._importPath=module&&module.assetpath||Object.getPrototypeOf(this.prototype).constructor.importPath}}return this._importPath}constructor(){super();this._template;this._importPath;this.rootPath;this.importPath;this.root;this.$}_initializeProperties(){instanceCount++;this.constructor.finalize();this.constructor._finalizeTemplate(this.localName);super._initializeProperties();this.rootPath=settings.c;this.importPath=this.constructor.importPath;let p$=propertyDefaults(this.constructor);if(!p$){return}for(let p in p$){let info=p$[p];if(!this.hasOwnProperty(p)){let value='function'==typeof info.value?info.value.call(this):info.value;if(this._hasAccessor(p)){this._setPendingProperty(p,value,!0)}else{this[p]=value}}}}static _processStyleText(cssText,baseURI){return Object(resolve_url.b)(cssText,baseURI)}static _finalizeTemplate(is){const template=this.prototype._template;if(template&&!template.__polymerFinalized){template.__polymerFinalized=!0;const importPath=this.importPath,baseURI=importPath?Object(resolve_url.c)(importPath):'';processElementStyles(this,template,is,baseURI);this.prototype._bindTemplate(template)}}connectedCallback(){if(window.ShadyCSS&&this._template){window.ShadyCSS.styleElement(this)}super.connectedCallback()}ready(){if(this._template){this.root=this._stampTemplate(this._template);this.$=this.root.$}super.ready()}_readyClients(){if(this._template){this.root=this._attachDom(this.root)}super._readyClients()}_attachDom(dom){if(this.attachShadow){if(dom){if(!this.shadowRoot){this.attachShadow({mode:'open'})}this.shadowRoot.appendChild(dom);return this.shadowRoot}return null}else{throw new Error('ShadowDOM not available. '+'PolymerElement can create dom as children instead of in '+'ShadowDOM by setting `this.root = this;` before `ready`.')}}updateStyles(properties){if(window.ShadyCSS){window.ShadyCSS.styleSubtree(this,properties)}}resolveUrl(url,base){if(!base&&this.importPath){base=Object(resolve_url.c)(this.importPath)}return Object(resolve_url.c)(url,base)}static _parseTemplateContent(template,templateInfo,nodeInfo){templateInfo.dynamicFns=templateInfo.dynamicFns||this._properties;return super._parseTemplateContent(template,templateInfo,nodeInfo)}}return PolymerElement});let instanceCount=0;const registrations=[];function register(prototype){registrations.push(prototype)}},function(module,__webpack_exports__,__webpack_require__){'use strict';var boot=__webpack_require__(6),mixin=__webpack_require__(5),utils_path=__webpack_require__(2),case_map=__webpack_require__(15),property_accessors=__webpack_require__(44);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const templateExtensions={"dom-if":!0,"dom-repeat":!0};function wrapTemplateExtension(node){let is=node.getAttribute('is');if(is&&templateExtensions[is]){let t=node;t.removeAttribute('is');node=t.ownerDocument.createElement(is);t.parentNode.replaceChild(node,t);node.appendChild(t);while(t.attributes.length){node.setAttribute(t.attributes[0].name,t.attributes[0].value);t.removeAttribute(t.attributes[0].name)}}return node}function findTemplateNode(root,nodeInfo){let parent=nodeInfo.parentInfo&&findTemplateNode(root,nodeInfo.parentInfo);if(parent){for(let n=parent.firstChild,i=0;n;n=n.nextSibling){if(nodeInfo.parentIndex===i++){return n}}}else{return root}}function applyIdToMap(inst,map,node,nodeInfo){if(nodeInfo.id){map[nodeInfo.id]=node}}function applyEventListener(inst,node,nodeInfo){if(nodeInfo.events&&nodeInfo.events.length){for(let j=0,e$=nodeInfo.events,e;j<e$.length&&(e=e$[j]);j++){inst._addMethodEventListenerToNode(node,e.name,e.value,inst)}}}function applyTemplateContent(inst,node,nodeInfo){if(nodeInfo.templateInfo){node._templateInfo=nodeInfo.templateInfo}}function createNodeEventHandler(context,eventName,methodName){context=context._methodHost||context;let handler=function(e){if(context[methodName]){context[methodName](e,e.detail)}else{console.warn('listener method `'+methodName+'` not defined')}};return handler}const TemplateStamp=Object(mixin.a)(superClass=>{return class extends superClass{static _parseTemplate(template,outerTemplateInfo){if(!template._templateInfo){let templateInfo=template._templateInfo={};templateInfo.nodeInfoList=[];templateInfo.stripWhiteSpace=outerTemplateInfo&&outerTemplateInfo.stripWhiteSpace||template.hasAttribute('strip-whitespace');this._parseTemplateContent(template,templateInfo,{parent:null})}return template._templateInfo}static _parseTemplateContent(template,templateInfo,nodeInfo){return this._parseTemplateNode(template.content,templateInfo,nodeInfo)}static _parseTemplateNode(node,templateInfo,nodeInfo){let noted,element=node;if('template'==element.localName&&!element.hasAttribute('preserve-content')){noted=this._parseTemplateNestedTemplate(element,templateInfo,nodeInfo)||noted}else if('slot'===element.localName){templateInfo.hasInsertionPoint=!0}if(element.firstChild){noted=this._parseTemplateChildNodes(element,templateInfo,nodeInfo)||noted}if(element.hasAttributes&&element.hasAttributes()){noted=this._parseTemplateNodeAttributes(element,templateInfo,nodeInfo)||noted}return noted}static _parseTemplateChildNodes(root,templateInfo,nodeInfo){if('script'===root.localName||'style'===root.localName){return}for(let node=root.firstChild,parentIndex=0,next;node;node=next){if('template'==node.localName){node=wrapTemplateExtension(node)}next=node.nextSibling;if(node.nodeType===Node.TEXT_NODE){let n=next;while(n&&n.nodeType===Node.TEXT_NODE){node.textContent+=n.textContent;next=n.nextSibling;root.removeChild(n);n=next}if(templateInfo.stripWhiteSpace&&!node.textContent.trim()){root.removeChild(node);continue}}let childInfo={parentIndex,parentInfo:nodeInfo};if(this._parseTemplateNode(node,templateInfo,childInfo)){childInfo.infoIndex=templateInfo.nodeInfoList.push(childInfo)-1}if(node.parentNode){parentIndex++}}}static _parseTemplateNestedTemplate(node,outerTemplateInfo,nodeInfo){let templateInfo=this._parseTemplate(node,outerTemplateInfo),content=templateInfo.content=node.content.ownerDocument.createDocumentFragment();content.appendChild(node.content);nodeInfo.templateInfo=templateInfo;return!0}static _parseTemplateNodeAttributes(node,templateInfo,nodeInfo){let noted=!1,attrs=Array.from(node.attributes);for(let i=attrs.length-1,a;a=attrs[i];i--){noted=this._parseTemplateNodeAttribute(node,templateInfo,nodeInfo,a.name,a.value)||noted}return noted}static _parseTemplateNodeAttribute(node,templateInfo,nodeInfo,name,value){if('on-'===name.slice(0,3)){node.removeAttribute(name);nodeInfo.events=nodeInfo.events||[];nodeInfo.events.push({name:name.slice(3),value});return!0}else if('id'===name){nodeInfo.id=value;return!0}return!1}static _contentForTemplate(template){let templateInfo=template._templateInfo;return templateInfo&&templateInfo.content||template.content}_stampTemplate(template){if(template&&!template.content&&window.HTMLTemplateElement&&HTMLTemplateElement.decorate){HTMLTemplateElement.decorate(template)}let templateInfo=this.constructor._parseTemplate(template),nodeInfo=templateInfo.nodeInfoList,content=templateInfo.content||template.content,dom=document.importNode(content,!0);dom.__noInsertionPoint=!templateInfo.hasInsertionPoint;let nodes=dom.nodeList=Array(nodeInfo.length);dom.$={};for(let i=0,l=nodeInfo.length,info,node;i<l&&(info=nodeInfo[i]);i++){node=nodes[i]=findTemplateNode(dom,info);applyIdToMap(this,dom.$,node,info);applyTemplateContent(this,node,info);applyEventListener(this,node,info)}dom=dom;return dom}_addMethodEventListenerToNode(node,eventName,methodName,context){context=context||node;let handler=createNodeEventHandler(context,eventName,methodName);this._addEventListenerToNode(node,eventName,handler);return handler}_addEventListenerToNode(node,eventName,handler){node.addEventListener(eventName,handler)}_removeEventListenerFromNode(node,eventName,handler){node.removeEventListener(eventName,handler)}}});var settings=__webpack_require__(7);__webpack_require__.d(__webpack_exports__,'a',function(){return property_effects_PropertyEffects});/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let property_effects_dedupeId=0;const TYPES={COMPUTE:'__computeEffects',REFLECT:'__reflectEffects',NOTIFY:'__notifyEffects',PROPAGATE:'__propagateEffects',OBSERVE:'__observeEffects',READ_ONLY:'__readOnly'},capitalAttributeRegex=/[A-Z]/;function ensureOwnEffectMap(model,type){let effects=model[type];if(!effects){effects=model[type]={}}else if(!model.hasOwnProperty(type)){effects=model[type]=Object.create(model[type]);for(let p in effects){let protoFx=effects[p],instFx=effects[p]=Array(protoFx.length);for(let i=0;i<protoFx.length;i++){instFx[i]=protoFx[i]}}}return effects}function runEffects(inst,effects,props,oldProps,hasPaths,extraArgs){if(effects){let ran=!1,id=property_effects_dedupeId++;for(let prop in props){if(runEffectsForProperty(inst,effects,id,prop,props,oldProps,hasPaths,extraArgs)){ran=!0}}return ran}return!1}function runEffectsForProperty(inst,effects,dedupeId,prop,props,oldProps,hasPaths,extraArgs){let ran=!1,rootProperty=hasPaths?Object(utils_path.g)(prop):prop,fxs=effects[rootProperty];if(fxs){for(let i=0,l=fxs.length,fx;i<l&&(fx=fxs[i]);i++){if((!fx.info||fx.info.lastRun!==dedupeId)&&(!hasPaths||pathMatchesTrigger(prop,fx.trigger))){if(fx.info){fx.info.lastRun=dedupeId}fx.fn(inst,prop,props,oldProps,fx.info,hasPaths,extraArgs);ran=!0}}}return ran}function pathMatchesTrigger(path,trigger){if(trigger){let triggerPath=trigger.name;return triggerPath==path||trigger.structured&&Object(utils_path.b)(triggerPath,path)||trigger.wildcard&&Object(utils_path.c)(triggerPath,path)}else{return!0}}function runObserverEffect(inst,property,props,oldProps,info){let fn='string'===typeof info.method?inst[info.method]:info.method,changedProp=info.property;if(fn){fn.call(inst,inst.__data[changedProp],oldProps[changedProp])}else if(!info.dynamicFn){console.warn('observer method `'+info.method+'` not defined')}}function runNotifyEffects(inst,notifyProps,props,oldProps,hasPaths){let fxs=inst[TYPES.NOTIFY],notified,id=property_effects_dedupeId++;for(let prop in notifyProps){if(notifyProps[prop]){if(fxs&&runEffectsForProperty(inst,fxs,id,prop,props,oldProps,hasPaths)){notified=!0}else if(hasPaths&&notifyPath(inst,prop,props)){notified=!0}}}let host;if(notified&&(host=inst.__dataHost)&&host._invalidateProperties){host._invalidateProperties()}}function notifyPath(inst,path,props){let rootProperty=Object(utils_path.g)(path);if(rootProperty!==path){let eventName=Object(case_map.a)(rootProperty)+'-changed';dispatchNotifyEvent(inst,eventName,props[path],path);return!0}return!1}function dispatchNotifyEvent(inst,eventName,value,path){let detail={value:value,queueProperty:!0};if(path){detail.path=path}inst.dispatchEvent(new CustomEvent(eventName,{detail}))}function runNotifyEffect(inst,property,props,oldProps,info,hasPaths){let rootProperty=hasPaths?Object(utils_path.g)(property):property,path=rootProperty!=property?property:null,value=path?Object(utils_path.a)(inst,path):inst.__data[property];if(path&&value===void 0){value=props[property]}dispatchNotifyEvent(inst,info.eventName,value,path)}function handleNotification(event,inst,fromProp,toPath,negate){let value,detail=event.detail,fromPath=detail&&detail.path;if(fromPath){toPath=Object(utils_path.i)(fromProp,toPath,fromPath);value=detail&&detail.value}else{value=event.currentTarget[fromProp]}value=negate?!value:value;if(!inst[TYPES.READ_ONLY]||!inst[TYPES.READ_ONLY][toPath]){if(inst._setPendingPropertyOrPath(toPath,value,!0,!!fromPath)&&(!detail||!detail.queueProperty)){inst._invalidateProperties()}}}function runReflectEffect(inst,property,props,oldProps,info){let value=inst.__data[property];if(settings.d){value=Object(settings.d)(value,info.attrName,'attribute',inst)}inst._propertyToAttribute(property,info.attrName,value)}function runComputedEffects(inst,changedProps,oldProps,hasPaths){let computeEffects=inst[TYPES.COMPUTE];if(computeEffects){let inputProps=changedProps;while(runEffects(inst,computeEffects,inputProps,oldProps,hasPaths)){Object.assign(oldProps,inst.__dataOld);Object.assign(changedProps,inst.__dataPending);inputProps=inst.__dataPending;inst.__dataPending=null}}}function runComputedEffect(inst,property,props,oldProps,info){let result=runMethodEffect(inst,property,props,oldProps,info),computedProp=info.methodInfo;if(inst.__dataHasAccessor&&inst.__dataHasAccessor[computedProp]){inst._setPendingProperty(computedProp,result,!0)}else{inst[computedProp]=result}}function computeLinkedPaths(inst,path,value){let links=inst.__dataLinkedPaths;if(links){let link;for(let a in links){let b=links[a];if(Object(utils_path.c)(a,path)){link=Object(utils_path.i)(a,b,path);inst._setPendingPropertyOrPath(link,value,!0,!0)}else if(Object(utils_path.c)(b,path)){link=Object(utils_path.i)(b,a,path);inst._setPendingPropertyOrPath(link,value,!0,!0)}}}}function addBinding(constructor,templateInfo,nodeInfo,kind,target,parts,literal){nodeInfo.bindings=nodeInfo.bindings||[];let binding={kind,target,parts,literal,isCompound:1!==parts.length};nodeInfo.bindings.push(binding);if(shouldAddListener(binding)){let{event,negate}=binding.parts[0];binding.listenerEvent=event||Object(case_map.a)(target)+'-changed';binding.listenerNegate=negate}let index=templateInfo.nodeInfoList.length;for(let i=0,part;i<binding.parts.length;i++){part=binding.parts[i];part.compoundIndex=i;addEffectForBindingPart(constructor,templateInfo,binding,part,index)}}function addEffectForBindingPart(constructor,templateInfo,binding,part,index){if(!part.literal){if('attribute'===binding.kind&&'-'===binding.target[0]){console.warn('Cannot set attribute '+binding.target+' because "-" is not a valid attribute starting character')}else{let dependencies=part.dependencies,info={index,binding,part,evaluator:constructor};for(let j=0,trigger;j<dependencies.length;j++){trigger=dependencies[j];if('string'==typeof trigger){trigger=parseArg(trigger);trigger.wildcard=!0}constructor._addTemplatePropertyEffect(templateInfo,trigger.rootProperty,{fn:runBindingEffect,info,trigger})}}}}function runBindingEffect(inst,path,props,oldProps,info,hasPaths,nodeList){let node=nodeList[info.index],binding=info.binding,part=info.part;if(hasPaths&&part.source&&path.length>part.source.length&&'property'==binding.kind&&!binding.isCompound&&node.__isPropertyEffectsClient&&node.__dataHasAccessor&&node.__dataHasAccessor[binding.target]){let value=props[path];path=Object(utils_path.i)(part.source,binding.target,path);if(node._setPendingPropertyOrPath(path,value,!1,!0)){inst._enqueueClient(node)}}else{let value=info.evaluator._evaluateBinding(inst,part,path,props,oldProps,hasPaths);applyBindingValue(inst,node,binding,part,value)}}function applyBindingValue(inst,node,binding,part,value){value=computeBindingValue(node,value,binding,part);if(settings.d){value=Object(settings.d)(value,binding.target,binding.kind,node)}if('attribute'==binding.kind){inst._valueToNodeAttribute(node,value,binding.target)}else{let prop=binding.target;if(node.__isPropertyEffectsClient&&node.__dataHasAccessor&&node.__dataHasAccessor[prop]){if(!node[TYPES.READ_ONLY]||!node[TYPES.READ_ONLY][prop]){if(node._setPendingProperty(prop,value)){inst._enqueueClient(node)}}}else{inst._setUnmanagedPropertyToNode(node,prop,value)}}}function computeBindingValue(node,value,binding,part){if(binding.isCompound){let storage=node.__dataCompoundStorage[binding.target];storage[part.compoundIndex]=value;value=storage.join('')}if('attribute'!==binding.kind){if('textContent'===binding.target||'value'===binding.target&&('input'===node.localName||'textarea'===node.localName)){value=value==void 0?'':value}}return value}function shouldAddListener(binding){return!!binding.target&&'attribute'!=binding.kind&&'text'!=binding.kind&&!binding.isCompound&&'{'===binding.parts[0].mode}function setupBindings(inst,templateInfo){let{nodeList,nodeInfoList}=templateInfo;if(nodeInfoList.length){for(let i=0;i<nodeInfoList.length;i++){let info=nodeInfoList[i],node=nodeList[i],bindings=info.bindings;if(bindings){for(let i=0,binding;i<bindings.length;i++){binding=bindings[i];setupCompoundStorage(node,binding);addNotifyListener(node,inst,binding)}}node.__dataHost=inst}}}function setupCompoundStorage(node,binding){if(binding.isCompound){let storage=node.__dataCompoundStorage||(node.__dataCompoundStorage={}),parts=binding.parts,literals=Array(parts.length);for(let j=0;j<parts.length;j++){literals[j]=parts[j].literal}let target=binding.target;storage[target]=literals;if(binding.literal&&'property'==binding.kind){node[target]=binding.literal}}}function addNotifyListener(node,inst,binding){if(binding.listenerEvent){let part=binding.parts[0];node.addEventListener(binding.listenerEvent,function(e){handleNotification(e,inst,binding.target,part.source,part.negate)})}}function createMethodEffect(model,sig,type,effectFn,methodInfo,dynamicFn){dynamicFn=sig.static||dynamicFn&&('object'!==typeof dynamicFn||dynamicFn[sig.methodName]);let info={methodName:sig.methodName,args:sig.args,methodInfo,dynamicFn};for(let i=0,arg;i<sig.args.length&&(arg=sig.args[i]);i++){if(!arg.literal){model._addPropertyEffect(arg.rootProperty,type,{fn:effectFn,info:info,trigger:arg})}}if(dynamicFn){model._addPropertyEffect(sig.methodName,type,{fn:effectFn,info:info})}}function runMethodEffect(inst,property,props,oldProps,info){let context=inst._methodHost||inst,fn=context[info.methodName];if(fn){let args=inst._marshalArgs(info.args,property,props);return fn.apply(context,args)}else if(!info.dynamicFn){console.warn('method `'+info.methodName+'` not defined')}}const emptyArray=[],IDENT='(?:'+'[a-zA-Z_$][\\w.:$\\-*]*'+')',ARGUMENT='(?:('+IDENT+'|'+('(?:'+'[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?'+')')+'|'+('(?:'+('(?:'+'\'(?:[^\'\\\\]|\\\\.)*\''+')')+'|'+('(?:'+'"(?:[^"\\\\]|\\\\.)*"'+')')+')')+')\\s*'+')',bindingRegex=/(\[\[|{{)\s*(?:(!)\s*)?((?:[a-zA-Z_$][\w.:$\-*]*)\s*(?:\(\s*(?:(?:(?:((?:[a-zA-Z_$][\w.:$\-*]*)|(?:[-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?)|(?:(?:'(?:[^'\\]|\\.)*')|(?:"(?:[^"\\]|\\.)*")))\s*)(?:,\s*(?:((?:[a-zA-Z_$][\w.:$\-*]*)|(?:[-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?)|(?:(?:'(?:[^'\\]|\\.)*')|(?:"(?:[^"\\]|\\.)*")))\s*))*)?)\)\s*)?)(?:]]|}})/g;function literalFromParts(parts){let s='';for(let i=0,literal;i<parts.length;i++){literal=parts[i].literal;s+=literal||''}return s}function parseMethod(expression){let m=expression.match(/([^\s]+?)\(([\s\S]*)\)/);if(m){let methodName=m[1],sig={methodName,static:!0,args:emptyArray};if(m[2].trim()){let args=m[2].replace(/\\,/g,'&comma;').split(',');return parseArgs(args,sig)}else{return sig}}return null}function parseArgs(argList,sig){sig.args=argList.map(function(rawArg){let arg=parseArg(rawArg);if(!arg.literal){sig.static=!1}return arg},this);return sig}function parseArg(rawArg){let arg=rawArg.trim().replace(/&comma;/g,',').replace(/\\(.)/g,'$1'),a={name:arg,value:'',literal:!1},fc=arg[0];if('-'===fc){fc=arg[1]}if('0'<=fc&&'9'>=fc){fc='#'}switch(fc){case'\'':case'"':a.value=arg.slice(1,-1);a.literal=!0;break;case'#':a.value=+arg;a.literal=!0;break;}if(!a.literal){a.rootProperty=Object(utils_path.g)(arg);a.structured=Object(utils_path.d)(arg);if(a.structured){a.wildcard='.*'==arg.slice(-2);if(a.wildcard){a.name=arg.slice(0,-2)}}}return a}function notifySplices(inst,array,path,splices){let splicesPath=path+'.splices';inst.notifyPath(splicesPath,{indexSplices:splices});inst.notifyPath(path+'.length',array.length);inst.__data[splicesPath]={indexSplices:null}}function notifySplice(inst,array,path,index,addedCount,removed){notifySplices(inst,array,path,[{index:index,addedCount:addedCount,removed:removed,object:array,type:'splice'}])}function upper(name){return name[0].toUpperCase()+name.substring(1)}const property_effects_PropertyEffects=Object(mixin.a)(superClass=>{const propertyEffectsBase=TemplateStamp(Object(property_accessors.a)(superClass));class PropertyEffects extends propertyEffectsBase{constructor(){super();this.__isPropertyEffectsClient=!0;this.__dataCounter=0;this.__dataClientsReady;this.__dataPendingClients;this.__dataToNotify;this.__dataLinkedPaths;this.__dataHasPaths;this.__dataCompoundStorage;this.__dataHost;this.__dataTemp;this.__dataClientsInitialized;this.__data;this.__dataPending;this.__dataOld;this.__computeEffects;this.__reflectEffects;this.__notifyEffects;this.__propagateEffects;this.__observeEffects;this.__readOnly;this.__templateInfo}get PROPERTY_EFFECT_TYPES(){return TYPES}_initializeProperties(){super._initializeProperties();hostStack.registerHost(this);this.__dataClientsReady=!1;this.__dataPendingClients=null;this.__dataToNotify=null;this.__dataLinkedPaths=null;this.__dataHasPaths=!1;this.__dataCompoundStorage=this.__dataCompoundStorage||null;this.__dataHost=this.__dataHost||null;this.__dataTemp={};this.__dataClientsInitialized=!1}_initializeProtoProperties(props){this.__data=Object.create(props);this.__dataPending=Object.create(props);this.__dataOld={}}_initializeInstanceProperties(props){let readOnly=this[TYPES.READ_ONLY];for(let prop in props){if(!readOnly||!readOnly[prop]){this.__dataPending=this.__dataPending||{};this.__dataOld=this.__dataOld||{};this.__data[prop]=this.__dataPending[prop]=props[prop]}}}_addPropertyEffect(property,type,effect){this._createPropertyAccessor(property,type==TYPES.READ_ONLY);let effects=ensureOwnEffectMap(this,type)[property];if(!effects){effects=this[type][property]=[]}effects.push(effect)}_removePropertyEffect(property,type,effect){let effects=ensureOwnEffectMap(this,type)[property],idx=effects.indexOf(effect);if(0<=idx){effects.splice(idx,1)}}_hasPropertyEffect(property,type){let effects=this[type];return!!(effects&&effects[property])}_hasReadOnlyEffect(property){return this._hasPropertyEffect(property,TYPES.READ_ONLY)}_hasNotifyEffect(property){return this._hasPropertyEffect(property,TYPES.NOTIFY)}_hasReflectEffect(property){return this._hasPropertyEffect(property,TYPES.REFLECT)}_hasComputedEffect(property){return this._hasPropertyEffect(property,TYPES.COMPUTE)}_setPendingPropertyOrPath(path,value,shouldNotify,isPathNotification){if(isPathNotification||Object(utils_path.g)(Array.isArray(path)?path[0]:path)!==path){if(!isPathNotification){let old=Object(utils_path.a)(this,path);path=Object(utils_path.h)(this,path,value);if(!path||!super._shouldPropertyChange(path,value,old)){return!1}}this.__dataHasPaths=!0;if(this._setPendingProperty(path,value,shouldNotify)){computeLinkedPaths(this,path,value);return!0}}else{if(this.__dataHasAccessor&&this.__dataHasAccessor[path]){return this._setPendingProperty(path,value,shouldNotify)}else{this[path]=value}}return!1}_setUnmanagedPropertyToNode(node,prop,value){if(value!==node[prop]||'object'==typeof value){node[prop]=value}}_setPendingProperty(property,value,shouldNotify){let propIsPath=this.__dataHasPaths&&Object(utils_path.d)(property),prevProps=propIsPath?this.__dataTemp:this.__data;if(this._shouldPropertyChange(property,value,prevProps[property])){if(!this.__dataPending){this.__dataPending={};this.__dataOld={}}if(!(property in this.__dataOld)){this.__dataOld[property]=this.__data[property]}if(propIsPath){this.__dataTemp[property]=value}else{this.__data[property]=value}this.__dataPending[property]=value;if(propIsPath||this[TYPES.NOTIFY]&&this[TYPES.NOTIFY][property]){this.__dataToNotify=this.__dataToNotify||{};this.__dataToNotify[property]=shouldNotify}return!0}return!1}_setProperty(property,value){if(this._setPendingProperty(property,value,!0)){this._invalidateProperties()}}_invalidateProperties(){if(this.__dataReady){this._flushProperties()}}_enqueueClient(client){this.__dataPendingClients=this.__dataPendingClients||[];if(client!==this){this.__dataPendingClients.push(client)}}_flushProperties(){this.__dataCounter++;super._flushProperties();this.__dataCounter--}_flushClients(){if(!this.__dataClientsReady){this.__dataClientsReady=!0;this._readyClients();this.__dataReady=!0}else{this.__enableOrFlushClients()}}__enableOrFlushClients(){let clients=this.__dataPendingClients;if(clients){this.__dataPendingClients=null;for(let i=0,client;i<clients.length;i++){client=clients[i];if(!client.__dataEnabled){client._enableProperties()}else if(client.__dataPending){client._flushProperties()}}}}_readyClients(){this.__enableOrFlushClients()}setProperties(props,setReadOnly){for(let path in props){if(setReadOnly||!this[TYPES.READ_ONLY]||!this[TYPES.READ_ONLY][path]){this._setPendingPropertyOrPath(path,props[path],!0)}}this._invalidateProperties()}ready(){this._flushProperties();if(!this.__dataClientsReady){this._flushClients()}if(this.__dataPending){this._flushProperties()}}_propertiesChanged(currentProps,changedProps,oldProps){let hasPaths=this.__dataHasPaths;this.__dataHasPaths=!1;runComputedEffects(this,changedProps,oldProps,hasPaths);let notifyProps=this.__dataToNotify;this.__dataToNotify=null;this._propagatePropertyChanges(changedProps,oldProps,hasPaths);this._flushClients();runEffects(this,this[TYPES.REFLECT],changedProps,oldProps,hasPaths);runEffects(this,this[TYPES.OBSERVE],changedProps,oldProps,hasPaths);if(notifyProps){runNotifyEffects(this,notifyProps,changedProps,oldProps,hasPaths)}if(1==this.__dataCounter){this.__dataTemp={}}}_propagatePropertyChanges(changedProps,oldProps,hasPaths){if(this[TYPES.PROPAGATE]){runEffects(this,this[TYPES.PROPAGATE],changedProps,oldProps,hasPaths)}let templateInfo=this.__templateInfo;while(templateInfo){runEffects(this,templateInfo.propertyEffects,changedProps,oldProps,hasPaths,templateInfo.nodeList);templateInfo=templateInfo.nextTemplateInfo}}linkPaths(to,from){to=Object(utils_path.f)(to);from=Object(utils_path.f)(from);this.__dataLinkedPaths=this.__dataLinkedPaths||{};this.__dataLinkedPaths[to]=from}unlinkPaths(path){path=Object(utils_path.f)(path);if(this.__dataLinkedPaths){delete this.__dataLinkedPaths[path]}}notifySplices(path,splices){let info={path:''},array=Object(utils_path.a)(this,path,info);notifySplices(this,array,info.path,splices)}get(path,root){return Object(utils_path.a)(root||this,path)}set(path,value,root){if(root){Object(utils_path.h)(root,path,value)}else{if(!this[TYPES.READ_ONLY]||!this[TYPES.READ_ONLY][path]){if(this._setPendingPropertyOrPath(path,value,!0)){this._invalidateProperties()}}}}push(path,...items){let info={path:''},array=Object(utils_path.a)(this,path,info),len=array.length,ret=array.push(...items);if(items.length){notifySplice(this,array,info.path,len,items.length,[])}return ret}pop(path){let info={path:''},array=Object(utils_path.a)(this,path,info),hadLength=!!array.length,ret=array.pop();if(hadLength){notifySplice(this,array,info.path,array.length,0,[ret])}return ret}splice(path,start,deleteCount,...items){var _Mathfloor=Math.floor;let info={path:''},array=Object(utils_path.a)(this,path,info);if(0>start){start=array.length-_Mathfloor(-start)}else if(start){start=_Mathfloor(start)}let ret;if(2===arguments.length){ret=array.splice(start)}else{ret=array.splice(start,deleteCount,...items)}if(items.length||ret.length){notifySplice(this,array,info.path,start,items.length,ret)}return ret}shift(path){let info={path:''},array=Object(utils_path.a)(this,path,info),hadLength=!!array.length,ret=array.shift();if(hadLength){notifySplice(this,array,info.path,0,0,[ret])}return ret}unshift(path,...items){let info={path:''},array=Object(utils_path.a)(this,path,info),ret=array.unshift(...items);if(items.length){notifySplice(this,array,info.path,0,items.length,[])}return ret}notifyPath(path,value){let propPath;if(1==arguments.length){let info={path:''};value=Object(utils_path.a)(this,path,info);propPath=info.path}else if(Array.isArray(path)){propPath=Object(utils_path.f)(path)}else{propPath=path}if(this._setPendingPropertyOrPath(propPath,value,!0,!0)){this._invalidateProperties()}}_createReadOnlyProperty(property,protectedSetter){this._addPropertyEffect(property,TYPES.READ_ONLY);if(protectedSetter){this['_set'+upper(property)]=function(value){this._setProperty(property,value)}}}_createPropertyObserver(property,method,dynamicFn){let info={property,method,dynamicFn:!!dynamicFn};this._addPropertyEffect(property,TYPES.OBSERVE,{fn:runObserverEffect,info,trigger:{name:property}});if(dynamicFn){this._addPropertyEffect(method,TYPES.OBSERVE,{fn:runObserverEffect,info,trigger:{name:method}})}}_createMethodObserver(expression,dynamicFn){let sig=parseMethod(expression);if(!sig){throw new Error('Malformed observer expression \''+expression+'\'')}createMethodEffect(this,sig,TYPES.OBSERVE,runMethodEffect,null,dynamicFn)}_createNotifyingProperty(property){this._addPropertyEffect(property,TYPES.NOTIFY,{fn:runNotifyEffect,info:{eventName:Object(case_map.a)(property)+'-changed',property:property}})}_createReflectedProperty(property){let attr=this.constructor.attributeNameForProperty(property);if('-'===attr[0]){console.warn('Property '+property+' cannot be reflected to attribute '+attr+' because "-" is not a valid starting attribute name. Use a lowercase first letter for the property instead.')}else{this._addPropertyEffect(property,TYPES.REFLECT,{fn:runReflectEffect,info:{attrName:attr}})}}_createComputedProperty(property,expression,dynamicFn){let sig=parseMethod(expression);if(!sig){throw new Error('Malformed computed expression \''+expression+'\'')}createMethodEffect(this,sig,TYPES.COMPUTE,runComputedEffect,property,dynamicFn)}_marshalArgs(args,path,props){const data=this.__data;let values=[];for(let i=0,l=args.length;i<l;i++){let arg=args[i],name=arg.name,v;if(arg.literal){v=arg.value}else{if(arg.structured){v=Object(utils_path.a)(data,name);if(v===void 0){v=props[name]}}else{v=data[name]}}if(arg.wildcard){let baseChanged=0===name.indexOf(path+'.'),matches=0===path.indexOf(name)&&!baseChanged;values[i]={path:matches?path:name,value:matches?props[path]:v,base:v}}else{values[i]=v}}return values}static addPropertyEffect(property,type,effect){this.prototype._addPropertyEffect(property,type,effect)}static createPropertyObserver(property,method,dynamicFn){this.prototype._createPropertyObserver(property,method,dynamicFn)}static createMethodObserver(expression,dynamicFn){this.prototype._createMethodObserver(expression,dynamicFn)}static createNotifyingProperty(property){this.prototype._createNotifyingProperty(property)}static createReadOnlyProperty(property,protectedSetter){this.prototype._createReadOnlyProperty(property,protectedSetter)}static createReflectedProperty(property){this.prototype._createReflectedProperty(property)}static createComputedProperty(property,expression,dynamicFn){this.prototype._createComputedProperty(property,expression,dynamicFn)}static bindTemplate(template){return this.prototype._bindTemplate(template)}_bindTemplate(template,instanceBinding){let templateInfo=this.constructor._parseTemplate(template),wasPreBound=this.__templateInfo==templateInfo;if(!wasPreBound){for(let prop in templateInfo.propertyEffects){this._createPropertyAccessor(prop)}}if(instanceBinding){templateInfo=Object.create(templateInfo);templateInfo.wasPreBound=wasPreBound;if(!wasPreBound&&this.__templateInfo){let last=this.__templateInfoLast||this.__templateInfo;this.__templateInfoLast=last.nextTemplateInfo=templateInfo;templateInfo.previousTemplateInfo=last;return templateInfo}}return this.__templateInfo=templateInfo}static _addTemplatePropertyEffect(templateInfo,prop,effect){let hostProps=templateInfo.hostProps=templateInfo.hostProps||{};hostProps[prop]=!0;let effects=templateInfo.propertyEffects=templateInfo.propertyEffects||{},propEffects=effects[prop]=effects[prop]||[];propEffects.push(effect)}_stampTemplate(template){hostStack.beginHosting(this);let dom=super._stampTemplate(template);hostStack.endHosting(this);let templateInfo=this._bindTemplate(template,!0);templateInfo.nodeList=dom.nodeList;if(!templateInfo.wasPreBound){let nodes=templateInfo.childNodes=[];for(let n=dom.firstChild;n;n=n.nextSibling){nodes.push(n)}}dom.templateInfo=templateInfo;setupBindings(this,templateInfo);if(this.__dataReady){runEffects(this,templateInfo.propertyEffects,this.__data,null,!1,templateInfo.nodeList)}return dom}_removeBoundDom(dom){let templateInfo=dom.templateInfo;if(templateInfo.previousTemplateInfo){templateInfo.previousTemplateInfo.nextTemplateInfo=templateInfo.nextTemplateInfo}if(templateInfo.nextTemplateInfo){templateInfo.nextTemplateInfo.previousTemplateInfo=templateInfo.previousTemplateInfo}if(this.__templateInfoLast==templateInfo){this.__templateInfoLast=templateInfo.previousTemplateInfo}templateInfo.previousTemplateInfo=templateInfo.nextTemplateInfo=null;let nodes=templateInfo.childNodes;for(let i=0,node;i<nodes.length;i++){node=nodes[i];node.parentNode.removeChild(node)}}static _parseTemplateNode(node,templateInfo,nodeInfo){let noted=super._parseTemplateNode(node,templateInfo,nodeInfo);if(node.nodeType===Node.TEXT_NODE){let parts=this._parseBindings(node.textContent,templateInfo);if(parts){node.textContent=literalFromParts(parts)||' ';addBinding(this,templateInfo,nodeInfo,'text','textContent',parts);noted=!0}}return noted}static _parseTemplateNodeAttribute(node,templateInfo,nodeInfo,name,value){let parts=this._parseBindings(value,templateInfo);if(parts){let origName=name,kind='property';if(capitalAttributeRegex.test(name)){kind='attribute'}else if('$'==name[name.length-1]){name=name.slice(0,-1);kind='attribute'}let literal=literalFromParts(parts);if(literal&&'attribute'==kind){node.setAttribute(name,literal)}if('input'===node.localName&&'value'===origName){node.setAttribute(origName,'')}node.removeAttribute(origName);if('property'===kind){name=Object(case_map.b)(name)}addBinding(this,templateInfo,nodeInfo,kind,name,parts,literal);return!0}else{return super._parseTemplateNodeAttribute(node,templateInfo,nodeInfo,name,value)}}static _parseTemplateNestedTemplate(node,templateInfo,nodeInfo){let noted=super._parseTemplateNestedTemplate(node,templateInfo,nodeInfo),hostProps=nodeInfo.templateInfo.hostProps;for(let source in hostProps){addBinding(this,templateInfo,nodeInfo,'property','_host_'+source,[{mode:'{',source,dependencies:[source]}])}return noted}static _parseBindings(text,templateInfo){let parts=[],lastIndex=0,m;while(null!==(m=bindingRegex.exec(text))){if(m.index>lastIndex){parts.push({literal:text.slice(lastIndex,m.index)})}let mode=m[1][0],negate=!!m[2],source=m[3].trim(),customEvent=!1,notifyEvent='',colon=-1;if('{'==mode&&0<(colon=source.indexOf('::'))){notifyEvent=source.substring(colon+2);source=source.substring(0,colon);customEvent=!0}let signature=parseMethod(source),dependencies=[];if(signature){let{args,methodName}=signature;for(let i=0,arg;i<args.length;i++){arg=args[i];if(!arg.literal){dependencies.push(arg)}}let dynamicFns=templateInfo.dynamicFns;if(dynamicFns&&dynamicFns[methodName]||signature.static){dependencies.push(methodName);signature.dynamicFn=!0}}else{dependencies.push(source)}parts.push({source,mode,negate,customEvent,signature,dependencies,event:notifyEvent});lastIndex=bindingRegex.lastIndex}if(lastIndex&&lastIndex<text.length){let literal=text.substring(lastIndex);if(literal){parts.push({literal:literal})}}if(parts.length){return parts}else{return null}}static _evaluateBinding(inst,part,path,props,oldProps,hasPaths){let value;if(part.signature){value=runMethodEffect(inst,path,props,oldProps,part.signature)}else if(path!=part.source){value=Object(utils_path.a)(inst,part.source)}else{if(hasPaths&&Object(utils_path.d)(path)){value=Object(utils_path.a)(inst,path)}else{value=inst.__data[path]}}if(part.negate){value=!value}return value}}return PropertyEffects});const hostStack=new class{constructor(){this.stack=[]}registerHost(inst){if(this.stack.length){let host=this.stack[this.stack.length-1];host._enqueueClient(inst)}}beginHosting(inst){this.stack.push(inst)}endHosting(inst){let stackLen=this.stack.length;if(stackLen&&this.stack[stackLen-1]==inst){this.stack.pop()}}}},,,function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return DomModule});var _utils_boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(11),_utils_settings_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(7);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let modules={},lcModules={};function setModule(id,module){modules[id]=lcModules[id.toLowerCase()]=module}function findModule(id){return modules[id]||lcModules[id.toLowerCase()]}function styleOutsideTemplateCheck(inst){if(inst.querySelector('style')){console.warn('dom-module %s has style outside template',inst.id)}}class DomModule extends HTMLElement{static get observedAttributes(){return['id']}static import(id,selector){if(id){let m=findModule(id);if(m&&selector){return m.querySelector(selector)}return m}return null}attributeChangedCallback(name,old,value){if(old!==value){this.register()}}get assetpath(){if(!this.__assetpath){const owner=window.HTMLImports&&HTMLImports.importForElement?HTMLImports.importForElement(this)||document:this.ownerDocument,url=Object(_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_1__.c)(this.getAttribute('assetpath')||'',owner.baseURI);this.__assetpath=Object(_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_1__.a)(url)}return this.__assetpath}register(id){id=id||this.id;if(id){if(_utils_settings_js__WEBPACK_IMPORTED_MODULE_2__.f&&findModule(id)!==void 0){setModule(id,null);throw new Error(`strictTemplatePolicy: dom-module ${id} re-registered`)}this.id=id;setModule(id,this);styleOutsideTemplateCheck(this)}}}DomModule.prototype.modules=modules;customElements.define('dom-module',DomModule)},,,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_1__.a`
<custom-style>
  <style is="custom-style">
    [hidden] {
      display: none !important;
    }
  </style>
</custom-style>
<custom-style>
  <style is="custom-style">
    html {

      --layout: {
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
      };

      --layout-inline: {
        display: -ms-inline-flexbox;
        display: -webkit-inline-flex;
        display: inline-flex;
      };

      --layout-horizontal: {
        @apply --layout;

        -ms-flex-direction: row;
        -webkit-flex-direction: row;
        flex-direction: row;
      };

      --layout-horizontal-reverse: {
        @apply --layout;

        -ms-flex-direction: row-reverse;
        -webkit-flex-direction: row-reverse;
        flex-direction: row-reverse;
      };

      --layout-vertical: {
        @apply --layout;

        -ms-flex-direction: column;
        -webkit-flex-direction: column;
        flex-direction: column;
      };

      --layout-vertical-reverse: {
        @apply --layout;

        -ms-flex-direction: column-reverse;
        -webkit-flex-direction: column-reverse;
        flex-direction: column-reverse;
      };

      --layout-wrap: {
        -ms-flex-wrap: wrap;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
      };

      --layout-wrap-reverse: {
        -ms-flex-wrap: wrap-reverse;
        -webkit-flex-wrap: wrap-reverse;
        flex-wrap: wrap-reverse;
      };

      --layout-flex-auto: {
        -ms-flex: 1 1 auto;
        -webkit-flex: 1 1 auto;
        flex: 1 1 auto;
      };

      --layout-flex-none: {
        -ms-flex: none;
        -webkit-flex: none;
        flex: none;
      };

      --layout-flex: {
        -ms-flex: 1 1 0.000000001px;
        -webkit-flex: 1;
        flex: 1;
        -webkit-flex-basis: 0.000000001px;
        flex-basis: 0.000000001px;
      };

      --layout-flex-2: {
        -ms-flex: 2;
        -webkit-flex: 2;
        flex: 2;
      };

      --layout-flex-3: {
        -ms-flex: 3;
        -webkit-flex: 3;
        flex: 3;
      };

      --layout-flex-4: {
        -ms-flex: 4;
        -webkit-flex: 4;
        flex: 4;
      };

      --layout-flex-5: {
        -ms-flex: 5;
        -webkit-flex: 5;
        flex: 5;
      };

      --layout-flex-6: {
        -ms-flex: 6;
        -webkit-flex: 6;
        flex: 6;
      };

      --layout-flex-7: {
        -ms-flex: 7;
        -webkit-flex: 7;
        flex: 7;
      };

      --layout-flex-8: {
        -ms-flex: 8;
        -webkit-flex: 8;
        flex: 8;
      };

      --layout-flex-9: {
        -ms-flex: 9;
        -webkit-flex: 9;
        flex: 9;
      };

      --layout-flex-10: {
        -ms-flex: 10;
        -webkit-flex: 10;
        flex: 10;
      };

      --layout-flex-11: {
        -ms-flex: 11;
        -webkit-flex: 11;
        flex: 11;
      };

      --layout-flex-12: {
        -ms-flex: 12;
        -webkit-flex: 12;
        flex: 12;
      };

      /* alignment in cross axis */

      --layout-start: {
        -ms-flex-align: start;
        -webkit-align-items: flex-start;
        align-items: flex-start;
      };

      --layout-center: {
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      };

      --layout-end: {
        -ms-flex-align: end;
        -webkit-align-items: flex-end;
        align-items: flex-end;
      };

      --layout-baseline: {
        -ms-flex-align: baseline;
        -webkit-align-items: baseline;
        align-items: baseline;
      };

      /* alignment in main axis */

      --layout-start-justified: {
        -ms-flex-pack: start;
        -webkit-justify-content: flex-start;
        justify-content: flex-start;
      };

      --layout-center-justified: {
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
      };

      --layout-end-justified: {
        -ms-flex-pack: end;
        -webkit-justify-content: flex-end;
        justify-content: flex-end;
      };

      --layout-around-justified: {
        -ms-flex-pack: distribute;
        -webkit-justify-content: space-around;
        justify-content: space-around;
      };

      --layout-justified: {
        -ms-flex-pack: justify;
        -webkit-justify-content: space-between;
        justify-content: space-between;
      };

      --layout-center-center: {
        @apply --layout-center;
        @apply --layout-center-justified;
      };

      /* self alignment */

      --layout-self-start: {
        -ms-align-self: flex-start;
        -webkit-align-self: flex-start;
        align-self: flex-start;
      };

      --layout-self-center: {
        -ms-align-self: center;
        -webkit-align-self: center;
        align-self: center;
      };

      --layout-self-end: {
        -ms-align-self: flex-end;
        -webkit-align-self: flex-end;
        align-self: flex-end;
      };

      --layout-self-stretch: {
        -ms-align-self: stretch;
        -webkit-align-self: stretch;
        align-self: stretch;
      };

      --layout-self-baseline: {
        -ms-align-self: baseline;
        -webkit-align-self: baseline;
        align-self: baseline;
      };

      /* multi-line alignment in main axis */

      --layout-start-aligned: {
        -ms-flex-line-pack: start;  /* IE10 */
        -ms-align-content: flex-start;
        -webkit-align-content: flex-start;
        align-content: flex-start;
      };

      --layout-end-aligned: {
        -ms-flex-line-pack: end;  /* IE10 */
        -ms-align-content: flex-end;
        -webkit-align-content: flex-end;
        align-content: flex-end;
      };

      --layout-center-aligned: {
        -ms-flex-line-pack: center;  /* IE10 */
        -ms-align-content: center;
        -webkit-align-content: center;
        align-content: center;
      };

      --layout-between-aligned: {
        -ms-flex-line-pack: justify;  /* IE10 */
        -ms-align-content: space-between;
        -webkit-align-content: space-between;
        align-content: space-between;
      };

      --layout-around-aligned: {
        -ms-flex-line-pack: distribute;  /* IE10 */
        -ms-align-content: space-around;
        -webkit-align-content: space-around;
        align-content: space-around;
      };

      /*******************************
                Other Layout
      *******************************/

      --layout-block: {
        display: block;
      };

      --layout-invisible: {
        visibility: hidden !important;
      };

      --layout-relative: {
        position: relative;
      };

      --layout-fit: {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
      };

      --layout-scroll: {
        -webkit-overflow-scrolling: touch;
        overflow: auto;
      };

      --layout-fullbleed: {
        margin: 0;
        height: 100vh;
      };

      /* fixed position */

      --layout-fixed-top: {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
      };

      --layout-fixed-right: {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
      };

      --layout-fixed-bottom: {
        position: fixed;
        right: 0;
        bottom: 0;
        left: 0;
      };

      --layout-fixed-left: {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
      };

    }
  </style>
</custom-style>`;template.setAttribute('style','display: none;');document.head.appendChild(template.content);var style=document.createElement('style');style.textContent='[hidden] { display: none !important; }';document.head.appendChild(style)},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return afterNextRender});__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let scheduled=!1,beforeRenderQueue=[],afterRenderQueue=[];function schedule(){scheduled=!0;requestAnimationFrame(function(){scheduled=!1;flushQueue(beforeRenderQueue);setTimeout(function(){runQueue(afterRenderQueue)})})}function flushQueue(queue){while(queue.length){callMethod(queue.shift())}}function runQueue(queue){for(let i=0,l=queue.length;i<l;i++){callMethod(queue.shift())}}function callMethod(info){const context=info[0],callback=info[1],args=info[2];try{callback.apply(context,args)}catch(e){setTimeout(()=>{throw e})}}function afterNextRender(context,callback,args){if(!scheduled){schedule()}afterRenderQueue.push([context,callback,args])}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'c',function(){return stylesFromTemplate});__webpack_require__.d(__webpack_exports__,'b',function(){return stylesFromModuleImports});__webpack_require__.d(__webpack_exports__,'a',function(){return cssFromModules});var _elements_dom_module_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(30),_resolve_url_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(11);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const SHADY_UNSCOPED_ATTR='shady-unscoped';function importModule(moduleId){return _elements_dom_module_js__WEBPACK_IMPORTED_MODULE_0__.a.import(moduleId)}function styleForImport(importDoc){let container=importDoc.body?importDoc.body:importDoc;const importCss=Object(_resolve_url_js__WEBPACK_IMPORTED_MODULE_1__.b)(container.textContent,importDoc.baseURI),style=document.createElement('style');style.textContent=importCss;return style}function stylesFromModules(moduleIds){const modules=moduleIds.trim().split(/\s+/),styles=[];for(let i=0;i<modules.length;i++){styles.push(...stylesFromModule(modules[i]))}return styles}function stylesFromModule(moduleId){const m=importModule(moduleId);if(!m){console.warn('Could not find style data in module named',moduleId);return[]}if(m._styles===void 0){const styles=[..._stylesFromModuleImports(m)],template=m.querySelector('template');if(template){styles.push(...stylesFromTemplate(template,m.assetpath))}m._styles=styles}return m._styles}function stylesFromTemplate(template,baseURI){if(!template._styles){const styles=[],e$=template.content.querySelectorAll('style');for(let i=0;i<e$.length;i++){let e=e$[i],include=e.getAttribute('include');if(include){styles.push(...stylesFromModules(include).filter(function(item,index,self){return self.indexOf(item)===index}))}if(baseURI){e.textContent=Object(_resolve_url_js__WEBPACK_IMPORTED_MODULE_1__.b)(e.textContent,baseURI)}styles.push(e)}template._styles=styles}return template._styles}function stylesFromModuleImports(moduleId){let m=importModule(moduleId);return m?_stylesFromModuleImports(m):[]}function _stylesFromModuleImports(module){const styles=[],p$=module.querySelectorAll('link[rel=import][type~=css]');for(let i=0,p;i<p$.length;i++){p=p$[i];if(p.import){const importDoc=p.import,unscoped=p.hasAttribute(SHADY_UNSCOPED_ATTR);if(unscoped&&!importDoc._unscopedStyle){const style=styleForImport(importDoc);style.setAttribute(SHADY_UNSCOPED_ATTR,'');importDoc._unscopedStyle=style}else if(!importDoc._style){importDoc._style=styleForImport(importDoc)}styles.push(unscoped?importDoc._unscopedStyle:importDoc._style)}}return styles}function cssFromModules(moduleIds){let modules=moduleIds.trim().split(/\s+/),cssText='';for(let i=0;i<modules.length;i++){cssText+=cssFromModule(modules[i])}return cssText}function cssFromModule(moduleId){let m=importModule(moduleId);if(m&&m._cssText===void 0){let cssText=_cssFromModuleImports(m),t=m.querySelector('template');if(t){cssText+=cssFromTemplate(t,m.assetpath)}m._cssText=cssText||null}if(!m){console.warn('Could not find style data in module named',moduleId)}return m&&m._cssText||''}function cssFromTemplate(template,baseURI){let cssText='';const e$=stylesFromTemplate(template,baseURI);for(let i=0,e;i<e$.length;i++){e=e$[i];if(e.parentNode){e.parentNode.removeChild(e)}cssText+=e.textContent}return cssText}function _cssFromModuleImports(module){let cssText='',styles=_stylesFromModuleImports(module);for(let i=0;i<styles.length;i++){cssText+=styles[i].textContent}return cssText}},function(module,__webpack_exports__,__webpack_require__){'use strict';var style_settings=__webpack_require__(9);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/class StyleNode{constructor(){this.start=0;this.end=0;this.previous=null;this.parent=null;this.rules=null;this.parsedCssText='';this.cssText='';this.atRule=!1;this.type=0;this.keyframesName='';this.selector='';this.parsedSelector=''}}function parse(text){text=clean(text);return parseCss(lex(text),text)}function clean(cssText){return cssText.replace(RX.comments,'').replace(RX.port,'')}function lex(text){let root=new StyleNode;root.start=0;root.end=text.length;let n=root;for(let i=0,l=text.length;i<l;i++){if(text[i]===OPEN_BRACE){if(!n.rules){n.rules=[]}let p=n,previous=p.rules[p.rules.length-1]||null;n=new StyleNode;n.start=i+1;n.parent=p;n.previous=previous;p.rules.push(n)}else if(text[i]===CLOSE_BRACE){n.end=i+1;n=n.parent||root}}return root}function parseCss(node,text){let t=text.substring(node.start,node.end-1);node.parsedCssText=node.cssText=t.trim();if(node.parent){let ss=node.previous?node.previous.end:node.parent.start;t=text.substring(ss,node.start-1);t=_expandUnicodeEscapes(t);t=t.replace(RX.multipleSpaces,' ');t=t.substring(t.lastIndexOf(';')+1);let s=node.parsedSelector=node.selector=t.trim();node.atRule=0===s.indexOf(AT_START);if(node.atRule){if(0===s.indexOf(MEDIA_START)){node.type=types.MEDIA_RULE}else if(s.match(RX.keyframesRule)){node.type=types.KEYFRAMES_RULE;node.keyframesName=node.selector.split(RX.multipleSpaces).pop()}}else{if(0===s.indexOf(VAR_START)){node.type=types.MIXIN_RULE}else{node.type=types.STYLE_RULE}}}let r$=node.rules;if(r$){for(let i=0,l=r$.length,r;i<l&&(r=r$[i]);i++){parseCss(r,text)}}return node}function _expandUnicodeEscapes(s){return s.replace(/\\([0-9a-f]{1,6})\s/gi,function(){let code=arguments[1],repeat=6-code.length;while(repeat--){code='0'+code}return'\\'+code})}function stringify(node,preserveProperties,text=''){let cssText='';if(node.cssText||node.rules){let r$=node.rules;if(r$&&!_hasMixinRules(r$)){for(let i=0,l=r$.length,r;i<l&&(r=r$[i]);i++){cssText=stringify(r,preserveProperties,cssText)}}else{cssText=preserveProperties?node.cssText:removeCustomProps(node.cssText);cssText=cssText.trim();if(cssText){cssText='  '+cssText+'\n'}}}if(cssText){if(node.selector){text+=node.selector+' '+OPEN_BRACE+'\n'}text+=cssText;if(node.selector){text+=CLOSE_BRACE+'\n\n'}}return text}function _hasMixinRules(rules){let r=rules[0];return!!r&&!!r.selector&&0===r.selector.indexOf(VAR_START)}function removeCustomProps(cssText){cssText=removeCustomPropAssignment(cssText);return removeCustomPropApply(cssText)}function removeCustomPropAssignment(cssText){return cssText.replace(RX.customProp,'').replace(RX.mixinProp,'')}function removeCustomPropApply(cssText){return cssText.replace(RX.mixinApply,'').replace(RX.varApply,'')}const types={STYLE_RULE:1,KEYFRAMES_RULE:7,MEDIA_RULE:4,MIXIN_RULE:1e3},OPEN_BRACE='{',CLOSE_BRACE='}',RX={comments:/\/\*[^*]*\*+([^/*][^*]*\*+)*\//gim,port:/@import[^;]*;/gim,customProp:/(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?(?:[;\n]|$)/gim,mixinProp:/(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?{[^}]*?}(?:[;\n]|$)?/gim,mixinApply:/@apply\s*\(?[^);]*\)?\s*(?:[;\n]|$)?/gim,varApply:/[^;:]*?:[^;]*?var\([^;]*\)(?:[;\n]|$)?/gim,keyframesRule:/^@[^\s]*keyframes/,multipleSpaces:/\s+/g},VAR_START='--',MEDIA_START='@media',AT_START='@';var common_regex=__webpack_require__(13);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const styleTextSet=new Set;function processUnscopedStyle(style){const text=style.textContent;if(!styleTextSet.has(text)){styleTextSet.add(text);const newStyle=style.cloneNode(!0);document.head.appendChild(newStyle)}}function isUnscopedStyle(style){return style.hasAttribute('shady-unscoped')}/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/function toCssText(rules,callback){if(!rules){return''}if('string'===typeof rules){rules=parse(rules)}if(callback){forEachRule(rules,callback)}return stringify(rules,style_settings.b)}function rulesForStyle(style){if(!style.__cssRules&&style.textContent){style.__cssRules=parse(style.textContent)}return style.__cssRules||null}function forEachRule(node,styleRuleCallback,keyframesRuleCallback,onlyActiveRules){if(!node){return}let skipRules=!1,type=node.type;if(onlyActiveRules){if(type===types.MEDIA_RULE){let matchMedia=node.selector.match(common_regex.a);if(matchMedia){if(!window.matchMedia(matchMedia[1]).matches){skipRules=!0}}}}if(type===types.STYLE_RULE){styleRuleCallback(node)}else if(keyframesRuleCallback&&type===types.KEYFRAMES_RULE){keyframesRuleCallback(node)}else if(type===types.MIXIN_RULE){skipRules=!0}let r$=node.rules;if(r$&&!skipRules){for(let i=0,l=r$.length,r;i<l&&(r=r$[i]);i++){forEachRule(r,styleRuleCallback,keyframesRuleCallback,onlyActiveRules)}}}let lastHeadApplyNode=null;function findMatchingParen(text,start){let level=0;for(let i=start,l=text.length;i<l;i++){if('('===text[i]){level++}else if(')'===text[i]){if(0===--level){return i}}}return-1}function processVariableAndFallback(str,callback){let start=str.indexOf('var(');if(-1===start){return callback(str,'','','')}let end=findMatchingParen(str,start+3),inner=str.substring(start+4,end),prefix=str.substring(0,start),suffix=processVariableAndFallback(str.substring(end+1),callback),comma=inner.indexOf(',');if(-1===comma){return callback(prefix,inner.trim(),'',suffix)}let value=inner.substring(0,comma).trim(),fallback=inner.substring(comma+1).trim();return callback(prefix,value,fallback,suffix)}function getIsExtends(element){let localName=element.localName,is='',typeExtension='';if(localName){if(-1<localName.indexOf('-')){is=localName}else{typeExtension=localName;is=element.getAttribute&&element.getAttribute('is')||''}}else{is=element.is;typeExtension=element.extends}return{is,typeExtension}}function gatherStyleText(element){const styleTextParts=[],styles=element.querySelectorAll('style');for(let i=0;i<styles.length;i++){const style=styles[i];if(isUnscopedStyle(style)){if(!style_settings.c){processUnscopedStyle(style);style.parentNode.removeChild(style)}}else{styleTextParts.push(style.textContent);style.parentNode.removeChild(style)}}return styleTextParts.join('').trim()}const CSS_BUILD_ATTR='css-build';function getCssBuild(element){if(style_settings.a!==void 0){return style_settings.a}if(element.__cssBuild===void 0){const attrValue=element.getAttribute(CSS_BUILD_ATTR);if(attrValue){element.__cssBuild=attrValue}else{const buildComment=getBuildComment(element);if(''!==buildComment){removeBuildComment(element)}element.__cssBuild=buildComment}}return element.__cssBuild||''}function elementHasBuiltCss(element){return''!==getCssBuild(element)}function getBuildComment(element){const buildComment='template'===element.localName?element.content.firstChild:element.firstChild;if(buildComment instanceof Comment){const commentParts=buildComment.textContent.trim().split(':');if(commentParts[0]===CSS_BUILD_ATTR){return commentParts[1]}}return''}function removeBuildComment(element){const buildComment='template'===element.localName?element.content.firstChild:element.firstChild;buildComment.parentNode.removeChild(buildComment)}var common_utils=__webpack_require__(21);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const APPLY_NAME_CLEAN=/;\s*/m,INITIAL_INHERIT=/^\s*(initial)|(inherit)\s*$/,IMPORTANT=/\s*!important/,MIXIN_VAR_SEP='_-_';class MixinMap{constructor(){this._map={}}set(name,props){name=name.trim();this._map[name]={properties:props,dependants:{}}}get(name){name=name.trim();return this._map[name]||null}}let invalidCallback=null;class apply_shim_ApplyShim{constructor(){this._currentElement=null;this._measureElement=null;this._map=new MixinMap}detectMixin(cssText){return Object(common_utils.a)(cssText)}gatherStyles(template){const styleText=gatherStyleText(template.content);if(styleText){const style=document.createElement('style');style.textContent=styleText;template.content.insertBefore(style,template.content.firstChild);return style}return null}transformTemplate(template,elementName){if(template._gatheredStyle===void 0){template._gatheredStyle=this.gatherStyles(template)}const style=template._gatheredStyle;return style?this.transformStyle(style,elementName):null}transformStyle(style,elementName=''){let ast=rulesForStyle(style);this.transformRules(ast,elementName);style.textContent=toCssText(ast);return ast}transformCustomStyle(style){let ast=rulesForStyle(style);forEachRule(ast,rule=>{if(':root'===rule.selector){rule.selector='html'}this.transformRule(rule)});style.textContent=toCssText(ast);return ast}transformRules(rules,elementName){this._currentElement=elementName;forEachRule(rules,r=>{this.transformRule(r)});this._currentElement=null}transformRule(rule){rule.cssText=this.transformCssText(rule.parsedCssText,rule);if(':root'===rule.selector){rule.selector=':host > *'}}transformCssText(cssText,rule){cssText=cssText.replace(common_regex.c,(matchText,propertyName,valueProperty,valueMixin)=>this._produceCssProperties(matchText,propertyName,valueProperty,valueMixin,rule));return this._consumeCssProperties(cssText,rule)}_getInitialValueForProperty(property){if(!this._measureElement){this._measureElement=document.createElement('meta');this._measureElement.setAttribute('apply-shim-measure','');this._measureElement.style.all='initial';document.head.appendChild(this._measureElement)}return window.getComputedStyle(this._measureElement).getPropertyValue(property)}_fallbacksFromPreviousRules(startRule){let topRule=startRule;while(topRule.parent){topRule=topRule.parent}const fallbacks={};let seenStartRule=!1;forEachRule(topRule,r=>{seenStartRule=seenStartRule||r===startRule;if(seenStartRule){return}if(r.selector===startRule.selector){Object.assign(fallbacks,this._cssTextToMap(r.parsedCssText))}});return fallbacks}_consumeCssProperties(text,rule){let m=null;while(m=common_regex.b.exec(text)){let matchText=m[0],mixinName=m[1],idx=m.index,applyPos=idx+matchText.indexOf('@apply'),afterApplyPos=idx+matchText.length,textBeforeApply=text.slice(0,applyPos),textAfterApply=text.slice(afterApplyPos),defaults=rule?this._fallbacksFromPreviousRules(rule):{};Object.assign(defaults,this._cssTextToMap(textBeforeApply));let replacement=this._atApplyToCssProperties(mixinName,defaults);text=`${textBeforeApply}${replacement}${textAfterApply}`;common_regex.b.lastIndex=idx+replacement.length}return text}_atApplyToCssProperties(mixinName,fallbacks){mixinName=mixinName.replace(APPLY_NAME_CLEAN,'');let vars=[],mixinEntry=this._map.get(mixinName);if(!mixinEntry){this._map.set(mixinName,{});mixinEntry=this._map.get(mixinName)}if(mixinEntry){if(this._currentElement){mixinEntry.dependants[this._currentElement]=!0}let p,parts,f;const properties=mixinEntry.properties;for(p in properties){f=fallbacks&&fallbacks[p];parts=[p,': var(',mixinName,MIXIN_VAR_SEP,p];if(f){parts.push(',',f.replace(IMPORTANT,''))}parts.push(')');if(IMPORTANT.test(properties[p])){parts.push(' !important')}vars.push(parts.join(''))}}return vars.join('; ')}_replaceInitialOrInherit(property,value){let match=INITIAL_INHERIT.exec(value);if(match){if(match[1]){value=this._getInitialValueForProperty(property)}else{value='apply-shim-inherit'}}return value}_cssTextToMap(text,replaceInitialOrInherit=!1){let props=text.split(';'),property,value,out={};for(let i=0,p,sp;i<props.length;i++){p=props[i];if(p){sp=p.split(':');if(1<sp.length){property=sp[0].trim();value=sp.slice(1).join(':');if(replaceInitialOrInherit){value=this._replaceInitialOrInherit(property,value)}out[property]=value}}}return out}_invalidateMixinEntry(mixinEntry){if(!invalidCallback){return}for(let elementName in mixinEntry.dependants){if(elementName!==this._currentElement){invalidCallback(elementName)}}}_produceCssProperties(matchText,propertyName,valueProperty,valueMixin,rule){if(valueProperty){processVariableAndFallback(valueProperty,(prefix,value)=>{if(value&&this._map.get(value)){valueMixin=`@apply ${value};`}})}if(!valueMixin){return matchText}let mixinAsProperties=this._consumeCssProperties(''+valueMixin,rule),prefix=matchText.slice(0,matchText.indexOf('--')),mixinValues=this._cssTextToMap(mixinAsProperties,!0),combinedProps=mixinValues,mixinEntry=this._map.get(propertyName),oldProps=mixinEntry&&mixinEntry.properties;if(oldProps){combinedProps=Object.assign(Object.create(oldProps),mixinValues)}else{this._map.set(propertyName,combinedProps)}let out=[],p,v,needToInvalidate=!1;for(p in combinedProps){v=mixinValues[p];if(v===void 0){v='initial'}if(oldProps&&!(p in oldProps)){needToInvalidate=!0}out.push(`${propertyName}${MIXIN_VAR_SEP}${p}: ${v}`)}if(needToInvalidate){this._invalidateMixinEntry(mixinEntry)}if(mixinEntry){mixinEntry.properties=combinedProps}if(valueProperty){prefix=`${matchText};${prefix}`}return`${prefix}${out.join('; ')};`}}apply_shim_ApplyShim.prototype.detectMixin=apply_shim_ApplyShim.prototype.detectMixin;apply_shim_ApplyShim.prototype.transformStyle=apply_shim_ApplyShim.prototype.transformStyle;apply_shim_ApplyShim.prototype.transformCustomStyle=apply_shim_ApplyShim.prototype.transformCustomStyle;apply_shim_ApplyShim.prototype.transformRules=apply_shim_ApplyShim.prototype.transformRules;apply_shim_ApplyShim.prototype.transformRule=apply_shim_ApplyShim.prototype.transformRule;apply_shim_ApplyShim.prototype.transformTemplate=apply_shim_ApplyShim.prototype.transformTemplate;apply_shim_ApplyShim.prototype._separator=MIXIN_VAR_SEP;Object.defineProperty(apply_shim_ApplyShim.prototype,'invalidCallback',{get(){return invalidCallback},set(cb){invalidCallback=cb}});/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/var template_map={};/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const CURRENT_VERSION='_applyShimCurrentVersion',NEXT_VERSION='_applyShimNextVersion',VALIDATING_VERSION='_applyShimValidatingVersion',promise=Promise.resolve();function invalidate(elementName){let template=template_map[elementName];if(template){invalidateTemplate(template)}}function invalidateTemplate(template){template[CURRENT_VERSION]=template[CURRENT_VERSION]||0;template[VALIDATING_VERSION]=template[VALIDATING_VERSION]||0;template[NEXT_VERSION]=(template[NEXT_VERSION]||0)+1}function templateIsValid(template){return template[CURRENT_VERSION]===template[NEXT_VERSION]}function templateIsValidating(template){return!templateIsValid(template)&&template[VALIDATING_VERSION]===template[NEXT_VERSION]}function startValidatingTemplate(template){template[VALIDATING_VERSION]=template[NEXT_VERSION];if(!template._validating){template._validating=!0;promise.then(function(){template[CURRENT_VERSION]=template[NEXT_VERSION];template._validating=!1})}}__webpack_require__(54);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const applyShim=new apply_shim_ApplyShim;class apply_shim_ApplyShimInterface{constructor(){this.customStyleInterface=null;applyShim.invalidCallback=invalidate}ensure(){if(this.customStyleInterface){return}if(window.ShadyCSS.CustomStyleInterface){this.customStyleInterface=window.ShadyCSS.CustomStyleInterface;this.customStyleInterface.transformCallback=style=>{applyShim.transformCustomStyle(style)};this.customStyleInterface.validateCallback=()=>{requestAnimationFrame(()=>{if(this.customStyleInterface.enqueued){this.flushCustomStyles()}})}}}prepareTemplate(template,elementName){this.ensure();if(elementHasBuiltCss(template)){return}template_map[elementName]=template;let ast=applyShim.transformTemplate(template,elementName);template._styleAst=ast}flushCustomStyles(){this.ensure();if(!this.customStyleInterface){return}let styles=this.customStyleInterface.processStyles();if(!this.customStyleInterface.enqueued){return}for(let i=0;i<styles.length;i++){let cs=styles[i],style=this.customStyleInterface.getStyleForCustomStyle(cs);if(style){applyShim.transformCustomStyle(style)}}this.customStyleInterface.enqueued=!1}styleSubtree(element,properties){this.ensure();if(properties){Object(common_utils.c)(element,properties)}if(element.shadowRoot){this.styleElement(element);let shadowChildren=element.shadowRoot.children||element.shadowRoot.childNodes;for(let i=0;i<shadowChildren.length;i++){this.styleSubtree(shadowChildren[i])}}else{let children=element.children||element.childNodes;for(let i=0;i<children.length;i++){this.styleSubtree(children[i])}}}styleElement(element){this.ensure();let{is}=getIsExtends(element),template=template_map[is];if(template&&elementHasBuiltCss(template)){return}if(template&&!templateIsValid(template)){if(!templateIsValidating(template)){this.prepareTemplate(template,is);startValidatingTemplate(template)}let root=element.shadowRoot;if(root){let style=root.querySelector('style');if(style){style.__cssRules=template._styleAst;style.textContent=toCssText(template._styleAst)}}}}styleDocument(properties){this.ensure();this.styleSubtree(document.body,properties)}}if(!window.ShadyCSS||!window.ShadyCSS.ScopingShim){const applyShimInterface=new apply_shim_ApplyShimInterface;let CustomStyleInterface=window.ShadyCSS&&window.ShadyCSS.CustomStyleInterface;window.ShadyCSS={prepareTemplate(template,elementName){applyShimInterface.flushCustomStyles();applyShimInterface.prepareTemplate(template,elementName)},prepareTemplateStyles(template,elementName,elementExtends){window.ShadyCSS.prepareTemplate(template,elementName,elementExtends)},prepareTemplateDom(){},styleSubtree(element,properties){applyShimInterface.flushCustomStyles();applyShimInterface.styleSubtree(element,properties)},styleElement(element){applyShimInterface.flushCustomStyles();applyShimInterface.styleElement(element)},styleDocument(properties){applyShimInterface.flushCustomStyles();applyShimInterface.styleDocument(properties)},getComputedStyleValue(element,property){return Object(common_utils.b)(element,property)},flushCustomStyles(){applyShimInterface.flushCustomStyles()},nativeCss:style_settings.b,nativeShadow:style_settings.c,cssBuild:style_settings.a};if(CustomStyleInterface){window.ShadyCSS.CustomStyleInterface=CustomStyleInterface}}window.ShadyCSS.ApplyShim=applyShim;var element_mixin=__webpack_require__(26),gesture_event_listeners=__webpack_require__(43),property_accessors=__webpack_require__(44),mixin=__webpack_require__(5);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const HOST_DIR=/:host\(:dir\((ltr|rtl)\)\)/g,EL_DIR=/([\s\w-#\.\[\]\*]*):dir\((ltr|rtl)\)/g,DIR_INSTANCES=[];let observer=null,DOCUMENT_DIR='';function getRTL(){DOCUMENT_DIR=document.documentElement.getAttribute('dir')}function setRTL(instance){if(!instance.__autoDirOptOut){instance.setAttribute('dir',DOCUMENT_DIR)}}function updateDirection(){getRTL();DOCUMENT_DIR=document.documentElement.getAttribute('dir');for(let i=0;i<DIR_INSTANCES.length;i++){setRTL(DIR_INSTANCES[i])}}function takeRecords(){if(observer&&observer.takeRecords().length){updateDirection()}}const DirMixin=Object(mixin.a)(base=>{if(!observer){getRTL();observer=new MutationObserver(updateDirection);observer.observe(document.documentElement,{attributes:!0,attributeFilter:['dir']})}const elementBase=Object(property_accessors.a)(base);class Dir extends elementBase{static _processStyleText(cssText,baseURI){cssText=super._processStyleText(cssText,baseURI);cssText=this._replaceDirInCssText(cssText);return cssText}static _replaceDirInCssText(text){let replacedText=text;replacedText=replacedText.replace(HOST_DIR,':host([dir="$1"])');replacedText=replacedText.replace(EL_DIR,':host([dir="$2"]) $1');if(text!==replacedText){this.__activateDir=!0}return replacedText}constructor(){super();this.__autoDirOptOut=!1}ready(){super.ready();this.__autoDirOptOut=this.hasAttribute('dir')}connectedCallback(){if(elementBase.prototype.connectedCallback){super.connectedCallback()}if(this.constructor.__activateDir){takeRecords();DIR_INSTANCES.push(this);setRTL(this)}}disconnectedCallback(){if(elementBase.prototype.disconnectedCallback){super.disconnectedCallback()}if(this.constructor.__activateDir){const idx=DIR_INSTANCES.indexOf(this);if(-1<idx){DIR_INSTANCES.splice(idx,1)}}}}Dir.__activateDir=!1;return Dir});__webpack_require__(34);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/function resolve(){document.body.removeAttribute('unresolved')}if('interactive'===document.readyState||'complete'===document.readyState){resolve()}else{window.addEventListener('DOMContentLoaded',resolve)}var polymer_dom=__webpack_require__(0),gestures=__webpack_require__(25),debounce=__webpack_require__(14),utils_async=__webpack_require__(8),path=__webpack_require__(2);__webpack_require__.d(__webpack_exports__,'a',function(){return LegacyElementMixin});/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let styleInterface=window.ShadyCSS;const LegacyElementMixin=Object(mixin.a)(base=>{const legacyElementBase=DirMixin(Object(gesture_event_listeners.a)(Object(element_mixin.a)(base))),DIRECTION_MAP={x:'pan-x',y:'pan-y',none:'none',all:'auto'};class LegacyElement extends legacyElementBase{constructor(){super();this.isAttached;this.__boundListeners;this._debouncers;this._applyListeners()}static get importMeta(){return this.prototype.importMeta}created(){}connectedCallback(){super.connectedCallback();this.isAttached=!0;this.attached()}attached(){}disconnectedCallback(){super.disconnectedCallback();this.isAttached=!1;this.detached()}detached(){}attributeChangedCallback(name,old,value,namespace){if(old!==value){super.attributeChangedCallback(name,old,value,namespace);this.attributeChanged(name,old,value)}}attributeChanged(){}_initializeProperties(){let proto=Object.getPrototypeOf(this);if(!proto.hasOwnProperty('__hasRegisterFinished')){proto.__hasRegisterFinished=!0;this._registered()}super._initializeProperties();this.root=this;this.created()}_registered(){}ready(){this._ensureAttributes();super.ready()}_ensureAttributes(){}_applyListeners(){}serialize(value){return this._serializeValue(value)}deserialize(value,type){return this._deserializeValue(value,type)}reflectPropertyToAttribute(property,attribute,value){this._propertyToAttribute(property,attribute,value)}serializeValueToAttribute(value,attribute,node){this._valueToNodeAttribute(node||this,value,attribute)}extend(prototype,api){if(!(prototype&&api)){return prototype||api}let n$=Object.getOwnPropertyNames(api);for(let i=0,n,pd;i<n$.length&&(n=n$[i]);i++){pd=Object.getOwnPropertyDescriptor(api,n);if(pd){Object.defineProperty(prototype,n,pd)}}return prototype}mixin(target,source){for(let i in source){target[i]=source[i]}return target}chainObject(object,prototype){if(object&&prototype&&object!==prototype){object.__proto__=prototype}return object}instanceTemplate(template){let content=this.constructor._contentForTemplate(template),dom=document.importNode(content,!0);return dom}fire(type,detail,options){options=options||{};detail=null===detail||detail===void 0?{}:detail;let event=new Event(type,{bubbles:options.bubbles===void 0?!0:options.bubbles,cancelable:!!options.cancelable,composed:options.composed===void 0?!0:options.composed});event.detail=detail;let node=options.node||this;node.dispatchEvent(event);return event}listen(node,eventName,methodName){node=node||this;let hbl=this.__boundListeners||(this.__boundListeners=new WeakMap),bl=hbl.get(node);if(!bl){bl={};hbl.set(node,bl)}let key=eventName+methodName;if(!bl[key]){bl[key]=this._addMethodEventListenerToNode(node,eventName,methodName,this)}}unlisten(node,eventName,methodName){node=node||this;let bl=this.__boundListeners&&this.__boundListeners.get(node),key=eventName+methodName,handler=bl&&bl[key];if(handler){this._removeEventListenerFromNode(node,eventName,handler);bl[key]=null}}setScrollDirection(direction,node){Object(gestures.f)(node||this,DIRECTION_MAP[direction]||'auto')}$$(slctr){return this.root.querySelector(slctr)}get domHost(){let root=this.getRootNode();return root instanceof DocumentFragment?root.host:root}distributeContent(){if(window.ShadyDOM&&this.shadowRoot){ShadyDOM.flush()}}getEffectiveChildNodes(){const thisEl=this,domApi=Object(polymer_dom.b)(thisEl);return domApi.getEffectiveChildNodes()}queryDistributedElements(selector){const thisEl=this,domApi=Object(polymer_dom.b)(thisEl);return domApi.queryDistributedElements(selector)}getEffectiveChildren(){let list=this.getEffectiveChildNodes();return list.filter(function(n){return n.nodeType===Node.ELEMENT_NODE})}getEffectiveTextContent(){let cn=this.getEffectiveChildNodes(),tc=[];for(let i=0,c;c=cn[i];i++){if(c.nodeType!==Node.COMMENT_NODE){tc.push(c.textContent)}}return tc.join('')}queryEffectiveChildren(selector){let e$=this.queryDistributedElements(selector);return e$&&e$[0]}queryAllEffectiveChildren(selector){return this.queryDistributedElements(selector)}getContentChildNodes(slctr){let content=this.root.querySelector(slctr||'slot');return content?Object(polymer_dom.b)(content).getDistributedNodes():[]}getContentChildren(slctr){let children=this.getContentChildNodes(slctr).filter(function(n){return n.nodeType===Node.ELEMENT_NODE});return children}isLightDescendant(node){const thisNode=this;return thisNode!==node&&thisNode.contains(node)&&thisNode.getRootNode()===node.getRootNode()}isLocalDescendant(node){return this.root===node.getRootNode()}scopeSubtree(){}getComputedStyleValue(property){return styleInterface.getComputedStyleValue(this,property)}debounce(jobName,callback,wait){this._debouncers=this._debouncers||{};return this._debouncers[jobName]=debounce.a.debounce(this._debouncers[jobName],0<wait?utils_async.d.after(wait):utils_async.c,callback.bind(this))}isDebouncerActive(jobName){this._debouncers=this._debouncers||{};let debouncer=this._debouncers[jobName];return!!(debouncer&&debouncer.isActive())}flushDebouncer(jobName){this._debouncers=this._debouncers||{};let debouncer=this._debouncers[jobName];if(debouncer){debouncer.flush()}}cancelDebouncer(jobName){this._debouncers=this._debouncers||{};let debouncer=this._debouncers[jobName];if(debouncer){debouncer.cancel()}}async(callback,waitTime){return 0<waitTime?utils_async.d.run(callback.bind(this),waitTime):~utils_async.c.run(callback.bind(this))}cancelAsync(handle){0>handle?utils_async.c.cancel(~handle):utils_async.d.cancel(handle)}create(tag,props){let elt=document.createElement(tag);if(props){if(elt.setProperties){elt.setProperties(props)}else{for(let n in props){elt[n]=props[n]}}}return elt}elementMatches(selector,node){return Object(polymer_dom.d)(node||this,selector)}toggleAttribute(name,bool){let node=this;if(3===arguments.length){node=arguments[2]}if(1==arguments.length){bool=!node.hasAttribute(name)}if(bool){node.setAttribute(name,'');return!0}else{node.removeAttribute(name);return!1}}toggleClass(name,bool,node){node=node||this;if(1==arguments.length){bool=!node.classList.contains(name)}if(bool){node.classList.add(name)}else{node.classList.remove(name)}}transform(transformText,node){node=node||this;node.style.webkitTransform=transformText;node.style.transform=transformText}translate3d(x,y,z,node){node=node||this;this.transform('translate3d('+x+','+y+','+z+')',node)}arrayDelete(arrayOrPath,item){let index;if(Array.isArray(arrayOrPath)){index=arrayOrPath.indexOf(item);if(0<=index){return arrayOrPath.splice(index,1)}}else{let arr=Object(path.a)(this,arrayOrPath);index=arr.indexOf(item);if(0<=index){return this.splice(arrayOrPath,index,1)}}return null}_logger(level,args){if(Array.isArray(args)&&1===args.length&&Array.isArray(args[0])){args=args[0]}switch(level){case'log':case'warn':case'error':console[level](...args);}}_log(...args){this._logger('log',args)}_warn(...args){this._logger('warn',args)}_error(...args){this._logger('error',args)}_logf(methodName,...args){return['[%s::%s]',this.is,methodName,...args]}}LegacyElement.prototype.is='';return LegacyElement})},,,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_color_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(68),_color_js__WEBPACK_IMPORTED_MODULE_1___default=__webpack_require__.n(_color_js__WEBPACK_IMPORTED_MODULE_1__),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
<custom-style>
  <style is="custom-style">
    html {
      /*
       * You can use these generic variables in your elements for easy theming.
       * For example, if all your elements use \`--primary-text-color\` as its main
       * color, then switching from a light to a dark theme is just a matter of
       * changing the value of \`--primary-text-color\` in your application.
       */
      --primary-text-color: var(--light-theme-text-color);
      --primary-background-color: var(--light-theme-background-color);
      --secondary-text-color: var(--light-theme-secondary-color);
      --disabled-text-color: var(--light-theme-disabled-color);
      --divider-color: var(--light-theme-divider-color);
      --error-color: var(--paper-deep-orange-a700);

      /*
       * Primary and accent colors. Also see color.js for more colors.
       */
      --primary-color: var(--paper-indigo-500);
      --light-primary-color: var(--paper-indigo-100);
      --dark-primary-color: var(--paper-indigo-700);

      --accent-color: var(--paper-pink-a200);
      --light-accent-color: var(--paper-pink-a100);
      --dark-accent-color: var(--paper-pink-a400);


      /*
       * Material Design Light background theme
       */
      --light-theme-background-color: #ffffff;
      --light-theme-base-color: #000000;
      --light-theme-text-color: var(--paper-grey-900);
      --light-theme-secondary-color: #737373;  /* for secondary text and icons */
      --light-theme-disabled-color: #9b9b9b;  /* disabled/hint text */
      --light-theme-divider-color: #dbdbdb;

      /*
       * Material Design Dark background theme
       */
      --dark-theme-background-color: var(--paper-grey-900);
      --dark-theme-base-color: #ffffff;
      --dark-theme-text-color: #ffffff;
      --dark-theme-secondary-color: #bcbcbc;  /* for secondary text and icons */
      --dark-theme-disabled-color: #646464;  /* disabled/hint text */
      --dark-theme-divider-color: #3c3c3c;

      /*
       * Deprecated values because of their confusing names.
       */
      --text-primary-color: var(--dark-theme-text-color);
      --default-primary-color: var(--primary-color);
    }
  </style>
</custom-style>`;template.setAttribute('style','display: none;');document.head.appendChild(template.content)},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return PaperRippleBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_paper_ripple_paper_ripple_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(76),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(23),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(0);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperRippleBehavior={properties:{noink:{type:Boolean,observer:'_noinkChanged'},_rippleContainer:{type:Object}},_buttonStateChanged:function(){if(this.focused){this.ensureRipple()}},_downHandler:function(event){_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_2__.b._downHandler.call(this,event);if(this.pressed){this.ensureRipple(event)}},ensureRipple:function(optTriggeringEvent){if(!this.hasRipple()){this._ripple=this._createRipple();this._ripple.noink=this.noink;var rippleContainer=this._rippleContainer||this.root;if(rippleContainer){Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(rippleContainer).appendChild(this._ripple)}if(optTriggeringEvent){var domContainer=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(this._rippleContainer||this),target=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(optTriggeringEvent).rootTarget;if(domContainer.deepContains(target)){this._ripple.uiDownAction(optTriggeringEvent)}}}},getRipple:function(){this.ensureRipple();return this._ripple},hasRipple:function(){return!!this._ripple},_createRipple:function(){var element=document.createElement('paper-ripple');return element},_noinkChanged:function(noink){if(this.hasRipple()){this._ripple.noink=noink}}}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return getActiveTranslation});__webpack_require__.d(__webpack_exports__,'b',function(){return getTranslation});var _build_translations_translationMetadata_json__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(42),_build_translations_translationMetadata_json__WEBPACK_IMPORTED_MODULE_0___namespace=__webpack_require__.t(42,1);function getActiveTranslation(){const lookup={};Object.keys(_build_translations_translationMetadata_json__WEBPACK_IMPORTED_MODULE_0__.translations).forEach(tr=>{lookup[tr.toLowerCase()]=tr});function languageGetTranslation(language){const lang=language.toLowerCase();if(lookup[lang]){return lookup[lang]}if('zh'===lang.split('-')[0]){return'zh-cn'===lang||'zh-sg'===lang?'zh-Hans':'zh-Hant'}return null}let translation=null,selectedLanguage;if(window.localStorage.selectedLanguage){try{selectedLanguage=JSON.parse(window.localStorage.selectedLanguage)}catch(e){}}if(selectedLanguage){translation=languageGetTranslation(selectedLanguage);if(translation){return translation}}if(navigator.languages){for(const locale of navigator.languages){translation=languageGetTranslation(locale);if(translation){return translation}}}translation=languageGetTranslation(navigator.language);if(translation){return translation}if(navigator.language.includes('-')){translation=languageGetTranslation(navigator.language.split('-')[0]);if(translation){return translation}}return'en'}const translations={};function getTranslation(fragment,translationInput){const translation=translationInput||getActiveTranslation(),metadata=_build_translations_translationMetadata_json__WEBPACK_IMPORTED_MODULE_0__.translations[translation];if(!metadata){if('en'!==translationInput){return getTranslation(fragment,'en')}return Promise.reject(new Error('Language en not found in metadata'))}const translationFingerprint=metadata.fingerprints[fragment?`${fragment}/${translation}`:translation];if(!translations[translationFingerprint]){translations[translationFingerprint]=fetch(`/static/translations/${translationFingerprint}`,{credentials:'same-origin'}).then(response=>response.json()).then(data=>({language:translation,data:data})).catch(error=>{delete translations[translationFingerprint];if('en'!==translationInput){return getTranslation(fragment,'en')}return Promise.reject(error)})}return translations[translationFingerprint]}getTranslation()},function(module){module.exports={fragments:['config','history','logbook','mailbox','profile','shopping-list','page-authorize','page-onboarding'],translations:{ar:{nativeName:'\u0627\u0644\u0639\u0631\u0628\u064A\u0629',fingerprints:{ar:'ar-c10e49bd63e728737204f83a25c3e82c.json',"config/ar":'config/ar-cc282c410fff075c8753e2df0c43bf47.json',"history/ar":'history/ar-c321d3dac3049b82ad4eede78ff91b9c.json',"logbook/ar":'logbook/ar-ccc52af979a33bea740c95f991e96b16.json',"mailbox/ar":'mailbox/ar-2509d061cee5c986656fb3e07c99b36c.json',"page-authorize/ar":'page-authorize/ar-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/ar":'profile/ar-921a42b5533687dde55aa0863e9caf62.json',"page-onboarding/ar":'page-onboarding/ar-44b6a1f86c6baf371ecb72a2cb784af8.json',"shopping-list/ar":'shopping-list/ar-99024fec625c3df4dfa08e57cc0ba426.json'}},bg:{nativeName:'\u0411\u044A\u043B\u0433\u0430\u0440\u0441\u043A\u0438',fingerprints:{bg:'bg-0a3bf7c4e7d7feb03683e8529ec8abd5.json',"config/bg":'config/bg-2b5e8e2dc426af007a984cce9884b550.json',"history/bg":'history/bg-5284d1b81db0ce4d8fbdc9f38b9776e7.json',"logbook/bg":'logbook/bg-6fb7d78641a30f742b2f9165431336ef.json',"mailbox/bg":'mailbox/bg-60d030b3fa80bbe834124d51e5de7128.json',"page-authorize/bg":'page-authorize/bg-4662716748be7be1e29db890403bbef8.json',"profile/bg":'profile/bg-9b3438d8c2ab46e14b7d73462a75141c.json',"page-onboarding/bg":'page-onboarding/bg-d47287e60ac0bbe1b18230a60a947af7.json',"shopping-list/bg":'shopping-list/bg-b9d8774859dd369e8870a809c46d38bf.json'}},bs:{nativeName:'Bosanski',fingerprints:{bs:'bs-4be6620280560f41e3eb1a5d9aa7fac0.json',"config/bs":'config/bs-b1964e16a45dd478ee2f2a1132d8e1a2.json',"history/bs":'history/bs-ff19fc552bb533b540bbadf9f88e6b78.json',"logbook/bs":'logbook/bs-aee3792969e54eb1920fa8d9da66cecf.json',"mailbox/bs":'mailbox/bs-b6910682902a5993edf247a428bd9ad3.json',"page-authorize/bs":'page-authorize/bs-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/bs":'profile/bs-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/bs":'page-onboarding/bs-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/bs":'shopping-list/bs-4f2f7e9d9ee35e3c3bd7d8f30cef36a8.json'}},ca:{nativeName:'Catal\xE0',fingerprints:{ca:'ca-871c79a96d9016ab3cfce87f79ba309a.json',"config/ca":'config/ca-ad5e277553d871bfa75e64643f63de6f.json',"history/ca":'history/ca-726032ecfcc6833b0add4babd6b02b1e.json',"logbook/ca":'logbook/ca-501baf8fa6db33b7b1834b1382668cd5.json',"mailbox/ca":'mailbox/ca-abcf74ecc1785e45764fa611a725d540.json',"page-authorize/ca":'page-authorize/ca-1db5805f22508e6d0b5fa5fc34b36b09.json',"profile/ca":'profile/ca-113d8cd8a537c54d62c206b1d2cda28b.json',"page-onboarding/ca":'page-onboarding/ca-05a03be30514956e1027558640f41626.json',"shopping-list/ca":'shopping-list/ca-69b46ff1a0ee7056c2c4ec2f822c524e.json'}},cs:{nativeName:'\u010Ce\u0161tina',fingerprints:{cs:'cs-27746b08e6c24af5253bf8896271aace.json',"config/cs":'config/cs-93a6a32eaa8e8fe58e915fce494be2cb.json',"history/cs":'history/cs-e07237794d0af2a097f6147a57d89f25.json',"logbook/cs":'logbook/cs-71286456ac7c7168f3c77285a98740d1.json',"mailbox/cs":'mailbox/cs-2ed76e6687045fbb46a0eaff96a7b15e.json',"page-authorize/cs":'page-authorize/cs-73917163e6689a8675ff538f218a36ff.json',"profile/cs":'profile/cs-c45fc1c09afd88878ae34611acf42b9c.json',"page-onboarding/cs":'page-onboarding/cs-5fc7718437501c5839fa3c23c6a2b1f9.json',"shopping-list/cs":'shopping-list/cs-f6b9ddea3b88b4441c688814e89c5d80.json'}},cy:{nativeName:'Cymraeg',fingerprints:{cy:'cy-c7699d081e51200fd1711827b1222c0e.json',"config/cy":'config/cy-1a6cd03829a46f076ef3a2891d84d55b.json',"history/cy":'history/cy-b2ef9a050371463a2881c0f8d4dab5af.json',"logbook/cy":'logbook/cy-48c12c541628ac18c74b5f277c4c87e8.json',"mailbox/cy":'mailbox/cy-170e5f1d136086aba8283acbdeef31ac.json',"page-authorize/cy":'page-authorize/cy-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/cy":'profile/cy-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/cy":'page-onboarding/cy-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/cy":'shopping-list/cy-69532d7d5274bc12c0e56a993e8526d7.json'}},da:{nativeName:'Dansk',fingerprints:{da:'da-d22e87943bb3f2232c7a3405c3ba89a5.json',"config/da":'config/da-d56684dd8165adac612416308f070f25.json',"history/da":'history/da-e9076a2d5e91c3778de3802b208e4205.json',"logbook/da":'logbook/da-f44c9ee9b78fa2a0619578dde04d2f12.json',"mailbox/da":'mailbox/da-4d8b449fed095727b7cac57c8259b598.json',"page-authorize/da":'page-authorize/da-239eb7e0240128745fdf3e40319fb447.json',"profile/da":'profile/da-acc8f31192467b769bcaf84927ace5ab.json',"page-onboarding/da":'page-onboarding/da-5458dc5d34e80c3e001cd5a1cd3ef9c6.json',"shopping-list/da":'shopping-list/da-702f5daf0b2e1464b0719fd252f32a56.json'}},de:{nativeName:'Deutsch',fingerprints:{de:'de-6dc09e17c854b5843391e6ed1400810d.json',"config/de":'config/de-a5cddf1597de3508f2a20579020f8073.json',"history/de":'history/de-4e70209d9cde408a3a51a351e24e04cb.json',"logbook/de":'logbook/de-5752cc1f692a8c60544fe19bfe9bd7df.json',"mailbox/de":'mailbox/de-006c408a6647fcb43c8364ee1928c1fb.json',"page-authorize/de":'page-authorize/de-1ede926dcab17a2e7741ea43edced843.json',"profile/de":'profile/de-724f90d1bf9e54c2cf368d5d8c7c4d35.json',"page-onboarding/de":'page-onboarding/de-2636d28557e69788b06559d3ff43bd8f.json',"shopping-list/de":'shopping-list/de-66db7a1493ed065e6cddec43d7f275c7.json'}},el:{nativeName:'\u0395\u03BB\u03BB\u03B7\u03BD\u03B9\u03BA\u03AC',fingerprints:{el:'el-d4b5b88446bf61f4470532bd3cb0e8dc.json',"config/el":'config/el-cf9e71f2264437184bbe7d386dce8b68.json',"history/el":'history/el-c731b6ed1707695bcc1efb80a969111b.json',"logbook/el":'logbook/el-b07eb85c848519cea034c3775b984ef7.json',"mailbox/el":'mailbox/el-5aff2968280fc37d9ed1081f0aa735d1.json',"page-authorize/el":'page-authorize/el-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/el":'profile/el-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/el":'page-onboarding/el-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/el":'shopping-list/el-ca53a02b4a4afd05878689eb7c1b0296.json'}},en:{nativeName:'English',fingerprints:{en:'en-afd91fa41e011079c982fb099cd35da0.json',"config/en":'config/en-b1964e16a45dd478ee2f2a1132d8e1a2.json',"history/en":'history/en-c731b6ed1707695bcc1efb80a969111b.json',"logbook/en":'logbook/en-b07eb85c848519cea034c3775b984ef7.json',"mailbox/en":'mailbox/en-5aff2968280fc37d9ed1081f0aa735d1.json',"page-authorize/en":'page-authorize/en-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/en":'profile/en-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/en":'page-onboarding/en-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/en":'shopping-list/en-ca53a02b4a4afd05878689eb7c1b0296.json'}},es:{nativeName:'Espa\xF1ol',fingerprints:{es:'es-8a81bd0c13bcf29a43a01a3fe135fd21.json',"config/es":'config/es-d4cb4bd0aeefdf49b1c6bb6441ad83de.json',"history/es":'history/es-226ee201175eecdbf6ea89087c23245f.json',"logbook/es":'logbook/es-434ada38337c52cee62abd18749d5063.json',"mailbox/es":'mailbox/es-a433ec9cfcd44224ba3baacc7a6a7b8d.json',"page-authorize/es":'page-authorize/es-521b5766f8a246ce389871edba6b9889.json',"profile/es":'profile/es-8abc169b82f0c062012596d87870b25a.json',"page-onboarding/es":'page-onboarding/es-c600a07f565d8adea0b2db156c064fcb.json',"shopping-list/es":'shopping-list/es-2a9d82cc1a2449787c14fa54f7354b7f.json'}},"es-419":{nativeName:'Espa\xF1ol (Latin America)',fingerprints:{"es-419":'es-419-dcddd05fa56261c82ea05f535367d533.json',"config/es-419":'config/es-419-efe3a5fd35c8b1b512596af11b39b889.json',"history/es-419":'history/es-419-0b9334fad5f7e132df381f65d368eba9.json',"logbook/es-419":'logbook/es-419-5bbf14be03c1685ef66d1dc39bc2d3c6.json',"mailbox/es-419":'mailbox/es-419-57ef0dbc5bb678c6aa53b461ae1c22b0.json',"page-authorize/es-419":'page-authorize/es-419-9564bb25ea4ee96a4af11ba540e586fb.json',"profile/es-419":'profile/es-419-93c52e7cac956e1ea02ac69af538738b.json',"page-onboarding/es-419":'page-onboarding/es-419-1450c627f55e7c7ba6f37d772ecb93e6.json',"shopping-list/es-419":'shopping-list/es-419-a04dc8ec5ae6217c186870e22188afda.json'}},et:{nativeName:'Eesti',fingerprints:{et:'et-c729cebfb0b45df3e2937ca13ec1bf13.json',"config/et":'config/et-735b61c7d50ebca6f19914843f85fdcf.json',"history/et":'history/et-e0b32c59ee85d22af6ff83da8864b616.json',"logbook/et":'logbook/et-054d9192516445961b8dd4ff611caf3a.json',"mailbox/et":'mailbox/et-63c257f3ad39805f75d945f45eeaae60.json',"page-authorize/et":'page-authorize/et-193082f593b69602d781143c7ad59adf.json',"profile/et":'profile/et-8dac28916a1e6fc75ede726b7d5ea1c9.json',"page-onboarding/et":'page-onboarding/et-dcd09c6612d83a200116ad2b8c082316.json',"shopping-list/et":'shopping-list/et-64a31b482eefdc4a8e9dd32ef2aae2cb.json'}},fa:{nativeName:'\u0641\u0627\u0631\u0633\u06CC',fingerprints:{fa:'fa-11c9632cada7fbc7eb3e735c3a45d36a.json',"config/fa":'config/fa-b1964e16a45dd478ee2f2a1132d8e1a2.json',"history/fa":'history/fa-c731b6ed1707695bcc1efb80a969111b.json',"logbook/fa":'logbook/fa-b07eb85c848519cea034c3775b984ef7.json',"mailbox/fa":'mailbox/fa-5aff2968280fc37d9ed1081f0aa735d1.json',"page-authorize/fa":'page-authorize/fa-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/fa":'profile/fa-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/fa":'page-onboarding/fa-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/fa":'shopping-list/fa-ca53a02b4a4afd05878689eb7c1b0296.json'}},fi:{nativeName:'Suomi',fingerprints:{fi:'fi-27bc10eb1bd9c763e52362ba2fab0fe8.json',"config/fi":'config/fi-51c36d21874e3b80561e9030ece84ed6.json',"history/fi":'history/fi-e7e4431a7db0bdd44f549bc29c0e6f24.json',"logbook/fi":'logbook/fi-dd92fc2f1b03861f42aaf31d020c4e1e.json',"mailbox/fi":'mailbox/fi-49f8386cb5b55ecb49fb76689a824d33.json',"page-authorize/fi":'page-authorize/fi-f2457f641cba5a8b68177e5f26425f5b.json',"profile/fi":'profile/fi-77d4df17d888b84f5f9978d2d21175ef.json',"page-onboarding/fi":'page-onboarding/fi-55e94164673949e921ce5dcbc0476f17.json',"shopping-list/fi":'shopping-list/fi-a36879e4a85dc2185f019f96da031dd3.json'}},fr:{nativeName:'Fran\xE7ais',fingerprints:{fr:'fr-e98810310a049050f1f2e02c711c08c3.json',"config/fr":'config/fr-a52828640388f8b3a73d40aa8f1c90be.json',"history/fr":'history/fr-0b24b7c275f06453f29734162c368b43.json',"logbook/fr":'logbook/fr-7ef24388ac0189bae0d35bb2eb1cc61c.json',"mailbox/fr":'mailbox/fr-9fafe1aada8f0c87a7697f5654791df0.json',"page-authorize/fr":'page-authorize/fr-c19829da6cde464b62ee481b36d4f493.json',"profile/fr":'profile/fr-4e73f55514531a09d9d5106563632a45.json',"page-onboarding/fr":'page-onboarding/fr-e073d6ca33d767fefcbded274c85232e.json',"shopping-list/fr":'shopping-list/fr-c68102bb021a2461f2daad53cf3e3857.json'}},gsw:{nativeName:'Schwiizerd\xFCtsch',fingerprints:{gsw:'gsw-1626bae936342c57fccbfa3e09a45a08.json',"config/gsw":'config/gsw-e45c2211c61aa253805ab992fb1593a6.json',"history/gsw":'history/gsw-8b0c8ba7dc48ae286346c2eaa74b1d40.json',"logbook/gsw":'logbook/gsw-b07eb85c848519cea034c3775b984ef7.json',"mailbox/gsw":'mailbox/gsw-5ed68a37a357fb93b437016049448ca1.json',"page-authorize/gsw":'page-authorize/gsw-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/gsw":'profile/gsw-9bbdebd6388a8b1c1bb0ad01d388d606.json',"page-onboarding/gsw":'page-onboarding/gsw-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/gsw":'shopping-list/gsw-ca53a02b4a4afd05878689eb7c1b0296.json'}},he:{nativeName:'\u05E2\u05D1\u05E8\u05D9\u05EA',isRTL:!0,fingerprints:{he:'he-e9c44545caebb39467a15be6957db78d.json',"config/he":'config/he-bbcf659432c8d16dd079f774848be264.json',"history/he":'history/he-49cd035460062b9e557610fae6f57c59.json',"logbook/he":'logbook/he-384551dbb56e5bf24de12252f9bf2f09.json',"mailbox/he":'mailbox/he-cce3340751d5ef5a30f36ed4be404a9e.json',"page-authorize/he":'page-authorize/he-6845eb705b127dfcd9764c25a6892402.json',"profile/he":'profile/he-6fc45d75032de7f4566ec106d6937212.json',"page-onboarding/he":'page-onboarding/he-2727da626e5e7e35366f76b1666f8127.json',"shopping-list/he":'shopping-list/he-587c419016a4fdb1b51dcb80f7f47d7a.json'}},hi:{nativeName:'\u0939\u093F\u0928\u094D\u0926\u0940',fingerprints:{hi:'hi-00918e4974aa29ec476841b72afd5ec0.json',"config/hi":'config/hi-cdfec53e050cbbe1b95582d3303eaa06.json',"history/hi":'history/hi-c731b6ed1707695bcc1efb80a969111b.json',"logbook/hi":'logbook/hi-b07eb85c848519cea034c3775b984ef7.json',"mailbox/hi":'mailbox/hi-5aff2968280fc37d9ed1081f0aa735d1.json',"page-authorize/hi":'page-authorize/hi-74c6836842fe8a9130177bff49c53162.json',"profile/hi":'profile/hi-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/hi":'page-onboarding/hi-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/hi":'shopping-list/hi-4c32ab06d6ce6256151be30ecbf8c630.json'}},hr:{nativeName:'Hrvatski',fingerprints:{hr:'hr-7604595c5c4cabdf7b2a905a1f467cf0.json',"config/hr":'config/hr-211c9260cf4e9c04646a76aed99dd614.json',"history/hr":'history/hr-c182fbf1b355504eb0c84a2f5e77cb95.json',"logbook/hr":'logbook/hr-cb6a4f072a4fa96f03e1745b2c45b9ed.json',"mailbox/hr":'mailbox/hr-1a9e32096cfb1e047e596bea7da02d70.json',"page-authorize/hr":'page-authorize/hr-2de5cb2ac94cbdd313b95d97a535db49.json',"profile/hr":'profile/hr-b5874c8b62921440dc547c0c58637f3f.json',"page-onboarding/hr":'page-onboarding/hr-b6dd1f1fd3dcc3c5f36603cbf572bb0f.json',"shopping-list/hr":'shopping-list/hr-4543c6cd4a2ca7ff4942cd421d950834.json'}},hu:{nativeName:'Magyar',fingerprints:{hu:'hu-20c7d5dc1ebb2cc1d3773c594c299d46.json',"config/hu":'config/hu-67f6a696c8b16ac4db892175e1567367.json',"history/hu":'history/hu-06ef9d6733e357ad1da57341ebf26098.json',"logbook/hu":'logbook/hu-8faf97598ee25f9b2128e3fa64776da4.json',"mailbox/hu":'mailbox/hu-e9d9f2449f6dfce9915bb7a6fe9b2ca1.json',"page-authorize/hu":'page-authorize/hu-c771130a24cd972f7eb98e479f470d42.json',"profile/hu":'profile/hu-4ef4b8a828c0f7352defc86df53b8ef9.json',"page-onboarding/hu":'page-onboarding/hu-83026f7d2ccc3091117b46cb96b0b726.json',"shopping-list/hu":'shopping-list/hu-196bd35532e272d5e0379f13dc31a1bc.json'}},id:{nativeName:'Indonesia',fingerprints:{id:'id-ad9e187bc40d456c5e563038609d6b3f.json',"config/id":'config/id-e63d115f1ddee17e28aea7c1da4d3a69.json',"history/id":'history/id-7b37f4ee3e9add21bb93adc63d195714.json',"logbook/id":'logbook/id-6ba68161a9ef409c1d7263aba782a3c6.json',"mailbox/id":'mailbox/id-cd7c3903174a68f27c9c8f88e3b1f257.json',"page-authorize/id":'page-authorize/id-e28a41d44b737c52fb8e47128bf319b6.json',"profile/id":'profile/id-726b150aa3f524dc2577769ca580eab4.json',"page-onboarding/id":'page-onboarding/id-f63083db13689dbdb7438a31e7b873f9.json',"shopping-list/id":'shopping-list/id-6f74f6f88ef230410479dcf498502f6a.json'}},it:{nativeName:'Italiano',fingerprints:{it:'it-f697041b761af0d8eccc42481f57ea9e.json',"config/it":'config/it-f9f43318ee409b4169e527154bd81050.json',"history/it":'history/it-a57d42a25333e44fcdda0c67da6246ab.json',"logbook/it":'logbook/it-a35171ccb4167076b851842bdcd59de9.json',"mailbox/it":'mailbox/it-c6d36cf8d8edba59cbba7360d385a9ff.json',"page-authorize/it":'page-authorize/it-db2b17c5d9972f838a6529119bf49cf9.json',"profile/it":'profile/it-21e9640e01aa27f3d3152f40eeac2c0f.json',"page-onboarding/it":'page-onboarding/it-631c0955a3db7f0e6b8c3dbe8b3c82c8.json',"shopping-list/it":'shopping-list/it-f5bd42a49a13e20db7149a9652b9f826.json'}},ja:{nativeName:'\u65E5\u672C\u8A9E',fingerprints:{ja:'ja-1f9c4c831316cff1fe01be5d2741d005.json',"config/ja":'config/ja-af7c0cbade69275bec5fd7253af7269f.json',"history/ja":'history/ja-fadc13765031920127c8f7f89b36562b.json',"logbook/ja":'logbook/ja-b07eb85c848519cea034c3775b984ef7.json',"mailbox/ja":'mailbox/ja-a7e1c1873579d1b68106ccb7c5fb1eab.json',"page-authorize/ja":'page-authorize/ja-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/ja":'profile/ja-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/ja":'page-onboarding/ja-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/ja":'shopping-list/ja-9987d984eca7128b156b9994208cb017.json'}},ko:{nativeName:'\uD55C\uAD6D\uC5B4',fingerprints:{ko:'ko-4feb7fc41752532db1fcebf9233fef17.json',"config/ko":'config/ko-99010c97e72719eec2fceb91f59febbd.json',"history/ko":'history/ko-2466cf47aa80071419940ebbd584af66.json',"logbook/ko":'logbook/ko-c86725c58285d74fd92726dc64331bfd.json',"mailbox/ko":'mailbox/ko-6243fbc81dd684d7aae64ee321b5c291.json',"page-authorize/ko":'page-authorize/ko-a42f4f3e1c93f6c2681a7c710232061f.json',"profile/ko":'profile/ko-f76ea3e8ec0fb271fcdfa2c03f2ac942.json',"page-onboarding/ko":'page-onboarding/ko-8d828d8651c10e9f682dfe9febeb0171.json',"shopping-list/ko":'shopping-list/ko-0cb2778002db711a0336fc24489fb2ee.json'}},lb:{nativeName:'L\xEBtzebuergesch',fingerprints:{lb:'lb-3a4d225eb21074a9b3fa9c915cd37a17.json',"config/lb":'config/lb-eeff61f14ed579dea8807e5788f9e437.json',"history/lb":'history/lb-b8871044bfee9a774b4c95c9c658c850.json',"logbook/lb":'logbook/lb-d0ee7c36c887b42e7a5e296e08e76291.json',"mailbox/lb":'mailbox/lb-801d3c9dae52237d2999d51a5fc3215a.json',"page-authorize/lb":'page-authorize/lb-40ed4e5a92ac8fb26766ea2c4c93d517.json',"profile/lb":'profile/lb-5b45ea71d6a9fa3ef30dece9dbf3ae66.json',"page-onboarding/lb":'page-onboarding/lb-5ba2e60e0d2e2a14b2f0a3b5c05f47f9.json',"shopping-list/lb":'shopping-list/lb-5b789da9cada841ec3f730afa9518b03.json'}},lt:{nativeName:'Lietuvi\u0173',fingerprints:{lt:'lt-1eae67105955e5faf150c8f629ca5e8d.json',"config/lt":'config/lt-17dabbaacfb941b259160b38cd130b89.json',"history/lt":'history/lt-c731b6ed1707695bcc1efb80a969111b.json',"logbook/lt":'logbook/lt-b07eb85c848519cea034c3775b984ef7.json',"mailbox/lt":'mailbox/lt-5aff2968280fc37d9ed1081f0aa735d1.json',"page-authorize/lt":'page-authorize/lt-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/lt":'profile/lt-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/lt":'page-onboarding/lt-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/lt":'shopping-list/lt-ca53a02b4a4afd05878689eb7c1b0296.json'}},lv:{nativeName:'Latvie\u0161u',fingerprints:{lv:'lv-8967e828b7f499b497476ad640a0eaa4.json',"config/lv":'config/lv-bdc1d593bd8f5178e3f43cf6becfe6d7.json',"history/lv":'history/lv-34028a79910f6759d7f1e62c2bd5b464.json',"logbook/lv":'logbook/lv-2068b29ac1f95fc8298276a6561f4599.json',"mailbox/lv":'mailbox/lv-10cab8d4e971dcc1b8edf9195acd5cca.json',"page-authorize/lv":'page-authorize/lv-4cc0955c01774b7a96c39504c919c2f3.json',"profile/lv":'profile/lv-86b9d7dbdfa0d4fa54602b63a9961fbe.json',"page-onboarding/lv":'page-onboarding/lv-fe9407279dfbfa83a7dd1dc845ab365a.json',"shopping-list/lv":'shopping-list/lv-211a209455331b12902eb24c2224a163.json'}},nl:{nativeName:'Nederlands',fingerprints:{nl:'nl-4e465ab3eb0b326a4c42409aa3546585.json',"config/nl":'config/nl-1be7b414d0f2ce9dfd0f3dab925cb564.json',"history/nl":'history/nl-2f0af34bf917f4dc9b3d7616e77ad55a.json',"logbook/nl":'logbook/nl-193f2d931f9035bb40b717cbdb97dac5.json',"mailbox/nl":'mailbox/nl-210a1f8fbb03d58f2b613e9aa6680e1d.json',"page-authorize/nl":'page-authorize/nl-84c8d95c508033bfd3bced50627a9bf6.json',"profile/nl":'profile/nl-612176865da8a712bbdb959fc183dc8a.json',"page-onboarding/nl":'page-onboarding/nl-13d6b65f0a9fb370ffd6a5ce5b7120f8.json',"shopping-list/nl":'shopping-list/nl-ca5bc361b3ac6fac0ca10b563deef4c3.json'}},nn:{nativeName:'Norsk Nynorsk',fingerprints:{nn:'nn-6909e60501e26917ca878f55412f734c.json',"config/nn":'config/nn-06a9636d09fd6090fde91134f372d07f.json',"history/nn":'history/nn-2230534a5f094ddcd802defaa43e8c82.json',"logbook/nn":'logbook/nn-2d0f82e5a8a41e32f4b8e58ce1b17f0a.json',"mailbox/nn":'mailbox/nn-2364a2d6904287efa0748d2c6010cd01.json',"page-authorize/nn":'page-authorize/nn-726eb079f40131e5e69ed266a87fef54.json',"profile/nn":'profile/nn-e81ec7b73ff8a98b8e2ff6b5a6b3d4ba.json',"page-onboarding/nn":'page-onboarding/nn-a8c064f8a558ab57605777b4ab81450e.json',"shopping-list/nn":'shopping-list/nn-005a84e9ee0a55bb7bab0034fa1393d8.json'}},no:{nativeName:'Norsk',fingerprints:{no:'no-b1cb68b15cccb889275f91a292ad47eb.json',"config/no":'config/no-3d1072f914033efda0b87979e76e55c2.json',"history/no":'history/no-2230534a5f094ddcd802defaa43e8c82.json',"logbook/no":'logbook/no-2d0f82e5a8a41e32f4b8e58ce1b17f0a.json',"mailbox/no":'mailbox/no-29e7765930ebdaec095388ecc12da788.json',"page-authorize/no":'page-authorize/no-ec6265e4d37c5bf103f9cf4253d11164.json',"profile/no":'profile/no-43fd76ddd60fe1aaf1f732a8cdbc0481.json',"page-onboarding/no":'page-onboarding/no-3e39b407d9e4f8872f53d3fa0fc0db68.json',"shopping-list/no":'shopping-list/no-0120da05c8e86cd9534d7ab696b27105.json'}},pl:{nativeName:'Polski',fingerprints:{pl:'pl-0796e28a982839b0357f7d7910075cfd.json',"config/pl":'config/pl-0db19862682225e54a6aeb146331ce65.json',"history/pl":'history/pl-72f2213cce350d37f290ebe304209d30.json',"logbook/pl":'logbook/pl-4097b5f9b150544a6b8993eb02295550.json',"mailbox/pl":'mailbox/pl-0f0be50366398fee52145e41637ad796.json',"page-authorize/pl":'page-authorize/pl-43f5409be7d1a80fbc470b8c7ecd1506.json',"profile/pl":'profile/pl-9e76cdcf18c483d62822d6c359a1a5b2.json',"page-onboarding/pl":'page-onboarding/pl-d257867570f4a54980ef93d2172d8cbe.json',"shopping-list/pl":'shopping-list/pl-3938b0e56c5b8a49233a6130217b29cc.json'}},pt:{nativeName:'Portugu\xEAs',fingerprints:{pt:'pt-1c66c86dff13b70dff4b952bcc98a179.json',"config/pt":'config/pt-b800d6144a2b8219c905c60398698a0e.json',"history/pt":'history/pt-fb0badd7a412af3b7339100c68100277.json',"logbook/pt":'logbook/pt-ce1816be46801d4b46c014076017f278.json',"mailbox/pt":'mailbox/pt-b14eadb11a749aa0ad2cf8ccce99bcb5.json',"page-authorize/pt":'page-authorize/pt-42bfcfc5fe0e600475ebc659f866a1b7.json',"profile/pt":'profile/pt-83475114b7fa00f6cfb6ae2fbbecfe24.json',"page-onboarding/pt":'page-onboarding/pt-8da0908c1a95368b1cfd90b0c3313339.json',"shopping-list/pt":'shopping-list/pt-b21bc5c7812437480ff662e258c6f528.json'}},"pt-BR":{nativeName:'Portugu\xEAs (BR)',fingerprints:{"pt-BR":'pt-BR-e8307f95e1de66d8a0a95e1630c34b37.json',"config/pt-BR":'config/pt-BR-2b6b214bfd73f8bc50cd1f92500c34f1.json',"history/pt-BR":'history/pt-BR-dcb3ed0df9f0274867b234a0fc321bdc.json',"logbook/pt-BR":'logbook/pt-BR-b737a57855bd14021c331693f815180c.json',"mailbox/pt-BR":'mailbox/pt-BR-273bfb5134c8f7e2a46159545223f56d.json',"page-authorize/pt-BR":'page-authorize/pt-BR-a26de58a789801473e3d19ae6c61b922.json',"profile/pt-BR":'profile/pt-BR-f30c33df1490afef62e35c0dca100a6e.json',"page-onboarding/pt-BR":'page-onboarding/pt-BR-a8ade1d0ebb2be8f620c44143d2132ae.json',"shopping-list/pt-BR":'shopping-list/pt-BR-0f097f6f81a88450a689ec18fd23675e.json'}},ro:{nativeName:'Rom\xE2n\u0103',fingerprints:{ro:'ro-f82a45a9ebeeba8f4a88e6354abf748c.json',"config/ro":'config/ro-110c6468a78eb4f2990fcc43adda7988.json',"history/ro":'history/ro-c17411a8f8c277de93ad0b1d7c923f82.json',"logbook/ro":'logbook/ro-a45769083a581b4fadc615e22316a371.json',"mailbox/ro":'mailbox/ro-caa8cd0ef2a22a5c6690140906b6a369.json',"page-authorize/ro":'page-authorize/ro-140f9508d1b05354b65e3682ce22f413.json',"profile/ro":'profile/ro-5367d607cebea4df68e0ca1df9ead7cd.json',"page-onboarding/ro":'page-onboarding/ro-4e02daacd72fd9c645fc1cacf4c5dcf0.json',"shopping-list/ro":'shopping-list/ro-9c9fc52be99ef3d62e95dc5316bf0fb9.json'}},ru:{nativeName:'\u0420\u0443\u0441\u0441\u043A\u0438\u0439',fingerprints:{ru:'ru-dd7fb0528064716aa4eeeafbb76620c4.json',"config/ru":'config/ru-cf59a931a7ca04a8742d3b5100f302a5.json',"history/ru":'history/ru-906a6a5a183855d33a639cd2eebf466b.json',"logbook/ru":'logbook/ru-fb94348c8224938560c43fb56dfce9a3.json',"mailbox/ru":'mailbox/ru-8fb6ee3e5ab59205aad1bf755635ad91.json',"page-authorize/ru":'page-authorize/ru-0e85b1efd8cc6daa63cdc572e78b7a66.json',"profile/ru":'profile/ru-87f514bb974d86208902d84db3aef7ea.json',"page-onboarding/ru":'page-onboarding/ru-44ccacb9376195e90c229e6c746a211d.json',"shopping-list/ru":'shopping-list/ru-7f81258e65befd495c2eb9b4b267549a.json'}},sk:{nativeName:'Sloven\u010Dina',fingerprints:{sk:'sk-92968c1d588dde49416f1f59ddd375d0.json',"config/sk":'config/sk-fc17ab59f3c8de8795d5a5d16ebc2911.json',"history/sk":'history/sk-03c3f4f5bb212cc6edcc7c74b8099c2d.json',"logbook/sk":'logbook/sk-94cc76b1947285f50e82e8c58f344baa.json',"mailbox/sk":'mailbox/sk-03dd52673830e64d96ded1844f650f67.json',"page-authorize/sk":'page-authorize/sk-219ffb491a05cc36b1012e326b96929f.json',"profile/sk":'profile/sk-16fbb7ab9ae6801066d7732e7553ece6.json',"page-onboarding/sk":'page-onboarding/sk-572ceff12f0aa54bba1f84f90fd37808.json',"shopping-list/sk":'shopping-list/sk-a7e9bcccd3f24423b7e07d38571283e4.json'}},sl:{nativeName:'Sloven\u0161\u010Dina',fingerprints:{sl:'sl-93fbb5db7923416e6320f012c0c20598.json',"config/sl":'config/sl-0d58397cff23a121d882ee9d783d0e62.json',"history/sl":'history/sl-f4a805a9a1e80c3915ea6cc6cf069998.json',"logbook/sl":'logbook/sl-9d5d1e651c4aa37ea4c1132023947194.json',"mailbox/sl":'mailbox/sl-f631c03128838d256c86ecbde3d001fe.json',"page-authorize/sl":'page-authorize/sl-097e0dfd338dc712605138683d5b73f3.json',"profile/sl":'profile/sl-8b2597eed609777760ddf027d2910143.json',"page-onboarding/sl":'page-onboarding/sl-ab59ae62ef4e7b78cceb85052db6b09c.json',"shopping-list/sl":'shopping-list/sl-e87362effc0bcc1c7d8f10257e16a1ba.json'}},sr:{nativeName:'\u0421\u0440\u043F\u0441\u043A\u0438',fingerprints:{sr:'sr-12e6075fb004a244324b925e5dfb7151.json',"config/sr":'config/sr-b1964e16a45dd478ee2f2a1132d8e1a2.json',"history/sr":'history/sr-c731b6ed1707695bcc1efb80a969111b.json',"logbook/sr":'logbook/sr-b07eb85c848519cea034c3775b984ef7.json',"mailbox/sr":'mailbox/sr-5aff2968280fc37d9ed1081f0aa735d1.json',"page-authorize/sr":'page-authorize/sr-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/sr":'profile/sr-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/sr":'page-onboarding/sr-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/sr":'shopping-list/sr-ca53a02b4a4afd05878689eb7c1b0296.json'}},"sr-Latn":{nativeName:'Srpski',fingerprints:{"sr-Latn":'sr-Latn-2b3c23bdb2e18ebba11a118f9abb7d96.json',"config/sr-Latn":'config/sr-Latn-b28d94b071b81b8b4cf2e84392e456cd.json',"history/sr-Latn":'history/sr-Latn-c731b6ed1707695bcc1efb80a969111b.json',"logbook/sr-Latn":'logbook/sr-Latn-b07eb85c848519cea034c3775b984ef7.json',"mailbox/sr-Latn":'mailbox/sr-Latn-5aff2968280fc37d9ed1081f0aa735d1.json',"page-authorize/sr-Latn":'page-authorize/sr-Latn-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/sr-Latn":'profile/sr-Latn-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/sr-Latn":'page-onboarding/sr-Latn-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/sr-Latn":'shopping-list/sr-Latn-ca53a02b4a4afd05878689eb7c1b0296.json'}},sv:{nativeName:'Svenska',fingerprints:{sv:'sv-1e0238b1957483ede3d53416ff8df9f7.json',"config/sv":'config/sv-7728ecd7e6b065f2216c1fd22957bc4c.json',"history/sv":'history/sv-b96b275475b0a0c4dee3ff54df0067d1.json',"logbook/sv":'logbook/sv-5553ea49a9a7896a0871b45072260de0.json',"mailbox/sv":'mailbox/sv-78ed74aa52d4257d3955103040096b9c.json',"page-authorize/sv":'page-authorize/sv-dc6ce107917a5a455cce4886a2b9545d.json',"profile/sv":'profile/sv-f3efc5900d3182257d8bb35604788a93.json',"page-onboarding/sv":'page-onboarding/sv-16cc849e3511034389c6c3a92d15bcd6.json',"shopping-list/sv":'shopping-list/sv-e9e367b54d84567879457e7b03b13650.json'}},ta:{nativeName:'\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD',fingerprints:{ta:'ta-a3303c9d009641012631ba93395d4d90.json',"config/ta":'config/ta-b1964e16a45dd478ee2f2a1132d8e1a2.json',"history/ta":'history/ta-c731b6ed1707695bcc1efb80a969111b.json',"logbook/ta":'logbook/ta-b07eb85c848519cea034c3775b984ef7.json',"mailbox/ta":'mailbox/ta-5aff2968280fc37d9ed1081f0aa735d1.json',"page-authorize/ta":'page-authorize/ta-826f00442f67e7e3a3c0b8bf132af1cf.json',"profile/ta":'profile/ta-c01d42036a4038a3eebbcb957e50921e.json',"page-onboarding/ta":'page-onboarding/ta-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/ta":'shopping-list/ta-ca53a02b4a4afd05878689eb7c1b0296.json'}},te:{nativeName:'\u0C24\u0C46\u0C32\u0C41\u0C17\u0C41',fingerprints:{te:'te-1053d26246fb70a4c31db91a3269f78c.json',"config/te":'config/te-29999431668192deadb7246667e20382.json',"history/te":'history/te-c0a1510e01a60f52b96cf0246cd34378.json',"logbook/te":'logbook/te-b07eb85c848519cea034c3775b984ef7.json',"mailbox/te":'mailbox/te-f5310c3d729f2cbf7d3e933064c6cd5b.json',"page-authorize/te":'page-authorize/te-1c5008e2bd7db330c4e4b370f0606de9.json',"profile/te":'profile/te-0043259b8aa6eb0b2274ea33671807ed.json',"page-onboarding/te":'page-onboarding/te-c012be2321488d1537ecc338bfe901b6.json',"shopping-list/te":'shopping-list/te-1ca1011342a53a93721a688b1ed97f6a.json'}},th:{nativeName:'\u0E20\u0E32\u0E29\u0E32\u0E44\u0E17\u0E22',fingerprints:{th:'th-ae61356e8a100d4f55e2b0db9b7fffc7.json',"config/th":'config/th-087f777577190736e282cda63b62250b.json',"history/th":'history/th-298be0c35cf5810ffbd6e14fb7f50951.json',"logbook/th":'logbook/th-d14495faad823da38343cf6a8af375f4.json',"mailbox/th":'mailbox/th-869e0f55f3081bd9a2de44a2518cd650.json',"page-authorize/th":'page-authorize/th-8aedd28cc06c7a27eef8a6be2fe6a604.json',"profile/th":'profile/th-46e3c0142ea81ac58936b2d382ba59df.json',"page-onboarding/th":'page-onboarding/th-095f9c44c0f7d6641b445dcff477db73.json',"shopping-list/th":'shopping-list/th-fed900d3b50ce1d35b02acc3026a7c83.json'}},tr:{nativeName:'T\xFCrk\xE7e',fingerprints:{tr:'tr-8dd2b62519ebf8d016b91212b7f1ee12.json',"config/tr":'config/tr-d58ba0a78859040ea5c288043011d9b8.json',"history/tr":'history/tr-c8a856bfaa267fa040fe8547808d4d8e.json',"logbook/tr":'logbook/tr-d5f8fbe9ec58185f449a1a7e897754e0.json',"mailbox/tr":'mailbox/tr-3918cdf8be7e5fd02936f2099b71adfd.json',"page-authorize/tr":'page-authorize/tr-07e2702cf853f68689f27e241e8dafdb.json',"profile/tr":'profile/tr-1458d53490a23c8e93016db2b0aa4767.json',"page-onboarding/tr":'page-onboarding/tr-871929d57acf59d70b5c1e17e4c0c7bc.json',"shopping-list/tr":'shopping-list/tr-e92e36d196d384475b21f4d4a945b30c.json'}},uk:{nativeName:'\u0423\u043A\u0440\u0430\u0457\u043D\u0441\u044C\u043A\u0430',fingerprints:{uk:'uk-160b0c14caf58fc582723843bb7132be.json',"config/uk":'config/uk-f55602d218be1aea5b6ead3c744a0273.json',"history/uk":'history/uk-ae9c488d8d86b4a42d24a2cc3083ec63.json',"logbook/uk":'logbook/uk-f886b2b41a150e7929ea643f842ea4e0.json',"mailbox/uk":'mailbox/uk-159332b3084bdb5577c9d1601c32f0c8.json',"page-authorize/uk":'page-authorize/uk-7b28d97742cc5785a46dac4fd2afb73a.json',"profile/uk":'profile/uk-9ec711c1b67c44eacb85070edc75b580.json',"page-onboarding/uk":'page-onboarding/uk-dd140b08da56ec73b48e43a3ec8347fe.json',"shopping-list/uk":'shopping-list/uk-44a4e5a2b14605dee5e0f50ef2c3c16a.json'}},vi:{nativeName:'Ti\u1EBFng Vi\u1EC7t',fingerprints:{vi:'vi-30ec477cc76d4ebe6b3c390ae62082c7.json',"config/vi":'config/vi-1f478f7daa0750e5074b960ed4ab7da7.json',"history/vi":'history/vi-d4b4e0f5c070be096ff57fd986ca7f46.json',"logbook/vi":'logbook/vi-dceb9ba3c916f7d033975ea4168cff5c.json',"mailbox/vi":'mailbox/vi-72716b644c2b813127cfc012a070b634.json',"page-authorize/vi":'page-authorize/vi-aa1668eeab3cdf45dfb8393db06906c3.json',"profile/vi":'profile/vi-14698a8bb5c5c954d815a458e582de25.json',"page-onboarding/vi":'page-onboarding/vi-39b03877d4aa696e4ca3529e5f0948ae.json',"shopping-list/vi":'shopping-list/vi-53808ddc1e8af830db9095fa1440a3ac.json'}},"zh-Hans":{nativeName:'\u7B80\u4F53\u4E2D\u6587',fingerprints:{"zh-Hans":'zh-Hans-e74726b99297fe639365e2cd94e81d00.json',"config/zh-Hans":'config/zh-Hans-6dc06d8b3425a124aa2cdafa55e7a1b3.json',"history/zh-Hans":'history/zh-Hans-5227a7eba9c5e4fb74100a0a328ba6bb.json',"logbook/zh-Hans":'logbook/zh-Hans-46e45be07db4c81551ec0707dd5ea9cb.json',"mailbox/zh-Hans":'mailbox/zh-Hans-c63f0f03c4095d7df8e82d649f2a9670.json',"page-authorize/zh-Hans":'page-authorize/zh-Hans-781ff893affa7004f589ae7eba138dfb.json',"profile/zh-Hans":'profile/zh-Hans-90f164be41117883469338572697432f.json',"page-onboarding/zh-Hans":'page-onboarding/zh-Hans-e5127f87a6dee4cb34e2b20d83e72b25.json',"shopping-list/zh-Hans":'shopping-list/zh-Hans-78ae21891e187b85f1f73effc7ab8278.json'}},"zh-Hant":{nativeName:'\u7E41\u9AD4\u4E2D\u6587',fingerprints:{"zh-Hant":'zh-Hant-15ff4bc89ef36cd59b5fd21b20d7a2f1.json',"config/zh-Hant":'config/zh-Hant-9810380f163589d0b675f8953126c030.json',"history/zh-Hant":'history/zh-Hant-18ee37b23fa0fe3191e440ddfcb00e89.json',"logbook/zh-Hant":'logbook/zh-Hant-b57422dc6e39179e4ca759f6c59320a1.json',"mailbox/zh-Hant":'mailbox/zh-Hant-ea296ec9aeefb095c6e6731f2c82c5bd.json',"page-authorize/zh-Hant":'page-authorize/zh-Hant-fdf375e29de245f91e96f3791faae8f4.json',"profile/zh-Hant":'profile/zh-Hant-cd5fb6d9c18b63fdc6f2925c60eb60e9.json',"page-onboarding/zh-Hant":'page-onboarding/zh-Hant-fce85a83f460ffc1661c71b0ef96af87.json',"shopping-list/zh-Hant":'shopping-list/zh-Hant-915da1656c131861ea98ae71de3395a5.json'}}}}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return GestureEventListeners});var _utils_boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_utils_mixin_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(5),_utils_gestures_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(25);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const GestureEventListeners=Object(_utils_mixin_js__WEBPACK_IMPORTED_MODULE_1__.a)(superClass=>{return class extends superClass{_addEventListenerToNode(node,eventName,handler){if(!Object(_utils_gestures_js__WEBPACK_IMPORTED_MODULE_2__.b)(node,eventName,handler)){super._addEventListenerToNode(node,eventName,handler)}}_removeEventListenerFromNode(node,eventName,handler){if(!Object(_utils_gestures_js__WEBPACK_IMPORTED_MODULE_2__.e)(node,eventName,handler)){super._removeEventListenerFromNode(node,eventName,handler)}}}})},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return PropertyAccessors});var _utils_boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_utils_mixin_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(5),_utils_case_map_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(15),_properties_changed_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(45);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const nativeProperties={};let proto=HTMLElement.prototype;while(proto){let props=Object.getOwnPropertyNames(proto);for(let i=0;i<props.length;i++){nativeProperties[props[i]]=!0}proto=Object.getPrototypeOf(proto)}function saveAccessorValue(model,property){if(!nativeProperties[property]){let value=model[property];if(value!==void 0){if(model.__data){model._setPendingProperty(property,value)}else{if(!model.__dataProto){model.__dataProto={}}else if(!model.hasOwnProperty(JSCompiler_renameProperty('__dataProto',model))){model.__dataProto=Object.create(model.__dataProto)}model.__dataProto[property]=value}}}}const PropertyAccessors=Object(_utils_mixin_js__WEBPACK_IMPORTED_MODULE_1__.a)(superClass=>{const base=Object(_properties_changed_js__WEBPACK_IMPORTED_MODULE_3__.a)(superClass);return class extends base{static createPropertiesForAttributes(){let a$=this.observedAttributes;for(let i=0;i<a$.length;i++){this.prototype._createPropertyAccessor(Object(_utils_case_map_js__WEBPACK_IMPORTED_MODULE_2__.b)(a$[i]))}}static attributeNameForProperty(property){return Object(_utils_case_map_js__WEBPACK_IMPORTED_MODULE_2__.a)(property)}_initializeProperties(){if(this.__dataProto){this._initializeProtoProperties(this.__dataProto);this.__dataProto=null}super._initializeProperties()}_initializeProtoProperties(props){for(let p in props){this._setProperty(p,props[p])}}_ensureAttribute(attribute,value){const el=this;if(!el.hasAttribute(attribute)){this._valueToNodeAttribute(el,value,attribute)}}_serializeValue(value){switch(typeof value){case'object':if(value instanceof Date){return value.toString()}else if(value){try{return JSON.stringify(value)}catch(x){return''}}default:return super._serializeValue(value);}}_deserializeValue(value,type){let outValue;switch(type){case Object:try{outValue=JSON.parse(value)}catch(x){outValue=value}break;case Array:try{outValue=JSON.parse(value)}catch(x){outValue=null;console.warn(`Polymer::Attributes: couldn't decode Array as JSON: ${value}`)}break;case Date:outValue=isNaN(value)?value+'':+value;outValue=new Date(outValue);break;default:outValue=super._deserializeValue(value,type);break;}return outValue}_definePropertyAccessor(property,readOnly){saveAccessorValue(this,property);super._definePropertyAccessor(property,readOnly)}_hasAccessor(property){return this.__dataHasAccessor&&this.__dataHasAccessor[property]}_isPropertyPending(prop){return!!(this.__dataPending&&prop in this.__dataPending)}}})},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return PropertiesChanged});var _utils_boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_utils_mixin_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(5),_utils_async_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(8);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const microtask=_utils_async_js__WEBPACK_IMPORTED_MODULE_2__.c,PropertiesChanged=Object(_utils_mixin_js__WEBPACK_IMPORTED_MODULE_1__.a)(superClass=>{return class extends superClass{static createProperties(props){const proto=this.prototype;for(let prop in props){if(!(prop in proto)){proto._createPropertyAccessor(prop)}}}static attributeNameForProperty(property){return property.toLowerCase()}static typeForProperty(){}_createPropertyAccessor(property,readOnly){this._addPropertyToAttributeMap(property);if(!this.hasOwnProperty('__dataHasAccessor')){this.__dataHasAccessor=Object.assign({},this.__dataHasAccessor)}if(!this.__dataHasAccessor[property]){this.__dataHasAccessor[property]=!0;this._definePropertyAccessor(property,readOnly)}}_addPropertyToAttributeMap(property){if(!this.hasOwnProperty('__dataAttributes')){this.__dataAttributes=Object.assign({},this.__dataAttributes)}if(!this.__dataAttributes[property]){const attr=this.constructor.attributeNameForProperty(property);this.__dataAttributes[attr]=property}}_definePropertyAccessor(property,readOnly){Object.defineProperty(this,property,{get(){return this._getProperty(property)},set:readOnly?function(){}:function(value){this._setProperty(property,value)}})}constructor(){super();this.__dataEnabled=!1;this.__dataReady=!1;this.__dataInvalid=!1;this.__data={};this.__dataPending=null;this.__dataOld=null;this.__dataInstanceProps=null;this.__serializing=!1;this._initializeProperties()}ready(){this.__dataReady=!0;this._flushProperties()}_initializeProperties(){for(let p in this.__dataHasAccessor){if(this.hasOwnProperty(p)){this.__dataInstanceProps=this.__dataInstanceProps||{};this.__dataInstanceProps[p]=this[p];delete this[p]}}}_initializeInstanceProperties(props){Object.assign(this,props)}_setProperty(property,value){if(this._setPendingProperty(property,value)){this._invalidateProperties()}}_getProperty(property){return this.__data[property]}_setPendingProperty(property,value){let old=this.__data[property],changed=this._shouldPropertyChange(property,value,old);if(changed){if(!this.__dataPending){this.__dataPending={};this.__dataOld={}}if(this.__dataOld&&!(property in this.__dataOld)){this.__dataOld[property]=old}this.__data[property]=value;this.__dataPending[property]=value}return changed}_invalidateProperties(){if(!this.__dataInvalid&&this.__dataReady){this.__dataInvalid=!0;microtask.run(()=>{if(this.__dataInvalid){this.__dataInvalid=!1;this._flushProperties()}})}}_enableProperties(){if(!this.__dataEnabled){this.__dataEnabled=!0;if(this.__dataInstanceProps){this._initializeInstanceProperties(this.__dataInstanceProps);this.__dataInstanceProps=null}this.ready()}}_flushProperties(){const props=this.__data,changedProps=this.__dataPending,old=this.__dataOld;if(this._shouldPropertiesChange(props,changedProps,old)){this.__dataPending=null;this.__dataOld=null;this._propertiesChanged(props,changedProps,old)}}_shouldPropertiesChange(currentProps,changedProps){return!!changedProps}_propertiesChanged(){}_shouldPropertyChange(property,value,old){return old!==value&&(old===old||value===value)}attributeChangedCallback(name,old,value,namespace){if(old!==value){this._attributeToProperty(name,value)}if(super.attributeChangedCallback){super.attributeChangedCallback(name,old,value,namespace)}}_attributeToProperty(attribute,value,type){if(!this.__serializing){const map=this.__dataAttributes,property=map&&map[attribute]||attribute;this[property]=this._deserializeValue(value,type||this.constructor.typeForProperty(property))}}_propertyToAttribute(property,attribute,value){this.__serializing=!0;value=3>arguments.length?this[property]:value;this._valueToNodeAttribute(this,value,attribute||this.constructor.attributeNameForProperty(property));this.__serializing=!1}_valueToNodeAttribute(node,value,attribute){const str=this._serializeValue(value);if(str===void 0){node.removeAttribute(attribute)}else{node.setAttribute(attribute,str)}}_serializeValue(value){switch(typeof value){case'boolean':return value?'':void 0;default:return null!=value?value.toString():void 0;}}_deserializeValue(value,type){switch(type){case Boolean:return null!==value;case Number:return+value;default:return value;}}}})},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return calculateSplices});__webpack_require__(6);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/function newSplice(index,removed,addedCount){return{index:index,removed:removed,addedCount:addedCount}}const EDIT_LEAVE=0,EDIT_UPDATE=1,EDIT_ADD=2,EDIT_DELETE=3;function calcEditDistances(current,currentStart,currentEnd,old,oldStart,oldEnd){let rowCount=oldEnd-oldStart+1,columnCount=currentEnd-currentStart+1,distances=Array(rowCount);for(let i=0;i<rowCount;i++){distances[i]=Array(columnCount);distances[i][0]=i}for(let j=0;j<columnCount;j++)distances[0][j]=j;for(let i=1;i<rowCount;i++){for(let j=1;j<columnCount;j++){if(equals(current[currentStart+j-1],old[oldStart+i-1]))distances[i][j]=distances[i-1][j-1];else{let north=distances[i-1][j]+1,west=distances[i][j-1]+1;distances[i][j]=north<west?north:west}}}return distances}function spliceOperationsFromEditDistances(distances){let i=distances.length-1,j=distances[0].length-1,current=distances[i][j],edits=[];while(0<i||0<j){if(0==i){edits.push(EDIT_ADD);j--;continue}if(0==j){edits.push(EDIT_DELETE);i--;continue}let northWest=distances[i-1][j-1],west=distances[i-1][j],north=distances[i][j-1],min;if(west<north)min=west<northWest?west:northWest;else min=north<northWest?north:northWest;if(min==northWest){if(northWest==current){edits.push(EDIT_LEAVE)}else{edits.push(EDIT_UPDATE);current=northWest}i--;j--}else if(min==west){edits.push(EDIT_DELETE);i--;current=west}else{edits.push(EDIT_ADD);j--;current=north}}edits.reverse();return edits}function calcSplices(current,currentStart,currentEnd,old,oldStart,oldEnd){let prefixCount=0,suffixCount=0,splice,minLength=Math.min(currentEnd-currentStart,oldEnd-oldStart);if(0==currentStart&&0==oldStart)prefixCount=sharedPrefix(current,old,minLength);if(currentEnd==current.length&&oldEnd==old.length)suffixCount=sharedSuffix(current,old,minLength-prefixCount);currentStart+=prefixCount;oldStart+=prefixCount;currentEnd-=suffixCount;oldEnd-=suffixCount;if(0==currentEnd-currentStart&&0==oldEnd-oldStart)return[];if(currentStart==currentEnd){splice=newSplice(currentStart,[],0);while(oldStart<oldEnd)splice.removed.push(old[oldStart++]);return[splice]}else if(oldStart==oldEnd)return[newSplice(currentStart,[],currentEnd-currentStart)];let ops=spliceOperationsFromEditDistances(calcEditDistances(current,currentStart,currentEnd,old,oldStart,oldEnd));splice=void 0;let splices=[],index=currentStart,oldIndex=oldStart;for(let i=0;i<ops.length;i++){switch(ops[i]){case EDIT_LEAVE:if(splice){splices.push(splice);splice=void 0}index++;oldIndex++;break;case EDIT_UPDATE:if(!splice)splice=newSplice(index,[],0);splice.addedCount++;index++;splice.removed.push(old[oldIndex]);oldIndex++;break;case EDIT_ADD:if(!splice)splice=newSplice(index,[],0);splice.addedCount++;index++;break;case EDIT_DELETE:if(!splice)splice=newSplice(index,[],0);splice.removed.push(old[oldIndex]);oldIndex++;break;}}if(splice){splices.push(splice)}return splices}function sharedPrefix(current,old,searchLength){for(let i=0;i<searchLength;i++)if(!equals(current[i],old[i]))return i;return searchLength}function sharedSuffix(current,old,searchLength){let index1=current.length,index2=old.length,count=0;while(count<searchLength&&equals(current[--index1],old[--index2]))count++;return count}function calculateSplices(current,previous){return calcSplices(current,0,current.length,previous,0,previous.length)}function equals(currentValue,previousValue){return currentValue===previousValue}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return IronMeta});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/class IronMeta{constructor(options){IronMeta[' '](options);this.type=options&&options.type||'default';this.key=options&&options.key;if(options&&'value'in options){this.value=options.value}}get value(){var type=this.type,key=this.key;if(type&&key){return IronMeta.types[type]&&IronMeta.types[type][key]}}set value(value){var type=this.type,key=this.key;if(type&&key){type=IronMeta.types[type]=IronMeta.types[type]||{};if(null==value){delete type[key]}else{type[key]=value}}}get list(){var type=this.type;if(type){var items=IronMeta.types[this.type];if(!items){return[]}return Object.keys(items).map(function(key){return metaDatas[this.type][key]},this)}}byKey(key){this.key=key;return this.value}}IronMeta[' ']=function(){};IronMeta.types={};var metaDatas=IronMeta.types;Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__.a)({is:'iron-meta',properties:{type:{type:String,value:'default'},key:{type:String},value:{type:String,notify:!0},self:{type:Boolean,observer:'_selfChanged'},__meta:{type:Boolean,computed:'__computeMeta(type, key, value)'}},hostAttributes:{hidden:!0},__computeMeta:function(type,key,value){var meta=new IronMeta({type:type,key:key});if(value!==void 0&&value!==meta.value){meta.value=value}else if(this.value!==meta.value){this.value=meta.value}return meta},get list(){return this.__meta&&this.__meta.list},_selfChanged:function(self){if(self){this.value=this}},byKey:function(key){return new IronMeta({type:this.type,key:key}).value}})},,,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_font_roboto_roboto_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(58),_polymer_font_roboto_roboto_js__WEBPACK_IMPORTED_MODULE_1___default=__webpack_require__.n(_polymer_font_roboto_roboto_js__WEBPACK_IMPORTED_MODULE_1__),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`<custom-style>
  <style is="custom-style">
    html {

      /* Shared Styles */
      --paper-font-common-base: {
        font-family: 'Roboto', 'Noto', sans-serif;
        -webkit-font-smoothing: antialiased;
      };

      --paper-font-common-code: {
        font-family: 'Roboto Mono', 'Consolas', 'Menlo', monospace;
        -webkit-font-smoothing: antialiased;
      };

      --paper-font-common-expensive-kerning: {
        text-rendering: optimizeLegibility;
      };

      --paper-font-common-nowrap: {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      };

      /* Material Font Styles */

      --paper-font-display4: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 112px;
        font-weight: 300;
        letter-spacing: -.044em;
        line-height: 120px;
      };

      --paper-font-display3: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 56px;
        font-weight: 400;
        letter-spacing: -.026em;
        line-height: 60px;
      };

      --paper-font-display2: {
        @apply --paper-font-common-base;

        font-size: 45px;
        font-weight: 400;
        letter-spacing: -.018em;
        line-height: 48px;
      };

      --paper-font-display1: {
        @apply --paper-font-common-base;

        font-size: 34px;
        font-weight: 400;
        letter-spacing: -.01em;
        line-height: 40px;
      };

      --paper-font-headline: {
        @apply --paper-font-common-base;

        font-size: 24px;
        font-weight: 400;
        letter-spacing: -.012em;
        line-height: 32px;
      };

      --paper-font-title: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 20px;
        font-weight: 500;
        line-height: 28px;
      };

      --paper-font-subhead: {
        @apply --paper-font-common-base;

        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
      };

      --paper-font-body2: {
        @apply --paper-font-common-base;

        font-size: 14px;
        font-weight: 500;
        line-height: 24px;
      };

      --paper-font-body1: {
        @apply --paper-font-common-base;

        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
      };

      --paper-font-caption: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 12px;
        font-weight: 400;
        letter-spacing: 0.011em;
        line-height: 20px;
      };

      --paper-font-menu: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 13px;
        font-weight: 500;
        line-height: 24px;
      };

      --paper-font-button: {
        @apply --paper-font-common-base;
        @apply --paper-font-common-nowrap;

        font-size: 14px;
        font-weight: 500;
        letter-spacing: 0.018em;
        line-height: 24px;
        text-transform: uppercase;
      };

      --paper-font-code2: {
        @apply --paper-font-common-code;

        font-size: 14px;
        font-weight: 700;
        line-height: 20px;
      };

      --paper-font-code1: {
        @apply --paper-font-common-code;

        font-size: 14px;
        font-weight: 500;
        line-height: 20px;
      };

    }

  </style>
</custom-style>`;template.setAttribute('style','display: none;');document.head.appendChild(template.content)},,function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return IronFormElementBehavior});__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronFormElementBehavior={properties:{name:{type:String},value:{notify:!0,type:String},required:{type:Boolean,value:!1}},attached:function(){},detached:function(){}}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return IronValidatableBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_meta_iron_meta_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(47);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/let IronValidatableBehaviorMeta=null;const IronValidatableBehavior={properties:{validator:{type:String},invalid:{notify:!0,reflectToAttribute:!0,type:Boolean,value:!1,observer:'_invalidChanged'}},registered:function(){IronValidatableBehaviorMeta=new _polymer_iron_meta_iron_meta_js__WEBPACK_IMPORTED_MODULE_1__.a({type:'validator'})},_invalidChanged:function(){if(this.invalid){this.setAttribute('aria-invalid','true')}else{this.removeAttribute('aria-invalid')}},get _validator(){return IronValidatableBehaviorMeta&&IronValidatableBehaviorMeta.byKey(this.validator)},hasValidator:function(){return null!=this._validator},validate:function(value){if(value===void 0&&this.value!==void 0)this.invalid=!this._getValidity(this.value);else this.invalid=!this._getValidity(value);return!this.invalid},_getValidity:function(value){if(this.hasValidator()){return this._validator.validate(value)}return!0}}},function(module,__webpack_exports__,__webpack_require__){'use strict';/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let readyPromise=null,whenReady=window.HTMLImports&&window.HTMLImports.whenReady||null,resolveFn;function documentWait(callback){requestAnimationFrame(function(){if(whenReady){whenReady(callback)}else{if(!readyPromise){readyPromise=new Promise(resolve=>{resolveFn=resolve});if('complete'===document.readyState){resolveFn()}else{document.addEventListener('readystatechange',()=>{if('complete'===document.readyState){resolveFn()}})}}readyPromise.then(function(){callback&&callback()})}})}__webpack_require__.d(__webpack_exports__,'a',function(){return custom_style_interface_CustomStyleInterface});/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const SEEN_MARKER='__seenByShadyCSS',CACHED_STYLE='__shadyCSSCachedStyle';let transformFn=null,validateFn=null;class custom_style_interface_CustomStyleInterface{constructor(){this.customStyles=[];this.enqueued=!1;documentWait(()=>{if(window.ShadyCSS.flushCustomStyles){window.ShadyCSS.flushCustomStyles()}})}enqueueDocumentValidation(){if(this.enqueued||!validateFn){return}this.enqueued=!0;documentWait(validateFn)}addCustomStyle(style){if(!style[SEEN_MARKER]){style[SEEN_MARKER]=!0;this.customStyles.push(style);this.enqueueDocumentValidation()}}getStyleForCustomStyle(customStyle){if(customStyle[CACHED_STYLE]){return customStyle[CACHED_STYLE]}let style;if(customStyle.getStyle){style=customStyle.getStyle()}else{style=customStyle}return style}processStyles(){const cs=this.customStyles;for(let i=0;i<cs.length;i++){const customStyle=cs[i];if(customStyle[CACHED_STYLE]){continue}const style=this.getStyleForCustomStyle(customStyle);if(style){const styleToTransform=style.__appliedElement||style;if(transformFn){transformFn(styleToTransform)}customStyle[CACHED_STYLE]=styleToTransform}}return cs}}custom_style_interface_CustomStyleInterface.prototype.addCustomStyle=custom_style_interface_CustomStyleInterface.prototype.addCustomStyle;custom_style_interface_CustomStyleInterface.prototype.getStyleForCustomStyle=custom_style_interface_CustomStyleInterface.prototype.getStyleForCustomStyle;custom_style_interface_CustomStyleInterface.prototype.processStyles=custom_style_interface_CustomStyleInterface.prototype.processStyles;Object.defineProperties(custom_style_interface_CustomStyleInterface.prototype,{transformCallback:{get(){return transformFn},set(fn){transformFn=fn}},validateCallback:{get(){return validateFn},set(fn){let needsEnqueue=!1;if(!validateFn){needsEnqueue=!0}validateFn=fn;if(needsEnqueue){this.enqueueDocumentValidation()}}}})},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return FlattenedNodesObserver});var _boot_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(6),_array_splice_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(46),_async_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(8);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/function isSlot(node){return'slot'===node.localName}class FlattenedNodesObserver{static getFlattenedNodes(node){if(isSlot(node)){node=node;return node.assignedNodes({flatten:!0})}else{return Array.from(node.childNodes).map(node=>{if(isSlot(node)){node=node;return node.assignedNodes({flatten:!0})}else{return[node]}}).reduce((a,b)=>a.concat(b),[])}}constructor(target,callback){this._shadyChildrenObserver=null;this._nativeChildrenObserver=null;this._connected=!1;this._target=target;this.callback=callback;this._effectiveNodes=[];this._observer=null;this._scheduled=!1;this._boundSchedule=()=>{this._schedule()};this.connect();this._schedule()}connect(){if(isSlot(this._target)){this._listenSlots([this._target])}else if(this._target.children){this._listenSlots(this._target.children);if(window.ShadyDOM){this._shadyChildrenObserver=ShadyDOM.observeChildren(this._target,mutations=>{this._processMutations(mutations)})}else{this._nativeChildrenObserver=new MutationObserver(mutations=>{this._processMutations(mutations)});this._nativeChildrenObserver.observe(this._target,{childList:!0})}}this._connected=!0}disconnect(){if(isSlot(this._target)){this._unlistenSlots([this._target])}else if(this._target.children){this._unlistenSlots(this._target.children);if(window.ShadyDOM&&this._shadyChildrenObserver){ShadyDOM.unobserveChildren(this._shadyChildrenObserver);this._shadyChildrenObserver=null}else if(this._nativeChildrenObserver){this._nativeChildrenObserver.disconnect();this._nativeChildrenObserver=null}}this._connected=!1}_schedule(){if(!this._scheduled){this._scheduled=!0;_async_js__WEBPACK_IMPORTED_MODULE_2__.c.run(()=>this.flush())}}_processMutations(mutations){this._processSlotMutations(mutations);this.flush()}_processSlotMutations(mutations){if(mutations){for(let i=0,mutation;i<mutations.length;i++){mutation=mutations[i];if(mutation.addedNodes){this._listenSlots(mutation.addedNodes)}if(mutation.removedNodes){this._unlistenSlots(mutation.removedNodes)}}}}flush(){if(!this._connected){return!1}if(window.ShadyDOM){ShadyDOM.flush()}if(this._nativeChildrenObserver){this._processSlotMutations(this._nativeChildrenObserver.takeRecords())}else if(this._shadyChildrenObserver){this._processSlotMutations(this._shadyChildrenObserver.takeRecords())}this._scheduled=!1;let info={target:this._target,addedNodes:[],removedNodes:[]},newNodes=this.constructor.getFlattenedNodes(this._target),splices=Object(_array_splice_js__WEBPACK_IMPORTED_MODULE_1__.a)(newNodes,this._effectiveNodes);for(let i=0,s;i<splices.length&&(s=splices[i]);i++){for(let j=0,n;j<s.removed.length&&(n=s.removed[j]);j++){info.removedNodes.push(n)}}for(let i=0,s;i<splices.length&&(s=splices[i]);i++){for(let j=s.index;j<s.index+s.addedCount;j++){info.addedNodes.push(newNodes[j])}}this._effectiveNodes=newNodes;let didFlush=!1;if(info.addedNodes.length||info.removedNodes.length){didFlush=!0;this.callback.call(this._target,info)}return didFlush}_listenSlots(nodeList){for(let i=0,n;i<nodeList.length;i++){n=nodeList[i];if(isSlot(n)){n.addEventListener('slotchange',this._boundSchedule)}}}_unlistenSlots(nodeList){for(let i=0,n;i<nodeList.length;i++){n=nodeList[i];if(isSlot(n)){n.removeEventListener('slotchange',this._boundSchedule)}}}}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'b',function(){return PaperButtonBehaviorImpl});__webpack_require__.d(__webpack_exports__,'a',function(){return PaperButtonBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(23),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(18),_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(40);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperButtonBehaviorImpl={properties:{elevation:{type:Number,reflectToAttribute:!0,readOnly:!0}},observers:['_calculateElevation(focused, disabled, active, pressed, receivedFocusFromKeyboard)','_computeKeyboardClass(receivedFocusFromKeyboard)'],hostAttributes:{role:'button',tabindex:'0',animated:!0},_calculateElevation:function(){var e=1;if(this.disabled){e=0}else if(this.active||this.pressed){e=4}else if(this.receivedFocusFromKeyboard){e=3}this._setElevation(e)},_computeKeyboardClass:function(receivedFocusFromKeyboard){this.toggleClass('keyboard-focus',receivedFocusFromKeyboard)},_spaceKeyDownHandler:function(event){_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__.b._spaceKeyDownHandler.call(this,event);if(this.hasRipple()&&1>this.getRipple().ripples.length){this._ripple.uiDownAction()}},_spaceKeyUpHandler:function(event){_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__.b._spaceKeyUpHandler.call(this,event);if(this.hasRipple()){this._ripple.uiUpAction()}}},PaperButtonBehavior=[_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__.a,_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__.a,_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_3__.a,PaperButtonBehaviorImpl]},,function(){},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return PaperInputAddonBehavior});__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperInputAddonBehavior={attached:function(){this.fire('addon-attached')},update:function(){}}},,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_1__.a`
<custom-style>
  <style is="custom-style">
    html {

      --shadow-transition: {
        transition: box-shadow 0.28s cubic-bezier(0.4, 0, 0.2, 1);
      };

      --shadow-none: {
        box-shadow: none;
      };

      /* from http://codepen.io/shyndman/pen/c5394ddf2e8b2a5c9185904b57421cdb */

      --shadow-elevation-2dp: {
        box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.14),
                    0 1px 5px 0 rgba(0, 0, 0, 0.12),
                    0 3px 1px -2px rgba(0, 0, 0, 0.2);
      };

      --shadow-elevation-3dp: {
        box-shadow: 0 3px 4px 0 rgba(0, 0, 0, 0.14),
                    0 1px 8px 0 rgba(0, 0, 0, 0.12),
                    0 3px 3px -2px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-4dp: {
        box-shadow: 0 4px 5px 0 rgba(0, 0, 0, 0.14),
                    0 1px 10px 0 rgba(0, 0, 0, 0.12),
                    0 2px 4px -1px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-6dp: {
        box-shadow: 0 6px 10px 0 rgba(0, 0, 0, 0.14),
                    0 1px 18px 0 rgba(0, 0, 0, 0.12),
                    0 3px 5px -1px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-8dp: {
        box-shadow: 0 8px 10px 1px rgba(0, 0, 0, 0.14),
                    0 3px 14px 2px rgba(0, 0, 0, 0.12),
                    0 5px 5px -3px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-12dp: {
        box-shadow: 0 12px 16px 1px rgba(0, 0, 0, 0.14),
                    0 4px 22px 3px rgba(0, 0, 0, 0.12),
                    0 6px 7px -4px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-16dp: {
        box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14),
                    0  6px 30px 5px rgba(0, 0, 0, 0.12),
                    0  8px 10px -5px rgba(0, 0, 0, 0.4);
      };

      --shadow-elevation-24dp: {
        box-shadow: 0 24px 38px 3px rgba(0, 0, 0, 0.14),
                    0 9px 46px 8px rgba(0, 0, 0, 0.12),
                    0 11px 15px -7px rgba(0, 0, 0, 0.4);
      };
    }
  </style>
</custom-style>`;template.setAttribute('style','display: none;');document.head.appendChild(template.content)},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'b',function(){return mixinBehaviors});__webpack_require__.d(__webpack_exports__,'a',function(){return Class});var _legacy_element_mixin_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(36);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let metaProps={attached:!0,detached:!0,ready:!0,created:!0,beforeRegister:!0,registered:!0,attributeChanged:!0,behaviors:!0};function mixinBehaviors(behaviors,klass){if(!behaviors){klass=klass;return klass}klass=Object(_legacy_element_mixin_js__WEBPACK_IMPORTED_MODULE_0__.a)(klass);if(!Array.isArray(behaviors)){behaviors=[behaviors]}let superBehaviors=klass.prototype.behaviors;behaviors=flattenBehaviors(behaviors,null,superBehaviors);klass=_mixinBehaviors(behaviors,klass);if(superBehaviors){behaviors=superBehaviors.concat(behaviors)}klass.prototype.behaviors=behaviors;return klass}function _mixinBehaviors(behaviors,klass){for(let i=0,b;i<behaviors.length;i++){b=behaviors[i];if(b){klass=Array.isArray(b)?_mixinBehaviors(b,klass):GenerateClassFromInfo(b,klass)}}return klass}function flattenBehaviors(behaviors,list,exclude){list=list||[];for(let i=behaviors.length-1,b;0<=i;i--){b=behaviors[i];if(b){if(Array.isArray(b)){flattenBehaviors(b,list)}else{if(0>list.indexOf(b)&&(!exclude||0>exclude.indexOf(b))){list.unshift(b)}}}else{console.warn('behavior is null, check for missing or 404 import')}}return list}function GenerateClassFromInfo(info,Base){class PolymerGenerated extends Base{static get properties(){return info.properties}static get observers(){return info.observers}created(){super.created();if(info.created){info.created.call(this)}}_registered(){super._registered();if(info.beforeRegister){info.beforeRegister.call(Object.getPrototypeOf(this))}if(info.registered){info.registered.call(Object.getPrototypeOf(this))}}_applyListeners(){super._applyListeners();if(info.listeners){for(let l in info.listeners){this._addMethodEventListenerToNode(this,l,info.listeners[l])}}}_ensureAttributes(){if(info.hostAttributes){for(let a in info.hostAttributes){this._ensureAttribute(a,info.hostAttributes[a])}}super._ensureAttributes()}ready(){super.ready();if(info.ready){info.ready.call(this)}}attached(){super.attached();if(info.attached){info.attached.call(this)}}detached(){super.detached();if(info.detached){info.detached.call(this)}}attributeChanged(name,old,value){super.attributeChanged(name,old,value);if(info.attributeChanged){info.attributeChanged.call(this,name,old,value)}}}PolymerGenerated.generatedFrom=info;for(let p in info){if(!(p in metaProps)){let pd=Object.getOwnPropertyDescriptor(info,p);if(pd){Object.defineProperty(PolymerGenerated.prototype,p,pd)}}}return PolymerGenerated}const Class=function(info,mixin){if(!info){console.warn(`Polymer's Class function requires \`info\` argument`)}const baseWithBehaviors=info.behaviors?mixinBehaviors(info.behaviors,HTMLElement):Object(_legacy_element_mixin_js__WEBPACK_IMPORTED_MODULE_0__.a)(HTMLElement),baseWithMixin=mixin?mixin(baseWithBehaviors):baseWithBehaviors,klass=GenerateClassFromInfo(info,baseWithMixin);klass.is=info.is;return klass}},function(module,__webpack_exports__,__webpack_require__){'use strict';var hop=Object.prototype.hasOwnProperty;function extend(obj){var sources=Array.prototype.slice.call(arguments,1),i,len,source,key;for(i=0,len=sources.length;i<len;i+=1){source=sources[i];if(!source){continue}for(key in source){if(hop.call(source,key)){obj[key]=source[key]}}}return obj}var realDefineProp=function(){try{return!!Object.defineProperty({},'a',{})}catch(e){return!1}}(),es3=!realDefineProp&&!Object.prototype.__defineGetter__,defineProperty=realDefineProp?Object.defineProperty:function(obj,name,desc){if('get'in desc&&obj.__defineGetter__){obj.__defineGetter__(name,desc.get)}else if(!hop.call(obj,name)||'value'in desc){obj[name]=desc.value}},objCreate=Object.create||function(proto,props){var obj,k;function F(){}F.prototype=proto;obj=new F;for(k in props){if(hop.call(props,k)){defineProperty(obj,k,props[k])}}return obj};function Compiler(locales,formats,pluralFn){this.locales=locales;this.formats=formats;this.pluralFn=pluralFn}Compiler.prototype.compile=function(ast){this.pluralStack=[];this.currentPlural=null;this.pluralNumberFormat=null;return this.compileMessage(ast)};Compiler.prototype.compileMessage=function(ast){if(!(ast&&'messageFormatPattern'===ast.type)){throw new Error('Message AST is not of type: "messageFormatPattern"')}var elements=ast.elements,pattern=[],i,len,element;for(i=0,len=elements.length;i<len;i+=1){element=elements[i];switch(element.type){case'messageTextElement':pattern.push(this.compileMessageText(element));break;case'argumentElement':pattern.push(this.compileArgument(element));break;default:throw new Error('Message element does not have a valid type');}}return pattern};Compiler.prototype.compileMessageText=function(element){if(this.currentPlural&&/(^|[^\\])#/g.test(element.value)){if(!this.pluralNumberFormat){this.pluralNumberFormat=new Intl.NumberFormat(this.locales)}return new PluralOffsetString(this.currentPlural.id,this.currentPlural.format.offset,this.pluralNumberFormat,element.value)}return element.value.replace(/\\#/g,'#')};Compiler.prototype.compileArgument=function(element){var format=element.format;if(!format){return new StringFormat(element.id)}var formats=this.formats,locales=this.locales,pluralFn=this.pluralFn,options;switch(format.type){case'numberFormat':options=formats.number[format.style];return{id:element.id,format:new Intl.NumberFormat(locales,options).format};case'dateFormat':options=formats.date[format.style];return{id:element.id,format:new Intl.DateTimeFormat(locales,options).format};case'timeFormat':options=formats.time[format.style];return{id:element.id,format:new Intl.DateTimeFormat(locales,options).format};case'pluralFormat':options=this.compileOptions(element);return new PluralFormat(element.id,format.ordinal,format.offset,options,pluralFn);case'selectFormat':options=this.compileOptions(element);return new SelectFormat(element.id,options);default:throw new Error('Message element does not have a valid format type');}};Compiler.prototype.compileOptions=function(element){var format=element.format,options=format.options,optionsHash={};this.pluralStack.push(this.currentPlural);this.currentPlural='pluralFormat'===format.type?element:null;var i,len,option;for(i=0,len=options.length;i<len;i+=1){option=options[i];optionsHash[option.selector]=this.compileMessage(option.value)}this.currentPlural=this.pluralStack.pop();return optionsHash};function StringFormat(id){this.id=id}StringFormat.prototype.format=function(value){if(!value&&'number'!==typeof value){return''}return'string'===typeof value?value:value+''};function PluralFormat(id,useOrdinal,offset,options,pluralFn){this.id=id;this.useOrdinal=useOrdinal;this.offset=offset;this.options=options;this.pluralFn=pluralFn}PluralFormat.prototype.getOption=function(value){var options=this.options,option=options['='+value]||options[this.pluralFn(value-this.offset,this.useOrdinal)];return option||options.other};function PluralOffsetString(id,offset,numberFormat,string){this.id=id;this.offset=offset;this.numberFormat=numberFormat;this.string=string}PluralOffsetString.prototype.format=function(value){var number=this.numberFormat.format(value-this.offset);return this.string.replace(/(^|[^\\])#/g,'$1'+number).replace(/\\#/g,'#')};function SelectFormat(id,options){this.id=id;this.options=options}SelectFormat.prototype.getOption=function(value){var options=this.options;return options[value]||options.other};var intl_messageformat_parser=__webpack_require__(64),intl_messageformat_parser_default=__webpack_require__.n(intl_messageformat_parser),core=MessageFormat;function MessageFormat(message,locales,formats){var ast='string'===typeof message?MessageFormat.__parse(message):message;if(!(ast&&'messageFormatPattern'===ast.type)){throw new TypeError('A message must be provided as a String or AST.')}formats=this._mergeFormats(MessageFormat.formats,formats);defineProperty(this,'_locale',{value:this._resolveLocale(locales)});var pluralFn=this._findPluralRuleFunction(this._locale),pattern=this._compilePattern(ast,locales,formats,pluralFn),messageFormat=this;this.format=function(values){try{return messageFormat._format(pattern,values)}catch(e){if(e.variableId){throw new Error('The intl string context variable \''+e.variableId+'\''+' was not provided to the string \''+message+'\'')}else{throw e}}}}defineProperty(MessageFormat,'formats',{enumerable:!0,value:{number:{currency:{style:'currency'},percent:{style:'percent'}},date:{short:{month:'numeric',day:'numeric',year:'2-digit'},medium:{month:'short',day:'numeric',year:'numeric'},long:{month:'long',day:'numeric',year:'numeric'},full:{weekday:'long',month:'long',day:'numeric',year:'numeric'}},time:{short:{hour:'numeric',minute:'numeric'},medium:{hour:'numeric',minute:'numeric',second:'numeric'},long:{hour:'numeric',minute:'numeric',second:'numeric',timeZoneName:'short'},full:{hour:'numeric',minute:'numeric',second:'numeric',timeZoneName:'short'}}}});defineProperty(MessageFormat,'__localeData__',{value:objCreate(null)});defineProperty(MessageFormat,'__addLocaleData',{value:function(data){if(!(data&&data.locale)){throw new Error('Locale data provided to IntlMessageFormat is missing a '+'`locale` property')}MessageFormat.__localeData__[data.locale.toLowerCase()]=data}});defineProperty(MessageFormat,'__parse',{value:intl_messageformat_parser_default.a.parse});defineProperty(MessageFormat,'defaultLocale',{enumerable:!0,writable:!0,value:void 0});MessageFormat.prototype.resolvedOptions=function(){return{locale:this._locale}};MessageFormat.prototype._compilePattern=function(ast,locales,formats,pluralFn){var compiler=new Compiler(locales,formats,pluralFn);return compiler.compile(ast)};MessageFormat.prototype._findPluralRuleFunction=function(locale){var localeData=MessageFormat.__localeData__,data=localeData[locale.toLowerCase()];while(data){if(data.pluralRuleFunction){return data.pluralRuleFunction}data=data.parentLocale&&localeData[data.parentLocale.toLowerCase()]}throw new Error('Locale data added to IntlMessageFormat is missing a '+'`pluralRuleFunction` for :'+locale)};MessageFormat.prototype._format=function(pattern,values){var result='',i,len,part,id,value,err;for(i=0,len=pattern.length;i<len;i+=1){part=pattern[i];if('string'===typeof part){result+=part;continue}id=part.id;if(!(values&&hop.call(values,id))){err=new Error('A value must be provided for: '+id);err.variableId=id;throw err}value=values[id];if(part.options){result+=this._format(part.getOption(value),values)}else{result+=part.format(value)}}return result};MessageFormat.prototype._mergeFormats=function(defaults,formats){var mergedFormats={},type,mergedType;for(type in defaults){if(!hop.call(defaults,type)){continue}mergedFormats[type]=mergedType=objCreate(defaults[type]);if(formats&&hop.call(formats,type)){extend(mergedType,formats[type])}}return mergedFormats};MessageFormat.prototype._resolveLocale=function(locales){if('string'===typeof locales){locales=[locales]}locales=(locales||[]).concat(MessageFormat.defaultLocale);var localeData=MessageFormat.__localeData__,i,len,localeParts,data;for(i=0,len=locales.length;i<len;i+=1){localeParts=locales[i].toLowerCase().split('-');while(localeParts.length){data=localeData[localeParts.join('-')];if(data){return data.locale}localeParts.pop()}}var defaultLocale=locales.pop();throw new Error('No locale data has been added to IntlMessageFormat for: '+locales.join(', ')+', or the default locale: '+defaultLocale)};core.__addLocaleData({locale:'en',pluralRuleFunction:function(n,ord){var s=(n+'').split('.'),v0=!s[1],t0=+s[0]==n,n10=t0&&s[0].slice(-1),n100=t0&&s[0].slice(-2);if(ord)return 1==n10&&11!=n100?'one':2==n10&&12!=n100?'two':3==n10&&13!=n100?'few':'other';return 1==n&&v0?'one':'other'}});core.defaultLocale='en';__webpack_require__.d(__webpack_exports__,'a',function(){return localizeBaseMixin});const localizeBaseMixin=superClass=>class extends superClass{__computeLocalize(language,resources,formats){const proto=this.constructor.prototype;this.__checkLocalizationCache(proto);if(!proto.__localizationCache){proto.__localizationCache={messages:{}}}proto.__localizationCache.messages={};return(key,...args)=>{if(!key||!resources||!language||!resources[language]){return''}const translatedValue=resources[language][key];if(!translatedValue){return this.useKeyIfMissing?key:''}const messageKey=key+translatedValue;let translatedMessage=proto.__localizationCache.messages[messageKey];if(!translatedMessage){translatedMessage=new core(translatedValue,language,formats);proto.__localizationCache.messages[messageKey]=translatedMessage}const argObject={};for(let i=0;i<args.length;i+=2){argObject[args[i]]=args[i+1]}try{return translatedMessage.format(argObject)}catch(err){return'Translation '+err}}}__checkLocalizationCache(proto){if(proto===void 0){return}if(proto.__localizationCache===void 0){proto.__localizationCache={messages:{}}}}}},function(module,exports,__webpack_require__){'use strict';exports=module.exports=__webpack_require__(90)['default'];exports['default']=exports},,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_element_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(10),_utils_templatize_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(24),_utils_debounce_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(14),_utils_flush_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(16),_mixins_mutable_data_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(20),_utils_path_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(2),_utils_async_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(8);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const domRepeatBase=Object(_mixins_mutable_data_js__WEBPACK_IMPORTED_MODULE_4__.b)(_polymer_element_js__WEBPACK_IMPORTED_MODULE_0__.a);class DomRepeat extends domRepeatBase{static get is(){return'dom-repeat'}static get template(){return null}static get properties(){return{items:{type:Array},as:{type:String,value:'item'},indexAs:{type:String,value:'index'},itemsIndexAs:{type:String,value:'itemsIndex'},sort:{type:Function,observer:'__sortChanged'},filter:{type:Function,observer:'__filterChanged'},observe:{type:String,observer:'__observeChanged'},delay:Number,renderedItemCount:{type:Number,notify:!0,readOnly:!0},initialCount:{type:Number,observer:'__initializeChunking'},targetFramerate:{type:Number,value:20},_targetFrameTime:{type:Number,computed:'__computeFrameTime(targetFramerate)'}}}static get observers(){return['__itemsChanged(items.*)']}constructor(){super();this.__instances=[];this.__limit=Infinity;this.__pool=[];this.__renderDebouncer=null;this.__itemsIdxToInstIdx={};this.__chunkCount=null;this.__lastChunkTime=null;this.__sortFn=null;this.__filterFn=null;this.__observePaths=null;this.__ctor=null;this.__isDetached=!0;this.template=null}disconnectedCallback(){super.disconnectedCallback();this.__isDetached=!0;for(let i=0;i<this.__instances.length;i++){this.__detachInstance(i)}}connectedCallback(){super.connectedCallback();this.style.display='none';if(this.__isDetached){this.__isDetached=!1;let parent=this.parentNode;for(let i=0;i<this.__instances.length;i++){this.__attachInstance(i,parent)}}}__ensureTemplatized(){if(!this.__ctor){let template=this.template=this.querySelector('template');if(!template){let observer=new MutationObserver(()=>{if(this.querySelector('template')){observer.disconnect();this.__render()}else{throw new Error('dom-repeat requires a <template> child')}});observer.observe(this,{childList:!0});return!1}let instanceProps={};instanceProps[this.as]=!0;instanceProps[this.indexAs]=!0;instanceProps[this.itemsIndexAs]=!0;this.__ctor=Object(_utils_templatize_js__WEBPACK_IMPORTED_MODULE_1__.b)(template,this,{mutableData:this.mutableData,parentModel:!0,instanceProps:instanceProps,forwardHostProp:function(prop,value){let i$=this.__instances;for(let i=0,inst;i<i$.length&&(inst=i$[i]);i++){inst.forwardHostProp(prop,value)}},notifyInstanceProp:function(inst,prop,value){if(Object(_utils_path_js__WEBPACK_IMPORTED_MODULE_5__.e)(this.as,prop)){let idx=inst[this.itemsIndexAs];if(prop==this.as){this.items[idx]=value}let path=Object(_utils_path_js__WEBPACK_IMPORTED_MODULE_5__.i)(this.as,'items.'+idx,prop);this.notifyPath(path,value)}}})}return!0}__getMethodHost(){return this.__dataHost._methodHost||this.__dataHost}__functionFromPropertyValue(functionOrMethodName){if('string'===typeof functionOrMethodName){let obj=this.__getMethodHost();return function(){return obj[functionOrMethodName].apply(obj,arguments)}}return functionOrMethodName}__sortChanged(sort){this.__sortFn=this.__functionFromPropertyValue(sort);if(this.items){this.__debounceRender(this.__render)}}__filterChanged(filter){this.__filterFn=this.__functionFromPropertyValue(filter);if(this.items){this.__debounceRender(this.__render)}}__computeFrameTime(rate){return Math.ceil(1e3/rate)}__initializeChunking(){if(this.initialCount){this.__limit=this.initialCount;this.__chunkCount=this.initialCount;this.__lastChunkTime=performance.now()}}__tryRenderChunk(){if(this.items&&this.__limit<this.items.length){this.__debounceRender(this.__requestRenderChunk)}}__requestRenderChunk(){requestAnimationFrame(()=>this.__renderChunk())}__renderChunk(){let currChunkTime=performance.now(),ratio=this._targetFrameTime/(currChunkTime-this.__lastChunkTime);this.__chunkCount=Math.round(this.__chunkCount*ratio)||1;this.__limit+=this.__chunkCount;this.__lastChunkTime=currChunkTime;this.__debounceRender(this.__render)}__observeChanged(){this.__observePaths=this.observe&&this.observe.replace('.*','.').split(' ')}__itemsChanged(change){if(this.items&&!Array.isArray(this.items)){console.warn('dom-repeat expected array for `items`, found',this.items)}if(!this.__handleItemPath(change.path,change.value)){this.__initializeChunking();this.__debounceRender(this.__render)}}__handleObservedPaths(path){if(this.__sortFn||this.__filterFn){if(!path){this.__debounceRender(this.__render,this.delay)}else if(this.__observePaths){let paths=this.__observePaths;for(let i=0;i<paths.length;i++){if(0===path.indexOf(paths[i])){this.__debounceRender(this.__render,this.delay)}}}}}__debounceRender(fn,delay=0){this.__renderDebouncer=_utils_debounce_js__WEBPACK_IMPORTED_MODULE_2__.a.debounce(this.__renderDebouncer,0<delay?_utils_async_js__WEBPACK_IMPORTED_MODULE_6__.d.after(delay):_utils_async_js__WEBPACK_IMPORTED_MODULE_6__.c,fn.bind(this));Object(_utils_flush_js__WEBPACK_IMPORTED_MODULE_3__.a)(this.__renderDebouncer)}render(){this.__debounceRender(this.__render);Object(_utils_flush_js__WEBPACK_IMPORTED_MODULE_3__.b)()}__render(){if(!this.__ensureTemplatized()){return}this.__applyFullRefresh();this.__pool.length=0;this._setRenderedItemCount(this.__instances.length);this.dispatchEvent(new CustomEvent('dom-change',{bubbles:!0,composed:!0}));this.__tryRenderChunk()}__applyFullRefresh(){let items=this.items||[],isntIdxToItemsIdx=Array(items.length);for(let i=0;i<items.length;i++){isntIdxToItemsIdx[i]=i}if(this.__filterFn){isntIdxToItemsIdx=isntIdxToItemsIdx.filter((i,idx,array)=>this.__filterFn(items[i],idx,array))}if(this.__sortFn){isntIdxToItemsIdx.sort((a,b)=>this.__sortFn(items[a],items[b]))}const itemsIdxToInstIdx=this.__itemsIdxToInstIdx={};let instIdx=0;const limit=Math.min(isntIdxToItemsIdx.length,this.__limit);for(;instIdx<limit;instIdx++){let inst=this.__instances[instIdx],itemIdx=isntIdxToItemsIdx[instIdx],item=items[itemIdx];itemsIdxToInstIdx[itemIdx]=instIdx;if(inst){inst._setPendingProperty(this.as,item);inst._setPendingProperty(this.indexAs,instIdx);inst._setPendingProperty(this.itemsIndexAs,itemIdx);inst._flushProperties()}else{this.__insertInstance(item,instIdx,itemIdx)}}for(let i=this.__instances.length-1;i>=instIdx;i--){this.__detachAndRemoveInstance(i)}}__detachInstance(idx){let inst=this.__instances[idx];for(let i=0,el;i<inst.children.length;i++){el=inst.children[i];inst.root.appendChild(el)}return inst}__attachInstance(idx,parent){let inst=this.__instances[idx];parent.insertBefore(inst.root,this)}__detachAndRemoveInstance(idx){let inst=this.__detachInstance(idx);if(inst){this.__pool.push(inst)}this.__instances.splice(idx,1)}__stampInstance(item,instIdx,itemIdx){let model={};model[this.as]=item;model[this.indexAs]=instIdx;model[this.itemsIndexAs]=itemIdx;return new this.__ctor(model)}__insertInstance(item,instIdx,itemIdx){let inst=this.__pool.pop();if(inst){inst._setPendingProperty(this.as,item);inst._setPendingProperty(this.indexAs,instIdx);inst._setPendingProperty(this.itemsIndexAs,itemIdx);inst._flushProperties()}else{inst=this.__stampInstance(item,instIdx,itemIdx)}let beforeRow=this.__instances[instIdx+1],beforeNode=beforeRow?beforeRow.children[0]:this;this.parentNode.insertBefore(inst.root,beforeNode);this.__instances[instIdx]=inst;return inst}_showHideChildren(hidden){for(let i=0;i<this.__instances.length;i++){this.__instances[i]._showHideChildren(hidden)}}__handleItemPath(path,value){let itemsPath=path.slice(6),dot=itemsPath.indexOf('.'),itemsIdx=0>dot?itemsPath:itemsPath.substring(0,dot);if(itemsIdx==parseInt(itemsIdx,10)){let itemSubPath=0>dot?'':itemsPath.substring(dot+1);this.__handleObservedPaths(itemSubPath);let instIdx=this.__itemsIdxToInstIdx[itemsIdx],inst=this.__instances[instIdx];if(inst){let itemPath=this.as+(itemSubPath?'.'+itemSubPath:'');inst._setPendingPropertyOrPath(itemPath,value,!1,!0);inst._flushProperties()}return!0}}itemForElement(el){let instance=this.modelForElement(el);return instance&&instance[this.as]}indexForElement(el){let instance=this.modelForElement(el);return instance&&instance[this.indexAs]}modelForElement(el){return Object(_utils_templatize_js__WEBPACK_IMPORTED_MODULE_1__.a)(this.template,el)}}customElements.define(DomRepeat.is,DomRepeat)},function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_element_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(10),_utils_templatize_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(24),_utils_debounce_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(14),_utils_flush_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(16),_utils_async_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(8),_utils_path_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(2);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/class DomIf extends _polymer_element_js__WEBPACK_IMPORTED_MODULE_0__.a{static get is(){return'dom-if'}static get template(){return null}static get properties(){return{if:{type:Boolean,observer:'__debounceRender'},restamp:{type:Boolean,observer:'__debounceRender'}}}constructor(){super();this.__renderDebouncer=null;this.__invalidProps=null;this.__instance=null;this._lastIf=!1;this.__ctor=null;this.__hideTemplateChildren__=!1}__debounceRender(){this.__renderDebouncer=_utils_debounce_js__WEBPACK_IMPORTED_MODULE_2__.a.debounce(this.__renderDebouncer,_utils_async_js__WEBPACK_IMPORTED_MODULE_4__.c,()=>this.__render());Object(_utils_flush_js__WEBPACK_IMPORTED_MODULE_3__.a)(this.__renderDebouncer)}disconnectedCallback(){super.disconnectedCallback();if(!this.parentNode||this.parentNode.nodeType==Node.DOCUMENT_FRAGMENT_NODE&&!this.parentNode.host){this.__teardownInstance()}}connectedCallback(){super.connectedCallback();this.style.display='none';if(this.if){this.__debounceRender()}}render(){Object(_utils_flush_js__WEBPACK_IMPORTED_MODULE_3__.b)()}__render(){if(this.if){if(!this.__ensureInstance()){return}this._showHideChildren()}else if(this.restamp){this.__teardownInstance()}if(!this.restamp&&this.__instance){this._showHideChildren()}if(this.if!=this._lastIf){this.dispatchEvent(new CustomEvent('dom-change',{bubbles:!0,composed:!0}));this._lastIf=this.if}}__ensureInstance(){let parentNode=this.parentNode;if(parentNode){if(!this.__ctor){let template=this.querySelector('template');if(!template){let observer=new MutationObserver(()=>{if(this.querySelector('template')){observer.disconnect();this.__render()}else{throw new Error('dom-if requires a <template> child')}});observer.observe(this,{childList:!0});return!1}this.__ctor=Object(_utils_templatize_js__WEBPACK_IMPORTED_MODULE_1__.b)(template,this,{mutableData:!0,forwardHostProp:function(prop,value){if(this.__instance){if(this.if){this.__instance.forwardHostProp(prop,value)}else{this.__invalidProps=this.__invalidProps||Object.create(null);this.__invalidProps[Object(_utils_path_js__WEBPACK_IMPORTED_MODULE_5__.g)(prop)]=!0}}}})}if(!this.__instance){this.__instance=new this.__ctor;parentNode.insertBefore(this.__instance.root,this)}else{this.__syncHostProperties();let c$=this.__instance.children;if(c$&&c$.length){let lastChild=this.previousSibling;if(lastChild!==c$[c$.length-1]){for(let i=0,n;i<c$.length&&(n=c$[i]);i++){parentNode.insertBefore(n,this)}}}}}return!0}__syncHostProperties(){let props=this.__invalidProps;if(props){for(let prop in props){this.__instance._setPendingProperty(prop,this.__dataHost[prop])}this.__invalidProps=null;this.__instance._flushProperties()}}__teardownInstance(){if(this.__instance){let c$=this.__instance.children;if(c$&&c$.length){let parent=c$[0].parentNode;if(parent){for(let i=0,n;i<c$.length&&(n=c$[i]);i++){parent.removeChild(n)}}}this.__instance=null;this.__invalidProps=null}}_showHideChildren(){let hidden=this.__hideTemplateChildren__||!this.if;if(this.__instance){this.__instance._showHideChildren(hidden)}}}customElements.define(DomIf.is,DomIf)},function(){},,function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return localizeLiteBaseMixin});var _localize_base_mixin__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(63),_util_hass_translation__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(41);const localizeLiteBaseMixin=superClass=>class extends Object(_localize_base_mixin__WEBPACK_IMPORTED_MODULE_0__.a)(superClass){_initializeLocalizeLite(){if(this.resources){return}if(!this.translationFragment){return}this._updateResources()}async _updateResources(){const{language,data}=await Object(_util_hass_translation__WEBPACK_IMPORTED_MODULE_1__.b)(this.translationFragment);this.resources={[language]:data}}}},,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(33),_polymer_paper_styles_element_styles_paper_material_styles_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(82),_polymer_paper_behaviors_paper_button_behavior_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(56),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_4__.c`
  <style include="paper-material-styles">
    /* Need to specify the same specificity as the styles imported from paper-material. */
    :host {
      @apply --layout-inline;
      @apply --layout-center-center;
      position: relative;
      box-sizing: border-box;
      min-width: 5.14em;
      margin: 0 0.29em;
      background: transparent;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      -webkit-tap-highlight-color: transparent;
      font: inherit;
      text-transform: uppercase;
      outline-width: 0;
      border-radius: 3px;
      -moz-user-select: none;
      -ms-user-select: none;
      -webkit-user-select: none;
      user-select: none;
      cursor: pointer;
      z-index: 0;
      padding: 0.7em 0.57em;

      @apply --paper-font-common-base;
      @apply --paper-button;
    }

    :host([elevation="1"]) {
      @apply --paper-material-elevation-1;
    }

    :host([elevation="2"]) {
      @apply --paper-material-elevation-2;
    }

    :host([elevation="3"]) {
      @apply --paper-material-elevation-3;
    }

    :host([elevation="4"]) {
      @apply --paper-material-elevation-4;
    }

    :host([elevation="5"]) {
      @apply --paper-material-elevation-5;
    }

    :host([hidden]) {
      display: none !important;
    }

    :host([raised].keyboard-focus) {
      font-weight: bold;
      @apply --paper-button-raised-keyboard-focus;
    }

    :host(:not([raised]).keyboard-focus) {
      font-weight: bold;
      @apply --paper-button-flat-keyboard-focus;
    }

    :host([disabled]) {
      background: none;
      color: #a8a8a8;
      cursor: auto;
      pointer-events: none;

      @apply --paper-button-disabled;
    }

    :host([disabled][raised]) {
      background: #eaeaea;
    }


    :host([animated]) {
      @apply --shadow-transition;
    }

    paper-ripple {
      color: var(--paper-button-ink-color);
    }
  </style>

  <slot></slot>`;template.setAttribute('strip-whitespace','');Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:template,is:'paper-button',behaviors:[_polymer_paper_behaviors_paper_button_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a],properties:{raised:{type:Boolean,reflectToAttribute:!0,value:!1,observer:'_calculateElevation'}},_calculateElevation:function(){if(!this.raised){this._setElevation(0)}else{_polymer_paper_behaviors_paper_button_behavior_js__WEBPACK_IMPORTED_MODULE_2__.b._calculateElevation.apply(this)}}})},,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_meta_iron_meta_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(47),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(0);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_2__.a)({is:'iron-iconset-svg',properties:{name:{type:String,observer:'_nameChanged'},size:{type:Number,value:24},rtlMirroring:{type:Boolean,value:!1},useGlobalRtlAttribute:{type:Boolean,value:!1}},created:function(){this._meta=new _polymer_iron_meta_iron_meta_js__WEBPACK_IMPORTED_MODULE_1__.a({type:'iconset',key:null,value:null})},attached:function(){this.style.display='none'},getIconNames:function(){this._icons=this._createIconMap();return Object.keys(this._icons).map(function(n){return this.name+':'+n},this)},applyIcon:function(element,iconName){this.removeIcon(element);var svg=this._cloneIcon(iconName,this.rtlMirroring&&this._targetIsRTL(element));if(svg){var pde=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(element.root||element);pde.insertBefore(svg,pde.childNodes[0]);return element._svgIcon=svg}return null},removeIcon:function(element){if(element._svgIcon){Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(element.root||element).removeChild(element._svgIcon);element._svgIcon=null}},_targetIsRTL:function(target){if(null==this.__targetIsRTL){if(this.useGlobalRtlAttribute){var globalElement=document.body&&document.body.hasAttribute('dir')?document.body:document.documentElement;this.__targetIsRTL='rtl'===globalElement.getAttribute('dir')}else{if(target&&target.nodeType!==Node.ELEMENT_NODE){target=target.host}this.__targetIsRTL=target&&'rtl'===window.getComputedStyle(target).direction}}return this.__targetIsRTL},_nameChanged:function(){this._meta.value=null;this._meta.key=this.name;this._meta.value=this;this.async(function(){this.fire('iron-iconset-added',this,{node:window})})},_createIconMap:function(){var icons=Object.create(null);Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(this).querySelectorAll('[id]').forEach(function(icon){icons[icon.id]=icon});return icons},_cloneIcon:function(id,mirrorAllowed){this._icons=this._icons||this._createIconMap();return this._prepareSvgClone(this._icons[id],this.size,mirrorAllowed)},_prepareSvgClone:function(sourceSvg,size,mirrorAllowed){if(sourceSvg){var content=sourceSvg.cloneNode(!0),svg=document.createElementNS('http://www.w3.org/2000/svg','svg'),viewBox=content.getAttribute('viewBox')||'0 0 '+size+' '+size,cssText='pointer-events: none; display: block; width: 100%; height: 100%;';if(mirrorAllowed&&content.hasAttribute('mirror-in-rtl')){cssText+='-webkit-transform:scale(-1,1);transform:scale(-1,1);transform-origin:center;'}svg.setAttribute('viewBox',viewBox);svg.setAttribute('preserveAspectRatio','xMidYMid meet');svg.setAttribute('focusable','false');svg.style.cssText=cssText;svg.appendChild(content).removeAttribute('id');return svg}return null}})},,function(module,__webpack_exports__,__webpack_require__){'use strict';var _Mathmax=Math.max,_Mathsqrt=Math.sqrt,_Mathmin=Math.min,_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(19),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(0),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(1),Utility={distance:function(x1,y1,x2,y2){var xDelta=x1-x2,yDelta=y1-y2;return _Mathsqrt(xDelta*xDelta+yDelta*yDelta)},now:window.performance&&window.performance.now?window.performance.now.bind(window.performance):Date.now};/**
@license
Copyright (c) 2014 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/function ElementMetrics(element){this.element=element;this.width=this.boundingRect.width;this.height=this.boundingRect.height;this.size=_Mathmax(this.width,this.height)}ElementMetrics.prototype={get boundingRect(){return this.element.getBoundingClientRect()},furthestCornerDistanceFrom:function(x,y){var topLeft=Utility.distance(x,y,0,0),topRight=Utility.distance(x,y,this.width,0),bottomLeft=Utility.distance(x,y,0,this.height),bottomRight=Utility.distance(x,y,this.width,this.height);return _Mathmax(topLeft,topRight,bottomLeft,bottomRight)}};function Ripple(element){this.element=element;this.color=window.getComputedStyle(element).color;this.wave=document.createElement('div');this.waveContainer=document.createElement('div');this.wave.style.backgroundColor=this.color;this.wave.classList.add('wave');this.waveContainer.classList.add('wave-container');Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(this.waveContainer).appendChild(this.wave);this.resetInteractionState()}Ripple.MAX_RADIUS=300;Ripple.prototype={get recenters(){return this.element.recenters},get center(){return this.element.center},get mouseDownElapsed(){var elapsed;if(!this.mouseDownStart){return 0}elapsed=Utility.now()-this.mouseDownStart;if(this.mouseUpStart){elapsed-=this.mouseUpElapsed}return elapsed},get mouseUpElapsed(){return this.mouseUpStart?Utility.now()-this.mouseUpStart:0},get mouseDownElapsedSeconds(){return this.mouseDownElapsed/1e3},get mouseUpElapsedSeconds(){return this.mouseUpElapsed/1e3},get mouseInteractionSeconds(){return this.mouseDownElapsedSeconds+this.mouseUpElapsedSeconds},get initialOpacity(){return this.element.initialOpacity},get opacityDecayVelocity(){return this.element.opacityDecayVelocity},get radius(){var width2=this.containerMetrics.width*this.containerMetrics.width,height2=this.containerMetrics.height*this.containerMetrics.height,waveRadius=1.1*_Mathmin(_Mathsqrt(width2+height2),Ripple.MAX_RADIUS)+5,duration=1.1-.2*(waveRadius/Ripple.MAX_RADIUS),timeNow=this.mouseInteractionSeconds/duration,size=waveRadius*(1-Math.pow(80,-timeNow));return Math.abs(size)},get opacity(){if(!this.mouseUpStart){return this.initialOpacity}return _Mathmax(0,this.initialOpacity-this.mouseUpElapsedSeconds*this.opacityDecayVelocity)},get outerOpacity(){var outerOpacity=.3*this.mouseUpElapsedSeconds,waveOpacity=this.opacity;return _Mathmax(0,_Mathmin(outerOpacity,waveOpacity))},get isOpacityFullyDecayed(){return .01>this.opacity&&this.radius>=_Mathmin(this.maxRadius,Ripple.MAX_RADIUS)},get isRestingAtMaxRadius(){return this.opacity>=this.initialOpacity&&this.radius>=_Mathmin(this.maxRadius,Ripple.MAX_RADIUS)},get isAnimationComplete(){return this.mouseUpStart?this.isOpacityFullyDecayed:this.isRestingAtMaxRadius},get translationFraction(){return _Mathmin(1,2*(this.radius/this.containerMetrics.size)/1.4142135623730951)},get xNow(){if(this.xEnd){return this.xStart+this.translationFraction*(this.xEnd-this.xStart)}return this.xStart},get yNow(){if(this.yEnd){return this.yStart+this.translationFraction*(this.yEnd-this.yStart)}return this.yStart},get isMouseDown(){return this.mouseDownStart&&!this.mouseUpStart},resetInteractionState:function(){this.maxRadius=0;this.mouseDownStart=0;this.mouseUpStart=0;this.xStart=0;this.yStart=0;this.xEnd=0;this.yEnd=0;this.slideDistance=0;this.containerMetrics=new ElementMetrics(this.element)},draw:function(){var scale,dx,dy;this.wave.style.opacity=this.opacity;scale=this.radius/(this.containerMetrics.size/2);dx=this.xNow-this.containerMetrics.width/2;dy=this.yNow-this.containerMetrics.height/2;this.waveContainer.style.webkitTransform='translate('+dx+'px, '+dy+'px)';this.waveContainer.style.transform='translate3d('+dx+'px, '+dy+'px, 0)';this.wave.style.webkitTransform='scale('+scale+','+scale+')';this.wave.style.transform='scale3d('+scale+','+scale+',1)'},downAction:function(event){var xCenter=this.containerMetrics.width/2,yCenter=this.containerMetrics.height/2;this.resetInteractionState();this.mouseDownStart=Utility.now();if(this.center){this.xStart=xCenter;this.yStart=yCenter;this.slideDistance=Utility.distance(this.xStart,this.yStart,this.xEnd,this.yEnd)}else{this.xStart=event?event.detail.x-this.containerMetrics.boundingRect.left:this.containerMetrics.width/2;this.yStart=event?event.detail.y-this.containerMetrics.boundingRect.top:this.containerMetrics.height/2}if(this.recenters){this.xEnd=xCenter;this.yEnd=yCenter;this.slideDistance=Utility.distance(this.xStart,this.yStart,this.xEnd,this.yEnd)}this.maxRadius=this.containerMetrics.furthestCornerDistanceFrom(this.xStart,this.yStart);this.waveContainer.style.top=(this.containerMetrics.height-this.containerMetrics.size)/2+'px';this.waveContainer.style.left=(this.containerMetrics.width-this.containerMetrics.size)/2+'px';this.waveContainer.style.width=this.containerMetrics.size+'px';this.waveContainer.style.height=this.containerMetrics.size+'px'},upAction:function(){if(!this.isMouseDown){return}this.mouseUpStart=Utility.now()},remove:function(){Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(this.waveContainer.parentNode).removeChild(this.waveContainer)}};Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_2__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__.a`
    <style>
      :host {
        display: block;
        position: absolute;
        border-radius: inherit;
        overflow: hidden;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;

        /* See PolymerElements/paper-behaviors/issues/34. On non-Chrome browsers,
         * creating a node (with a position:absolute) in the middle of an event
         * handler "interrupts" that event handler (which happens when the
         * ripple is created on demand) */
        pointer-events: none;
      }

      :host([animating]) {
        /* This resolves a rendering issue in Chrome (as of 40) where the
           ripple is not properly clipped by its parent (which may have
           rounded corners). See: http://jsbin.com/temexa/4

           Note: We only apply this style conditionally. Otherwise, the browser
           will create a new compositing layer for every ripple element on the
           page, and that would be bad. */
        -webkit-transform: translate(0, 0);
        transform: translate3d(0, 0, 0);
      }

      #background,
      #waves,
      .wave-container,
      .wave {
        pointer-events: none;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
      }

      #background,
      .wave {
        opacity: 0;
      }

      #waves,
      .wave {
        overflow: hidden;
      }

      .wave-container,
      .wave {
        border-radius: 50%;
      }

      :host(.circle) #background,
      :host(.circle) #waves {
        border-radius: 50%;
      }

      :host(.circle) .wave-container {
        overflow: hidden;
      }
    </style>

    <div id="background"></div>
    <div id="waves"></div>
`,is:'paper-ripple',behaviors:[_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_1__.a],properties:{initialOpacity:{type:Number,value:.25},opacityDecayVelocity:{type:Number,value:.8},recenters:{type:Boolean,value:!1},center:{type:Boolean,value:!1},ripples:{type:Array,value:function(){return[]}},animating:{type:Boolean,readOnly:!0,reflectToAttribute:!0,value:!1},holdDown:{type:Boolean,value:!1,observer:'_holdDownChanged'},noink:{type:Boolean,value:!1},_animating:{type:Boolean},_boundAnimate:{type:Function,value:function(){return this.animate.bind(this)}}},get target(){return this.keyEventTarget},keyBindings:{"enter:keydown":'_onEnterKeydown',"space:keydown":'_onSpaceKeydown',"space:keyup":'_onSpaceKeyup'},attached:function(){if(11==this.parentNode.nodeType){this.keyEventTarget=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(this).getOwnerRoot().host}else{this.keyEventTarget=this.parentNode}var keyEventTarget=this.keyEventTarget;this.listen(keyEventTarget,'up','uiUpAction');this.listen(keyEventTarget,'down','uiDownAction')},detached:function(){this.unlisten(this.keyEventTarget,'up','uiUpAction');this.unlisten(this.keyEventTarget,'down','uiDownAction');this.keyEventTarget=null},get shouldKeepAnimating(){for(var index=0;index<this.ripples.length;++index){if(!this.ripples[index].isAnimationComplete){return!0}}return!1},simulatedRipple:function(){this.downAction(null);this.async(function(){this.upAction()},1)},uiDownAction:function(event){if(!this.noink){this.downAction(event)}},downAction:function(event){if(this.holdDown&&0<this.ripples.length){return}var ripple=this.addRipple();ripple.downAction(event);if(!this._animating){this._animating=!0;this.animate()}},uiUpAction:function(event){if(!this.noink){this.upAction(event)}},upAction:function(event){if(this.holdDown){return}this.ripples.forEach(function(ripple){ripple.upAction(event)});this._animating=!0;this.animate()},onAnimationComplete:function(){this._animating=!1;this.$.background.style.backgroundColor=null;this.fire('transitionend')},addRipple:function(){var ripple=new Ripple(this);Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(this.$.waves).appendChild(ripple.waveContainer);this.$.background.style.backgroundColor=ripple.color;this.ripples.push(ripple);this._setAnimating(!0);return ripple},removeRipple:function(ripple){var rippleIndex=this.ripples.indexOf(ripple);if(0>rippleIndex){return}this.ripples.splice(rippleIndex,1);ripple.remove();if(!this.ripples.length){this._setAnimating(!1)}},animate:function(){if(!this._animating){return}var index,ripple;for(index=0;index<this.ripples.length;++index){ripple=this.ripples[index];ripple.draw();this.$.background.style.opacity=ripple.outerOpacity;if(ripple.isOpacityFullyDecayed&&!ripple.isRestingAtMaxRadius){this.removeRipple(ripple)}}if(!this.shouldKeepAnimating&&0===this.ripples.length){this.onAnimationComplete()}else{window.requestAnimationFrame(this._boundAnimate)}},animateRipple:function(){return this.animate()},_onEnterKeydown:function(){this.uiDownAction();this.async(this.uiUpAction,1)},_onSpaceKeydown:function(){this.uiDownAction()},_onSpaceKeyup:function(){this.uiUpAction()},_holdDownChanged:function(newVal,oldVal){if(oldVal===void 0){return}if(newVal){this.downAction()}else{this.upAction()}}})},,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_input_iron_input_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(101),_paper_input_char_counter_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(102),_paper_input_container_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(103),_paper_input_error_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(104),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(52),_polymer_polymer_lib_elements_dom_module_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(30),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(1),_paper_input_behavior_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(83);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_7__.a)({is:'paper-input',_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__.a`
    <style>
      :host {
        display: block;
      }

      :host([focused]) {
        outline: none;
      }

      :host([hidden]) {
        display: none !important;
      }

      input {
        /* Firefox sets a min-width on the input, which can cause layout issues */
        min-width: 0;
      }

      /* In 1.x, the <input> is distributed to paper-input-container, which styles it.
      In 2.x the <iron-input> is distributed to paper-input-container, which styles
      it, but in order for this to work correctly, we need to reset some
      of the native input's properties to inherit (from the iron-input) */
      iron-input > input {
        @apply --paper-input-container-shared-input-style;
        font-family: inherit;
        font-weight: inherit;
        font-size: inherit;
        letter-spacing: inherit;
        word-spacing: inherit;
        line-height: inherit;
        text-shadow: inherit;
        color: inherit;
        cursor: inherit;
      }

      input:disabled {
        @apply --paper-input-container-input-disabled;
      }

      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        @apply --paper-input-container-input-webkit-spinner;
      }

      input::-webkit-clear-button {
        @apply --paper-input-container-input-webkit-clear;
      }

      input::-webkit-calendar-picker-indicator {
        @apply --paper-input-container-input-webkit-calendar-picker-indicator;
      }

      input::-webkit-input-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input:-moz-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input::-moz-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input::-ms-clear {
        @apply --paper-input-container-ms-clear;
      }

      input::-ms-reveal {
        @apply --paper-input-container-ms-reveal;
      }

      input:-ms-input-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      label {
        pointer-events: none;
      }
    </style>

    <paper-input-container id="container" no-label-float="[[noLabelFloat]]" always-float-label="[[_computeAlwaysFloatLabel(alwaysFloatLabel,placeholder)]]" auto-validate\$="[[autoValidate]]" disabled\$="[[disabled]]" invalid="[[invalid]]">

      <slot name="prefix" slot="prefix"></slot>

      <label hidden\$="[[!label]]" aria-hidden="true" for\$="[[_inputId]]" slot="label">[[label]]</label>

      <!-- Need to bind maxlength so that the paper-input-char-counter works correctly -->
      <iron-input bind-value="{{value}}" slot="input" class="input-element" id\$="[[_inputId]]" maxlength\$="[[maxlength]]" allowed-pattern="[[allowedPattern]]" invalid="{{invalid}}" validator="[[validator]]">
        <input aria-labelledby\$="[[_ariaLabelledBy]]" aria-describedby\$="[[_ariaDescribedBy]]" disabled\$="[[disabled]]" title\$="[[title]]" type\$="[[type]]" pattern\$="[[pattern]]" required\$="[[required]]" autocomplete\$="[[autocomplete]]" autofocus\$="[[autofocus]]" inputmode\$="[[inputmode]]" minlength\$="[[minlength]]" maxlength\$="[[maxlength]]" min\$="[[min]]" max\$="[[max]]" step\$="[[step]]" name\$="[[name]]" placeholder\$="[[placeholder]]" readonly\$="[[readonly]]" list\$="[[list]]" size\$="[[size]]" autocapitalize\$="[[autocapitalize]]" autocorrect\$="[[autocorrect]]" on-change="_onChange" tabindex\$="[[tabIndex]]" autosave\$="[[autosave]]" results\$="[[results]]" accept\$="[[accept]]" multiple\$="[[multiple]]">
      </iron-input>

      <slot name="suffix" slot="suffix"></slot>

      <template is="dom-if" if="[[errorMessage]]">
        <paper-input-error aria-live="assertive" slot="add-on">[[errorMessage]]</paper-input-error>
      </template>

      <template is="dom-if" if="[[charCounter]]">
        <paper-input-char-counter slot="add-on"></paper-input-char-counter>
      </template>

    </paper-input-container>
  `,behaviors:[_paper_input_behavior_js__WEBPACK_IMPORTED_MODULE_9__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a],properties:{value:{type:String}},get _focusableElement(){return this.inputElement._inputElement},listeners:{"iron-input-ready":'_onIronInputReady'},_onIronInputReady:function(){if(!this.$.nativeInput){this.$.nativeInput=this.$$('input')}if(this.inputElement&&-1!==this._typesThatHaveText.indexOf(this.$.nativeInput.type)){this.alwaysFloatLabel=!0}if(!!this.inputElement.bindValue){this.$.container._handleValueAndAutoValidate(this.inputElement)}}})},,,function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return IronA11yAnnouncer});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronA11yAnnouncer=Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
    <style>
      :host {
        display: inline-block;
        position: fixed;
        clip: rect(0px,0px,0px,0px);
      }
    </style>
    <div aria-live\$="[[mode]]">[[_text]]</div>
`,is:'iron-a11y-announcer',properties:{mode:{type:String,value:'polite'},_text:{type:String,value:''}},created:function(){if(!IronA11yAnnouncer.instance){IronA11yAnnouncer.instance=this}document.body.addEventListener('iron-announce',this._onIronAnnounce.bind(this))},announce:function(text){this._text='';this.async(function(){this._text=text},100)},_onIronAnnounce:function(event){if(event.detail&&event.detail.text){this.announce(event.detail.text)}}});IronA11yAnnouncer.instance=null;IronA11yAnnouncer.requestAvailability=function(){if(!IronA11yAnnouncer.instance){IronA11yAnnouncer.instance=document.createElement('iron-a11y-announcer')}document.body.appendChild(IronA11yAnnouncer.instance)}},function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_shadow_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(61),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
<dom-module id="paper-material-styles">
  <template>
    <style>
      html {
        --paper-material: {
          display: block;
          position: relative;
        };
        --paper-material-elevation-1: {
          @apply --shadow-elevation-2dp;
        };
        --paper-material-elevation-2: {
          @apply --shadow-elevation-4dp;
        };
        --paper-material-elevation-3: {
          @apply --shadow-elevation-6dp;
        };
        --paper-material-elevation-4: {
          @apply --shadow-elevation-8dp;
        };
        --paper-material-elevation-5: {
          @apply --shadow-elevation-16dp;
        };
      }
      .paper-material {
        @apply --paper-material;
      }
      .paper-material[elevation="1"] {
        @apply --paper-material-elevation-1;
      }
      .paper-material[elevation="2"] {
        @apply --paper-material-elevation-2;
      }
      .paper-material[elevation="3"] {
        @apply --paper-material-elevation-3;
      }
      .paper-material[elevation="4"] {
        @apply --paper-material-elevation-4;
      }
      .paper-material[elevation="5"] {
        @apply --paper-material-elevation-5;
      }

      /* Duplicate the styles because of https://github.com/webcomponents/shadycss/issues/193 */
      :host {
        --paper-material: {
          display: block;
          position: relative;
        };
        --paper-material-elevation-1: {
          @apply --shadow-elevation-2dp;
        };
        --paper-material-elevation-2: {
          @apply --shadow-elevation-4dp;
        };
        --paper-material-elevation-3: {
          @apply --shadow-elevation-6dp;
        };
        --paper-material-elevation-4: {
          @apply --shadow-elevation-8dp;
        };
        --paper-material-elevation-5: {
          @apply --shadow-elevation-16dp;
        };
      }
      :host(.paper-material) {
        @apply --paper-material;
      }
      :host(.paper-material[elevation="1"]) {
        @apply --paper-material-elevation-1;
      }
      :host(.paper-material[elevation="2"]) {
        @apply --paper-material-elevation-2;
      }
      :host(.paper-material[elevation="3"]) {
        @apply --paper-material-elevation-3;
      }
      :host(.paper-material[elevation="4"]) {
        @apply --paper-material-elevation-4;
      }
      :host(.paper-material[elevation="5"]) {
        @apply --paper-material-elevation-5;
      }
    </style>
  </template>
</dom-module>`;template.setAttribute('style','display: none;');document.head.appendChild(template.content)},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return PaperInputBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(19),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(18),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(0),_polymer_polymer_polymer_element_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(10);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperInputHelper={NextLabelID:1,NextAddonID:1,NextInputID:1},PaperInputBehaviorImpl={properties:{label:{type:String},value:{notify:!0,type:String},disabled:{type:Boolean,value:!1},invalid:{type:Boolean,value:!1,notify:!0},allowedPattern:{type:String},type:{type:String},list:{type:String},pattern:{type:String},required:{type:Boolean,value:!1},errorMessage:{type:String},charCounter:{type:Boolean,value:!1},noLabelFloat:{type:Boolean,value:!1},alwaysFloatLabel:{type:Boolean,value:!1},autoValidate:{type:Boolean,value:!1},validator:{type:String},autocomplete:{type:String,value:'off'},autofocus:{type:Boolean,observer:'_autofocusChanged'},inputmode:{type:String},minlength:{type:Number},maxlength:{type:Number},min:{type:String},max:{type:String},step:{type:String},name:{type:String},placeholder:{type:String,value:''},readonly:{type:Boolean,value:!1},size:{type:Number},autocapitalize:{type:String,value:'none'},autocorrect:{type:String,value:'off'},autosave:{type:String},results:{type:Number},accept:{type:String},multiple:{type:Boolean},_ariaDescribedBy:{type:String,value:''},_ariaLabelledBy:{type:String,value:''},_inputId:{type:String,value:''}},listeners:{"addon-attached":'_onAddonAttached'},keyBindings:{"shift+tab:keydown":'_onShiftTabDown'},hostAttributes:{tabindex:0},get inputElement(){if(!this.$){this.$={}}if(!this.$.input){this._generateInputId();this.$.input=this.$$('#'+this._inputId)}return this.$.input},get _focusableElement(){return this.inputElement},created:function(){this._typesThatHaveText=['date','datetime','datetime-local','month','time','week','file']},attached:function(){this._updateAriaLabelledBy();if(!_polymer_polymer_polymer_element_js__WEBPACK_IMPORTED_MODULE_4__.a&&this.inputElement&&-1!==this._typesThatHaveText.indexOf(this.inputElement.type)){this.alwaysFloatLabel=!0}},_appendStringWithSpace:function(str,more){if(str){str=str+' '+more}else{str=more}return str},_onAddonAttached:function(event){var target=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(event).rootTarget;if(target.id){this._ariaDescribedBy=this._appendStringWithSpace(this._ariaDescribedBy,target.id)}else{var id='paper-input-add-on-'+PaperInputHelper.NextAddonID++;target.id=id;this._ariaDescribedBy=this._appendStringWithSpace(this._ariaDescribedBy,id)}},validate:function(){return this.inputElement.validate()},_focusBlurHandler:function(event){_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__.a._focusBlurHandler.call(this,event);if(this.focused&&!this._shiftTabPressed&&this._focusableElement){this._focusableElement.focus()}},_onShiftTabDown:function(){var oldTabIndex=this.getAttribute('tabindex');this._shiftTabPressed=!0;this.setAttribute('tabindex','-1');this.async(function(){this.setAttribute('tabindex',oldTabIndex);this._shiftTabPressed=!1},1)},_handleAutoValidate:function(){if(this.autoValidate)this.validate()},updateValueAndPreserveCaret:function(newValue){try{var start=this.inputElement.selectionStart;this.value=newValue;this.inputElement.selectionStart=start;this.inputElement.selectionEnd=start}catch(e){this.value=newValue}},_computeAlwaysFloatLabel:function(alwaysFloatLabel,placeholder){return placeholder||alwaysFloatLabel},_updateAriaLabelledBy:function(){var label=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_3__.b)(this.root).querySelector('label');if(!label){this._ariaLabelledBy='';return}var labelledBy;if(label.id){labelledBy=label.id}else{labelledBy='paper-input-label-'+PaperInputHelper.NextLabelID++;label.id=labelledBy}this._ariaLabelledBy=labelledBy},_generateInputId:function(){if(!this._inputId||''===this._inputId){this._inputId='input-'+PaperInputHelper.NextInputID++}},_onChange:function(event){if(this.shadowRoot){this.fire(event.type,{sourceEvent:event},{node:this,bubbles:event.bubbles,cancelable:event.cancelable})}},_autofocusChanged:function(){if(this.autofocus&&this._focusableElement){var activeElement=document.activeElement,isActiveElementValid=activeElement instanceof HTMLElement,isSomeElementActive=isActiveElementValid&&activeElement!==document.body&&activeElement!==document.documentElement;if(!isSomeElementActive){this._focusableElement.focus()}}}},PaperInputBehavior=[_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__.a,_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_1__.a,PaperInputBehaviorImpl]},,function(module,__webpack_exports__,__webpack_require__){'use strict';var custom_style_interface=__webpack_require__(54),common_utils=__webpack_require__(21),style_settings=__webpack_require__(9);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const customStyleInterface=new custom_style_interface.a;if(!window.ShadyCSS){window.ShadyCSS={prepareTemplate(){},prepareTemplateDom(){},prepareTemplateStyles(){},styleSubtree(element,properties){customStyleInterface.processStyles();Object(common_utils.c)(element,properties)},styleElement(){customStyleInterface.processStyles()},styleDocument(properties){customStyleInterface.processStyles();Object(common_utils.c)(document.body,properties)},getComputedStyleValue(element,property){return Object(common_utils.b)(element,property)},flushCustomStyles(){},nativeCss:style_settings.b,nativeShadow:style_settings.c,cssBuild:style_settings.a}}window.ShadyCSS.CustomStyleInterface=customStyleInterface;var style_gather=__webpack_require__(35);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const attr='include',CustomStyleInterface=window.ShadyCSS.CustomStyleInterface;class custom_style_CustomStyle extends HTMLElement{constructor(){super();this._style=null;CustomStyleInterface.addCustomStyle(this)}getStyle(){if(this._style){return this._style}const style=this.querySelector('style');if(!style){return null}this._style=style;const include=style.getAttribute(attr);if(include){style.removeAttribute(attr);style.textContent=Object(style_gather.a)(include)+style.textContent}if(this.ownerDocument!==window.document){window.document.head.appendChild(this)}return this._style}}window.customElements.define('custom-style',custom_style_CustomStyle)},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return Templatizer});var _utils_templatize_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(24);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const Templatizer={templatize(template,mutableData){this._templatizerTemplate=template;this.ctor=Object(_utils_templatize_js__WEBPACK_IMPORTED_MODULE_0__.b)(template,this,{mutableData:!!mutableData,parentModel:this._parentModel,instanceProps:this._instanceProps,forwardHostProp:this._forwardHostPropV2,notifyInstanceProp:this._notifyInstancePropV2})},stamp(model){return new this.ctor(model)},modelForElement(el){return Object(_utils_templatize_js__WEBPACK_IMPORTED_MODULE_0__.a)(this._templatizerTemplate,el)}}},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return OptionalMutableDataBehavior});var _mixins_mutable_data_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(20);/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/let mutablePropertyChange;(()=>{mutablePropertyChange=_mixins_mutable_data_js__WEBPACK_IMPORTED_MODULE_0__.a._mutablePropertyChange})();const MutableDataBehavior={_shouldPropertyChange(property,value,old){return mutablePropertyChange(this,property,value,old,!0)}},OptionalMutableDataBehavior={properties:{mutableData:Boolean},_shouldPropertyChange(property,value,old){return mutablePropertyChange(this,property,value,old,this.mutableData)}}},function(){const documentContainer=document.createElement('template');documentContainer.setAttribute('style','display: none;');documentContainer.innerHTML=`<style>
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-Thin.ttf) format("truetype");
font-weight: 100;
font-style: normal;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-ThinItalic.ttf) format("truetype");
font-weight: 100;
font-style: italic;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-Light.ttf) format("truetype");
font-weight: 300;
font-style: normal;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-LightItalic.ttf) format("truetype");
font-weight: 300;
font-style: italic;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-Regular.ttf) format("truetype");
font-weight: 400;
font-style: normal;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-Italic.ttf) format("truetype");
font-weight: 400;
font-style: italic;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-Medium.ttf) format("truetype");
font-weight: 500;
font-style: normal;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-MediumItalic.ttf) format("truetype");
font-weight: 500;
font-style: italic;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-Bold.ttf) format("truetype");
font-weight: 700;
font-style: normal;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-BoldItalic.ttf) format("truetype");
font-weight: 700;
font-style: italic;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-Black.ttf) format("truetype");
font-weight: 900;
font-style: normal;
}
@font-face {
font-family: "Roboto";
src: url(/static/fonts/roboto/Roboto-BlackItalic.ttf) format("truetype");
font-weight: 900;
font-style: italic;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-Thin.ttf) format("truetype");
font-weight: 100;
font-style: normal;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-ThinItalic.ttf) format("truetype");
font-weight: 100;
font-style: italic;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-Light.ttf) format("truetype");
font-weight: 300;
font-style: normal;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-LightItalic.ttf) format("truetype");
font-weight: 300;
font-style: italic;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-Regular.ttf) format("truetype");
font-weight: 400;
font-style: normal;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-Italic.ttf) format("truetype");
font-weight: 400;
font-style: italic;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-Medium.ttf) format("truetype");
font-weight: 500;
font-style: normal;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-MediumItalic.ttf) format("truetype");
font-weight: 500;
font-style: italic;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-Bold.ttf) format("truetype");
font-weight: 700;
font-style: normal;
}
@font-face {
font-family: "Roboto Mono";
src: url(/static/fonts/robotomono/RobotoMono-BoldItalic.ttf) format("truetype");
font-weight: 700;
font-style: italic;
}
</style>`;document.head.appendChild(documentContainer.content);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__(74);const IronIconsetClass=customElements.get('iron-iconset-svg');customElements.define('ha-iconset-svg',class extends IronIconsetClass{_fireIronIconsetAdded(){this.async(()=>this.fire('iron-iconset-added',this,{node:window}))}_nameChanged(){this._meta.value=null;this._meta.key=this.name;this._meta.value=this;if(this.ownerDocument&&'loading'===this.ownerDocument.readyState){this.ownerDocument.addEventListener('DOMContentLoaded',()=>{this._fireIronIconsetAdded()})}else{this._fireIronIconsetAdded()}}})},function(module,exports){'use strict';exports['default']=function(){function peg$SyntaxError(message,expected,found,location){this.message=message;this.expected=expected;this.found=found;this.location=location;this.name='SyntaxError';if('function'===typeof Error.captureStackTrace){Error.captureStackTrace(this,peg$SyntaxError)}}(function(child,parent){function ctor(){this.constructor=child}ctor.prototype=parent.prototype;child.prototype=new ctor})(peg$SyntaxError,Error);function peg$parse(input){var options=1<arguments.length?arguments[1]:{},parser=this,peg$FAILED={},peg$startRuleFunctions={start:peg$parsestart},peg$startRuleFunction=peg$parsestart,peg$c0=function(elements){return{type:'messageFormatPattern',elements:elements,location:location()}},peg$c1=function(text){var string='',i,j,outerLen,inner,innerLen;for(i=0,outerLen=text.length;i<outerLen;i+=1){inner=text[i];for(j=0,innerLen=inner.length;j<innerLen;j+=1){string+=inner[j]}}return string},peg$c2=function(messageText){return{type:'messageTextElement',value:messageText,location:location()}},peg$c3=/^[^ \t\n\r,.+={}#]/,peg$c4={type:'class',value:'[^ \\t\\n\\r,.+={}#]',description:'[^ \\t\\n\\r,.+={}#]'},peg$c5='{',peg$c6={type:'literal',value:'{',description:'"{"'},peg$c7=',',peg$c8={type:'literal',value:',',description:'","'},peg$c9='}',peg$c10={type:'literal',value:'}',description:'"}"'},peg$c11=function(id,format){return{type:'argumentElement',id:id,format:format&&format[2],location:location()}},peg$c12='number',peg$c13={type:'literal',value:'number',description:'"number"'},peg$c14='date',peg$c15={type:'literal',value:'date',description:'"date"'},peg$c16='time',peg$c17={type:'literal',value:'time',description:'"time"'},peg$c18=function(type,style){return{type:type+'Format',style:style&&style[2],location:location()}},peg$c19='plural',peg$c20={type:'literal',value:'plural',description:'"plural"'},peg$c21=function(pluralStyle){return{type:pluralStyle.type,ordinal:!1,offset:pluralStyle.offset||0,options:pluralStyle.options,location:location()}},peg$c22='selectordinal',peg$c23={type:'literal',value:'selectordinal',description:'"selectordinal"'},peg$c24=function(pluralStyle){return{type:pluralStyle.type,ordinal:!0,offset:pluralStyle.offset||0,options:pluralStyle.options,location:location()}},peg$c25='select',peg$c26={type:'literal',value:'select',description:'"select"'},peg$c27=function(options){return{type:'selectFormat',options:options,location:location()}},peg$c29={type:'literal',value:'=',description:'"="'},peg$c30=function(selector,pattern){return{type:'optionalFormatPattern',selector:selector,value:pattern,location:location()}},peg$c31='offset:',peg$c32={type:'literal',value:'offset:',description:'"offset:"'},peg$c33=function(number){return number},peg$c34=function(offset,options){return{type:'pluralFormat',offset:offset,options:options,location:location()}},peg$c35={type:'other',description:'whitespace'},peg$c36=/^[ \t\n\r]/,peg$c37={type:'class',value:'[ \\t\\n\\r]',description:'[ \\t\\n\\r]'},peg$c38={type:'other',description:'optionalWhitespace'},peg$c39=/^[0-9]/,peg$c40={type:'class',value:'[0-9]',description:'[0-9]'},peg$c41=/^[0-9a-f]/i,peg$c42={type:'class',value:'[0-9a-f]i',description:'[0-9a-f]i'},peg$c44={type:'literal',value:'0',description:'"0"'},peg$c45=/^[1-9]/,peg$c46={type:'class',value:'[1-9]',description:'[1-9]'},peg$c47=function(digits){return parseInt(digits,10)},peg$c48=/^[^{}\\\0-\x1F \t\n\r]/,peg$c49={type:'class',value:'[^{}\\\\\\0-\\x1F\\x7f \\t\\n\\r]',description:'[^{}\\\\\\0-\\x1F\\x7f \\t\\n\\r]'},peg$c50='\\\\',peg$c51={type:'literal',value:'\\\\',description:'"\\\\\\\\"'},peg$c52=function(){return'\\'},peg$c53='\\#',peg$c54={type:'literal',value:'\\#',description:'"\\\\#"'},peg$c55=function(){return'\\#'},peg$c56='\\{',peg$c57={type:'literal',value:'\\{',description:'"\\\\{"'},peg$c58=function(){return'{'},peg$c59='\\}',peg$c60={type:'literal',value:'\\}',description:'"\\\\}"'},peg$c61=function(){return'}'},peg$c62='\\u',peg$c63={type:'literal',value:'\\u',description:'"\\\\u"'},peg$c64=function(digits){return String.fromCharCode(parseInt(digits,16))},peg$c65=function(chars){return chars.join('')},peg$currPos=0,peg$savedPos=0,peg$posDetailsCache=[{line:1,column:1,seenCR:!1}],peg$maxFailPos=0,peg$maxFailExpected=[],peg$silentFails=0,peg$result;if('startRule'in options){if(!(options.startRule in peg$startRuleFunctions)){throw new Error('Can\'t start parsing from rule "'+options.startRule+'".')}peg$startRuleFunction=peg$startRuleFunctions[options.startRule]}function location(){return peg$computeLocation(peg$savedPos,peg$currPos)}function peg$computePosDetails(pos){var details=peg$posDetailsCache[pos],p,ch;if(details){return details}else{p=pos-1;while(!peg$posDetailsCache[p]){p--}details=peg$posDetailsCache[p];details={line:details.line,column:details.column,seenCR:details.seenCR};while(p<pos){ch=input.charAt(p);if('\n'===ch){if(!details.seenCR){details.line++}details.column=1;details.seenCR=!1}else if('\r'===ch||'\u2028'===ch||'\u2029'===ch){details.line++;details.column=1;details.seenCR=!0}else{details.column++;details.seenCR=!1}p++}peg$posDetailsCache[pos]=details;return details}}function peg$computeLocation(startPos,endPos){var startPosDetails=peg$computePosDetails(startPos),endPosDetails=peg$computePosDetails(endPos);return{start:{offset:startPos,line:startPosDetails.line,column:startPosDetails.column},end:{offset:endPos,line:endPosDetails.line,column:endPosDetails.column}}}function peg$fail(expected){if(peg$currPos<peg$maxFailPos){return}if(peg$currPos>peg$maxFailPos){peg$maxFailPos=peg$currPos;peg$maxFailExpected=[]}peg$maxFailExpected.push(expected)}function peg$buildException(message,expected,found,location){function cleanupExpected(expected){var i=1;expected.sort(function(a,b){if(a.description<b.description){return-1}else if(a.description>b.description){return 1}else{return 0}});while(i<expected.length){if(expected[i-1]===expected[i]){expected.splice(i,1)}else{i++}}}if(null!==expected){cleanupExpected(expected)}return new peg$SyntaxError(null!==message?message:function(expected,found){var expectedDescs=Array(expected.length),expectedDesc,foundDesc,i;for(i=0;i<expected.length;i++){expectedDescs[i]=expected[i].description}expectedDesc=1<expected.length?expectedDescs.slice(0,-1).join(', ')+' or '+expectedDescs[expected.length-1]:expectedDescs[0];foundDesc=found?'"'+function(s){function hex(ch){return ch.charCodeAt(0).toString(16).toUpperCase()}return s.replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\x08/g,'\\b').replace(/\t/g,'\\t').replace(/\n/g,'\\n').replace(/\f/g,'\\f').replace(/\r/g,'\\r').replace(/[\x00-\x07\x0B\x0E\x0F]/g,function(ch){return'\\x0'+hex(ch)}).replace(/[\x10-\x1F\x80-\xFF]/g,function(ch){return'\\x'+hex(ch)}).replace(/[\u0100-\u0FFF]/g,function(ch){return'\\u0'+hex(ch)}).replace(/[\u1000-\uFFFF]/g,function(ch){return'\\u'+hex(ch)})}(found)+'"':'end of input';return'Expected '+expectedDesc+' but '+foundDesc+' found.'}(expected,found),expected,found,location)}function peg$parsestart(){var s0=peg$parsemessageFormatPattern();return s0}function peg$parsemessageFormatPattern(){var s0,s1,s2;s0=peg$currPos;s1=[];s2=peg$parsemessageFormatElement();while(s2!==peg$FAILED){s1.push(s2);s2=peg$parsemessageFormatElement()}if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c0(s1)}s0=s1;return s0}function peg$parsemessageFormatElement(){var s0=peg$parsemessageTextElement();if(s0===peg$FAILED){s0=peg$parseargumentElement()}return s0}function peg$parsemessageText(){var s0,s1,s2,s3,s4,s5;s0=peg$currPos;s1=[];s2=peg$currPos;s3=peg$parse_();if(s3!==peg$FAILED){s4=peg$parsechars();if(s4!==peg$FAILED){s5=peg$parse_();if(s5!==peg$FAILED){s3=[s3,s4,s5];s2=s3}else{peg$currPos=s2;s2=peg$FAILED}}else{peg$currPos=s2;s2=peg$FAILED}}else{peg$currPos=s2;s2=peg$FAILED}if(s2!==peg$FAILED){while(s2!==peg$FAILED){s1.push(s2);s2=peg$currPos;s3=peg$parse_();if(s3!==peg$FAILED){s4=peg$parsechars();if(s4!==peg$FAILED){s5=peg$parse_();if(s5!==peg$FAILED){s3=[s3,s4,s5];s2=s3}else{peg$currPos=s2;s2=peg$FAILED}}else{peg$currPos=s2;s2=peg$FAILED}}else{peg$currPos=s2;s2=peg$FAILED}}}else{s1=peg$FAILED}if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c1(s1)}s0=s1;if(s0===peg$FAILED){s0=peg$currPos;s1=peg$parsews();if(s1!==peg$FAILED){s0=input.substring(s0,peg$currPos)}else{s0=s1}}return s0}function peg$parsemessageTextElement(){var s0,s1;s0=peg$currPos;s1=peg$parsemessageText();if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c2(s1)}s0=s1;return s0}function peg$parseargument(){var s0,s1,s2;s0=peg$parsenumber();if(s0===peg$FAILED){s0=peg$currPos;s1=[];if(peg$c3.test(input.charAt(peg$currPos))){s2=input.charAt(peg$currPos);peg$currPos++}else{s2=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c4)}}if(s2!==peg$FAILED){while(s2!==peg$FAILED){s1.push(s2);if(peg$c3.test(input.charAt(peg$currPos))){s2=input.charAt(peg$currPos);peg$currPos++}else{s2=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c4)}}}}else{s1=peg$FAILED}if(s1!==peg$FAILED){s0=input.substring(s0,peg$currPos)}else{s0=s1}}return s0}function peg$parseargumentElement(){var s0,s1,s2,s3,s4,s5,s6,s7,s8;s0=peg$currPos;if(123===input.charCodeAt(peg$currPos)){s1=peg$c5;peg$currPos++}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c6)}}if(s1!==peg$FAILED){s2=peg$parse_();if(s2!==peg$FAILED){s3=peg$parseargument();if(s3!==peg$FAILED){s4=peg$parse_();if(s4!==peg$FAILED){s5=peg$currPos;if(44===input.charCodeAt(peg$currPos)){s6=peg$c7;peg$currPos++}else{s6=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c8)}}if(s6!==peg$FAILED){s7=peg$parse_();if(s7!==peg$FAILED){s8=peg$parseelementFormat();if(s8!==peg$FAILED){s6=[s6,s7,s8];s5=s6}else{peg$currPos=s5;s5=peg$FAILED}}else{peg$currPos=s5;s5=peg$FAILED}}else{peg$currPos=s5;s5=peg$FAILED}if(s5===peg$FAILED){s5=null}if(s5!==peg$FAILED){s6=peg$parse_();if(s6!==peg$FAILED){if(125===input.charCodeAt(peg$currPos)){s7=peg$c9;peg$currPos++}else{s7=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c10)}}if(s7!==peg$FAILED){peg$savedPos=s0;s1=peg$c11(s3,s5);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}return s0}function peg$parseelementFormat(){var s0=peg$parsesimpleFormat();if(s0===peg$FAILED){s0=peg$parsepluralFormat();if(s0===peg$FAILED){s0=peg$parseselectOrdinalFormat();if(s0===peg$FAILED){s0=peg$parseselectFormat()}}}return s0}function peg$parsesimpleFormat(){var s0,s1,s2,s3,s4,s5,s6;s0=peg$currPos;if(input.substr(peg$currPos,6)===peg$c12){s1=peg$c12;peg$currPos+=6}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c13)}}if(s1===peg$FAILED){if(input.substr(peg$currPos,4)===peg$c14){s1=peg$c14;peg$currPos+=4}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c15)}}if(s1===peg$FAILED){if(input.substr(peg$currPos,4)===peg$c16){s1=peg$c16;peg$currPos+=4}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c17)}}}}if(s1!==peg$FAILED){s2=peg$parse_();if(s2!==peg$FAILED){s3=peg$currPos;if(44===input.charCodeAt(peg$currPos)){s4=peg$c7;peg$currPos++}else{s4=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c8)}}if(s4!==peg$FAILED){s5=peg$parse_();if(s5!==peg$FAILED){s6=peg$parsechars();if(s6!==peg$FAILED){s4=[s4,s5,s6];s3=s4}else{peg$currPos=s3;s3=peg$FAILED}}else{peg$currPos=s3;s3=peg$FAILED}}else{peg$currPos=s3;s3=peg$FAILED}if(s3===peg$FAILED){s3=null}if(s3!==peg$FAILED){peg$savedPos=s0;s1=peg$c18(s1,s3);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}return s0}function peg$parsepluralFormat(){var s0,s1,s2,s3,s4,s5;s0=peg$currPos;if(input.substr(peg$currPos,6)===peg$c19){s1=peg$c19;peg$currPos+=6}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c20)}}if(s1!==peg$FAILED){s2=peg$parse_();if(s2!==peg$FAILED){if(44===input.charCodeAt(peg$currPos)){s3=peg$c7;peg$currPos++}else{s3=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c8)}}if(s3!==peg$FAILED){s4=peg$parse_();if(s4!==peg$FAILED){s5=peg$parsepluralStyle();if(s5!==peg$FAILED){peg$savedPos=s0;s1=peg$c21(s5);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}return s0}function peg$parseselectOrdinalFormat(){var s0,s1,s2,s3,s4,s5;s0=peg$currPos;if(input.substr(peg$currPos,13)===peg$c22){s1=peg$c22;peg$currPos+=13}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c23)}}if(s1!==peg$FAILED){s2=peg$parse_();if(s2!==peg$FAILED){if(44===input.charCodeAt(peg$currPos)){s3=peg$c7;peg$currPos++}else{s3=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c8)}}if(s3!==peg$FAILED){s4=peg$parse_();if(s4!==peg$FAILED){s5=peg$parsepluralStyle();if(s5!==peg$FAILED){peg$savedPos=s0;s1=peg$c24(s5);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}return s0}function peg$parseselectFormat(){var s0,s1,s2,s3,s4,s5,s6;s0=peg$currPos;if(input.substr(peg$currPos,6)===peg$c25){s1=peg$c25;peg$currPos+=6}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c26)}}if(s1!==peg$FAILED){s2=peg$parse_();if(s2!==peg$FAILED){if(44===input.charCodeAt(peg$currPos)){s3=peg$c7;peg$currPos++}else{s3=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c8)}}if(s3!==peg$FAILED){s4=peg$parse_();if(s4!==peg$FAILED){s5=[];s6=peg$parseoptionalFormatPattern();if(s6!==peg$FAILED){while(s6!==peg$FAILED){s5.push(s6);s6=peg$parseoptionalFormatPattern()}}else{s5=peg$FAILED}if(s5!==peg$FAILED){peg$savedPos=s0;s1=peg$c27(s5);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}return s0}function peg$parseselector(){var s0,s1,s2,s3;s0=peg$currPos;s1=peg$currPos;if(61===input.charCodeAt(peg$currPos)){s2='=';peg$currPos++}else{s2=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c29)}}if(s2!==peg$FAILED){s3=peg$parsenumber();if(s3!==peg$FAILED){s2=[s2,s3];s1=s2}else{peg$currPos=s1;s1=peg$FAILED}}else{peg$currPos=s1;s1=peg$FAILED}if(s1!==peg$FAILED){s0=input.substring(s0,peg$currPos)}else{s0=s1}if(s0===peg$FAILED){s0=peg$parsechars()}return s0}function peg$parseoptionalFormatPattern(){var s0,s1,s2,s3,s4,s5,s6,s7,s8;s0=peg$currPos;s1=peg$parse_();if(s1!==peg$FAILED){s2=peg$parseselector();if(s2!==peg$FAILED){s3=peg$parse_();if(s3!==peg$FAILED){if(123===input.charCodeAt(peg$currPos)){s4=peg$c5;peg$currPos++}else{s4=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c6)}}if(s4!==peg$FAILED){s5=peg$parse_();if(s5!==peg$FAILED){s6=peg$parsemessageFormatPattern();if(s6!==peg$FAILED){s7=peg$parse_();if(s7!==peg$FAILED){if(125===input.charCodeAt(peg$currPos)){s8=peg$c9;peg$currPos++}else{s8=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c10)}}if(s8!==peg$FAILED){peg$savedPos=s0;s1=peg$c30(s2,s6);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}return s0}function peg$parseoffset(){var s0,s1,s2,s3;s0=peg$currPos;if(input.substr(peg$currPos,7)===peg$c31){s1=peg$c31;peg$currPos+=7}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c32)}}if(s1!==peg$FAILED){s2=peg$parse_();if(s2!==peg$FAILED){s3=peg$parsenumber();if(s3!==peg$FAILED){peg$savedPos=s0;s1=peg$c33(s3);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}return s0}function peg$parsepluralStyle(){var s0,s1,s2,s3,s4;s0=peg$currPos;s1=peg$parseoffset();if(s1===peg$FAILED){s1=null}if(s1!==peg$FAILED){s2=peg$parse_();if(s2!==peg$FAILED){s3=[];s4=peg$parseoptionalFormatPattern();if(s4!==peg$FAILED){while(s4!==peg$FAILED){s3.push(s4);s4=peg$parseoptionalFormatPattern()}}else{s3=peg$FAILED}if(s3!==peg$FAILED){peg$savedPos=s0;s1=peg$c34(s1,s3);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}return s0}function peg$parsews(){var s0,s1;peg$silentFails++;s0=[];if(peg$c36.test(input.charAt(peg$currPos))){s1=input.charAt(peg$currPos);peg$currPos++}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c37)}}if(s1!==peg$FAILED){while(s1!==peg$FAILED){s0.push(s1);if(peg$c36.test(input.charAt(peg$currPos))){s1=input.charAt(peg$currPos);peg$currPos++}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c37)}}}}else{s0=peg$FAILED}peg$silentFails--;if(s0===peg$FAILED){s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c35)}}return s0}function peg$parse_(){var s0,s1,s2;peg$silentFails++;s0=peg$currPos;s1=[];s2=peg$parsews();while(s2!==peg$FAILED){s1.push(s2);s2=peg$parsews()}if(s1!==peg$FAILED){s0=input.substring(s0,peg$currPos)}else{s0=s1}peg$silentFails--;if(s0===peg$FAILED){s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c38)}}return s0}function peg$parsedigit(){var s0;if(peg$c39.test(input.charAt(peg$currPos))){s0=input.charAt(peg$currPos);peg$currPos++}else{s0=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c40)}}return s0}function peg$parsehexDigit(){var s0;if(peg$c41.test(input.charAt(peg$currPos))){s0=input.charAt(peg$currPos);peg$currPos++}else{s0=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c42)}}return s0}function peg$parsenumber(){var s0,s1,s2,s3,s4,s5;s0=peg$currPos;if(48===input.charCodeAt(peg$currPos)){s1='0';peg$currPos++}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c44)}}if(s1===peg$FAILED){s1=peg$currPos;s2=peg$currPos;if(peg$c45.test(input.charAt(peg$currPos))){s3=input.charAt(peg$currPos);peg$currPos++}else{s3=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c46)}}if(s3!==peg$FAILED){s4=[];s5=peg$parsedigit();while(s5!==peg$FAILED){s4.push(s5);s5=peg$parsedigit()}if(s4!==peg$FAILED){s3=[s3,s4];s2=s3}else{peg$currPos=s2;s2=peg$FAILED}}else{peg$currPos=s2;s2=peg$FAILED}if(s2!==peg$FAILED){s1=input.substring(s1,peg$currPos)}else{s1=s2}}if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c47(s1)}s0=s1;return s0}function peg$parsechar(){var s0,s1,s2,s3,s4,s5,s6,s7;if(peg$c48.test(input.charAt(peg$currPos))){s0=input.charAt(peg$currPos);peg$currPos++}else{s0=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c49)}}if(s0===peg$FAILED){s0=peg$currPos;if(input.substr(peg$currPos,2)===peg$c50){s1=peg$c50;peg$currPos+=2}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c51)}}if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c52()}s0=s1;if(s0===peg$FAILED){s0=peg$currPos;if(input.substr(peg$currPos,2)===peg$c53){s1=peg$c53;peg$currPos+=2}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c54)}}if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c55()}s0=s1;if(s0===peg$FAILED){s0=peg$currPos;if(input.substr(peg$currPos,2)===peg$c56){s1=peg$c56;peg$currPos+=2}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c57)}}if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c58()}s0=s1;if(s0===peg$FAILED){s0=peg$currPos;if(input.substr(peg$currPos,2)===peg$c59){s1=peg$c59;peg$currPos+=2}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c60)}}if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c61()}s0=s1;if(s0===peg$FAILED){s0=peg$currPos;if(input.substr(peg$currPos,2)===peg$c62){s1=peg$c62;peg$currPos+=2}else{s1=peg$FAILED;if(0===peg$silentFails){peg$fail(peg$c63)}}if(s1!==peg$FAILED){s2=peg$currPos;s3=peg$currPos;s4=peg$parsehexDigit();if(s4!==peg$FAILED){s5=peg$parsehexDigit();if(s5!==peg$FAILED){s6=peg$parsehexDigit();if(s6!==peg$FAILED){s7=peg$parsehexDigit();if(s7!==peg$FAILED){s4=[s4,s5,s6,s7];s3=s4}else{peg$currPos=s3;s3=peg$FAILED}}else{peg$currPos=s3;s3=peg$FAILED}}else{peg$currPos=s3;s3=peg$FAILED}}else{peg$currPos=s3;s3=peg$FAILED}if(s3!==peg$FAILED){s2=input.substring(s2,peg$currPos)}else{s2=s3}if(s2!==peg$FAILED){peg$savedPos=s0;s1=peg$c64(s2);s0=s1}else{peg$currPos=s0;s0=peg$FAILED}}else{peg$currPos=s0;s0=peg$FAILED}}}}}}return s0}function peg$parsechars(){var s0,s1,s2;s0=peg$currPos;s1=[];s2=peg$parsechar();if(s2!==peg$FAILED){while(s2!==peg$FAILED){s1.push(s2);s2=peg$parsechar()}}else{s1=peg$FAILED}if(s1!==peg$FAILED){peg$savedPos=s0;s1=peg$c65(s1)}s0=s1;return s0}peg$result=peg$startRuleFunction();if(peg$result!==peg$FAILED&&peg$currPos===input.length){return peg$result}else{if(peg$result!==peg$FAILED&&peg$currPos<input.length){peg$fail({type:'end',description:'end of input'})}throw peg$buildException(null,peg$maxFailExpected,peg$maxFailPos<input.length?input.charAt(peg$maxFailPos):null,peg$maxFailPos<input.length?peg$computeLocation(peg$maxFailPos,peg$maxFailPos+1):peg$computeLocation(peg$maxFailPos,peg$maxFailPos))}}return{SyntaxError:peg$SyntaxError,parse:peg$parse}}()},function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.d(__webpack_exports__,'a',function(){return localizeLiteMixin});var _polymer_polymer_lib_utils_mixin__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(5),_util_hass_translation__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(41),_localize_lite_base_mixin__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(70);const localizeLiteMixin=Object(_polymer_polymer_lib_utils_mixin__WEBPACK_IMPORTED_MODULE_0__.a)(superClass=>class extends Object(_localize_lite_base_mixin__WEBPACK_IMPORTED_MODULE_2__.a)(superClass){static get properties(){return{language:{type:String,value:Object(_util_hass_translation__WEBPACK_IMPORTED_MODULE_1__.a)()},resources:Object,translationFragment:String,localize:{type:Function,computed:'__computeLocalize(language, resources, formats)'}}}ready(){super.ready();this._initializeLocalizeLite()}})},,,,,,,,,,function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_a11y_announcer_iron_a11y_announcer_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(81),_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(53),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(0),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__.a`
    <style>
      :host {
        display: inline-block;
      }
    </style>
    <slot id="content"></slot>
`,is:'iron-input',behaviors:[_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a],properties:{bindValue:{type:String,value:''},value:{type:String,computed:'_computeValue(bindValue)'},allowedPattern:{type:String},autoValidate:{type:Boolean,value:!1},_inputElement:Object},observers:['_bindValueChanged(bindValue, _inputElement)'],listeners:{input:'_onInput',keypress:'_onKeypress'},created:function(){_polymer_iron_a11y_announcer_iron_a11y_announcer_js__WEBPACK_IMPORTED_MODULE_1__.a.requestAvailability();this._previousValidInput='';this._patternAlreadyChecked=!1},attached:function(){this._observer=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__.b)(this).observeNodes(function(){this._initSlottedInput()}.bind(this))},detached:function(){if(this._observer){Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__.b)(this).unobserveNodes(this._observer);this._observer=null}},get inputElement(){return this._inputElement},_initSlottedInput:function(){this._inputElement=this.getEffectiveChildren()[0];if(this.inputElement&&this.inputElement.value){this.bindValue=this.inputElement.value}this.fire('iron-input-ready')},get _patternRegExp(){var pattern;if(this.allowedPattern){pattern=new RegExp(this.allowedPattern)}else{switch(this.inputElement.type){case'number':pattern=/[0-9.,e-]/;break;}}return pattern},_bindValueChanged:function(bindValue,inputElement){if(!inputElement){return}if(bindValue===void 0){inputElement.value=null}else if(bindValue!==inputElement.value){this.inputElement.value=bindValue}if(this.autoValidate){this.validate()}this.fire('bind-value-changed',{value:bindValue})},_onInput:function(){if(this.allowedPattern&&!this._patternAlreadyChecked){var valid=this._checkPatternValidity();if(!valid){this._announceInvalidCharacter('Invalid string of characters not entered.');this.inputElement.value=this._previousValidInput}}this.bindValue=this._previousValidInput=this.inputElement.value;this._patternAlreadyChecked=!1},_isPrintable:function(event){var anyNonPrintable=8==event.keyCode||9==event.keyCode||13==event.keyCode||27==event.keyCode,mozNonPrintable=19==event.keyCode||20==event.keyCode||45==event.keyCode||46==event.keyCode||144==event.keyCode||145==event.keyCode||32<event.keyCode&&41>event.keyCode||111<event.keyCode&&124>event.keyCode;return!anyNonPrintable&&!(0==event.charCode&&mozNonPrintable)},_onKeypress:function(event){if(!this.allowedPattern&&'number'!==this.inputElement.type){return}var regexp=this._patternRegExp;if(!regexp){return}if(event.metaKey||event.ctrlKey||event.altKey){return}this._patternAlreadyChecked=!0;var thisChar=String.fromCharCode(event.charCode);if(this._isPrintable(event)&&!regexp.test(thisChar)){event.preventDefault();this._announceInvalidCharacter('Invalid character '+thisChar+' not entered.')}},_checkPatternValidity:function(){var regexp=this._patternRegExp;if(!regexp){return!0}for(var i=0;i<this.inputElement.value.length;i++){if(!regexp.test(this.inputElement.value[i])){return!1}}return!0},validate:function(){if(!this.inputElement){this.invalid=!1;return!0}var valid=this.inputElement.checkValidity();if(valid){if(this.required&&''===this.bindValue){valid=!1}else if(this.hasValidator()){valid=_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a.validate.call(this,this.bindValue)}}this.invalid=!valid;this.fire('iron-input-validate');return valid},_announceInvalidCharacter:function(message){this.fire('iron-announce',{text:message})},_computeValue:function(bindValue){return bindValue}})},function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_paper_styles_typography_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(50),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(1),_paper_input_addon_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(59);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_2__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_3__.a`
    <style>
      :host {
        display: inline-block;
        float: right;

        @apply --paper-font-caption;
        @apply --paper-input-char-counter;
      }

      :host([hidden]) {
        display: none !important;
      }

      :host(:dir(rtl)) {
        float: left;
      }
    </style>

    <span>[[_charCounterStr]]</span>
`,is:'paper-input-char-counter',behaviors:[_paper_input_addon_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a],properties:{_charCounterStr:{type:String,value:'0'}},update:function(state){if(!state.inputElement){return}state.value=state.value||'';var counter=state.value.toString().length.toString();if(state.inputElement.hasAttribute('maxlength')){counter+='/'+state.inputElement.getAttribute('maxlength')}this._charCounterStr=counter}})},function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(39),_polymer_paper_styles_typography_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(50),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(0),_polymer_polymer_lib_utils_case_map_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(15),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_7__.a`
<custom-style>
  <style is="custom-style">
    html {
      --paper-input-container-shared-input-style: {
        position: relative; /* to make a stacking context */
        outline: none;
        box-shadow: none;
        padding: 0;
        margin: 0;
        width: 100%;
        max-width: 100%;
        background: transparent;
        border: none;
        color: var(--paper-input-container-input-color, var(--primary-text-color));
        -webkit-appearance: none;
        text-align: inherit;
        vertical-align: var(--paper-input-container-input-align, bottom);

        @apply --paper-font-subhead;
      };
    }
  </style>
</custom-style>
`;template.setAttribute('style','display: none;');document.head.appendChild(template.content);Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_7__.a`
    <style>
      :host {
        display: block;
        padding: 8px 0;
        @apply --paper-input-container;
      }

      :host([inline]) {
        display: inline-block;
      }

      :host([disabled]) {
        pointer-events: none;
        opacity: 0.33;

        @apply --paper-input-container-disabled;
      }

      :host([hidden]) {
        display: none !important;
      }

      [hidden] {
        display: none !important;
      }

      .floated-label-placeholder {
        @apply --paper-font-caption;
      }

      .underline {
        height: 2px;
        position: relative;
      }

      .focused-line {
        @apply --layout-fit;
        border-bottom: 2px solid var(--paper-input-container-focus-color, var(--primary-color));

        -webkit-transform-origin: center center;
        transform-origin: center center;
        -webkit-transform: scale3d(0,1,1);
        transform: scale3d(0,1,1);

        @apply --paper-input-container-underline-focus;
      }

      .underline.is-highlighted .focused-line {
        -webkit-transform: none;
        transform: none;
        -webkit-transition: -webkit-transform 0.25s;
        transition: transform 0.25s;

        @apply --paper-transition-easing;
      }

      .underline.is-invalid .focused-line {
        border-color: var(--paper-input-container-invalid-color, var(--error-color));
        -webkit-transform: none;
        transform: none;
        -webkit-transition: -webkit-transform 0.25s;
        transition: transform 0.25s;

        @apply --paper-transition-easing;
      }

      .unfocused-line {
        @apply --layout-fit;
        border-bottom: 1px solid var(--paper-input-container-color, var(--secondary-text-color));
        @apply --paper-input-container-underline;
      }

      :host([disabled]) .unfocused-line {
        border-bottom: 1px dashed;
        border-color: var(--paper-input-container-color, var(--secondary-text-color));
        @apply --paper-input-container-underline-disabled;
      }

      .input-wrapper {
        @apply --layout-horizontal;
        @apply --layout-center;
        position: relative;
      }

      .input-content {
        @apply --layout-flex-auto;
        @apply --layout-relative;
        max-width: 100%;
      }

      .input-content ::slotted(label),
      .input-content ::slotted(.paper-input-label) {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        font: inherit;
        color: var(--paper-input-container-color, var(--secondary-text-color));
        -webkit-transition: -webkit-transform 0.25s, width 0.25s;
        transition: transform 0.25s, width 0.25s;
        -webkit-transform-origin: left top;
        transform-origin: left top;
        /* Fix for safari not focusing 0-height date/time inputs with -webkit-apperance: none; */
        min-height: 1px;

        @apply --paper-font-common-nowrap;
        @apply --paper-font-subhead;
        @apply --paper-input-container-label;
        @apply --paper-transition-easing;
      }

      .input-content.label-is-floating ::slotted(label),
      .input-content.label-is-floating ::slotted(.paper-input-label) {
        -webkit-transform: translateY(-75%) scale(0.75);
        transform: translateY(-75%) scale(0.75);

        /* Since we scale to 75/100 of the size, we actually have 100/75 of the
        original space now available */
        width: 133%;

        @apply --paper-input-container-label-floating;
      }

      :host(:dir(rtl)) .input-content.label-is-floating ::slotted(label),
      :host(:dir(rtl)) .input-content.label-is-floating ::slotted(.paper-input-label) {
        right: 0;
        left: auto;
        -webkit-transform-origin: right top;
        transform-origin: right top;
      }

      .input-content.label-is-highlighted ::slotted(label),
      .input-content.label-is-highlighted ::slotted(.paper-input-label) {
        color: var(--paper-input-container-focus-color, var(--primary-color));

        @apply --paper-input-container-label-focus;
      }

      .input-content.is-invalid ::slotted(label),
      .input-content.is-invalid ::slotted(.paper-input-label) {
        color: var(--paper-input-container-invalid-color, var(--error-color));
      }

      .input-content.label-is-hidden ::slotted(label),
      .input-content.label-is-hidden ::slotted(.paper-input-label) {
        visibility: hidden;
      }

      .input-content ::slotted(input),
      .input-content ::slotted(iron-input),
      .input-content ::slotted(textarea),
      .input-content ::slotted(iron-autogrow-textarea),
      .input-content ::slotted(.paper-input-input) {
        @apply --paper-input-container-shared-input-style;
        /* The apply shim doesn't apply the nested color custom property,
          so we have to re-apply it here. */
        color: var(--paper-input-container-input-color, var(--primary-text-color));
        @apply --paper-input-container-input;
      }

      .input-content ::slotted(input)::-webkit-outer-spin-button,
      .input-content ::slotted(input)::-webkit-inner-spin-button {
        @apply --paper-input-container-input-webkit-spinner;
      }

      .input-content.focused ::slotted(input),
      .input-content.focused ::slotted(iron-input),
      .input-content.focused ::slotted(textarea),
      .input-content.focused ::slotted(iron-autogrow-textarea),
      .input-content.focused ::slotted(.paper-input-input) {
        @apply --paper-input-container-input-focus;
      }

      .input-content.is-invalid ::slotted(input),
      .input-content.is-invalid ::slotted(iron-input),
      .input-content.is-invalid ::slotted(textarea),
      .input-content.is-invalid ::slotted(iron-autogrow-textarea),
      .input-content.is-invalid ::slotted(.paper-input-input) {
        @apply --paper-input-container-input-invalid;
      }

      .prefix ::slotted(*) {
        display: inline-block;
        @apply --paper-font-subhead;
        @apply --layout-flex-none;
        @apply --paper-input-prefix;
      }

      .suffix ::slotted(*) {
        display: inline-block;
        @apply --paper-font-subhead;
        @apply --layout-flex-none;

        @apply --paper-input-suffix;
      }

      /* Firefox sets a min-width on the input, which can cause layout issues */
      .input-content ::slotted(input) {
        min-width: 0;
      }

      .input-content ::slotted(textarea) {
        resize: none;
      }

      .add-on-content {
        position: relative;
      }

      .add-on-content.is-invalid ::slotted(*) {
        color: var(--paper-input-container-invalid-color, var(--error-color));
      }

      .add-on-content.is-highlighted ::slotted(*) {
        color: var(--paper-input-container-focus-color, var(--primary-color));
      }
    </style>

    <div class="floated-label-placeholder" aria-hidden="true" hidden="[[noLabelFloat]]">&nbsp;</div>

    <div class="input-wrapper">
      <span class="prefix"><slot name="prefix"></slot></span>

      <div class\$="[[_computeInputContentClass(noLabelFloat,alwaysFloatLabel,focused,invalid,_inputHasContent)]]" id="labelAndInputContainer">
        <slot name="label"></slot>
        <slot name="input"></slot>
      </div>

      <span class="suffix"><slot name="suffix"></slot></span>
    </div>

    <div class\$="[[_computeUnderlineClass(focused,invalid)]]">
      <div class="unfocused-line"></div>
      <div class="focused-line"></div>
    </div>

    <div class\$="[[_computeAddOnContentClass(focused,invalid)]]">
      <slot name="add-on"></slot>
    </div>
`,is:'paper-input-container',properties:{noLabelFloat:{type:Boolean,value:!1},alwaysFloatLabel:{type:Boolean,value:!1},attrForValue:{type:String,value:'bind-value'},autoValidate:{type:Boolean,value:!1},invalid:{observer:'_invalidChanged',type:Boolean,value:!1},focused:{readOnly:!0,type:Boolean,value:!1,notify:!0},_addons:{type:Array},_inputHasContent:{type:Boolean,value:!1},_inputSelector:{type:String,value:'input,iron-input,textarea,.paper-input-input'},_boundOnFocus:{type:Function,value:function(){return this._onFocus.bind(this)}},_boundOnBlur:{type:Function,value:function(){return this._onBlur.bind(this)}},_boundOnInput:{type:Function,value:function(){return this._onInput.bind(this)}},_boundValueChanged:{type:Function,value:function(){return this._onValueChanged.bind(this)}}},listeners:{"addon-attached":'_onAddonAttached',"iron-input-validate":'_onIronInputValidate'},get _valueChangedEvent(){return this.attrForValue+'-changed'},get _propertyForValue(){return Object(_polymer_polymer_lib_utils_case_map_js__WEBPACK_IMPORTED_MODULE_6__.b)(this.attrForValue)},get _inputElement(){return Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_5__.b)(this).querySelector(this._inputSelector)},get _inputElementValue(){return this._inputElement[this._propertyForValue]||this._inputElement.value},ready:function(){this.__isFirstValueUpdate=!0;if(!this._addons){this._addons=[]}this.addEventListener('focus',this._boundOnFocus,!0);this.addEventListener('blur',this._boundOnBlur,!0)},attached:function(){if(this.attrForValue){this._inputElement.addEventListener(this._valueChangedEvent,this._boundValueChanged)}else{this.addEventListener('input',this._onInput)}if(this._inputElementValue&&''!=this._inputElementValue){this._handleValueAndAutoValidate(this._inputElement)}else{this._handleValue(this._inputElement)}},_onAddonAttached:function(event){if(!this._addons){this._addons=[]}var target=event.target;if(-1===this._addons.indexOf(target)){this._addons.push(target);if(this.isAttached){this._handleValue(this._inputElement)}}},_onFocus:function(){this._setFocused(!0)},_onBlur:function(){this._setFocused(!1);this._handleValueAndAutoValidate(this._inputElement)},_onInput:function(event){this._handleValueAndAutoValidate(event.target)},_onValueChanged:function(event){var input=event.target;if(this.__isFirstValueUpdate){this.__isFirstValueUpdate=!1;if(input.value===void 0||''===input.value){return}}this._handleValueAndAutoValidate(event.target)},_handleValue:function(inputElement){var value=this._inputElementValue;if(value||0===value||'number'===inputElement.type&&!inputElement.checkValidity()){this._inputHasContent=!0}else{this._inputHasContent=!1}this.updateAddons({inputElement:inputElement,value:value,invalid:this.invalid})},_handleValueAndAutoValidate:function(inputElement){if(this.autoValidate&&inputElement){var valid;if(inputElement.validate){valid=inputElement.validate(this._inputElementValue)}else{valid=inputElement.checkValidity()}this.invalid=!valid}this._handleValue(inputElement)},_onIronInputValidate:function(){this.invalid=this._inputElement.invalid},_invalidChanged:function(){if(this._addons){this.updateAddons({invalid:this.invalid})}},updateAddons:function(state){for(var addon,index=0;addon=this._addons[index];index++){addon.update(state)}},_computeInputContentClass:function(noLabelFloat,alwaysFloatLabel,focused,invalid,_inputHasContent){var cls='input-content';if(!noLabelFloat){var label=this.querySelector('label');if(alwaysFloatLabel||_inputHasContent){cls+=' label-is-floating';this.$.labelAndInputContainer.style.position='static';if(invalid){cls+=' is-invalid'}else if(focused){cls+=' label-is-highlighted'}}else{if(label){this.$.labelAndInputContainer.style.position='relative'}if(invalid){cls+=' is-invalid'}}}else{if(_inputHasContent){cls+=' label-is-hidden'}if(invalid){cls+=' is-invalid'}}if(focused){cls+=' focused'}return cls},_computeUnderlineClass:function(focused,invalid){var cls='underline';if(invalid){cls+=' is-invalid'}else if(focused){cls+=' is-highlighted'}return cls},_computeAddOnContentClass:function(focused,invalid){var cls='add-on-content';if(invalid){cls+=' is-invalid'}else if(focused){cls+=' is-highlighted'}return cls}})},function(module,__webpack_exports__,__webpack_require__){'use strict';var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(39),_polymer_paper_styles_typography_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(50),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(1),_paper_input_addon_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(59);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__.a`
    <style>
      :host {
        display: inline-block;
        visibility: hidden;

        color: var(--paper-input-container-invalid-color, var(--error-color));

        @apply --paper-font-caption;
        @apply --paper-input-error;
        position: absolute;
        left:0;
        right:0;
      }

      :host([invalid]) {
        visibility: visible;
      };
    </style>

    <slot></slot>
`,is:'paper-input-error',behaviors:[_paper_input_addon_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a],properties:{invalid:{readOnly:!0,reflectToAttribute:!0,type:Boolean}},update:function(state){this._setInvalid(state.invalid)}})},,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,function(module,__webpack_exports__,__webpack_require__){'use strict';__webpack_require__.r(__webpack_exports__);var ha_iconset_svg=__webpack_require__(89),roboto=__webpack_require__(88),dom_if=__webpack_require__(67),dom_repeat=__webpack_require__(66),paper_input=__webpack_require__(78),paper_button=__webpack_require__(72),html_tag=__webpack_require__(1),polymer_element=__webpack_require__(10),localize_lite_mixin=__webpack_require__(91);class ha_onboarding_HaOnboarding extends Object(localize_lite_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
    <style>
      .error {
        color: red;
      }

      .action {
        margin: 32px 0;
        text-align: center;
      }
    </style>

    <p>
      [[localize('ui.panel.page-onboarding.intro')]]
    </p>

    <p>
      [[localize('ui.panel.page-onboarding.user.intro')]]
    </p>

    <template is='dom-if' if='[[_errorMsg]]'>
      <p class='error'>[[_computeErrorMsg(localize, _errorMsg)]]</p>
    </template>

    <form>
      <paper-input
        autofocus
        label="[[localize('ui.panel.page-onboarding.user.data.name')]]"
        value='{{_name}}'
        required
        auto-validate
        autocapitalize='on'
        error-message="[[localize('ui.panel.page-onboarding.user.required_field')]]"
        on-blur='_maybePopulateUsername'
      ></paper-input>

      <paper-input
        label="[[localize('ui.panel.page-onboarding.user.data.username')]]"
        value='{{_username}}'
        required
        auto-validate
        autocapitalize='none'
        error-message="[[localize('ui.panel.page-onboarding.user.required_field')]]"
      ></paper-input>

      <paper-input
        label="[[localize('ui.panel.page-onboarding.user.data.password')]]"
        value='{{_password}}'
        required
        type='password'
        auto-validate
        error-message="[[localize('ui.panel.page-onboarding.user.required_field')]]"
      ></paper-input>

      <template is='dom-if' if='[[!_loading]]'>
        <p class='action'>
          <paper-button raised on-click='_submitForm'>
            [[localize('ui.panel.page-onboarding.user.create_account')]]
          </paper-button>
        </p>
      </template>
    </div>
  </form>
`}static get properties(){return{_name:String,_username:String,_password:String,_loading:{type:Boolean,value:!1},translationFragment:{type:String,value:'page-onboarding'},_errorMsg:String}}async ready(){super.ready();this.addEventListener('keypress',ev=>{if(13===ev.keyCode){this._submitForm()}});try{const response=await window.stepsPromise;if(404===response.status){document.location='/';return}const steps=await response.json();if(steps.every(step=>step.done)){document.location='/'}}catch(err){alert('Something went wrong loading loading onboarding, try refreshing')}}_maybePopulateUsername(){if(this._username)return;const parts=this._name.split(' ');if(parts.length){this._username=parts[0].toLowerCase()}}async _submitForm(){if(!this._name||!this._username||!this._password){this._errorMsg='required_fields';return}this._errorMsg='';try{const response=await fetch('/api/onboarding/users',{method:'POST',credentials:'same-origin',body:JSON.stringify({name:this._name,username:this._username,password:this._password})});if(!response.ok){throw{message:`Bad response from server: ${response.status}`}}document.location='/'}catch(err){console.error(err);this.setProperties({_loading:!1,_errorMsg:err.message})}}_computeErrorMsg(localize,errorMsg){return localize(`ui.panel.page-onboarding.user.error.${errorMsg}`)||errorMsg}}customElements.define('ha-onboarding',ha_onboarding_HaOnboarding)}]);
//# sourceMappingURL=onboarding-536637dc.js.map