(window.webpackJsonp=window.webpackJsonp||[]).push([[41,105],{101:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_a11y_announcer_iron_a11y_announcer_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(81),_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(53),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(0),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__.a`
    <style>
      :host {
        display: inline-block;
      }
    </style>
    <slot id="content"></slot>
`,is:"iron-input",behaviors:[_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a],properties:{bindValue:{type:String,value:""},value:{type:String,computed:"_computeValue(bindValue)"},allowedPattern:{type:String},autoValidate:{type:Boolean,value:!1},_inputElement:Object},observers:["_bindValueChanged(bindValue, _inputElement)"],listeners:{input:"_onInput",keypress:"_onKeypress"},created:function(){_polymer_iron_a11y_announcer_iron_a11y_announcer_js__WEBPACK_IMPORTED_MODULE_1__.a.requestAvailability();this._previousValidInput="";this._patternAlreadyChecked=!1},attached:function(){this._observer=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__.b)(this).observeNodes(function(){this._initSlottedInput()}.bind(this))},detached:function(){if(this._observer){Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__.b)(this).unobserveNodes(this._observer);this._observer=null}},get inputElement(){return this._inputElement},_initSlottedInput:function(){this._inputElement=this.getEffectiveChildren()[0];if(this.inputElement&&this.inputElement.value){this.bindValue=this.inputElement.value}this.fire("iron-input-ready")},get _patternRegExp(){var pattern;if(this.allowedPattern){pattern=new RegExp(this.allowedPattern)}else{switch(this.inputElement.type){case"number":pattern=/[0-9.,e-]/;break;}}return pattern},_bindValueChanged:function(bindValue,inputElement){if(!inputElement){return}if(bindValue===void 0){inputElement.value=null}else if(bindValue!==inputElement.value){this.inputElement.value=bindValue}if(this.autoValidate){this.validate()}this.fire("bind-value-changed",{value:bindValue})},_onInput:function(){if(this.allowedPattern&&!this._patternAlreadyChecked){var valid=this._checkPatternValidity();if(!valid){this._announceInvalidCharacter("Invalid string of characters not entered.");this.inputElement.value=this._previousValidInput}}this.bindValue=this._previousValidInput=this.inputElement.value;this._patternAlreadyChecked=!1},_isPrintable:function(event){var anyNonPrintable=8==event.keyCode||9==event.keyCode||13==event.keyCode||27==event.keyCode,mozNonPrintable=19==event.keyCode||20==event.keyCode||45==event.keyCode||46==event.keyCode||144==event.keyCode||145==event.keyCode||32<event.keyCode&&41>event.keyCode||111<event.keyCode&&124>event.keyCode;return!anyNonPrintable&&!(0==event.charCode&&mozNonPrintable)},_onKeypress:function(event){if(!this.allowedPattern&&"number"!==this.inputElement.type){return}var regexp=this._patternRegExp;if(!regexp){return}if(event.metaKey||event.ctrlKey||event.altKey){return}this._patternAlreadyChecked=!0;var thisChar=String.fromCharCode(event.charCode);if(this._isPrintable(event)&&!regexp.test(thisChar)){event.preventDefault();this._announceInvalidCharacter("Invalid character "+thisChar+" not entered.")}},_checkPatternValidity:function(){var regexp=this._patternRegExp;if(!regexp){return!0}for(var i=0;i<this.inputElement.value.length;i++){if(!regexp.test(this.inputElement.value[i])){return!1}}return!0},validate:function(){if(!this.inputElement){this.invalid=!1;return!0}var valid=this.inputElement.checkValidity();if(valid){if(this.required&&""===this.bindValue){valid=!1}else if(this.hasValidator()){valid=_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a.validate.call(this,this.bindValue)}}this.invalid=!valid;this.fire("iron-input-validate");return valid},_announceInvalidCharacter:function(message){this.fire("iron-announce",{text:message})},_computeValue:function(bindValue){return bindValue}})},106:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return PaperItemBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(23),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(18);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperItemBehavior=[_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__.a,_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__.a,{hostAttributes:{role:"option",tabindex:"0"}}]},107:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const NeonAnimatableBehavior={properties:{animationConfig:{type:Object},entryAnimation:{observer:"_entryAnimationChanged",type:String},exitAnimation:{observer:"_exitAnimationChanged",type:String}},_entryAnimationChanged:function(){this.animationConfig=this.animationConfig||{};this.animationConfig.entry=[{name:this.entryAnimation,node:this}]},_exitAnimationChanged:function(){this.animationConfig=this.animationConfig||{};this.animationConfig.exit=[{name:this.exitAnimation,node:this}]},_copyProperties:function(config1,config2){for(var property in config2){config1[property]=config2[property]}},_cloneConfig:function(config){var clone={isClone:!0};this._copyProperties(clone,config);return clone},_getAnimationConfigRecursive:function(type,map,allConfigs){if(!this.animationConfig){return}if(this.animationConfig.value&&"function"===typeof this.animationConfig.value){this._warn(this._logf("playAnimation","Please put 'animationConfig' inside of your components 'properties' object instead of outside of it."));return}var thisConfig;if(type){thisConfig=this.animationConfig[type]}else{thisConfig=this.animationConfig}if(!Array.isArray(thisConfig)){thisConfig=[thisConfig]}if(thisConfig){for(var config,index=0;config=thisConfig[index];index++){if(config.animatable){config.animatable._getAnimationConfigRecursive(config.type||type,map,allConfigs)}else{if(config.id){var cachedConfig=map[config.id];if(cachedConfig){if(!cachedConfig.isClone){map[config.id]=this._cloneConfig(cachedConfig);cachedConfig=map[config.id]}this._copyProperties(cachedConfig,config)}else{map[config.id]=config}}else{allConfigs.push(config)}}}}},getAnimationConfig:function(type){var map={},allConfigs=[];this._getAnimationConfigRecursive(type,map,allConfigs);for(var key in map){allConfigs.push(map[key])}return allConfigs}};__webpack_require__.d(__webpack_exports__,"a",function(){return NeonAnimationRunnerBehavior});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const NeonAnimationRunnerBehavior=[NeonAnimatableBehavior,{_configureAnimations:function(configs){var results=[],resultsToPlay=[];if(0<configs.length){for(let config,index=0,neonAnimation;config=configs[index];index++){neonAnimation=document.createElement(config.name);if(neonAnimation.isNeonAnimation){let result=null;if(!neonAnimation.configure){neonAnimation.configure=function(){return null}}result=neonAnimation.configure(config);resultsToPlay.push({result:result,config:config,neonAnimation:neonAnimation})}else{console.warn(this.is+":",config.name,"not found!")}}}for(var i=0;i<resultsToPlay.length;i++){let result=resultsToPlay[i].result,config=resultsToPlay[i].config,neonAnimation=resultsToPlay[i].neonAnimation;try{if("function"!=typeof result.cancel){result=document.timeline.play(result)}}catch(e){result=null;console.warn("Couldnt play","(",config.name,").",e)}if(result){results.push({neonAnimation:neonAnimation,config:config,animation:result})}}return results},_shouldComplete:function(activeEntries){for(var finished=!0,i=0;i<activeEntries.length;i++){if("finished"!=activeEntries[i].animation.playState){finished=!1;break}}return finished},_complete:function(activeEntries){for(var i=0;i<activeEntries.length;i++){activeEntries[i].neonAnimation.complete(activeEntries[i].config)}for(var i=0;i<activeEntries.length;i++){activeEntries[i].animation.cancel()}},playAnimation:function(type,cookie){var configs=this.getAnimationConfig(type);if(!configs){return}this._active=this._active||{};if(this._active[type]){this._complete(this._active[type]);delete this._active[type]}var activeEntries=this._configureAnimations(configs);if(0==activeEntries.length){this.fire("neon-animation-finish",cookie,{bubbles:!1});return}this._active[type]=activeEntries;for(var i=0;i<activeEntries.length;i++){activeEntries[i].animation.onfinish=function(){if(this._shouldComplete(activeEntries)){this._complete(activeEntries);delete this._active[type];this.fire("neon-animation-finish",cookie,{bubbles:!1})}}.bind(this)}},cancelAnimation:function(){for(var k in this._active){var entries=this._active[k];for(var j in entries){entries[j].animation.cancel()}}this._active={}}}]},109:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_legacy=__webpack_require__(3),iron_form_element_behavior=__webpack_require__(52),iron_validatable_behavior=__webpack_require__(53);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronCheckedElementBehaviorImpl={properties:{checked:{type:Boolean,value:!1,reflectToAttribute:!0,notify:!0,observer:"_checkedChanged"},toggles:{type:Boolean,value:!0,reflectToAttribute:!0},value:{type:String,value:"on",observer:"_valueChanged"}},observers:["_requiredChanged(required)"],created:function(){this._hasIronCheckedElementBehavior=!0},_getValidity:function(){return this.disabled||!this.required||this.checked},_requiredChanged:function(){if(this.required){this.setAttribute("aria-required","true")}else{this.removeAttribute("aria-required")}},_checkedChanged:function(){this.active=this.checked;this.fire("iron-change")},_valueChanged:function(){if(this.value===void 0||null===this.value){this.value="on"}}},IronCheckedElementBehavior=[iron_form_element_behavior.a,iron_validatable_behavior.a,IronCheckedElementBehaviorImpl];var paper_inky_focus_behavior=__webpack_require__(51),paper_ripple_behavior=__webpack_require__(40);__webpack_require__.d(__webpack_exports__,"a",function(){return PaperCheckedElementBehavior});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperCheckedElementBehavior=[paper_inky_focus_behavior.a,IronCheckedElementBehavior,{_checkedChanged:function(){IronCheckedElementBehaviorImpl._checkedChanged.call(this);if(this.hasRipple()){if(this.checked){this._ripple.setAttribute("checked","")}else{this._ripple.removeAttribute("checked")}}},_buttonStateChanged:function(){paper_ripple_behavior.a._buttonStateChanged.call(this);if(this.disabled){return}if(this.isAttached){this.checked=this.active}}}]},126:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_paper_item_shared_styles_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(127),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(1),_paper_item_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(106);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__.a`
    <style include="paper-item-shared-styles">
      :host {
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-subhead;

        @apply --paper-item;
      }
    </style>
    <slot></slot>
`,is:"paper-item",behaviors:[_paper_item_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a]})},127:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(33),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(58),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1__),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(39),_polymer_paper_styles_typography_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(50);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<dom-module id="paper-item-shared-styles">
  <template>
    <style>
      :host, .paper-item {
        display: block;
        position: relative;
        min-height: var(--paper-item-min-height, 48px);
        padding: 0px 16px;
      }

      .paper-item {
        @apply --paper-font-subhead;
        border:none;
        outline: none;
        background: white;
        width: 100%;
        text-align: left;
      }

      :host([hidden]), .paper-item[hidden] {
        display: none !important;
      }

      :host(.iron-selected), .paper-item.iron-selected {
        font-weight: var(--paper-item-selected-weight, bold);

        @apply --paper-item-selected;
      }

      :host([disabled]), .paper-item[disabled] {
        color: var(--paper-item-disabled-color, var(--disabled-text-color));

        @apply --paper-item-disabled;
      }

      :host(:focus), .paper-item:focus {
        position: relative;
        outline: 0;

        @apply --paper-item-focused;
      }

      :host(:focus):before, .paper-item:focus:before {
        @apply --layout-fit;

        background: currentColor;
        content: '';
        opacity: var(--dark-divider-opacity);
        pointer-events: none;

        @apply --paper-item-focused-before;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild($_documentContainer.content)},128:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(39),_polymer_iron_menu_behavior_iron_menu_behavior_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(110),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__.a`
    <style>
      :host {
        display: block;
        padding: 8px 0;

        background: var(--paper-listbox-background-color, var(--primary-background-color));
        color: var(--paper-listbox-color, var(--primary-text-color));

        @apply --paper-listbox;
      }
    </style>

    <slot></slot>
`,is:"paper-listbox",behaviors:[_polymer_iron_menu_behavior_iron_menu_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a],hostAttributes:{role:"listbox"}})},129:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(19),_polymer_iron_icon_iron_icon_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(95),_polymer_paper_input_paper_input_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(78),_polymer_paper_menu_button_paper_menu_button_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(130),_polymer_paper_ripple_paper_ripple_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(76),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(39),_paper_dropdown_menu_icons_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(131),_paper_dropdown_menu_shared_styles_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(132),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(23),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_10__=__webpack_require__(18),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_11__=__webpack_require__(52),_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_12__=__webpack_require__(53),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_13__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_14__=__webpack_require__(0),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_15__=__webpack_require__(25),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_16__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_13__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_16__.a`
    <style include="paper-dropdown-menu-shared-styles"></style>

    <!-- this div fulfills an a11y requirement for combobox, do not remove -->
    <span role="button"></span>
    <paper-menu-button id="menuButton" vertical-align="[[verticalAlign]]" horizontal-align="[[horizontalAlign]]" dynamic-align="[[dynamicAlign]]" vertical-offset="[[_computeMenuVerticalOffset(noLabelFloat, verticalOffset)]]" disabled="[[disabled]]" no-animations="[[noAnimations]]" on-iron-select="_onIronSelect" on-iron-deselect="_onIronDeselect" opened="{{opened}}" close-on-activate allow-outside-scroll="[[allowOutsideScroll]]" restore-focus-on-close="[[restoreFocusOnClose]]">
      <!-- support hybrid mode: user might be using paper-menu-button 1.x which distributes via <content> -->
      <div class="dropdown-trigger" slot="dropdown-trigger">
        <paper-ripple></paper-ripple>
        <!-- paper-input has type="text" for a11y, do not remove -->
        <paper-input type="text" invalid="[[invalid]]" readonly disabled="[[disabled]]" value="[[value]]" placeholder="[[placeholder]]" error-message="[[errorMessage]]" always-float-label="[[alwaysFloatLabel]]" no-label-float="[[noLabelFloat]]" label="[[label]]">
          <!-- support hybrid mode: user might be using paper-input 1.x which distributes via <content> -->
          <iron-icon icon="paper-dropdown-menu:arrow-drop-down" suffix slot="suffix"></iron-icon>
        </paper-input>
      </div>
      <slot id="content" name="dropdown-content" slot="dropdown-content"></slot>
    </paper-menu-button>
`,is:"paper-dropdown-menu",behaviors:[_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_9__.a,_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_10__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_11__.a,_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_12__.a],properties:{selectedItemLabel:{type:String,notify:!0,readOnly:!0},selectedItem:{type:Object,notify:!0,readOnly:!0},value:{type:String,notify:!0},label:{type:String},placeholder:{type:String},errorMessage:{type:String},opened:{type:Boolean,notify:!0,value:!1,observer:"_openedChanged"},allowOutsideScroll:{type:Boolean,value:!1},noLabelFloat:{type:Boolean,value:!1,reflectToAttribute:!0},alwaysFloatLabel:{type:Boolean,value:!1},noAnimations:{type:Boolean,value:!1},horizontalAlign:{type:String,value:"right"},verticalAlign:{type:String,value:"top"},verticalOffset:Number,dynamicAlign:{type:Boolean},restoreFocusOnClose:{type:Boolean,value:!0}},listeners:{tap:"_onTap"},keyBindings:{"up down":"open",esc:"close"},hostAttributes:{role:"combobox","aria-autocomplete":"none","aria-haspopup":"true"},observers:["_selectedItemChanged(selectedItem)"],attached:function(){var contentElement=this.contentElement;if(contentElement&&contentElement.selectedItem){this._setSelectedItem(contentElement.selectedItem)}},get contentElement(){for(var nodes=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_14__.b)(this.$.content).getDistributedNodes(),i=0,l=nodes.length;i<l;i++){if(nodes[i].nodeType===Node.ELEMENT_NODE){return nodes[i]}}},open:function(){this.$.menuButton.open()},close:function(){this.$.menuButton.close()},_onIronSelect:function(event){this._setSelectedItem(event.detail.item)},_onIronDeselect:function(){this._setSelectedItem(null)},_onTap:function(event){if(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_15__.c(event)===this){this.open()}},_selectedItemChanged:function(selectedItem){var value="";if(!selectedItem){value=""}else{value=selectedItem.label||selectedItem.getAttribute("label")||selectedItem.textContent.trim()}this.value=value;this._setSelectedItemLabel(value)},_computeMenuVerticalOffset:function(noLabelFloat,opt_verticalOffset){if(opt_verticalOffset){return opt_verticalOffset}return noLabelFloat?-4:8},_getValidity:function(){return this.disabled||!this.required||this.required&&!!this.value},_openedChanged:function(){var openState=this.opened?"true":"false",e=this.contentElement;if(e){e.setAttribute("aria-expanded",openState)}}})},130:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_legacy=__webpack_require__(3),iron_a11y_keys_behavior=__webpack_require__(19),iron_control_state=__webpack_require__(18),iron_overlay_behavior=__webpack_require__(73),neon_animation_runner_behavior=__webpack_require__(107),polymer_fn=__webpack_require__(4),polymer_dom=__webpack_require__(0),html_tag=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({_template:html_tag.a`
    <style>
      :host {
        position: fixed;
      }

      #contentWrapper ::slotted(*) {
        overflow: auto;
      }

      #contentWrapper.animating ::slotted(*) {
        overflow: hidden;
        pointer-events: none;
      }
    </style>

    <div id="contentWrapper">
      <slot id="content" name="dropdown-content"></slot>
    </div>
`,is:"iron-dropdown",behaviors:[iron_control_state.a,iron_a11y_keys_behavior.a,iron_overlay_behavior.a,neon_animation_runner_behavior.a],properties:{horizontalAlign:{type:String,value:"left",reflectToAttribute:!0},verticalAlign:{type:String,value:"top",reflectToAttribute:!0},openAnimationConfig:{type:Object},closeAnimationConfig:{type:Object},focusTarget:{type:Object},noAnimations:{type:Boolean,value:!1},allowOutsideScroll:{type:Boolean,value:!1,observer:"_allowOutsideScrollChanged"}},listeners:{"neon-animation-finish":"_onNeonAnimationFinish"},observers:["_updateOverlayPosition(positionTarget, verticalAlign, horizontalAlign, verticalOffset, horizontalOffset)"],get containedElement(){for(var nodes=Object(polymer_dom.b)(this.$.content).getDistributedNodes(),i=0,l=nodes.length;i<l;i++){if(nodes[i].nodeType===Node.ELEMENT_NODE){return nodes[i]}}},ready:function(){if(!this.scrollAction){this.scrollAction=this.allowOutsideScroll?"refit":"lock"}this._readied=!0},attached:function(){if(!this.sizingTarget||this.sizingTarget===this){this.sizingTarget=this.containedElement||this}},detached:function(){this.cancelAnimation()},_openedChanged:function(){if(this.opened&&this.disabled){this.cancel()}else{this.cancelAnimation();this._updateAnimationConfig();iron_overlay_behavior.b._openedChanged.apply(this,arguments)}},_renderOpened:function(){if(!this.noAnimations&&this.animationConfig.open){this.$.contentWrapper.classList.add("animating");this.playAnimation("open")}else{iron_overlay_behavior.b._renderOpened.apply(this,arguments)}},_renderClosed:function(){if(!this.noAnimations&&this.animationConfig.close){this.$.contentWrapper.classList.add("animating");this.playAnimation("close")}else{iron_overlay_behavior.b._renderClosed.apply(this,arguments)}},_onNeonAnimationFinish:function(){this.$.contentWrapper.classList.remove("animating");if(this.opened){this._finishRenderOpened()}else{this._finishRenderClosed()}},_updateAnimationConfig:function(){for(var animationNode=this.containedElement,animations=[].concat(this.openAnimationConfig||[]).concat(this.closeAnimationConfig||[]),i=0;i<animations.length;i++){animations[i].node=animationNode}this.animationConfig={open:this.openAnimationConfig,close:this.closeAnimationConfig}},_updateOverlayPosition:function(){if(this.isAttached){this.notifyResize()}},_allowOutsideScrollChanged:function(allowOutsideScroll){if(!this._readied){return}if(!allowOutsideScroll){this.scrollAction="lock"}else if(!this.scrollAction||"lock"===this.scrollAction){this.scrollAction="refit"}},_applyFocus:function(){var focusTarget=this.focusTarget||this.containedElement;if(focusTarget&&this.opened&&!this.noAutoFocus){focusTarget.focus()}else{iron_overlay_behavior.b._applyFocus.apply(this,arguments)}}});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const NeonAnimationBehavior={properties:{animationTiming:{type:Object,value:function(){return{duration:500,easing:"cubic-bezier(0.4, 0, 0.2, 1)",fill:"both"}}}},isNeonAnimation:!0,created:function(){if(!document.body.animate){console.warn("No web animations detected. This element will not"+" function without a web animations polyfill.")}},timingFromConfig:function(config){if(config.timing){for(var property in config.timing){this.animationTiming[property]=config.timing[property]}}return this.animationTiming},setPrefixedProperty:function(node,property,value){for(var map={transform:["webkitTransform"],transformOrigin:["mozTransformOrigin","webkitTransformOrigin"]},prefixes=map[property],prefix,index=0;prefix=prefixes[index];index++){node.style[prefix]=value}node.style[property]=value},complete:function(){}};/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({is:"fade-in-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node;this._effect=new KeyframeEffect(node,[{opacity:"0"},{opacity:"1"}],this.timingFromConfig(config));return this._effect}});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({is:"fade-out-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node;this._effect=new KeyframeEffect(node,[{opacity:"1"},{opacity:"0"}],this.timingFromConfig(config));return this._effect}});var default_theme=__webpack_require__(39),shadow=__webpack_require__(61);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({is:"paper-menu-grow-height-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node,rect=node.getBoundingClientRect(),height=rect.height;this._effect=new KeyframeEffect(node,[{height:height/2+"px"},{height:height+"px"}],this.timingFromConfig(config));return this._effect}});Object(polymer_fn.a)({is:"paper-menu-grow-width-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node,rect=node.getBoundingClientRect(),width=rect.width;this._effect=new KeyframeEffect(node,[{width:width/2+"px"},{width:width+"px"}],this.timingFromConfig(config));return this._effect}});Object(polymer_fn.a)({is:"paper-menu-shrink-width-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node,rect=node.getBoundingClientRect(),width=rect.width;this._effect=new KeyframeEffect(node,[{width:width+"px"},{width:width-width/20+"px"}],this.timingFromConfig(config));return this._effect}});Object(polymer_fn.a)({is:"paper-menu-shrink-height-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node,rect=node.getBoundingClientRect(),height=rect.height;this.setPrefixedProperty(node,"transformOrigin","0 0");this._effect=new KeyframeEffect(node,[{height:height+"px",transform:"translateY(0)"},{height:height/2+"px",transform:"translateY(-20px)"}],this.timingFromConfig(config));return this._effect}});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/var config={ANIMATION_CUBIC_BEZIER:"cubic-bezier(.3,.95,.5,1)",MAX_ANIMATION_TIME_MS:400};const PaperMenuButton=Object(polymer_fn.a)({_template:html_tag.a`
    <style>
      :host {
        display: inline-block;
        position: relative;
        padding: 8px;
        outline: none;

        @apply --paper-menu-button;
      }

      :host([disabled]) {
        cursor: auto;
        color: var(--disabled-text-color);

        @apply --paper-menu-button-disabled;
      }

      iron-dropdown {
        @apply --paper-menu-button-dropdown;
      }

      .dropdown-content {
        @apply --shadow-elevation-2dp;

        position: relative;
        border-radius: 2px;
        background-color: var(--paper-menu-button-dropdown-background, var(--primary-background-color));

        @apply --paper-menu-button-content;
      }

      :host([vertical-align="top"]) .dropdown-content {
        margin-bottom: 20px;
        margin-top: -10px;
        top: 10px;
      }

      :host([vertical-align="bottom"]) .dropdown-content {
        bottom: 10px;
        margin-bottom: -10px;
        margin-top: 20px;
      }

      #trigger {
        cursor: pointer;
      }
    </style>

    <div id="trigger" on-tap="toggle">
      <slot name="dropdown-trigger"></slot>
    </div>

    <iron-dropdown id="dropdown" opened="{{opened}}" horizontal-align="[[horizontalAlign]]" vertical-align="[[verticalAlign]]" dynamic-align="[[dynamicAlign]]" horizontal-offset="[[horizontalOffset]]" vertical-offset="[[verticalOffset]]" no-overlap="[[noOverlap]]" open-animation-config="[[openAnimationConfig]]" close-animation-config="[[closeAnimationConfig]]" no-animations="[[noAnimations]]" focus-target="[[_dropdownContent]]" allow-outside-scroll="[[allowOutsideScroll]]" restore-focus-on-close="[[restoreFocusOnClose]]" on-iron-overlay-canceled="__onIronOverlayCanceled">
      <div slot="dropdown-content" class="dropdown-content">
        <slot id="content" name="dropdown-content"></slot>
      </div>
    </iron-dropdown>
`,is:"paper-menu-button",behaviors:[iron_a11y_keys_behavior.a,iron_control_state.a],properties:{opened:{type:Boolean,value:!1,notify:!0,observer:"_openedChanged"},horizontalAlign:{type:String,value:"left",reflectToAttribute:!0},verticalAlign:{type:String,value:"top",reflectToAttribute:!0},dynamicAlign:{type:Boolean},horizontalOffset:{type:Number,value:0,notify:!0},verticalOffset:{type:Number,value:0,notify:!0},noOverlap:{type:Boolean},noAnimations:{type:Boolean,value:!1},ignoreSelect:{type:Boolean,value:!1},closeOnActivate:{type:Boolean,value:!1},openAnimationConfig:{type:Object,value:function(){return[{name:"fade-in-animation",timing:{delay:100,duration:200}},{name:"paper-menu-grow-width-animation",timing:{delay:100,duration:150,easing:config.ANIMATION_CUBIC_BEZIER}},{name:"paper-menu-grow-height-animation",timing:{delay:100,duration:275,easing:config.ANIMATION_CUBIC_BEZIER}}]}},closeAnimationConfig:{type:Object,value:function(){return[{name:"fade-out-animation",timing:{duration:150}},{name:"paper-menu-shrink-width-animation",timing:{delay:100,duration:50,easing:config.ANIMATION_CUBIC_BEZIER}},{name:"paper-menu-shrink-height-animation",timing:{duration:200,easing:"ease-in"}}]}},allowOutsideScroll:{type:Boolean,value:!1},restoreFocusOnClose:{type:Boolean,value:!0},_dropdownContent:{type:Object}},hostAttributes:{role:"group","aria-haspopup":"true"},listeners:{"iron-activate":"_onIronActivate","iron-select":"_onIronSelect"},get contentElement(){for(var nodes=Object(polymer_dom.b)(this.$.content).getDistributedNodes(),i=0,l=nodes.length;i<l;i++){if(nodes[i].nodeType===Node.ELEMENT_NODE){return nodes[i]}}},toggle:function(){if(this.opened){this.close()}else{this.open()}},open:function(){if(this.disabled){return}this.$.dropdown.open()},close:function(){this.$.dropdown.close()},_onIronSelect:function(){if(!this.ignoreSelect){this.close()}},_onIronActivate:function(){if(this.closeOnActivate){this.close()}},_openedChanged:function(opened,oldOpened){if(opened){this._dropdownContent=this.contentElement;this.fire("paper-dropdown-open")}else if(null!=oldOpened){this.fire("paper-dropdown-close")}},_disabledChanged:function(disabled){iron_control_state.a._disabledChanged.apply(this,arguments);if(disabled&&this.opened){this.close()}},__onIronOverlayCanceled:function(event){var uiEvent=event.detail,trigger=this.$.trigger,path=Object(polymer_dom.b)(uiEvent).path;if(-1<path.indexOf(trigger)){event.preventDefault()}}});Object.keys(config).forEach(function(key){PaperMenuButton[key]=config[key]})},131:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(74);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<iron-iconset-svg name="paper-dropdown-menu" size="24">
<svg><defs>
<g id="arrow-drop-down"><path d="M7 10l5 5 5-5z"></path></g>
</defs></svg>
</iron-iconset-svg>`;document.head.appendChild($_documentContainer.content)},132:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(39);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<dom-module id="paper-dropdown-menu-shared-styles">
  <template>
    <style>
      :host {
        display: inline-block;
        position: relative;
        text-align: left;

        /* NOTE(cdata): Both values are needed, since some phones require the
         * value to be \`transparent\`.
         */
        -webkit-tap-highlight-color: rgba(0,0,0,0);
        -webkit-tap-highlight-color: transparent;

        --paper-input-container-input: {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          max-width: 100%;
          box-sizing: border-box;
          cursor: pointer;
        };

        @apply --paper-dropdown-menu;
      }

      :host([disabled]) {
        @apply --paper-dropdown-menu-disabled;
      }

      :host([noink]) paper-ripple {
        display: none;
      }

      :host([no-label-float]) paper-ripple {
        top: 8px;
      }

      paper-ripple {
        top: 12px;
        left: 0px;
        bottom: 8px;
        right: 0px;

        @apply --paper-dropdown-menu-ripple;
      }

      paper-menu-button {
        display: block;
        padding: 0;

        @apply --paper-dropdown-menu-button;
      }

      paper-input {
        @apply --paper-dropdown-menu-input;
      }

      iron-icon {
        color: var(--disabled-text-color);

        @apply --paper-dropdown-menu-icon;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild($_documentContainer.content)},135:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(58),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__),_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(97),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__.a`
    <style>
      :host {
        display: block;
        width: 200px;
        position: relative;
        overflow: hidden;
      }

      :host([hidden]), [hidden] {
        display: none !important;
      }

      #progressContainer {
        @apply --paper-progress-container;
        position: relative;
      }

      #progressContainer,
      /* the stripe for the indeterminate animation*/
      .indeterminate::after {
        height: var(--paper-progress-height, 4px);
      }

      #primaryProgress,
      #secondaryProgress,
      .indeterminate::after {
        @apply --layout-fit;
      }

      #progressContainer,
      .indeterminate::after {
        background: var(--paper-progress-container-color, var(--google-grey-300));
      }

      :host(.transiting) #primaryProgress,
      :host(.transiting) #secondaryProgress {
        -webkit-transition-property: -webkit-transform;
        transition-property: transform;

        /* Duration */
        -webkit-transition-duration: var(--paper-progress-transition-duration, 0.08s);
        transition-duration: var(--paper-progress-transition-duration, 0.08s);

        /* Timing function */
        -webkit-transition-timing-function: var(--paper-progress-transition-timing-function, ease);
        transition-timing-function: var(--paper-progress-transition-timing-function, ease);

        /* Delay */
        -webkit-transition-delay: var(--paper-progress-transition-delay, 0s);
        transition-delay: var(--paper-progress-transition-delay, 0s);
      }

      #primaryProgress,
      #secondaryProgress {
        @apply --layout-fit;
        -webkit-transform-origin: left center;
        transform-origin: left center;
        -webkit-transform: scaleX(0);
        transform: scaleX(0);
        will-change: transform;
      }

      #primaryProgress {
        background: var(--paper-progress-active-color, var(--google-green-500));
      }

      #secondaryProgress {
        background: var(--paper-progress-secondary-color, var(--google-green-100));
      }

      :host([disabled]) #primaryProgress {
        background: var(--paper-progress-disabled-active-color, var(--google-grey-500));
      }

      :host([disabled]) #secondaryProgress {
        background: var(--paper-progress-disabled-secondary-color, var(--google-grey-300));
      }

      :host(:not([disabled])) #primaryProgress.indeterminate {
        -webkit-transform-origin: right center;
        transform-origin: right center;
        -webkit-animation: indeterminate-bar var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
        animation: indeterminate-bar var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
      }

      :host(:not([disabled])) #primaryProgress.indeterminate::after {
        content: "";
        -webkit-transform-origin: center center;
        transform-origin: center center;

        -webkit-animation: indeterminate-splitter var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
        animation: indeterminate-splitter var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
      }

      @-webkit-keyframes indeterminate-bar {
        0% {
          -webkit-transform: scaleX(1) translateX(-100%);
        }
        50% {
          -webkit-transform: scaleX(1) translateX(0%);
        }
        75% {
          -webkit-transform: scaleX(1) translateX(0%);
          -webkit-animation-timing-function: cubic-bezier(.28,.62,.37,.91);
        }
        100% {
          -webkit-transform: scaleX(0) translateX(0%);
        }
      }

      @-webkit-keyframes indeterminate-splitter {
        0% {
          -webkit-transform: scaleX(.75) translateX(-125%);
        }
        30% {
          -webkit-transform: scaleX(.75) translateX(-125%);
          -webkit-animation-timing-function: cubic-bezier(.42,0,.6,.8);
        }
        90% {
          -webkit-transform: scaleX(.75) translateX(125%);
        }
        100% {
          -webkit-transform: scaleX(.75) translateX(125%);
        }
      }

      @keyframes indeterminate-bar {
        0% {
          transform: scaleX(1) translateX(-100%);
        }
        50% {
          transform: scaleX(1) translateX(0%);
        }
        75% {
          transform: scaleX(1) translateX(0%);
          animation-timing-function: cubic-bezier(.28,.62,.37,.91);
        }
        100% {
          transform: scaleX(0) translateX(0%);
        }
      }

      @keyframes indeterminate-splitter {
        0% {
          transform: scaleX(.75) translateX(-125%);
        }
        30% {
          transform: scaleX(.75) translateX(-125%);
          animation-timing-function: cubic-bezier(.42,0,.6,.8);
        }
        90% {
          transform: scaleX(.75) translateX(125%);
        }
        100% {
          transform: scaleX(.75) translateX(125%);
        }
      }
    </style>

    <div id="progressContainer">
      <div id="secondaryProgress" hidden\$="[[_hideSecondaryProgress(secondaryRatio)]]"></div>
      <div id="primaryProgress"></div>
    </div>
`,is:"paper-progress",behaviors:[_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_3__.a],properties:{secondaryProgress:{type:Number,value:0},secondaryRatio:{type:Number,value:0,readOnly:!0},indeterminate:{type:Boolean,value:!1,observer:"_toggleIndeterminate"},disabled:{type:Boolean,value:!1,reflectToAttribute:!0,observer:"_disabledChanged"}},observers:["_progressChanged(secondaryProgress, value, min, max, indeterminate)"],hostAttributes:{role:"progressbar"},_toggleIndeterminate:function(indeterminate){this.toggleClass("indeterminate",indeterminate,this.$.primaryProgress)},_transformProgress:function(progress,ratio){progress.style.transform=progress.style.webkitTransform="scaleX("+ratio/100+")"},_mainRatioChanged:function(ratio){this._transformProgress(this.$.primaryProgress,ratio)},_progressChanged:function(secondaryProgress,value,min,max,indeterminate){secondaryProgress=this._clampValue(secondaryProgress);value=this._clampValue(value);var secondaryRatio=100*this._calcRatio(secondaryProgress),mainRatio=100*this._calcRatio(value);this._setSecondaryRatio(secondaryRatio);this._transformProgress(this.$.secondaryProgress,secondaryRatio);this._transformProgress(this.$.primaryProgress,mainRatio);this.secondaryProgress=secondaryProgress;if(indeterminate){this.removeAttribute("aria-valuenow")}else{this.setAttribute("aria-valuenow",value)}this.setAttribute("aria-valuemin",min);this.setAttribute("aria-valuemax",max)},_disabledChanged:function(disabled){this.setAttribute("aria-disabled",disabled?"true":"false")},_hideSecondaryProgress:function(secondaryRatio){return 0===secondaryRatio}})},136:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(33),_polymer_paper_input_paper_input_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(78),_polymer_paper_progress_paper_progress_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(135),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(58),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3__),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(19),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(52),_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(97),_polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(51),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(4),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(25),_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_10__=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_10__.c`
  <style>
    :host {
      @apply --layout;
      @apply --layout-justified;
      @apply --layout-center;
      width: 200px;
      cursor: default;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      --paper-progress-active-color: var(--paper-slider-active-color, var(--google-blue-700));
      --paper-progress-secondary-color: var(--paper-slider-secondary-color, var(--google-blue-300));
      --paper-progress-disabled-active-color: var(--paper-slider-disabled-active-color, var(--paper-grey-400));
      --paper-progress-disabled-secondary-color: var(--paper-slider-disabled-secondary-color, var(--paper-grey-400));
      --calculated-paper-slider-height: var(--paper-slider-height, 2px);
    }

    /* focus shows the ripple */
    :host(:focus) {
      outline: none;
    }

    /**
      * NOTE(keanulee): Though :host-context is not universally supported, some pages
      * still rely on paper-slider being flipped when dir="rtl" is set on body. For full
      * compatibility, dir="rtl" must be explicitly set on paper-slider.
      */
    :dir(rtl) #sliderContainer {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
    }

    /**
      * NOTE(keanulee): This is separate from the rule above because :host-context may
      * not be recognized.
      */
    :host([dir="rtl"]) #sliderContainer {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
    }

    /**
      * NOTE(keanulee): Needed to override the :host-context rule (where supported)
      * to support LTR sliders in RTL pages.
      */
    :host([dir="ltr"]) #sliderContainer {
      -webkit-transform: scaleX(1);
      transform: scaleX(1);
    }

    #sliderContainer {
      position: relative;
      width: 100%;
      height: calc(30px + var(--calculated-paper-slider-height));
      margin-left: calc(15px + var(--calculated-paper-slider-height)/2);
      margin-right: calc(15px + var(--calculated-paper-slider-height)/2);
    }

    #sliderContainer:focus {
      outline: 0;
    }

    #sliderContainer.editable {
      margin-top: 12px;
      margin-bottom: 12px;
    }

    .bar-container {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      overflow: hidden;
    }

    .ring > .bar-container {
      left: calc(5px + var(--calculated-paper-slider-height)/2);
      transition: left 0.18s ease;
    }

    .ring.expand.dragging > .bar-container {
      transition: none;
    }

    .ring.expand:not(.pin) > .bar-container {
      left: calc(8px + var(--calculated-paper-slider-height)/2);
    }

    #sliderBar {
      padding: 15px 0;
      width: 100%;
      background-color: var(--paper-slider-bar-color, transparent);
      --paper-progress-container-color: var(--paper-slider-container-color, var(--paper-grey-400));
      --paper-progress-height: var(--calculated-paper-slider-height);
    }

    .slider-markers {
      position: absolute;
      /* slider-knob is 30px + the slider-height so that the markers should start at a offset of 15px*/
      top: 15px;
      height: var(--calculated-paper-slider-height);
      left: 0;
      right: -1px;
      box-sizing: border-box;
      pointer-events: none;
      @apply --layout-horizontal;
    }

    .slider-marker {
      @apply --layout-flex;
    }
    .slider-markers::after,
    .slider-marker::after {
      content: "";
      display: block;
      margin-left: -1px;
      width: 2px;
      height: var(--calculated-paper-slider-height);
      border-radius: 50%;
      background-color: var(--paper-slider-markers-color, #000);
    }

    .slider-knob {
      position: absolute;
      left: 0;
      top: 0;
      margin-left: calc(-15px - var(--calculated-paper-slider-height)/2);
      width: calc(30px + var(--calculated-paper-slider-height));
      height: calc(30px + var(--calculated-paper-slider-height));
    }

    .transiting > .slider-knob {
      transition: left 0.08s ease;
    }

    .slider-knob:focus {
      outline: none;
    }

    .slider-knob.dragging {
      transition: none;
    }

    .snaps > .slider-knob.dragging {
      transition: -webkit-transform 0.08s ease;
      transition: transform 0.08s ease;
    }

    .slider-knob-inner {
      margin: 10px;
      width: calc(100% - 20px);
      height: calc(100% - 20px);
      background-color: var(--paper-slider-knob-color, var(--google-blue-700));
      border: 2px solid var(--paper-slider-knob-color, var(--google-blue-700));
      border-radius: 50%;

      -moz-box-sizing: border-box;
      box-sizing: border-box;

      transition-property: -webkit-transform, background-color, border;
      transition-property: transform, background-color, border;
      transition-duration: 0.18s;
      transition-timing-function: ease;
    }

    .expand:not(.pin) > .slider-knob > .slider-knob-inner {
      -webkit-transform: scale(1.5);
      transform: scale(1.5);
    }

    .ring > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-knob-start-color, transparent);
      border: 2px solid var(--paper-slider-knob-start-border-color, var(--paper-grey-400));
    }

    .slider-knob-inner::before {
      background-color: var(--paper-slider-pin-color, var(--google-blue-700));
    }

    .pin > .slider-knob > .slider-knob-inner::before {
      content: "";
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -13px;
      width: 26px;
      height: 26px;
      border-radius: 50% 50% 50% 0;

      -webkit-transform: rotate(-45deg) scale(0) translate(0);
      transform: rotate(-45deg) scale(0) translate(0);
    }

    .slider-knob-inner::before,
    .slider-knob-inner::after {
      transition: -webkit-transform .18s ease, background-color .18s ease;
      transition: transform .18s ease, background-color .18s ease;
    }

    .pin.ring > .slider-knob > .slider-knob-inner::before {
      background-color: var(--paper-slider-pin-start-color, var(--paper-grey-400));
    }

    .pin.expand > .slider-knob > .slider-knob-inner::before {
      -webkit-transform: rotate(-45deg) scale(1) translate(17px, -17px);
      transform: rotate(-45deg) scale(1) translate(17px, -17px);
    }

    .pin > .slider-knob > .slider-knob-inner::after {
      content: attr(value);
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -16px;
      width: 32px;
      height: 26px;
      text-align: center;
      color: var(--paper-slider-font-color, #fff);
      font-size: 10px;

      -webkit-transform: scale(0) translate(0);
      transform: scale(0) translate(0);
    }

    .pin.expand > .slider-knob > .slider-knob-inner::after {
      -webkit-transform: scale(1) translate(0, -17px);
      transform: scale(1) translate(0, -17px);
    }

    /* paper-input */
    .slider-input {
      width: 50px;
      overflow: hidden;
      --paper-input-container-input: {
        text-align: center;
        @apply --paper-slider-input-container-input;
      };
      @apply --paper-slider-input;
    }

    /* disabled state */
    #sliderContainer.disabled {
      pointer-events: none;
    }

    .disabled > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-disabled-knob-color, var(--paper-grey-400));
      border: 2px solid var(--paper-slider-disabled-knob-color, var(--paper-grey-400));
      -webkit-transform: scale3d(0.75, 0.75, 1);
      transform: scale3d(0.75, 0.75, 1);
    }

    .disabled.ring > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-knob-start-color, transparent);
      border: 2px solid var(--paper-slider-knob-start-border-color, var(--paper-grey-400));
    }

    paper-ripple {
      color: var(--paper-slider-knob-color, var(--google-blue-700));
    }
  </style>

  <div id="sliderContainer" class\$="[[_getClassNames(disabled, pin, snaps, immediateValue, min, expand, dragging, transiting, editable)]]">
    <div class="bar-container">
      <paper-progress disabled\$="[[disabled]]" id="sliderBar" aria-hidden="true" min="[[min]]" max="[[max]]" step="[[step]]" value="[[immediateValue]]" secondary-progress="[[secondaryProgress]]" on-down="_bardown" on-up="_resetKnob" on-track="_bartrack" on-tap="_barclick">
      </paper-progress>
    </div>

    <template is="dom-if" if="[[snaps]]">
      <div class="slider-markers">
        <template is="dom-repeat" items="[[markers]]">
          <div class="slider-marker"></div>
        </template>
      </div>
    </template>

    <div id="sliderKnob" class="slider-knob" on-down="_knobdown" on-up="_resetKnob" on-track="_onTrack" on-transitionend="_knobTransitionEnd">
        <div class="slider-knob-inner" value\$="[[immediateValue]]"></div>
    </div>
  </div>

  <template is="dom-if" if="[[editable]]">
    <paper-input id="input" type="number" step="[[step]]" min="[[min]]" max="[[max]]" class="slider-input" disabled\$="[[disabled]]" value="[[immediateValue]]" on-change="_changeValue" on-keydown="_inputKeyDown" no-label-float>
    </paper-input>
  </template>
`;template.setAttribute("strip-whitespace","");Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_8__.a)({_template:template,is:"paper-slider",behaviors:[_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a,_polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__.a,_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_6__.a],properties:{value:{type:Number,value:0},snaps:{type:Boolean,value:!1,notify:!0},pin:{type:Boolean,value:!1,notify:!0},secondaryProgress:{type:Number,value:0,notify:!0,observer:"_secondaryProgressChanged"},editable:{type:Boolean,value:!1},immediateValue:{type:Number,value:0,readOnly:!0,notify:!0},maxMarkers:{type:Number,value:0,notify:!0},expand:{type:Boolean,value:!1,readOnly:!0},ignoreBarTouch:{type:Boolean,value:!1},dragging:{type:Boolean,value:!1,readOnly:!0,notify:!0},transiting:{type:Boolean,value:!1,readOnly:!0},markers:{type:Array,readOnly:!0,value:function(){return[]}}},observers:["_updateKnob(value, min, max, snaps, step)","_valueChanged(value)","_immediateValueChanged(immediateValue)","_updateMarkers(maxMarkers, min, max, snaps)"],hostAttributes:{role:"slider",tabindex:0},keyBindings:{left:"_leftKey",right:"_rightKey","down pagedown home":"_decrementKey","up pageup end":"_incrementKey"},ready:function(){if(this.ignoreBarTouch){Object(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_9__.f)(this.$.sliderBar,"auto")}},increment:function(){this.value=this._clampValue(this.value+this.step)},decrement:function(){this.value=this._clampValue(this.value-this.step)},_updateKnob:function(value,min,max){this.setAttribute("aria-valuemin",min);this.setAttribute("aria-valuemax",max);this.setAttribute("aria-valuenow",value);this._positionKnob(100*this._calcRatio(value))},_valueChanged:function(){this.fire("value-change",{composed:!0})},_immediateValueChanged:function(){if(this.dragging){this.fire("immediate-value-change",{composed:!0})}else{this.value=this.immediateValue}},_secondaryProgressChanged:function(){this.secondaryProgress=this._clampValue(this.secondaryProgress)},_expandKnob:function(){this._setExpand(!0)},_resetKnob:function(){this.cancelDebouncer("expandKnob");this._setExpand(!1)},_positionKnob:function(ratio){this._setImmediateValue(this._calcStep(this._calcKnobPosition(ratio)));this._setRatio(100*this._calcRatio(this.immediateValue));this.$.sliderKnob.style.left=this.ratio+"%";if(this.dragging){this._knobstartx=this.ratio*this._w/100;this.translate3d(0,0,0,this.$.sliderKnob)}},_calcKnobPosition:function(ratio){return(this.max-this.min)*ratio/100+this.min},_onTrack:function(event){event.stopPropagation();switch(event.detail.state){case"start":this._trackStart(event);break;case"track":this._trackX(event);break;case"end":this._trackEnd();break;}},_trackStart:function(){this._setTransiting(!1);this._w=this.$.sliderBar.offsetWidth;this._x=this.ratio*this._w/100;this._startx=this._x;this._knobstartx=this._startx;this._minx=-this._startx;this._maxx=this._w-this._startx;this.$.sliderKnob.classList.add("dragging");this._setDragging(!0)},_trackX:function(event){if(!this.dragging){this._trackStart(event)}var direction=this._isRTL?-1:1,dx=Math.min(this._maxx,Math.max(this._minx,event.detail.dx*direction));this._x=this._startx+dx;var immediateValue=this._calcStep(this._calcKnobPosition(100*(this._x/this._w)));this._setImmediateValue(immediateValue);var translateX=this._calcRatio(this.immediateValue)*this._w-this._knobstartx;this.translate3d(translateX+"px",0,0,this.$.sliderKnob)},_trackEnd:function(){var s=this.$.sliderKnob.style;this.$.sliderKnob.classList.remove("dragging");this._setDragging(!1);this._resetKnob();this.value=this.immediateValue;s.transform=s.webkitTransform="";this.fire("change",{composed:!0})},_knobdown:function(event){this._expandKnob();event.preventDefault();this.focus()},_bartrack:function(event){if(this._allowBarEvent(event)){this._onTrack(event)}},_barclick:function(event){this._w=this.$.sliderBar.offsetWidth;var rect=this.$.sliderBar.getBoundingClientRect(),ratio=100*((event.detail.x-rect.left)/this._w);if(this._isRTL){ratio=100-ratio}var prevRatio=this.ratio;this._setTransiting(!0);this._positionKnob(ratio);if(prevRatio===this.ratio){this._setTransiting(!1)}this.async(function(){this.fire("change",{composed:!0})});event.preventDefault();this.focus()},_bardown:function(event){if(this._allowBarEvent(event)){this.debounce("expandKnob",this._expandKnob,60);this._barclick(event)}},_knobTransitionEnd:function(event){if(event.target===this.$.sliderKnob){this._setTransiting(!1)}},_updateMarkers:function(maxMarkers,min,max,snaps){if(!snaps){this._setMarkers([])}var steps=Math.round((max-min)/this.step);if(steps>maxMarkers){steps=maxMarkers}if(0>steps||!isFinite(steps)){steps=0}this._setMarkers(Array(steps))},_mergeClasses:function(classes){return Object.keys(classes).filter(function(className){return classes[className]}).join(" ")},_getClassNames:function(){return this._mergeClasses({disabled:this.disabled,pin:this.pin,snaps:this.snaps,ring:this.immediateValue<=this.min,expand:this.expand,dragging:this.dragging,transiting:this.transiting,editable:this.editable})},_allowBarEvent:function(event){return!this.ignoreBarTouch||event.detail.sourceEvent instanceof MouseEvent},get _isRTL(){if(this.__isRTL===void 0){this.__isRTL="rtl"===window.getComputedStyle(this).direction}return this.__isRTL},_leftKey:function(event){if(this._isRTL)this._incrementKey(event);else this._decrementKey(event)},_rightKey:function(event){if(this._isRTL)this._decrementKey(event);else this._incrementKey(event)},_incrementKey:function(event){if(!this.disabled){if("end"===event.detail.key){this.value=this.max}else{this.increment()}this.fire("change");event.preventDefault()}},_decrementKey:function(event){if(!this.disabled){if("home"===event.detail.key){this.value=this.min}else{this.decrement()}this.fire("change");event.preventDefault()}},_changeValue:function(event){this.value=event.target.value;this.fire("change",{composed:!0})},_inputKeyDown:function(event){event.stopPropagation()},_createRipple:function(){this._rippleContainer=this.$.sliderKnob;return _polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__.b._createRipple.call(this)},_focusedChanged:function(receivedFocusFromKeyboard){if(receivedFocusFromKeyboard){this.ensureRipple()}if(this.hasRipple()){if(receivedFocusFromKeyboard){this._ripple.style.display=""}else{this._ripple.style.display="none"}this._ripple.holdDown=receivedFocusFromKeyboard}}})},137:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(136);const PaperSliderClass=customElements.get("paper-slider");class HaPaperSlider extends PaperSliderClass{static get template(){const tpl=document.createElement("template");tpl.innerHTML=PaperSliderClass.template.innerHTML;const styleEl=document.createElement("style");styleEl.innerHTML=`
      .pin > .slider-knob > .slider-knob-inner {
        font-size:  var(--ha-paper-slider-pin-font-size, 10px);
        line-height: normal;
      }

      .pin > .slider-knob > .slider-knob-inner::before {
        top: unset;
        margin-left: unset;

        bottom: calc(15px + var(--calculated-paper-slider-height)/2);
        left: 50%;
        width: 2.2em;
        height: 2.2em;

        -webkit-transform-origin: left bottom;
        transform-origin: left bottom;
        -webkit-transform: rotate(-45deg) scale(0) translate(0);
        transform: rotate(-45deg) scale(0) translate(0);
      }

      .pin.expand > .slider-knob > .slider-knob-inner::before {
        -webkit-transform: rotate(-45deg) scale(1) translate(7px, -7px);
        transform: rotate(-45deg) scale(1) translate(7px, -7px);
      }

      .pin > .slider-knob > .slider-knob-inner::after {
        top: unset;
        font-size: unset;

        bottom: calc(15px + var(--calculated-paper-slider-height)/2);
        left: 50%;
        margin-left: -1.1em;
        width: 2.2em;
        height: 2.1em;

        -webkit-transform-origin: center bottom;
        transform-origin: center bottom;
        -webkit-transform: scale(0) translate(0);
        transform: scale(0) translate(0);
      }

      .pin.expand > .slider-knob > .slider-knob-inner::after {
        -webkit-transform: scale(1) translate(0, -10px);
        transform: scale(1) translate(0, -10px);
      }
    `;tpl.content.appendChild(styleEl);return tpl}}customElements.define("ha-paper-slider",HaPaperSlider)},152:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_iron_image_iron_image_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(164),_polymer_paper_styles_element_styles_paper_material_styles_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(82),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(39),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_5__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_6__.a`
    <style include="paper-material-styles">
      :host {
        display: inline-block;
        position: relative;
        box-sizing: border-box;
        background-color: var(--paper-card-background-color, var(--primary-background-color));
        border-radius: 2px;

        @apply --paper-font-common-base;
        @apply --paper-card;
      }

      /* IE 10 support for HTML5 hidden attr */
      :host([hidden]), [hidden] {
        display: none !important;
      }

      .header {
        position: relative;
        border-top-left-radius: inherit;
        border-top-right-radius: inherit;
        overflow: hidden;

        @apply --paper-card-header;
      }

      .header iron-image {
        display: block;
        width: 100%;
        --iron-image-width: 100%;
        pointer-events: none;

        @apply --paper-card-header-image;
      }

      .header .title-text {
        padding: 16px;
        font-size: 24px;
        font-weight: 400;
        color: var(--paper-card-header-color, #000);

        @apply --paper-card-header-text;
      }

      .header .title-text.over-image {
        position: absolute;
        bottom: 0px;

        @apply --paper-card-header-image-text;
      }

      :host ::slotted(.card-content) {
        padding: 16px;
        position:relative;

        @apply --paper-card-content;
      }

      :host ::slotted(.card-actions) {
        border-top: 1px solid #e8e8e8;
        padding: 5px 16px;
        position:relative;

        @apply --paper-card-actions;
      }

      :host([elevation="1"]) {
        @apply --paper-material-elevation-1;
      }

      :host([elevation="2"]) {
        @apply --paper-material-elevation-2;
      }

      :host([elevation="3"]) {
        @apply --paper-material-elevation-3;
      }

      :host([elevation="4"]) {
        @apply --paper-material-elevation-4;
      }

      :host([elevation="5"]) {
        @apply --paper-material-elevation-5;
      }
    </style>

    <div class="header">
      <iron-image hidden\$="[[!image]]" aria-hidden\$="[[_isHidden(image)]]" src="[[image]]" alt="[[alt]]" placeholder="[[placeholderImage]]" preload="[[preloadImage]]" fade="[[fadeImage]]"></iron-image>
      <div hidden\$="[[!heading]]" class\$="title-text [[_computeHeadingClass(image)]]">[[heading]]</div>
    </div>

    <slot></slot>
`,is:"paper-card",properties:{heading:{type:String,value:"",observer:"_headingChanged"},image:{type:String,value:""},alt:{type:String},preloadImage:{type:Boolean,value:!1},fadeImage:{type:Boolean,value:!1},placeholderImage:{type:String,value:null},elevation:{type:Number,value:1,reflectToAttribute:!0},animatedShadow:{type:Boolean,value:!1},animated:{type:Boolean,reflectToAttribute:!0,readOnly:!0,computed:"_computeAnimated(animatedShadow)"}},_isHidden:function(image){return image?"false":"true"},_headingChanged:function(heading){var currentHeading=this.getAttribute("heading"),currentLabel=this.getAttribute("aria-label");if("string"!==typeof currentLabel||currentLabel===currentHeading){this.setAttribute("aria-label",heading)}},_computeHeadingClass:function(image){return image?" over-image":""},_computeAnimated:function(animatedShadow){return animatedShadow}})},153:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return computeStateDomain});var _compute_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(157);function computeStateDomain(stateObj){return Object(_compute_domain__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj.entity_id)}},156:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return domainIcon});var _const__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(80);const fixedIcons={alert:"hass:alert",automation:"hass:playlist-play",calendar:"hass:calendar",camera:"hass:video",climate:"hass:thermostat",configurator:"hass:settings",conversation:"hass:text-to-speech",device_tracker:"hass:account",fan:"hass:fan",group:"hass:google-circles-communities",history_graph:"hass:chart-line",homeassistant:"hass:home-assistant",homekit:"hass:home-automation",image_processing:"hass:image-filter-frames",input_boolean:"hass:drawing",input_datetime:"hass:calendar-clock",input_number:"hass:ray-vertex",input_select:"hass:format-list-bulleted",input_text:"hass:textbox",light:"hass:lightbulb",mailbox:"hass:mailbox",notify:"hass:comment-alert",plant:"hass:flower",proximity:"hass:apple-safari",remote:"hass:remote",scene:"hass:google-pages",script:"hass:file-document",sensor:"hass:eye",simple_alarm:"hass:bell",sun:"hass:white-balance-sunny",switch:"hass:flash",timer:"hass:timer",updater:"hass:cloud-upload",vacuum:"hass:robot-vacuum",water_heater:"hass:thermometer",weblink:"hass:open-in-new"};function domainIcon(domain,state){if(domain in fixedIcons){return fixedIcons[domain]}switch(domain){case"alarm_control_panel":switch(state){case"armed_home":return"hass:bell-plus";case"armed_night":return"hass:bell-sleep";case"disarmed":return"hass:bell-outline";case"triggered":return"hass:bell-ring";default:return"hass:bell";}case"binary_sensor":return state&&"off"===state?"hass:radiobox-blank":"hass:checkbox-marked-circle";case"cover":return"closed"===state?"hass:window-closed":"hass:window-open";case"lock":return state&&"unlocked"===state?"hass:lock-open":"hass:lock";case"media_player":return state&&"off"!==state&&"idle"!==state?"hass:cast-connected":"hass:cast";case"zwave":switch(state){case"dead":return"hass:emoticon-dead";case"sleeping":return"hass:sleep";case"initializing":return"hass:timer-sand";default:return"hass:z-wave";}default:console.warn("Unable to find icon for domain "+domain+" ("+state+")");return _const__WEBPACK_IMPORTED_MODULE_0__.a;}}},157:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return computeDomain});function computeDomain(entityId){return entityId.substr(0,entityId.indexOf("."))}},159:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(95);const IronIconClass=customElements.get("iron-icon");let loaded=!1;customElements.define("ha-icon",class extends IronIconClass{listen(...args){super.listen(...args);if(!loaded&&"mdi"===this._iconsetName){loaded=!0;__webpack_require__.e(49).then(__webpack_require__.bind(null,212))}}})},161:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_ha_icon__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(159),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(153),_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(175);class StateBadge extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        :host {
          position: relative;
          display: inline-block;
          width: 40px;
          color: var(--paper-item-icon-color, #44739e);
          border-radius: 50%;
          height: 40px;
          text-align: center;
          background-size: cover;
          line-height: 40px;
        }

        ha-icon {
          transition: color 0.3s ease-in-out, filter 0.3s ease-in-out;
        }

        /* Color the icon if light or sun is on */
        ha-icon[data-domain="light"][data-state="on"],
        ha-icon[data-domain="switch"][data-state="on"],
        ha-icon[data-domain="binary_sensor"][data-state="on"],
        ha-icon[data-domain="fan"][data-state="on"],
        ha-icon[data-domain="sun"][data-state="above_horizon"] {
          color: var(--paper-item-icon-active-color, #fdd835);
        }

        /* Color the icon if unavailable */
        ha-icon[data-state="unavailable"] {
          color: var(--state-icon-unavailable-color);
        }
      </style>

      <ha-icon
        id="icon"
        data-domain$="[[_computeDomain(stateObj)]]"
        data-state$="[[stateObj.state]]"
        icon="[[_computeIcon(stateObj, overrideIcon)]]"
      ></ha-icon>
    `}static get properties(){return{stateObj:{type:Object,observer:"_updateIconAppearance"},overrideIcon:String}}_computeDomain(stateObj){return Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_3__.a)(stateObj)}_computeIcon(stateObj,overrideIcon){return overrideIcon||Object(_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_4__.a)(stateObj)}_updateIconAppearance(newVal){var errorMessage=null;const iconStyle={color:"",filter:""},hostStyle={backgroundImage:""};if(newVal.attributes.entity_picture){hostStyle.backgroundImage="url("+newVal.attributes.entity_picture+")";iconStyle.display="none"}else{if(newVal.attributes.hs_color){const hue=newVal.attributes.hs_color[0],sat=newVal.attributes.hs_color[1];if(10<sat)iconStyle.color=`hsl(${hue}, 100%, ${100-sat/2}%)`}if(newVal.attributes.brightness){const brightness=newVal.attributes.brightness;if("number"!==typeof brightness){errorMessage=`Type error: state-badge expected number, but type of ${newVal.entity_id}.attributes.brightness is ${typeof brightness} (${brightness})`;console.warn(errorMessage)}iconStyle.filter=`brightness(${(brightness+245)/5}%)`}}Object.assign(this.$.icon.style,iconStyle);Object.assign(this.style,hostStyle);if(errorMessage){throw new Error(`Frontend error: ${errorMessage}`)}}}customElements.define("state-badge",StateBadge)},164:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1),_polymer_polymer_lib_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(11);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
    <style>
      :host {
        display: inline-block;
        overflow: hidden;
        position: relative;
      }

      #baseURIAnchor {
        display: none;
      }

      #sizedImgDiv {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        display: none;
      }

      #img {
        display: block;
        width: var(--iron-image-width, auto);
        height: var(--iron-image-height, auto);
      }

      :host([sizing]) #sizedImgDiv {
        display: block;
      }

      :host([sizing]) #img {
        display: none;
      }

      #placeholder {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        background-color: inherit;
        opacity: 1;

        @apply --iron-image-placeholder;
      }

      #placeholder.faded-out {
        transition: opacity 0.5s linear;
        opacity: 0;
      }
    </style>

    <a id="baseURIAnchor" href="#"></a>
    <div id="sizedImgDiv" role="img" hidden\$="[[_computeImgDivHidden(sizing)]]" aria-hidden\$="[[_computeImgDivARIAHidden(alt)]]" aria-label\$="[[_computeImgDivARIALabel(alt, src)]]"></div>
    <img id="img" alt\$="[[alt]]" hidden\$="[[_computeImgHidden(sizing)]]" crossorigin\$="[[crossorigin]]" on-load="_imgOnLoad" on-error="_imgOnError">
    <div id="placeholder" hidden\$="[[_computePlaceholderHidden(preload, fade, loading, loaded)]]" class\$="[[_computePlaceholderClassName(preload, fade, loading, loaded)]]"></div>
`,is:"iron-image",properties:{src:{type:String,value:""},alt:{type:String,value:null},crossorigin:{type:String,value:null},preventLoad:{type:Boolean,value:!1},sizing:{type:String,value:null,reflectToAttribute:!0},position:{type:String,value:"center"},preload:{type:Boolean,value:!1},placeholder:{type:String,value:null,observer:"_placeholderChanged"},fade:{type:Boolean,value:!1},loaded:{notify:!0,readOnly:!0,type:Boolean,value:!1},loading:{notify:!0,readOnly:!0,type:Boolean,value:!1},error:{notify:!0,readOnly:!0,type:Boolean,value:!1},width:{observer:"_widthChanged",type:Number,value:null},height:{observer:"_heightChanged",type:Number,value:null}},observers:["_transformChanged(sizing, position)","_loadStateObserver(src, preventLoad)"],created:function(){this._resolvedSrc=""},_imgOnLoad:function(){if(this.$.img.src!==this._resolveSrc(this.src)){return}this._setLoading(!1);this._setLoaded(!0);this._setError(!1)},_imgOnError:function(){if(this.$.img.src!==this._resolveSrc(this.src)){return}this.$.img.removeAttribute("src");this.$.sizedImgDiv.style.backgroundImage="";this._setLoading(!1);this._setLoaded(!1);this._setError(!0)},_computePlaceholderHidden:function(){return!this.preload||!this.fade&&!this.loading&&this.loaded},_computePlaceholderClassName:function(){return this.preload&&this.fade&&!this.loading&&this.loaded?"faded-out":""},_computeImgDivHidden:function(){return!this.sizing},_computeImgDivARIAHidden:function(){return""===this.alt?"true":void 0},_computeImgDivARIALabel:function(){if(null!==this.alt){return this.alt}if(""===this.src){return""}var resolved=this._resolveSrc(this.src);return resolved.replace(/[?|#].*/g,"").split("/").pop()},_computeImgHidden:function(){return!!this.sizing},_widthChanged:function(){this.style.width=isNaN(this.width)?this.width:this.width+"px"},_heightChanged:function(){this.style.height=isNaN(this.height)?this.height:this.height+"px"},_loadStateObserver:function(src,preventLoad){var newResolvedSrc=this._resolveSrc(src);if(newResolvedSrc===this._resolvedSrc){return}this._resolvedSrc="";this.$.img.removeAttribute("src");this.$.sizedImgDiv.style.backgroundImage="";if(""===src||preventLoad){this._setLoading(!1);this._setLoaded(!1);this._setError(!1)}else{this._resolvedSrc=newResolvedSrc;this.$.img.src=this._resolvedSrc;this.$.sizedImgDiv.style.backgroundImage="url(\""+this._resolvedSrc+"\")";this._setLoading(!0);this._setLoaded(!1);this._setError(!1)}},_placeholderChanged:function(){this.$.placeholder.style.backgroundImage=this.placeholder?"url(\""+this.placeholder+"\")":""},_transformChanged:function(){var sizedImgDivStyle=this.$.sizedImgDiv.style,placeholderStyle=this.$.placeholder.style;sizedImgDivStyle.backgroundSize=placeholderStyle.backgroundSize=this.sizing;sizedImgDivStyle.backgroundPosition=placeholderStyle.backgroundPosition=this.sizing?this.position:"";sizedImgDivStyle.backgroundRepeat=placeholderStyle.backgroundRepeat=this.sizing?"no-repeat":""},_resolveSrc:function(testSrc){var resolved=Object(_polymer_polymer_lib_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_3__.c)(testSrc,this.$.baseURIAnchor.href);if("/"===resolved[0]){resolved=(location.origin||location.protocol+"//"+location.host)+resolved}return resolved}})},165:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"b",function(){return PaperDialogBehaviorImpl});__webpack_require__.d(__webpack_exports__,"a",function(){return PaperDialogBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_overlay_behavior_iron_overlay_behavior_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(73),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(0);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperDialogBehaviorImpl={hostAttributes:{role:"dialog",tabindex:"-1"},properties:{modal:{type:Boolean,value:!1},__readied:{type:Boolean,value:!1}},observers:["_modalChanged(modal, __readied)"],listeners:{tap:"_onDialogClick"},ready:function(){this.__prevNoCancelOnOutsideClick=this.noCancelOnOutsideClick;this.__prevNoCancelOnEscKey=this.noCancelOnEscKey;this.__prevWithBackdrop=this.withBackdrop;this.__readied=!0},_modalChanged:function(modal,readied){if(!readied){return}if(modal){this.__prevNoCancelOnOutsideClick=this.noCancelOnOutsideClick;this.__prevNoCancelOnEscKey=this.noCancelOnEscKey;this.__prevWithBackdrop=this.withBackdrop;this.noCancelOnOutsideClick=!0;this.noCancelOnEscKey=!0;this.withBackdrop=!0}else{this.noCancelOnOutsideClick=this.noCancelOnOutsideClick&&this.__prevNoCancelOnOutsideClick;this.noCancelOnEscKey=this.noCancelOnEscKey&&this.__prevNoCancelOnEscKey;this.withBackdrop=this.withBackdrop&&this.__prevWithBackdrop}},_updateClosingReasonConfirmed:function(confirmed){this.closingReason=this.closingReason||{};this.closingReason.confirmed=confirmed},_onDialogClick:function(event){for(var path=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_2__.b)(event).path,i=0,l=path.indexOf(this),target;i<l;i++){target=path[i];if(target.hasAttribute&&(target.hasAttribute("dialog-dismiss")||target.hasAttribute("dialog-confirm"))){this._updateClosingReasonConfirmed(target.hasAttribute("dialog-confirm"));this.close();event.stopPropagation();break}}}},PaperDialogBehavior=[_polymer_iron_overlay_behavior_iron_overlay_behavior_js__WEBPACK_IMPORTED_MODULE_1__.a,PaperDialogBehaviorImpl]},170:function(module,__webpack_exports__){"use strict";var _Mathabs=Math.abs,_Mathround=Math.round,fecha={},token=/d{1,4}|M{1,4}|YY(?:YY)?|S{1,3}|Do|ZZ|([HhMsDm])\1?|[aA]|"[^"]*"|'[^']*'/g,twoDigits="\\d\\d?",word="[^\\s]+",literal=/\[([^]*?)\]/gm,noop=function(){};function regexEscape(str){return str.replace(/[|\\{()[^$+*?.-]/g,"\\$&")}function shorten(arr,sLen){for(var newArr=[],i=0,len=arr.length;i<len;i++){newArr.push(arr[i].substr(0,sLen))}return newArr}function monthUpdate(arrName){return function(d,v,i18n){var index=i18n[arrName].indexOf(v.charAt(0).toUpperCase()+v.substr(1).toLowerCase());if(~index){d.month=index}}}function pad(val,len){val=val+"";len=len||2;while(val.length<len){val="0"+val}return val}var dayNames=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],monthNames=["January","February","March","April","May","June","July","August","September","October","November","December"],monthNamesShort=shorten(monthNames,3),dayNamesShort=shorten(dayNames,3);fecha.i18n={dayNamesShort:dayNamesShort,dayNames:dayNames,monthNamesShort:monthNamesShort,monthNames:monthNames,amPm:["am","pm"],DoFn:function(D){return D+["th","st","nd","rd"][3<D%10?0:(10!==D-D%10)*D%10]}};var formatFlags={D:function(dateObj){return dateObj.getDate()},DD:function(dateObj){return pad(dateObj.getDate())},Do:function(dateObj,i18n){return i18n.DoFn(dateObj.getDate())},d:function(dateObj){return dateObj.getDay()},dd:function(dateObj){return pad(dateObj.getDay())},ddd:function(dateObj,i18n){return i18n.dayNamesShort[dateObj.getDay()]},dddd:function(dateObj,i18n){return i18n.dayNames[dateObj.getDay()]},M:function(dateObj){return dateObj.getMonth()+1},MM:function(dateObj){return pad(dateObj.getMonth()+1)},MMM:function(dateObj,i18n){return i18n.monthNamesShort[dateObj.getMonth()]},MMMM:function(dateObj,i18n){return i18n.monthNames[dateObj.getMonth()]},YY:function(dateObj){return pad(dateObj.getFullYear()+"",4).substr(2)},YYYY:function(dateObj){return pad(dateObj.getFullYear(),4)},h:function(dateObj){return dateObj.getHours()%12||12},hh:function(dateObj){return pad(dateObj.getHours()%12||12)},H:function(dateObj){return dateObj.getHours()},HH:function(dateObj){return pad(dateObj.getHours())},m:function(dateObj){return dateObj.getMinutes()},mm:function(dateObj){return pad(dateObj.getMinutes())},s:function(dateObj){return dateObj.getSeconds()},ss:function(dateObj){return pad(dateObj.getSeconds())},S:function(dateObj){return _Mathround(dateObj.getMilliseconds()/100)},SS:function(dateObj){return pad(_Mathround(dateObj.getMilliseconds()/10),2)},SSS:function(dateObj){return pad(dateObj.getMilliseconds(),3)},a:function(dateObj,i18n){return 12>dateObj.getHours()?i18n.amPm[0]:i18n.amPm[1]},A:function(dateObj,i18n){return 12>dateObj.getHours()?i18n.amPm[0].toUpperCase():i18n.amPm[1].toUpperCase()},ZZ:function(dateObj){var o=dateObj.getTimezoneOffset();return(0<o?"-":"+")+pad(100*Math.floor(_Mathabs(o)/60)+_Mathabs(o)%60,4)}},parseFlags={D:[twoDigits,function(d,v){d.day=v}],Do:[twoDigits+word,function(d,v){d.day=parseInt(v,10)}],M:[twoDigits,function(d,v){d.month=v-1}],YY:[twoDigits,function(d,v){var da=new Date,cent=+(""+da.getFullYear()).substr(0,2);d.year=""+(68<v?cent-1:cent)+v}],h:[twoDigits,function(d,v){d.hour=v}],m:[twoDigits,function(d,v){d.minute=v}],s:[twoDigits,function(d,v){d.second=v}],YYYY:["\\d{4}",function(d,v){d.year=v}],S:["\\d",function(d,v){d.millisecond=100*v}],SS:["\\d{2}",function(d,v){d.millisecond=10*v}],SSS:["\\d{3}",function(d,v){d.millisecond=v}],d:[twoDigits,noop],ddd:[word,noop],MMM:[word,monthUpdate("monthNamesShort")],MMMM:[word,monthUpdate("monthNames")],a:[word,function(d,v,i18n){var val=v.toLowerCase();if(val===i18n.amPm[0]){d.isPm=!1}else if(val===i18n.amPm[1]){d.isPm=!0}}],ZZ:["[^\\s]*?[\\+\\-]\\d\\d:?\\d\\d|[^\\s]*?Z",function(d,v){var parts=(v+"").match(/([\+\-]|\d\d)/gi),minutes;if(parts){minutes=+(60*parts[1])+parseInt(parts[2],10);d.timezoneOffset="+"===parts[0]?minutes:-minutes}}]};parseFlags.dd=parseFlags.d;parseFlags.dddd=parseFlags.ddd;parseFlags.DD=parseFlags.D;parseFlags.mm=parseFlags.m;parseFlags.hh=parseFlags.H=parseFlags.HH=parseFlags.h;parseFlags.MM=parseFlags.M;parseFlags.ss=parseFlags.s;parseFlags.A=parseFlags.a;fecha.masks={default:"ddd MMM DD YYYY HH:mm:ss",shortDate:"M/D/YY",mediumDate:"MMM D, YYYY",longDate:"MMMM D, YYYY",fullDate:"dddd, MMMM D, YYYY",shortTime:"HH:mm",mediumTime:"HH:mm:ss",longTime:"HH:mm:ss.SSS"};fecha.format=function(dateObj,mask,i18nSettings){var i18n=i18nSettings||fecha.i18n;if("number"===typeof dateObj){dateObj=new Date(dateObj)}if("[object Date]"!==Object.prototype.toString.call(dateObj)||isNaN(dateObj.getTime())){throw new Error("Invalid Date in fecha.format")}mask=fecha.masks[mask]||mask||fecha.masks["default"];var literals=[];mask=mask.replace(literal,function($0,$1){literals.push($1);return"??"});mask=mask.replace(token,function($0){return $0 in formatFlags?formatFlags[$0](dateObj,i18n):$0.slice(1,$0.length-1)});return mask.replace(/\?\?/g,function(){return literals.shift()})};fecha.parse=function(dateStr,format,i18nSettings){var i18n=i18nSettings||fecha.i18n;if("string"!==typeof format){throw new Error("Invalid format in fecha.parse")}format=fecha.masks[format]||format;if(1e3<dateStr.length){return null}var dateInfo={},parseInfo=[],newFormat=regexEscape(format).replace(token,function($0){if(parseFlags[$0]){var info=parseFlags[$0];parseInfo.push(info[1]);return"("+info[0]+")"}return $0}),matches=dateStr.match(new RegExp(newFormat,"i"));if(!matches){return null}for(var i=1;i<matches.length;i++){parseInfo[i-1](dateInfo,matches[i],i18n)}var today=new Date;if(!0===dateInfo.isPm&&null!=dateInfo.hour&&12!==+dateInfo.hour){dateInfo.hour=+dateInfo.hour+12}else if(!1===dateInfo.isPm&&12===+dateInfo.hour){dateInfo.hour=0}var date;if(null!=dateInfo.timezoneOffset){dateInfo.minute=+(dateInfo.minute||0)-+dateInfo.timezoneOffset;date=new Date(Date.UTC(dateInfo.year||today.getFullYear(),dateInfo.month||0,dateInfo.day||1,dateInfo.hour||0,dateInfo.minute||0,dateInfo.second||0,dateInfo.millisecond||0))}else{date=new Date(dateInfo.year||today.getFullYear(),dateInfo.month||0,dateInfo.day||1,dateInfo.hour||0,dateInfo.minute||0,dateInfo.second||0,dateInfo.millisecond||0)}return date};__webpack_exports__.a=fecha},173:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(170);__webpack_exports__.a=function(){try{new Date().toLocaleString("i")}catch(e){return"RangeError"===e.name}return!1}()?(dateObj,locales)=>dateObj.toLocaleString(locales,{year:"numeric",month:"long",day:"numeric",hour:"numeric",minute:"2-digit"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"haDateTime")},175:function(module,__webpack_exports__,__webpack_require__){"use strict";var common_const=__webpack_require__(80),compute_domain=__webpack_require__(157),domain_icon=__webpack_require__(156);const fixedDeviceClassIcons={humidity:"hass:water-percent",illuminance:"hass:brightness-5",temperature:"hass:thermometer",pressure:"hass:gauge"};function sensorIcon(state){const dclass=state.attributes.device_class;if(dclass&&dclass in fixedDeviceClassIcons){return fixedDeviceClassIcons[dclass]}if("battery"===dclass){const battery=+state.state;if(isNaN(battery)){return"hass:battery-unknown"}const batteryRound=10*Math.round(battery/10);if(100<=batteryRound){return"hass:battery"}if(0>=batteryRound){return"hass:battery-alert"}return`${"hass"}:battery-${batteryRound}`}const unit=state.attributes.unit_of_measurement;if(unit===common_const.j||unit===common_const.k){return"hass:thermometer"}return Object(domain_icon.a)("sensor")}__webpack_require__.d(__webpack_exports__,"a",function(){return stateIcon});const domainIcons={binary_sensor:function(state){const activated=state.state&&"off"===state.state;switch(state.attributes.device_class){case"battery":return activated?"hass:battery":"hass:battery-outline";case"cold":return activated?"hass:thermometer":"hass:snowflake";case"connectivity":return activated?"hass:server-network-off":"hass:server-network";case"door":return activated?"hass:door-closed":"hass:door-open";case"garage_door":return activated?"hass:garage":"hass:garage-open";case"gas":case"power":case"problem":case"safety":case"smoke":return activated?"hass:verified":"hass:alert";case"heat":return activated?"hass:thermometer":"hass:fire";case"light":return activated?"hass:brightness-5":"hass:brightness-7";case"lock":return activated?"hass:lock":"hass:lock-open";case"moisture":return activated?"hass:water-off":"hass:water";case"motion":return activated?"hass:walk":"hass:run";case"occupancy":return activated?"hass:home-outline":"hass:home";case"opening":return activated?"hass:square":"hass:square-outline";case"plug":return activated?"hass:power-plug-off":"hass:power-plug";case"presence":return activated?"hass:home-outline":"hass:home";case"sound":return activated?"hass:music-note-off":"hass:music-note";case"vibration":return activated?"hass:crop-portrait":"hass:vibrate";case"window":return activated?"hass:window-closed":"hass:window-open";default:return activated?"hass:radiobox-blank":"hass:checkbox-marked-circle";}},cover:function(state){const open="closed"!==state.state;switch(state.attributes.device_class){case"garage":return open?"hass:garage-open":"hass:garage";default:return Object(domain_icon.a)("cover",state.state);}},sensor:sensorIcon,input_datetime:function(state){if(!state.attributes.has_date){return"hass:clock"}if(!state.attributes.has_time){return"hass:calendar"}return Object(domain_icon.a)("input_datetime")}};function stateIcon(state){if(!state){return common_const.a}if(state.attributes.icon){return state.attributes.icon}const domain=Object(compute_domain.a)(state.entity_id);if(domain in domainIcons){return domainIcons[domain](state)}return Object(domain_icon.a)(domain,state.state)}},177:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(39),_polymer_paper_styles_typography_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(50),_polymer_paper_styles_shadow_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(61);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<dom-module id="paper-dialog-shared-styles">
  <template>
    <style>
      :host {
        display: block;
        margin: 24px 40px;

        background: var(--paper-dialog-background-color, var(--primary-background-color));
        color: var(--paper-dialog-color, var(--primary-text-color));

        @apply --paper-font-body1;
        @apply --shadow-elevation-16dp;
        @apply --paper-dialog;
      }

      :host > ::slotted(*) {
        margin-top: 20px;
        padding: 0 24px;
      }

      :host > ::slotted(.no-padding) {
        padding: 0;
      }

      
      :host > ::slotted(*:first-child) {
        margin-top: 24px;
      }

      :host > ::slotted(*:last-child) {
        margin-bottom: 24px;
      }

      /* In 1.x, this selector was \`:host > ::content h2\`. In 2.x <slot> allows
      to select direct children only, which increases the weight of this
      selector, so we have to re-define first-child/last-child margins below. */
      :host > ::slotted(h2) {
        position: relative;
        margin: 0;

        @apply --paper-font-title;
        @apply --paper-dialog-title;
      }

      /* Apply mixin again, in case it sets margin-top. */
      :host > ::slotted(h2:first-child) {
        margin-top: 24px;
        @apply --paper-dialog-title;
      }

      /* Apply mixin again, in case it sets margin-bottom. */
      :host > ::slotted(h2:last-child) {
        margin-bottom: 24px;
        @apply --paper-dialog-title;
      }

      :host > ::slotted(.paper-dialog-buttons),
      :host > ::slotted(.buttons) {
        position: relative;
        padding: 8px 8px 8px 24px;
        margin: 0;

        color: var(--paper-dialog-button-color, var(--primary-color));

        @apply --layout-horizontal;
        @apply --layout-end-justified;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild($_documentContainer.content)},185:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return isComponentLoaded});function isComponentLoaded(hass,component){return hass&&-1!==hass.config.components.indexOf(component)}},186:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(39),_polymer_paper_dialog_behavior_paper_dialog_behavior_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(165),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__.a`
    <style>

      :host {
        display: block;
        @apply --layout-relative;
      }

      :host(.is-scrolled:not(:first-child))::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: var(--divider-color);
      }

      :host(.can-scroll:not(.scrolled-to-bottom):not(:last-child))::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 1px;
        background: var(--divider-color);
      }

      .scrollable {
        padding: 0 24px;

        @apply --layout-scroll;
        @apply --paper-dialog-scrollable;
      }

      .fit {
        @apply --layout-fit;
      }
    </style>

    <div id="scrollable" class="scrollable" on-scroll="updateScrollState">
      <slot></slot>
    </div>
`,is:"paper-dialog-scrollable",properties:{dialogElement:{type:Object}},get scrollTarget(){return this.$.scrollable},ready:function(){this._ensureTarget();this.classList.add("no-padding")},attached:function(){this._ensureTarget();requestAnimationFrame(this.updateScrollState.bind(this))},updateScrollState:function(){this.toggleClass("is-scrolled",0<this.scrollTarget.scrollTop);this.toggleClass("can-scroll",this.scrollTarget.offsetHeight<this.scrollTarget.scrollHeight);this.toggleClass("scrolled-to-bottom",this.scrollTarget.scrollTop+this.scrollTarget.offsetHeight>=this.scrollTarget.scrollHeight)},_ensureTarget:function(){this.dialogElement=this.dialogElement||this.parentElement;if(this.dialogElement&&this.dialogElement.behaviors&&0<=this.dialogElement.behaviors.indexOf(_polymer_paper_dialog_behavior_paper_dialog_behavior_js__WEBPACK_IMPORTED_MODULE_3__.b)){this.dialogElement.sizingTarget=this.scrollTarget;this.scrollTarget.classList.remove("fit")}else if(this.dialogElement){this.scrollTarget.classList.add("fit")}}})},187:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(58),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(39),_polymer_paper_behaviors_paper_checked_element_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(109),_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(40),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(4),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(25),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(1),_polymer_polymer_lib_utils_render_status_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(34);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__.a`

    <style>
      :host {
        display: inline-block;
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-common-base;
      }

      :host([disabled]) {
        pointer-events: none;
      }

      :host(:focus) {
        outline:none;
      }

      .toggle-bar {
        position: absolute;
        height: 100%;
        width: 100%;
        border-radius: 8px;
        pointer-events: none;
        opacity: 0.4;
        transition: background-color linear .08s;
        background-color: var(--paper-toggle-button-unchecked-bar-color, #000000);

        @apply --paper-toggle-button-unchecked-bar;
      }

      .toggle-button {
        position: absolute;
        top: -3px;
        left: 0;
        height: 20px;
        width: 20px;
        border-radius: 50%;
        box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.6);
        transition: -webkit-transform linear .08s, background-color linear .08s;
        transition: transform linear .08s, background-color linear .08s;
        will-change: transform;
        background-color: var(--paper-toggle-button-unchecked-button-color, var(--paper-grey-50));

        @apply --paper-toggle-button-unchecked-button;
      }

      .toggle-button.dragging {
        -webkit-transition: none;
        transition: none;
      }

      :host([checked]:not([disabled])) .toggle-bar {
        opacity: 0.5;
        background-color: var(--paper-toggle-button-checked-bar-color, var(--primary-color));

        @apply --paper-toggle-button-checked-bar;
      }

      :host([disabled]) .toggle-bar {
        background-color: #000;
        opacity: 0.12;
      }

      :host([checked]) .toggle-button {
        -webkit-transform: translate(16px, 0);
        transform: translate(16px, 0);
      }

      :host([checked]:not([disabled])) .toggle-button {
        background-color: var(--paper-toggle-button-checked-button-color, var(--primary-color));

        @apply --paper-toggle-button-checked-button;
      }

      :host([disabled]) .toggle-button {
        background-color: #bdbdbd;
        opacity: 1;
      }

      .toggle-ink {
        position: absolute;
        top: -14px;
        left: -14px;
        right: auto;
        bottom: auto;
        width: 48px;
        height: 48px;
        opacity: 0.5;
        pointer-events: none;
        color: var(--paper-toggle-button-unchecked-ink-color, var(--primary-text-color));

        @apply --paper-toggle-button-unchecked-ink;
      }

      :host([checked]) .toggle-ink {
        color: var(--paper-toggle-button-checked-ink-color, var(--primary-color));

        @apply --paper-toggle-button-checked-ink;
      }

      .toggle-container {
        display: inline-block;
        position: relative;
        width: 36px;
        height: 14px;
        /* The toggle button has an absolute position of -3px; The extra 1px
        /* accounts for the toggle button shadow box. */
        margin: 4px 1px;
      }

      .toggle-label {
        position: relative;
        display: inline-block;
        vertical-align: middle;
        padding-left: var(--paper-toggle-button-label-spacing, 8px);
        pointer-events: none;
        color: var(--paper-toggle-button-label-color, var(--primary-text-color));
      }

      /* invalid state */
      :host([invalid]) .toggle-bar {
        background-color: var(--paper-toggle-button-invalid-bar-color, var(--error-color));
      }

      :host([invalid]) .toggle-button {
        background-color: var(--paper-toggle-button-invalid-button-color, var(--error-color));
      }

      :host([invalid]) .toggle-ink {
        color: var(--paper-toggle-button-invalid-ink-color, var(--error-color));
      }
    </style>

    <div class="toggle-container">
      <div id="toggleBar" class="toggle-bar"></div>
      <div id="toggleButton" class="toggle-button"></div>
    </div>

    <div class="toggle-label"><slot></slot></div>

  `;template.setAttribute("strip-whitespace","");Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_6__.a)({_template:template,is:"paper-toggle-button",behaviors:[_polymer_paper_behaviors_paper_checked_element_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a],hostAttributes:{role:"button","aria-pressed":"false",tabindex:0},properties:{},listeners:{track:"_ontrack"},attached:function(){Object(_polymer_polymer_lib_utils_render_status_js__WEBPACK_IMPORTED_MODULE_9__.a)(this,function(){Object(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_7__.f)(this,"pan-y")})},_ontrack:function(event){var track=event.detail;if("start"===track.state){this._trackStart(track)}else if("track"===track.state){this._trackMove(track)}else if("end"===track.state){this._trackEnd(track)}},_trackStart:function(){this._width=this.$.toggleBar.offsetWidth/2;this._trackChecked=this.checked;this.$.toggleButton.classList.add("dragging")},_trackMove:function(track){var dx=track.dx;this._x=Math.min(this._width,Math.max(0,this._trackChecked?this._width+dx:dx));this.translate3d(this._x+"px",0,0,this.$.toggleButton);this._userActivate(this._x>this._width/2)},_trackEnd:function(){this.$.toggleButton.classList.remove("dragging");this.transform("",this.$.toggleButton)},_createRipple:function(){this._rippleContainer=this.$.toggleButton;var ripple=_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a._createRipple();ripple.id="ink";ripple.setAttribute("recenters","");ripple.classList.add("circle","toggle-ink");return ripple}})},188:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(170);__webpack_exports__.a=function(){try{new Date().toLocaleTimeString("i")}catch(e){return"RangeError"===e.name}return!1}()?(dateObj,locales)=>dateObj.toLocaleTimeString(locales,{hour:"numeric",minute:"2-digit"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"shortTime")},190:function(module,__webpack_exports__,__webpack_require__){"use strict";var _compute_state_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(153),_datetime_format_date_time__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(173),_datetime_format_date__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(208),_datetime_format_time__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(188);__webpack_exports__.a=(localize,stateObj,language)=>{let display;const domain=Object(_compute_state_domain__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj);if("binary_sensor"===domain){if(stateObj.attributes.device_class){display=localize(`state.${domain}.${stateObj.attributes.device_class}.${stateObj.state}`)}if(!display){display=localize(`state.${domain}.default.${stateObj.state}`)}}else if(stateObj.attributes.unit_of_measurement&&!["unknown","unavailable"].includes(stateObj.state)){display=stateObj.state+" "+stateObj.attributes.unit_of_measurement}else if("input_datetime"===domain){let date;if(!stateObj.attributes.has_time){date=new Date(stateObj.attributes.year,stateObj.attributes.month-1,stateObj.attributes.day);display=Object(_datetime_format_date__WEBPACK_IMPORTED_MODULE_2__.a)(date,language)}else if(!stateObj.attributes.has_date){const now=new Date;date=new Date(now.getFullYear(),now.getMonth(),now.getDay(),stateObj.attributes.hour,stateObj.attributes.minute);display=Object(_datetime_format_time__WEBPACK_IMPORTED_MODULE_3__.a)(date,language)}else{date=new Date(stateObj.attributes.year,stateObj.attributes.month-1,stateObj.attributes.day,stateObj.attributes.hour,stateObj.attributes.minute);display=Object(_datetime_format_date_time__WEBPACK_IMPORTED_MODULE_1__.a)(date,language)}}else if("zwave"===domain){if(["initializing","dead"].includes(stateObj.state)){display=localize(`state.zwave.query_stage.${stateObj.state}`,"query_stage",stateObj.attributes.query_stage)}else{display=localize(`state.zwave.default.${stateObj.state}`)}}else{display=localize(`state.${domain}.${stateObj.state}`)}if(!display){display=localize(`state.default.${stateObj.state}`)||localize(`component.${domain}.state.${stateObj.state}`)||stateObj.state}return display}},193:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return supportsFeature});const supportsFeature=(stateObj,feature)=>{return 0!==(stateObj.attributes.supported_features&feature)}},198:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return CoverEntity});__webpack_require__.d(__webpack_exports__,"b",function(){return isTiltOnly});var _common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(193);class CoverEntity{constructor(hass,stateObj){this.hass=hass;this.stateObj=stateObj;this._attr=stateObj.attributes;this._feat=this._attr.supported_features}get isFullyOpen(){if(this._attr.current_position!==void 0){return 100===this._attr.current_position}return"open"===this.stateObj.state}get isFullyClosed(){if(this._attr.current_position!==void 0){return 0===this._attr.current_position}return"closed"===this.stateObj.state}get isFullyOpenTilt(){return 100===this._attr.current_tilt_position}get isFullyClosedTilt(){return 0===this._attr.current_tilt_position}get isOpening(){return"opening"===this.stateObj.state}get isClosing(){return"closing"===this.stateObj.state}get supportsOpen(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1)}get supportsClose(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,2)}get supportsSetPosition(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,4)}get supportsStop(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,8)}get supportsOpenTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16)}get supportsCloseTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,32)}get supportsStopTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,64)}get supportsSetTiltPosition(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,128)}get isTiltOnly(){const supportsCover=this.supportsOpen||this.supportsClose||this.supportsStop,supportsTilt=this.supportsOpenTilt||this.supportsCloseTilt||this.supportsStopTilt;return supportsTilt&&!supportsCover}openCover(){this.callService("open_cover")}closeCover(){this.callService("close_cover")}stopCover(){this.callService("stop_cover")}openCoverTilt(){this.callService("open_cover_tilt")}closeCoverTilt(){this.callService("close_cover_tilt")}stopCoverTilt(){this.callService("stop_cover_tilt")}setCoverPosition(position){this.callService("set_cover_position",{position})}setCoverTiltPosition(tiltPosition){this.callService("set_cover_tilt_position",{tilt_position:tiltPosition})}callService(service,data={}){data.entity_id=this.stateObj.entity_id;this.hass.callService("cover",service,data)}}const supportsOpen=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,1),supportsClose=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,2),supportsStop=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,8),supportsOpenTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,16),supportsCloseTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,32),supportsStopTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,64);function isTiltOnly(stateObj){const supportsCover=supportsOpen(stateObj)||supportsClose(stateObj)||supportsStop(stateObj),supportsTilt=supportsOpenTilt(stateObj)||supportsCloseTilt(stateObj)||supportsStopTilt(stateObj);return supportsTilt&&!supportsCover}},201:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(10),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(48);let loaded=null;const svgWhiteList=["svg","path"];class HaMarkdown extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_1__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_0__.a){static get properties(){return{content:{type:String,observer:"_render"},allowSvg:{type:Boolean,value:!1}}}connectedCallback(){super.connectedCallback();this._scriptLoaded=0;this._renderScheduled=!1;this._resize=()=>this.fire("iron-resize");if(!loaded){loaded=Promise.all([__webpack_require__.e(99),__webpack_require__.e(63)]).then(__webpack_require__.bind(null,252))}loaded.then(({marked,filterXSS})=>{this.marked=marked;this.filterXSS=filterXSS;this._scriptLoaded=1},()=>{this._scriptLoaded=2}).then(()=>this._render())}_render(){if(0===this._scriptLoaded||this._renderScheduled)return;this._renderScheduled=!0;Promise.resolve().then(()=>{this._renderScheduled=!1;if(1===this._scriptLoaded){this.innerHTML=this.filterXSS(this.marked(this.content,{gfm:!0,tables:!0,breaks:!0}),{onIgnoreTag:this.allowSvg?(tag,html)=>0<=svgWhiteList.indexOf(tag)?html:null:null});this._resize();const walker=document.createTreeWalker(this,1,null,!1);while(walker.nextNode()){const node=walker.currentNode;if("A"===node.tagName&&node.host!==document.location.host){node.target="_blank"}else if("IMG"===node.tagName){node.addEventListener("load",this._resize)}}}else if(2===this._scriptLoaded){this.innerText=this.content}})}}customElements.define("ha-markdown",HaMarkdown)},202:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(99),_polymer_paper_toggle_button_paper_toggle_button__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(187),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(10),_common_const__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(80),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(153);class HaEntityToggle extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__.a`
      <style>
        :host {
          white-space: nowrap;
          min-width: 38px;
        }
        paper-icon-button {
          color: var(
            --paper-icon-button-inactive-color,
            var(--primary-text-color)
          );
          transition: color 0.5s;
        }
        paper-icon-button[state-active] {
          color: var(--paper-icon-button-active-color, var(--primary-color));
        }
        paper-toggle-button {
          cursor: pointer;
          --paper-toggle-button-label-spacing: 0;
          padding: 13px 5px;
          margin: -4px -5px;
        }
      </style>

      <template is="dom-if" if="[[stateObj.attributes.assumed_state]]">
        <paper-icon-button
          icon="hass:flash-off"
          on-click="turnOff"
          state-active$="[[!isOn]]"
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:flash"
          on-click="turnOn"
          state-active$="[[isOn]]"
        ></paper-icon-button>
      </template>
      <template is="dom-if" if="[[!stateObj.attributes.assumed_state]]">
        <paper-toggle-button
          checked="[[toggleChecked]]"
          on-change="toggleChanged"
        ></paper-toggle-button>
      </template>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"stateObjObserver"},toggleChecked:{type:Boolean,value:!1},isOn:{type:Boolean,computed:"computeIsOn(stateObj)",observer:"isOnChanged"}}}ready(){super.ready();this.addEventListener("click",ev=>this.onTap(ev));this.forceStateChange()}onTap(ev){ev.stopPropagation()}toggleChanged(ev){const newVal=ev.target.checked;if(newVal&&!this.isOn){this.callService(!0)}else if(!newVal&&this.isOn){this.callService(!1)}}isOnChanged(newVal){this.toggleChecked=newVal}forceStateChange(){if(this.toggleChecked===this.isOn){this.toggleChecked=!this.toggleChecked}this.toggleChecked=this.isOn}turnOn(){this.callService(!0)}turnOff(){this.callService(!1)}computeIsOn(stateObj){return stateObj&&!_common_const__WEBPACK_IMPORTED_MODULE_4__.i.includes(stateObj.state)}stateObjObserver(newVal,oldVal){if(!oldVal||!newVal)return;if(this.computeIsOn(newVal)===this.computeIsOn(oldVal)){this.forceStateChange()}}callService(turnOn){const stateDomain=Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_5__.a)(this.stateObj);let serviceDomain,service;if("lock"===stateDomain){serviceDomain="lock";service=turnOn?"unlock":"lock"}else if("cover"===stateDomain){serviceDomain="cover";service=turnOn?"open_cover":"close_cover"}else if("group"===stateDomain){serviceDomain="homeassistant";service=turnOn?"turn_on":"turn_off"}else{serviceDomain=stateDomain;service=turnOn?"turn_on":"turn_off"}const currentState=this.stateObj;this.hass.callService(serviceDomain,service,{entity_id:this.stateObj.entity_id}).then(()=>{setTimeout(()=>{if(this.stateObj===currentState){this.forceStateChange()}},2e3)})}}customElements.define("ha-entity-toggle",HaEntityToggle)},203:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"c",function(){return fetchRecent});__webpack_require__.d(__webpack_exports__,"b",function(){return fetchDate});__webpack_require__.d(__webpack_exports__,"a",function(){return computeHistory});var _common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(105),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(153),_common_entity_compute_state_display__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(190);const DOMAINS_USE_LAST_UPDATED=["climate","water_heater"],LINE_ATTRIBUTES_TO_KEEP=["temperature","current_temperature","target_temp_low","target_temp_high"],fetchRecent=(hass,entityId,startTime,endTime,skipInitialState=!1)=>{let url="history/period";if(startTime){url+="/"+startTime.toISOString()}url+="?filter_entity_id="+entityId;if(endTime){url+="&end_time="+endTime.toISOString()}if(skipInitialState){url+="&skip_initial_state"}return hass.callApi("GET",url)},fetchDate=(hass,startTime,endTime)=>{return hass.callApi("GET",`history/period/${startTime.toISOString()}?end_time=${endTime.toISOString()}`)},equalState=(obj1,obj2)=>obj1.state===obj2.state&&(!obj1.attributes||LINE_ATTRIBUTES_TO_KEEP.every(attr=>obj1.attributes[attr]===obj2.attributes[attr])),processTimelineEntity=(localize,language,states)=>{const data=[];for(const state of states){if(0<data.length&&state.state===data[data.length-1].state){continue}data.push({state_localize:Object(_common_entity_compute_state_display__WEBPACK_IMPORTED_MODULE_2__.a)(localize,state,language),state:state.state,last_changed:state.last_changed})}return{name:Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__.a)(states[0]),entity_id:states[0].entity_id,data}},processLineChartEntities=(unit,entities)=>{const data=[];for(const states of entities){const last=states[states.length-1],domain=Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(last),processedStates=[];for(const state of states){let processedState;if(DOMAINS_USE_LAST_UPDATED.includes(domain)){processedState={state:state.state,last_changed:state.last_updated,attributes:{}};for(const attr of LINE_ATTRIBUTES_TO_KEEP){if(attr in state.attributes){processedState.attributes[attr]=state.attributes[attr]}}}else{processedState=state}if(1<processedStates.length&&equalState(processedState,processedStates[processedStates.length-1])&&equalState(processedState,processedStates[processedStates.length-2])){continue}processedStates.push(processedState)}data.push({domain,name:Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__.a)(last),entity_id:last.entity_id,states:processedStates})}return{unit,identifier:entities.map(states=>states[0].entity_id).join(""),data}},computeHistory=(hass,stateHistory,localize,language)=>{const lineChartDevices={},timelineDevices=[];if(!stateHistory){return{line:[],timeline:[]}}stateHistory.forEach(stateInfo=>{if(0===stateInfo.length){return}const stateWithUnit=stateInfo.find(state=>"unit_of_measurement"in state.attributes);let unit;if(stateWithUnit){unit=stateWithUnit.attributes.unit_of_measurement}else if("climate"===Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(stateInfo[0])){unit=hass.config.unit_system.temperature}else if("water_heater"===Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(stateInfo[0])){unit=hass.config.unit_system.temperature}if(!unit){timelineDevices.push(processTimelineEntity(localize,language,stateInfo))}else if(unit in lineChartDevices){lineChartDevices[unit].push(stateInfo)}else{lineChartDevices[unit]=[stateInfo]}});const unitStates=Object.keys(lineChartDevices).map(unit=>processLineChartEntities(unit,lineChartDevices[unit]));return{line:unitStates,timeline:timelineDevices}}},208:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(170);__webpack_exports__.a=function(){try{new Date().toLocaleDateString("i")}catch(e){return"RangeError"===e.name}return!1}()?(dateObj,locales)=>dateObj.toLocaleDateString(locales,{year:"numeric",month:"long",day:"numeric"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"mediumDate")},216:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_legacy_polymer_dom__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(0),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_common_datetime_relative_time__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(231),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(71);class HaRelativeTime extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_3__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get properties(){return{hass:Object,datetime:{type:String,observer:"datetimeChanged"},datetimeObj:{type:Object,observer:"datetimeObjChanged"},parsedDateTime:Object}}constructor(){super();this.updateRelative=this.updateRelative.bind(this)}connectedCallback(){super.connectedCallback();this.updateInterval=setInterval(this.updateRelative,6e4)}disconnectedCallback(){super.disconnectedCallback();clearInterval(this.updateInterval)}datetimeChanged(newVal){this.parsedDateTime=newVal?new Date(newVal):null;this.updateRelative()}datetimeObjChanged(newVal){this.parsedDateTime=newVal;this.updateRelative()}updateRelative(){const root=Object(_polymer_polymer_lib_legacy_polymer_dom__WEBPACK_IMPORTED_MODULE_0__.b)(this);if(!this.parsedDateTime){root.innerHTML=this.localize("ui.components.relative_time.never")}else{root.innerHTML=Object(_common_datetime_relative_time__WEBPACK_IMPORTED_MODULE_2__.a)(this.parsedDateTime,this.localize)}}}customElements.define("ha-relative-time",HaRelativeTime)},219:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathfloor=Math.floor;__webpack_require__.d(__webpack_exports__,"a",function(){return secondsToDuration});const leftPad=num=>10>num?`0${num}`:num;function secondsToDuration(d){const h=_Mathfloor(d/3600),m=_Mathfloor(d%3600/60),s=_Mathfloor(d%3600%60);if(0<h){return`${h}:${leftPad(m)}:${leftPad(s)}`}if(0<m){return`${m}:${leftPad(s)}`}if(0<s){return""+s}return null}},220:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return MediaPlayerEntity});var _common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(193);class MediaPlayerEntity{constructor(hass,stateObj){this.hass=hass;this.stateObj=stateObj;this._attr=stateObj.attributes;this._feat=this._attr.supported_features}get isOff(){return"off"===this.stateObj.state}get isIdle(){return"idle"===this.stateObj.state}get isMuted(){return this._attr.is_volume_muted}get isPaused(){return"paused"===this.stateObj.state}get isPlaying(){return"playing"===this.stateObj.state}get isMusic(){return"music"===this._attr.media_content_type}get isTVShow(){return"tvshow"===this._attr.media_content_type}get hasMediaControl(){return-1!==["playing","paused","unknown"].indexOf(this.stateObj.state)}get volumeSliderValue(){return 100*this._attr.volume_level}get showProgress(){return(this.isPlaying||this.isPaused)&&"media_duration"in this.stateObj.attributes&&"media_position"in this.stateObj.attributes&&"media_position_updated_at"in this.stateObj.attributes}get currentProgress(){var progress=this._attr.media_position;if(this.isPlaying){progress+=(Date.now()-new Date(this._attr.media_position_updated_at).getTime())/1e3}return progress}get supportsPause(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1)}get supportsVolumeSet(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,4)}get supportsVolumeMute(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,8)}get supportsPreviousTrack(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16)}get supportsNextTrack(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,32)}get supportsTurnOn(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,128)}get supportsTurnOff(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,256)}get supportsPlayMedia(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,512)}get supportsVolumeButtons(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1024)}get supportsSelectSource(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,2048)}get supportsSelectSoundMode(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,65536)}get supportsPlay(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16384)}get primaryTitle(){return this._attr.media_title}get secondaryTitle(){if(this.isMusic){return this._attr.media_artist}if(this.isTVShow){var text=this._attr.media_series_title;if(this._attr.media_season){text+=" S"+this._attr.media_season;if(this._attr.media_episode){text+="E"+this._attr.media_episode}}return text}if(this._attr.app_name){return this._attr.app_name}return""}get source(){return this._attr.source}get sourceList(){return this._attr.source_list}get soundMode(){return this._attr.sound_mode}get soundModeList(){return this._attr.sound_mode_list}mediaPlayPause(){this.callService("media_play_pause")}nextTrack(){this.callService("media_next_track")}playbackControl(){this.callService("media_play_pause")}previousTrack(){this.callService("media_previous_track")}setVolume(volume){this.callService("volume_set",{volume_level:volume})}togglePower(){if(this.isOff){this.turnOn()}else{this.turnOff()}}turnOff(){this.callService("turn_off")}turnOn(){this.callService("turn_on")}volumeDown(){this.callService("volume_down")}volumeMute(mute){if(!this.supportsVolumeMute){throw new Error("Muting volume not supported")}this.callService("volume_mute",{is_volume_muted:mute})}volumeUp(){this.callService("volume_up")}selectSource(source){this.callService("select_source",{source})}selectSoundMode(soundMode){this.callService("select_sound_mode",{sound_mode:soundMode})}callService(service,data={}){data.entity_id=this.stateObj.entity_id;this.hass.callService("media_player",service,data)}}},221:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return attributeClassNames});function attributeClassNames(stateObj,attributes){if(!stateObj){return""}return attributes.map(attribute=>attribute in stateObj.attributes?"has-"+attribute:"").filter(attr=>""!==attr).join(" ")}},225:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathmax=Math.max,paper_spinner=__webpack_require__(111),html_tag=__webpack_require__(1),polymer_element=__webpack_require__(10),debounce=__webpack_require__(14),iron_resizable_behavior=__webpack_require__(84),paper_icon_button=__webpack_require__(99),utils_async=__webpack_require__(8),legacy_class=__webpack_require__(62),format_time=__webpack_require__(188);let scriptsLoaded=null;class ha_chart_base_HaChartBase extends Object(legacy_class.b)([iron_resizable_behavior.a],polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
        }
        .chartHeader {
          padding: 6px 0 0 0;
          width: 100%;
          display: flex;
          flex-direction: row;
        }
        .chartHeader > div {
          vertical-align: top;
          padding: 0 8px;
        }
        .chartHeader > div.chartTitle {
          padding-top: 8px;
          flex: 0 0 0;
          max-width: 30%;
        }
        .chartHeader > div.chartLegend {
          flex: 1 1;
          min-width: 70%;
        }
        :root {
          user-select: none;
          -moz-user-select: none;
          -webkit-user-select: none;
          -ms-user-select: none;
        }
        .chartTooltip {
          font-size: 90%;
          opacity: 1;
          position: absolute;
          background: rgba(80, 80, 80, 0.9);
          color: white;
          border-radius: 3px;
          pointer-events: none;
          transform: translate(-50%, 12px);
          z-index: 1000;
          width: 200px;
          transition: opacity 0.15s ease-in-out;
        }
        .chartLegend ul,
        .chartTooltip ul {
          display: inline-block;
          padding: 0 0px;
          margin: 5px 0 0 0;
          width: 100%;
        }
        .chartTooltip li {
          display: block;
          white-space: pre-line;
        }
        .chartTooltip .title {
          text-align: center;
          font-weight: 500;
        }
        .chartLegend li {
          display: inline-block;
          padding: 0 6px;
          max-width: 49%;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          box-sizing: border-box;
        }
        .chartLegend li:nth-child(odd):last-of-type {
          /* Make last item take full width if it is odd-numbered. */
          max-width: 100%;
        }
        .chartLegend li[data-hidden] {
          text-decoration: line-through;
        }
        .chartLegend em,
        .chartTooltip em {
          border-radius: 5px;
          display: inline-block;
          height: 10px;
          margin-right: 4px;
          width: 10px;
        }
        paper-icon-button {
          color: var(--secondary-text-color);
        }
      </style>
      <template is="dom-if" if="[[unit]]">
        <div class="chartHeader">
          <div class="chartTitle">[[unit]]</div>
          <div class="chartLegend">
            <ul>
              <template is="dom-repeat" items="[[metas]]">
                <li on-click="_legendClick" data-hidden$="[[item.hidden]]">
                  <em style$="background-color:[[item.bgColor]]"></em>
                  [[item.label]]
                </li>
              </template>
            </ul>
          </div>
        </div>
      </template>
      <div id="chartTarget" style="height:40px; width:100%">
        <canvas id="chartCanvas"></canvas>
        <div
          class$="chartTooltip [[tooltip.yAlign]]"
          style$="opacity:[[tooltip.opacity]]; top:[[tooltip.top]]; left:[[tooltip.left]]; padding:[[tooltip.yPadding]]px [[tooltip.xPadding]]px"
        >
          <div class="title">[[tooltip.title]]</div>
          <div>
            <ul>
              <template is="dom-repeat" items="[[tooltip.lines]]">
                <li>
                  <em style$="background-color:[[item.bgColor]]"></em
                  >[[item.text]]
                </li>
              </template>
            </ul>
          </div>
        </div>
      </div>
    `}get chart(){return this._chart}static get properties(){return{data:Object,identifier:String,rendered:{type:Boolean,notify:!0,value:!1,readOnly:!0},metas:{type:Array,value:()=>[]},tooltip:{type:Object,value:()=>({opacity:"0",left:"0",top:"0",xPadding:"5",yPadding:"3"})},unit:Object}}static get observers(){return["onPropsChange(data)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.onPropsChange();this._resizeListener=()=>{this._debouncer=debounce.a.debounce(this._debouncer,utils_async.d.after(10),()=>{if(this._isAttached){this.resizeChart()}})};if("function"===typeof ResizeObserver){this.resizeObserver=new ResizeObserver(entries=>{entries.forEach(()=>{this._resizeListener()})});this.resizeObserver.observe(this.$.chartTarget)}else{this.addEventListener("iron-resize",this._resizeListener)}if(null===scriptsLoaded){scriptsLoaded=Promise.all([__webpack_require__.e(95),__webpack_require__.e(69)]).then(__webpack_require__.bind(null,735))}scriptsLoaded.then(ChartModule=>{this.ChartClass=ChartModule.default;this.onPropsChange()})}disconnectedCallback(){super.disconnectedCallback();this._isAttached=!1;if(this.resizeObserver){this.resizeObserver.unobserve(this.$.chartTarget)}this.removeEventListener("iron-resize",this._resizeListener);if(this._resizeTimer!==void 0){clearInterval(this._resizeTimer);this._resizeTimer=void 0}}onPropsChange(){if(!this._isAttached||!this.ChartClass||!this.data){return}this.drawChart()}_customTooltips(tooltip){if(0===tooltip.opacity){this.set(["tooltip","opacity"],0);return}if(tooltip.yAlign){this.set(["tooltip","yAlign"],tooltip.yAlign)}else{this.set(["tooltip","yAlign"],"no-transform")}const title=tooltip.title?tooltip.title[0]||"":"";this.set(["tooltip","title"],title);const bodyLines=tooltip.body.map(n=>n.lines);if(tooltip.body){this.set(["tooltip","lines"],bodyLines.map((body,i)=>{const colors=tooltip.labelColors[i];return{color:colors.borderColor,bgColor:colors.backgroundColor,text:body.join("\n")}}))}const parentWidth=this.$.chartTarget.clientWidth;let positionX=tooltip.caretX;const positionY=this._chart.canvas.offsetTop+tooltip.caretY;if(tooltip.caretX+100>parentWidth){positionX=parentWidth-100}else if(100>tooltip.caretX){positionX=100}positionX+=this._chart.canvas.offsetLeft;this.tooltip=Object.assign({},this.tooltip,{opacity:1,left:`${positionX}px`,top:`${positionY}px`})}_legendClick(event){event=event||window.event;event.stopPropagation();let target=event.target||event.srcElement;while("LI"!==target.nodeName){target=target.parentElement}const index=event.model.itemsIndex,meta=this._chart.getDatasetMeta(index);meta.hidden=null===meta.hidden?!this._chart.data.datasets[index].hidden:null;this.set(["metas",index,"hidden"],this._chart.isDatasetVisible(index)?null:"hidden");this._chart.update()}_drawLegend(){const chart=this._chart,preserveVisibility=this._oldIdentifier&&this.identifier===this._oldIdentifier;this._oldIdentifier=this.identifier;this.set("metas",this._chart.data.datasets.map((x,i)=>({label:x.label,color:x.color,bgColor:x.backgroundColor,hidden:preserveVisibility&&i<this.metas.length?this.metas[i].hidden:!chart.isDatasetVisible(i)})));let updateNeeded=!1;if(preserveVisibility){for(let i=0;i<this.metas.length;i++){const meta=chart.getDatasetMeta(i);if(!!meta.hidden!==!!this.metas[i].hidden)updateNeeded=!0;meta.hidden=this.metas[i].hidden?!0:null}}if(updateNeeded){chart.update()}this.unit=this.data.unit}_formatTickValue(value,index,values){if(0===values.length){return value}const date=new Date(values[index].value);return Object(format_time.a)(date)}drawChart(){const data=this.data.data,ctx=this.$.chartCanvas;if((!data.datasets||!data.datasets.length)&&!this._chart){return}if("timeline"!==this.data.type&&0<data.datasets.length){const cnt=data.datasets.length,colors=this.constructor.getColorList(cnt);for(let loopI=0;loopI<cnt;loopI++){data.datasets[loopI].borderColor=colors[loopI].rgbString();data.datasets[loopI].backgroundColor=colors[loopI].alpha(.6).rgbaString()}}if(this._chart){this._customTooltips({opacity:0});this._chart.data=data;this._chart.update({duration:0});if(this.isTimeline){this._chart.options.scales.yAxes[0].gridLines.display=1<data.length}else if(!0===this.data.legend){this._drawLegend()}this.resizeChart()}else{if(!data.datasets){return}this._customTooltips({opacity:0});let options={responsive:!0,maintainAspectRatio:!1,animation:{duration:0},hover:{animationDuration:0},responsiveAnimationDuration:0,tooltips:{enabled:!1,custom:this._customTooltips.bind(this)},legend:{display:!1},line:{spanGaps:!0},elements:{font:"12px 'Roboto', 'sans-serif'"},ticks:{fontFamily:"'Roboto', 'sans-serif'"}};options=Chart.helpers.merge(options,this.data.options);options.scales.xAxes[0].ticks.callback=this._formatTickValue;if("timeline"===this.data.type){this.set("isTimeline",!0);if(this.data.colors!==void 0){this._colorFunc=this.constructor.getColorGenerator(this.data.colors.staticColors,this.data.colors.staticColorIndex)}if(this._colorFunc!==void 0){options.elements.colorFunction=this._colorFunc}if(1===data.datasets.length){if(options.scales.yAxes[0].ticks){options.scales.yAxes[0].ticks.display=!1}else{options.scales.yAxes[0].ticks={display:!1}}if(options.scales.yAxes[0].gridLines){options.scales.yAxes[0].gridLines.display=!1}else{options.scales.yAxes[0].gridLines={display:!1}}}this.$.chartTarget.style.height="50px"}else{this.$.chartTarget.style.height="160px"}const chartData={type:this.data.type,data:this.data.data,options:options,plugins:[{afterRender:()=>this._setRendered(!0)}]};this._chart=new this.ChartClass(ctx,chartData);if(!0!==this.isTimeline&&!0===this.data.legend){this._drawLegend()}this.resizeChart()}}resizeChart(){if(!this._chart)return;if(this._resizeTimer===void 0){this._resizeTimer=setInterval(this.resizeChart.bind(this),10);return}clearInterval(this._resizeTimer);this._resizeTimer=void 0;this._resizeChart()}_resizeChart(){const chartTarget=this.$.chartTarget,options=this.data,data=options.data;if(0===data.datasets.length){return}if(!this.isTimeline){this._chart.resize();return}const areaTop=this._chart.chartArea.top,areaBot=this._chart.chartArea.bottom,height1=this._chart.canvas.clientHeight;if(0<areaBot){this._axisHeight=height1-areaBot+areaTop}if(!this._axisHeight){chartTarget.style.height="50px";this._chart.resize();this.resizeChart();return}if(this._axisHeight){const cnt=data.datasets.length,targetHeight=30*cnt+this._axisHeight+"px";if(chartTarget.style.height!==targetHeight){chartTarget.style.height=targetHeight}this._chart.resize()}}static getColorList(count){let processL=!1;if(10<count){processL=!0;count=Math.ceil(count/2)}const h1=360/count,result=[];for(let loopI=0;loopI<count;loopI++){result[loopI]=Color().hsl(h1*loopI,80,38);if(processL){result[loopI+count]=Color().hsl(h1*loopI,80,62)}}return result}static getColorGenerator(staticColors,startIndex){const palette=["ff0029","66a61e","377eb8","984ea3","00d2d5","ff7f00","af8d00","7f80cd","b3e900","c42e60","a65628","f781bf","8dd3c7","bebada","fb8072","80b1d3","fdb462","fccde5","bc80bd","ffed6f","c4eaff","cf8c00","1b9e77","d95f02","e7298a","e6ab02","a6761d","0097ff","00d067","f43600","4ba93b","5779bb","927acc","97ee3f","bf3947","9f5b00","f48758","8caed6","f2b94f","eff26e","e43872","d9b100","9d7a00","698cff","d9d9d9","00d27e","d06800","009f82","c49200","cbe8ff","fecddf","c27eb6","8cd2ce","c4b8d9","f883b0","a49100","f48800","27d0df","a04a9b"];function getColorIndex(idx){return Color("#"+palette[idx%palette.length])}const colorDict={};let colorIndex=0;if(0<startIndex)colorIndex=startIndex;if(staticColors){Object.keys(staticColors).forEach(c=>{const c1=staticColors[c];if(isFinite(c1)){colorDict[c.toLowerCase()]=getColorIndex(c1)}else{colorDict[c.toLowerCase()]=Color(staticColors[c])}})}function getColor(__,data){let ret;const name=data[3];if(null===name)return Color().hsl(0,40,38);if(name===void 0)return Color().hsl(120,40,38);const name1=name.toLowerCase();if(ret===void 0){ret=colorDict[name1]}if(ret===void 0){ret=getColorIndex(colorIndex);colorIndex++;colorDict[name1]=ret}return ret}return getColor}}customElements.define("ha-chart-base",ha_chart_base_HaChartBase);var localize_mixin=__webpack_require__(71),format_date_time=__webpack_require__(173);class state_history_chart_line_StateHistoryChartLine extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          overflow: hidden;
          height: 0;
          transition: height 0.3s ease-in-out;
        }
      </style>
      <ha-chart-base
        id="chart"
        data="[[chartData]]"
        identifier="[[identifier]]"
        rendered="{{rendered}}"
      ></ha-chart-base>
    `}static get properties(){return{chartData:Object,data:Object,names:Object,unit:String,identifier:String,isSingleDevice:{type:Boolean,value:!1},endTime:Object,rendered:{type:Boolean,value:!1,observer:"_onRenderedChanged"}}}static get observers(){return["dataChanged(data, endTime, isSingleDevice)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.drawChart()}dataChanged(){this.drawChart()}_onRenderedChanged(rendered){if(rendered)this.animateHeight()}animateHeight(){requestAnimationFrame(()=>requestAnimationFrame(()=>{this.style.height=this.$.chart.scrollHeight+"px"}))}drawChart(){const unit=this.unit,deviceStates=this.data,datasets=[];let endTime;if(!this._isAttached){return}if(0===deviceStates.length){return}function safeParseFloat(value){const parsed=parseFloat(value);return isFinite(parsed)?parsed:null}endTime=this.endTime||new Date(_Mathmax.apply(null,deviceStates.map(devSts=>new Date(devSts.states[devSts.states.length-1].last_changed))));if(endTime>new Date){endTime=new Date}const names=this.names||{};deviceStates.forEach(states=>{const domain=states.domain,name=names[states.entity_id]||states.name;let prevValues;const data=[];function pushData(timestamp,datavalues){if(!datavalues)return;if(timestamp>endTime){return}data.forEach((d,i)=>{d.data.push({x:timestamp,y:datavalues[i]})});prevValues=datavalues}function addColumn(nameY,step,fill){let dataFill=!1,dataStep=!1;if(fill){dataFill="origin"}if(step){dataStep="before"}data.push({label:nameY,fill:dataFill,steppedLine:dataStep,pointRadius:0,data:[],unitText:unit})}if("thermostat"===domain||"climate"===domain||"water_heater"===domain){const hasTargetRange=states.states.some(state=>state.attributes&&state.attributes.target_temp_high!==state.attributes.target_temp_low),hasHeat=states.states.some(state=>"heat"===state.state),hasCool=states.states.some(state=>"cool"===state.state);addColumn(name+" current temperature",!0);if(hasHeat){addColumn(name+" heating",!0,!0)}if(hasCool){addColumn(name+" cooling",!0,!0)}if(hasTargetRange){addColumn(name+" target temperature high",!0);addColumn(name+" target temperature low",!0)}else{addColumn(name+" target temperature",!0)}states.states.forEach(state=>{if(!state.attributes)return;const curTemp=safeParseFloat(state.attributes.current_temperature),series=[curTemp];if(hasHeat){series.push("heat"===state.state?curTemp:null)}if(hasCool){series.push("cool"===state.state?curTemp:null)}if(hasTargetRange){const targetHigh=safeParseFloat(state.attributes.target_temp_high),targetLow=safeParseFloat(state.attributes.target_temp_low);series.push(targetHigh,targetLow);pushData(new Date(state.last_changed),series)}else{const target=safeParseFloat(state.attributes.temperature);series.push(target);pushData(new Date(state.last_changed),series)}})}else{addColumn(name,"sensor"===domain);let lastValue=null,lastDate=null,lastNullDate=null;states.states.forEach(state=>{const value=safeParseFloat(state.state),date=new Date(state.last_changed);if(null!==value&&null!==lastNullDate){const dateTime=date.getTime(),lastNullDateTime=lastNullDate.getTime(),lastDateTime=lastDate.getTime(),tmpValue=(value-lastValue)*((lastNullDateTime-lastDateTime)/(dateTime-lastDateTime))+lastValue;pushData(lastNullDate,[tmpValue]);pushData(new Date(lastNullDateTime+1),[null]);pushData(date,[value]);lastDate=date;lastValue=value;lastNullDate=null}else if(null!==value&&null===lastNullDate){pushData(date,[value]);lastDate=date;lastValue=value}else if(null===value&&null===lastNullDate&&null!==lastValue){lastNullDate=date}})}pushData(endTime,prevValues,!1);Array.prototype.push.apply(datasets,data)});const chartOptions={type:"line",unit:unit,legend:!this.isSingleDevice,options:{scales:{xAxes:[{type:"time",ticks:{major:{fontStyle:"bold"}}}],yAxes:[{ticks:{maxTicksLimit:7}}]},tooltips:{mode:"neareach",callbacks:{title:(items,data)=>{const item=items[0],date=data.datasets[item.datasetIndex].data[item.index].x;return Object(format_date_time.a)(date,this.hass.language)}}},hover:{mode:"neareach"},layout:{padding:{top:5}},elements:{line:{tension:.1,pointRadius:0,borderWidth:1.5},point:{hitRadius:5}},plugins:{filler:{propagate:!0}}},data:{labels:[],datasets:datasets}};this.chartData=chartOptions}}customElements.define("state-history-chart-line",state_history_chart_line_StateHistoryChartLine);class state_history_chart_timeline_StateHistoryChartTimeline extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          opacity: 0;
          transition: opacity 0.3s ease-in-out;
        }
        :host([rendered]) {
          opacity: 1;
        }
      </style>
      <ha-chart-base
        data="[[chartData]]"
        rendered="{{rendered}}"
      ></ha-chart-base>
    `}static get properties(){return{hass:{type:Object},chartData:Object,data:{type:Object,observer:"dataChanged"},names:Object,noSingle:Boolean,endTime:Date,rendered:{type:Boolean,value:!1,reflectToAttribute:!0}}}static get observers(){return["dataChanged(data, endTime, localize, language)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.drawChart()}dataChanged(){this.drawChart()}drawChart(){let stateHistory=this.data;if(!this._isAttached){return}if(!stateHistory){stateHistory=[]}const startTime=new Date(stateHistory.reduce((minTime,stateInfo)=>Math.min(minTime,new Date(stateInfo.data[0].last_changed)),new Date));let endTime=this.endTime||new Date(stateHistory.reduce((maxTime,stateInfo)=>_Mathmax(maxTime,new Date(stateInfo.data[stateInfo.data.length-1].last_changed)),startTime));if(endTime>new Date){endTime=new Date}const labels=[],datasets=[],names=this.names||{};stateHistory.forEach(stateInfo=>{let newLastChanged,prevState=null,locState=null,prevLastChanged=startTime;const entityDisplay=names[stateInfo.entity_id]||stateInfo.name,dataRow=[];stateInfo.data.forEach(state=>{let newState=state.state;const timeStamp=new Date(state.last_changed);if(newState===void 0||""===newState){newState=null}if(timeStamp>endTime){return}if(null!==prevState&&newState!==prevState){newLastChanged=new Date(state.last_changed);dataRow.push([prevLastChanged,newLastChanged,locState,prevState]);prevState=newState;locState=state.state_localize;prevLastChanged=newLastChanged}else if(null===prevState){prevState=newState;locState=state.state_localize;prevLastChanged=new Date(state.last_changed)}});if(null!==prevState){dataRow.push([prevLastChanged,endTime,locState,prevState])}datasets.push({data:dataRow});labels.push(entityDisplay)});this.chartData={type:"timeline",options:{tooltips:{callbacks:{label:(item,data)=>{const values=data.datasets[item.datasetIndex].data[item.index],start=Object(format_date_time.a)(values[0],this.hass.language),end=Object(format_date_time.a)(values[1],this.hass.language),state=values[2];return[state,start,end]}}},scales:{xAxes:[{ticks:{major:{fontStyle:"bold"}}}],yAxes:[{afterSetDimensions:yaxe=>{yaxe.maxWidth=.18*yaxe.chart.width}}]}},data:{labels:labels,datasets:datasets},colors:{staticColors:{on:1,off:0,unavailable:"#a0a0a0",unknown:"#606060",idle:2},staticColorIndex:3}}}}customElements.define("state-history-chart-timeline",state_history_chart_timeline_StateHistoryChartTimeline);class state_history_charts_StateHistoryCharts extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          /* height of single timeline chart = 58px */
          min-height: 58px;
        }
        .info {
          text-align: center;
          line-height: 58px;
          color: var(--secondary-text-color);
        }
      </style>
      <template
        is="dom-if"
        class="info"
        if="[[_computeIsLoading(isLoadingData)]]"
      >
        <div class="info">
          [[localize('ui.components.history_charts.loading_history')]]
        </div>
      </template>

      <template
        is="dom-if"
        class="info"
        if="[[_computeIsEmpty(isLoadingData, historyData)]]"
      >
        <div class="info">
          [[localize('ui.components.history_charts.no_history_found')]]
        </div>
      </template>

      <template is="dom-if" if="[[historyData.timeline.length]]">
        <state-history-chart-timeline
          hass="[[hass]]"
          data="[[historyData.timeline]]"
          end-time="[[_computeEndTime(endTime, upToNow, historyData)]]"
          no-single="[[noSingle]]"
          names="[[names]]"
        ></state-history-chart-timeline>
      </template>

      <template is="dom-repeat" items="[[historyData.line]]">
        <state-history-chart-line
          hass="[[hass]]"
          unit="[[item.unit]]"
          data="[[item.data]]"
          identifier="[[item.identifier]]"
          is-single-device="[[_computeIsSingleLineChart(item.data, noSingle)]]"
          end-time="[[_computeEndTime(endTime, upToNow, historyData)]]"
          names="[[names]]"
        ></state-history-chart-line>
      </template>
    `}static get properties(){return{hass:Object,historyData:{type:Object,value:null},names:Object,isLoadingData:Boolean,endTime:{type:Object},upToNow:Boolean,noSingle:Boolean}}_computeIsSingleLineChart(data,noSingle){return!noSingle&&data&&1===data.length}_computeIsEmpty(isLoadingData,historyData){const historyDataEmpty=!historyData||!historyData.timeline||!historyData.line||0===historyData.timeline.length&&0===historyData.line.length;return!isLoadingData&&historyDataEmpty}_computeIsLoading(isLoading){return isLoading&&!this.historyData}_computeEndTime(endTime,upToNow){return upToNow?new Date:endTime}}customElements.define("state-history-charts",state_history_charts_StateHistoryCharts)},226:function(module,__webpack_exports__,__webpack_require__){"use strict";var utils_async=__webpack_require__(8),debounce=__webpack_require__(14),polymer_element=__webpack_require__(10),localize_mixin=__webpack_require__(71),data_history=__webpack_require__(203);const RECENT_CACHE={},stateHistoryCache={},getRecent=(hass,entityId,startTime,endTime,localize,language)=>{const cacheKey=entityId,cache=RECENT_CACHE[cacheKey];if(cache&&Date.now()-cache.created<6e4&&cache.language===language){return cache.data}const prom=Object(data_history.c)(hass,entityId,startTime,endTime).then(stateHistory=>Object(data_history.a)(hass,stateHistory,localize,language),err=>{delete RECENT_CACHE[entityId];throw err});RECENT_CACHE[cacheKey]={created:Date.now(),language,data:prom};return prom};function getEmptyCache(language,startTime,endTime){return{prom:Promise.resolve({line:[],timeline:[]}),language,startTime,endTime,data:{line:[],timeline:[]}}}const getRecentWithCache=(hass,entityId,cacheConfig,localize,language)=>{const cacheKey=cacheConfig.cacheKey,endTime=new Date,startTime=new Date(endTime);startTime.setHours(startTime.getHours()-cacheConfig.hoursToShow);let toFetchStartTime=startTime,appendingToCache=!1,cache=stateHistoryCache[cacheKey];if(cache&&toFetchStartTime>=cache.startTime&&toFetchStartTime<=cache.endTime&&cache.language===language){toFetchStartTime=cache.endTime;appendingToCache=!0;if(endTime<=cache.endTime){return cache.prom}}else{cache=stateHistoryCache[cacheKey]=getEmptyCache(language,startTime,endTime)}const curCacheProm=cache.prom,genProm=async()=>{let fetchedHistory;try{const results=await Promise.all([curCacheProm,Object(data_history.c)(hass,entityId,toFetchStartTime,endTime,appendingToCache)]);fetchedHistory=results[1]}catch(err){delete stateHistoryCache[cacheKey];throw err}const stateHistory=Object(data_history.a)(hass,fetchedHistory,localize,language);if(appendingToCache){mergeLine(stateHistory.line,cache.data.line);mergeTimeline(stateHistory.timeline,cache.data.timeline);pruneStartTime(startTime,cache.data)}else{cache.data=stateHistory}return cache.data};cache.prom=genProm();cache.startTime=startTime;cache.endTime=endTime;return cache.prom},mergeLine=(historyLines,cacheLines)=>{historyLines.forEach(line=>{const unit=line.unit,oldLine=cacheLines.find(cacheLine=>cacheLine.unit===unit);if(oldLine){line.data.forEach(entity=>{const oldEntity=oldLine.data.find(cacheEntity=>entity.entity_id===cacheEntity.entity_id);if(oldEntity){oldEntity.states=oldEntity.states.concat(entity.states)}else{oldLine.data.push(entity)}})}else{cacheLines.push(line)}})},mergeTimeline=(historyTimelines,cacheTimelines)=>{historyTimelines.forEach(timeline=>{const oldTimeline=cacheTimelines.find(cacheTimeline=>cacheTimeline.entity_id===timeline.entity_id);if(oldTimeline){oldTimeline.data=oldTimeline.data.concat(timeline.data)}else{cacheTimelines.push(timeline)}})},pruneArray=(originalStartTime,arr)=>{if(0===arr.length){return arr}const changedAfterStartTime=arr.findIndex(state=>new Date(state.last_changed)>originalStartTime);if(0===changedAfterStartTime){return arr}const updateIndex=-1===changedAfterStartTime?arr.length-1:changedAfterStartTime-1;arr[updateIndex].last_changed=originalStartTime;return arr.slice(updateIndex)},pruneStartTime=(originalStartTime,cacheData)=>{cacheData.line.forEach(line=>{line.data.forEach(entity=>{entity.states=pruneArray(originalStartTime,entity.states)})});cacheData.timeline.forEach(timeline=>{timeline.data=pruneArray(originalStartTime,timeline.data)})};class ha_state_history_data_HaStateHistoryData extends Object(localize_mixin.a)(polymer_element.a){static get properties(){return{hass:{type:Object,observer:"hassChanged"},filterType:String,cacheConfig:Object,startTime:Date,endTime:Date,entityId:String,isLoading:{type:Boolean,value:!0,readOnly:!0,notify:!0},data:{type:Object,value:null,readOnly:!0,notify:!0}}}static get observers(){return["filterChangedDebouncer(filterType, entityId, startTime, endTime, cacheConfig, localize)"]}connectedCallback(){super.connectedCallback();this.filterChangedDebouncer(this.filterType,this.entityId,this.startTime,this.endTime,this.cacheConfig,this.localize)}disconnectedCallback(){if(this._refreshTimeoutId){window.clearInterval(this._refreshTimeoutId);this._refreshTimeoutId=null}super.disconnectedCallback()}hassChanged(newHass,oldHass){if(!oldHass&&!this._madeFirstCall){this.filterChangedDebouncer(this.filterType,this.entityId,this.startTime,this.endTime,this.cacheConfig,this.localize)}}filterChangedDebouncer(...args){this._debounceFilterChanged=debounce.a.debounce(this._debounceFilterChanged,utils_async.d.after(0),()=>{this.filterChanged(...args)})}filterChanged(filterType,entityId,startTime,endTime,cacheConfig,localize){if(!this.hass){return}if(cacheConfig&&!cacheConfig.cacheKey){return}if(!localize){return}this._madeFirstCall=!0;const language=this.hass.language;let data;if("date"===filterType){if(!startTime||!endTime)return;data=Object(data_history.b)(this.hass,startTime,endTime).then(dateHistory=>Object(data_history.a)(this.hass,dateHistory,localize,language))}else if("recent-entity"===filterType){if(!entityId)return;if(cacheConfig){data=this.getRecentWithCacheRefresh(entityId,cacheConfig,localize,language)}else{data=getRecent(this.hass,entityId,startTime,endTime,localize,language)}}else{return}this._setIsLoading(!0);data.then(stateHistory=>{this._setData(stateHistory);this._setIsLoading(!1)})}getRecentWithCacheRefresh(entityId,cacheConfig,localize,language){if(this._refreshTimeoutId){window.clearInterval(this._refreshTimeoutId);this._refreshTimeoutId=null}if(cacheConfig.refresh){this._refreshTimeoutId=window.setInterval(()=>{getRecentWithCache(this.hass,entityId,cacheConfig,localize,language).then(stateHistory=>{this._setData(Object.assign({},stateHistory))})},1e3*cacheConfig.refresh)}return getRecentWithCache(this.hass,entityId,cacheConfig,localize,language)}}customElements.define("ha-state-history-data",ha_state_history_data_HaStateHistoryData)},227:function(module,__webpack_exports__,__webpack_require__){"use strict";function durationToSeconds(duration){const parts=duration.split(":").map(Number);return 3600*parts[0]+60*parts[1]+parts[2]}__webpack_require__.d(__webpack_exports__,"a",function(){return timerTimeRemaining});function timerTimeRemaining(stateObj){let timeRemaining=durationToSeconds(stateObj.attributes.remaining);if("active"===stateObj.state){const now=new Date().getTime(),madeActive=new Date(stateObj.last_changed).getTime();timeRemaining=Math.max(timeRemaining-(now-madeActive)/1e3,0)}return timeRemaining}},231:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathfloor2=Math.floor;__webpack_require__.d(__webpack_exports__,"a",function(){return relativeTime});const tests=[60,60,24,7],langKey=["second","minute","hour","day"];function relativeTime(dateObj,localize,options={}){const compareTime=options.compareTime||new Date;let delta=(compareTime.getTime()-dateObj.getTime())/1e3;const tense=0<=delta?"past":"future";delta=Math.abs(delta);let timeDesc;for(let i=0;i<tests.length;i++){if(delta<tests[i]){delta=_Mathfloor2(delta);timeDesc=localize(`ui.components.relative_time.duration.${langKey[i]}`,"count",delta);break}delta/=tests[i]}if(timeDesc===void 0){delta=_Mathfloor2(delta);timeDesc=localize("ui.components.relative_time.duration.week","count",delta)}return!1===options.includeTense?timeDesc:localize(`ui.components.relative_time.${tense}`,"time",timeDesc)}},234:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_classes__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(79),_polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(99),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(10),_util_cover_model__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(198);class HaCoverTiltControls extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__.a`
      <style include="iron-flex"></style>
      <style>
        :host {
          white-space: nowrap;
        }
        [invisible] {
          visibility: hidden !important;
        }
      </style>
      <paper-icon-button
        icon="hass:arrow-top-right"
        on-click="onOpenTiltTap"
        title="Open tilt"
        invisible$="[[!entityObj.supportsOpenTilt]]"
        disabled="[[computeOpenDisabled(stateObj, entityObj)]]"
      ></paper-icon-button>
      <paper-icon-button
        icon="hass:stop"
        on-click="onStopTiltTap"
        invisible$="[[!entityObj.supportsStopTilt]]"
        title="Stop tilt"
      ></paper-icon-button>
      <paper-icon-button
        icon="hass:arrow-bottom-left"
        on-click="onCloseTiltTap"
        title="Close tilt"
        invisible$="[[!entityObj.supportsCloseTilt]]"
        disabled="[[computeClosedDisabled(stateObj, entityObj)]]"
      ></paper-icon-button>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"}}}computeEntityObj(hass,stateObj){return new _util_cover_model__WEBPACK_IMPORTED_MODULE_4__.a(hass,stateObj)}computeOpenDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return entityObj.isFullyOpenTilt&&!assumedState}computeClosedDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return entityObj.isFullyClosedTilt&&!assumedState}onOpenTiltTap(ev){ev.stopPropagation();this.entityObj.openCoverTilt()}onCloseTiltTap(ev){ev.stopPropagation();this.entityObj.closeCoverTilt()}onStopTiltTap(ev){ev.stopPropagation();this.entityObj.stopCoverTilt()}}customElements.define("ha-cover-tilt-controls",HaCoverTiltControls)},245:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(71);class HaClimateState extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_2__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        :host {
          display: flex;
          flex-direction: column;
          justify-content: center;
          white-space: nowrap;
        }

        .target {
          color: var(--primary-text-color);
        }

        .current {
          color: var(--secondary-text-color);
        }

        .state-label {
          font-weight: bold;
          text-transform: capitalize;
        }
      </style>

      <div class="target">
        <template is="dom-if" if="[[_hasKnownState(stateObj.state)]]">
          <span class="state-label"> [[_localizeState(stateObj.state)]] </span>
        </template>
        [[computeTarget(hass, stateObj)]]
      </div>

      <template is="dom-if" if="[[currentStatus]]">
        <div class="current">
          [[localize('ui.card.climate.currently')]]: [[currentStatus]]
        </div>
      </template>
    `}static get properties(){return{hass:Object,stateObj:Object,currentStatus:{type:String,computed:"computeCurrentStatus(hass, stateObj)"}}}computeCurrentStatus(hass,stateObj){if(!hass||!stateObj)return null;if(null!=stateObj.attributes.current_temperature){return`${stateObj.attributes.current_temperature} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.current_humidity){return`${stateObj.attributes.current_humidity} %`}return null}computeTarget(hass,stateObj){if(!hass||!stateObj)return null;if(null!=stateObj.attributes.target_temp_low&&null!=stateObj.attributes.target_temp_high){return`${stateObj.attributes.target_temp_low} - ${stateObj.attributes.target_temp_high} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.temperature){return`${stateObj.attributes.temperature} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.target_humidity_low&&null!=stateObj.attributes.target_humidity_high){return`${stateObj.attributes.target_humidity_low} - ${stateObj.attributes.target_humidity_high} %`}if(null!=stateObj.attributes.humidity){return`${stateObj.attributes.humidity} %`}return""}_hasKnownState(state){return"unknown"!==state}_localizeState(state){return this.localize(`state.climate.${state}`)||state}}customElements.define("ha-climate-state",HaClimateState)},246:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(99),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(10),_util_cover_model__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(198);class HaCoverControls extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style>
        .state {
          white-space: nowrap;
        }
        [invisible] {
          visibility: hidden !important;
        }
      </style>

      <div class="state">
        <paper-icon-button
          icon="hass:arrow-up"
          on-click="onOpenTap"
          invisible$="[[!entityObj.supportsOpen]]"
          disabled="[[computeOpenDisabled(stateObj, entityObj)]]"
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:stop"
          on-click="onStopTap"
          invisible$="[[!entityObj.supportsStop]]"
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:arrow-down"
          on-click="onCloseTap"
          invisible$="[[!entityObj.supportsClose]]"
          disabled="[[computeClosedDisabled(stateObj, entityObj)]]"
        ></paper-icon-button>
      </div>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"}}}computeEntityObj(hass,stateObj){return new _util_cover_model__WEBPACK_IMPORTED_MODULE_3__.a(hass,stateObj)}computeOpenDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return(entityObj.isFullyOpen||entityObj.isOpening)&&!assumedState}computeClosedDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return(entityObj.isFullyClosed||entityObj.isClosing)&&!assumedState}onOpenTap(ev){ev.stopPropagation();this.entityObj.openCover()}onCloseTap(ev){ev.stopPropagation();this.entityObj.closeCover()}onStopTap(ev){ev.stopPropagation();this.entityObj.stopCover()}}customElements.define("ha-cover-controls",HaCoverControls)},247:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathround2=Math.round,_polymer_paper_slider__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(136);const PaperSliderClass=customElements.get("paper-slider");customElements.define("ha-slider",class extends PaperSliderClass{_calcStep(value){if(!this.step){return parseFloat(value)}const numSteps=_Mathround2((value-this.min)/this.step),stepStr=this.step.toString(),stepPointAt=stepStr.indexOf(".");if(-1!==stepPointAt){const precision=10**(stepStr.length-stepPointAt-1);return _Mathround2((numSteps*this.step+this.min)*precision)/precision}return numSteps*this.step+this.min}})},255:function(module,__webpack_exports__,__webpack_require__){"use strict";function canToggleDomain(hass,domain){const services=hass.services[domain];if(!services){return!1}if("lock"===domain){return"lock"in services}if("cover"===domain){return"open_cover"in services}return"turn_on"in services}var compute_state_domain=__webpack_require__(153),supports_feature=__webpack_require__(193);__webpack_require__.d(__webpack_exports__,"a",function(){return canToggleState});function canToggleState(hass,stateObj){const domain=Object(compute_state_domain.a)(stateObj);if("group"===domain){return"on"===stateObj.state||"off"===stateObj.state}if("climate"===domain){return Object(supports_feature.a)(stateObj,4096)}return canToggleDomain(hass,domain)}},266:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_element=__webpack_require__(10),iron_flex_layout_classes=__webpack_require__(79),html_tag=__webpack_require__(1),ha_relative_time=__webpack_require__(216),state_badge=__webpack_require__(161),compute_state_name=__webpack_require__(105),compute_rtl=__webpack_require__(112);class state_info_StateInfo extends polymer_element.a{static get template(){return html_tag.a`
      ${this.styleTemplate} ${this.stateBadgeTemplate} ${this.infoTemplate}
    `}static get styleTemplate(){return html_tag.a`
      <style>
        :host {
          @apply --paper-font-body1;
          min-width: 120px;
          white-space: nowrap;
        }

        state-badge {
          float: left;
        }

        :host([rtl]) state-badge {
          float: right;
        }

        .info {
          margin-left: 56px;
        }

        :host([rtl]) .info {
          margin-right: 56px;
          margin-left: 0;
          text-align: right;
        }

        .name {
          @apply --paper-font-common-nowrap;
          color: var(--primary-text-color);
          line-height: 40px;
        }

        .name[in-dialog],
        :host([secondary-line]) .name {
          line-height: 20px;
        }

        .time-ago,
        .extra-info,
        .extra-info > * {
          @apply --paper-font-common-nowrap;
          color: var(--secondary-text-color);
        }
      </style>
    `}static get stateBadgeTemplate(){return html_tag.a`
      <state-badge state-obj="[[stateObj]]"></state-badge>
    `}static get infoTemplate(){return html_tag.a`
      <div class="info">
        <div class="name" in-dialog$="[[inDialog]]">
          [[computeStateName(stateObj)]]
        </div>

        <template is="dom-if" if="[[inDialog]]">
          <div class="time-ago">
            <ha-relative-time
              hass="[[hass]]"
              datetime="[[stateObj.last_changed]]"
            ></ha-relative-time>
          </div>
        </template>
        <template is="dom-if" if="[[!inDialog]]">
          <div class="extra-info"><slot> </slot></div>
        </template>
      </div>
    `}static get properties(){return{detailed:{type:Boolean,value:!1},hass:Object,stateObj:Object,inDialog:Boolean,rtl:{type:Boolean,reflectToAttribute:!0,computed:"computeRTL(hass)"}}}computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}computeRTL(hass){return Object(compute_rtl.a)(hass)}}customElements.define("state-info",state_info_StateInfo);__webpack_require__(245);class state_card_climate_StateCardClimate extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          @apply --paper-font-body1;
          line-height: 1.5;
        }

        ha-climate-state {
          margin-left: 16px;
          text-align: right;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <ha-climate-state
          hass="[[hass]]"
          state-obj="[[stateObj]]"
        ></ha-climate-state>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}}customElements.define("state-card-climate",state_card_climate_StateCardClimate);var paper_button=__webpack_require__(72),localize_mixin=__webpack_require__(71);class state_card_configurator_StateCardConfigurator extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <paper-button hidden$="[[inDialog]]"
          >[[_localizeState(stateObj.state)]]</paper-button
        >
      </div>

      <!-- pre load the image so the dialog is rendered the proper size -->
      <template is="dom-if" if="[[stateObj.attributes.description_image]]">
        <img hidden="" src="[[stateObj.attributes.description_image]]" />
      </template>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}_localizeState(state){return this.localize(`state.configurator.${state}`)}}customElements.define("state-card-configurator",state_card_configurator_StateCardConfigurator);var ha_cover_controls=__webpack_require__(246),ha_cover_tilt_controls=__webpack_require__(234),cover_model=__webpack_require__(198);class state_card_cover_StateCardCover extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          line-height: 1.5;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <div class="horizontal layout">
          <ha-cover-controls
            hidden$="[[entityObj.isTiltOnly]]"
            hass="[[hass]]"
            state-obj="[[stateObj]]"
          ></ha-cover-controls>
          <ha-cover-tilt-controls
            hidden$="[[!entityObj.isTiltOnly]]"
            hass="[[hass]]"
            state-obj="[[stateObj]]"
          ></ha-cover-tilt-controls>
        </div>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"}}}computeEntityObj(hass,stateObj){var entity=new cover_model.a(hass,stateObj);return entity}}customElements.define("state-card-cover",state_card_cover_StateCardCover);var compute_state_display=__webpack_require__(190),attribute_class_names=__webpack_require__(221);class state_card_display_StateCardDisplay extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          @apply --layout-horizontal;
          @apply --layout-justified;
          @apply --layout-baseline;
        }

        :host([rtl]) {
          direction: rtl;
          text-align: right;
        }

        state-info {
          flex: 1 1 auto;
          min-width: 0;
        }
        .state {
          @apply --paper-font-body1;
          color: var(--primary-text-color);
          margin-left: 16px;
          text-align: right;
          max-width: 40%;
          flex: 0 0 auto;
        }
        :host([rtl]) .state {
          margin-right: 16px;
          margin-left: 0;
          text-align: left;
        }

        .state.has-unit_of_measurement {
          white-space: nowrap;
        }
      </style>

      ${this.stateInfoTemplate}
      <div class$="[[computeClassNames(stateObj)]]">
        [[computeStateDisplay(localize, stateObj, language)]]
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1},rtl:{type:Boolean,reflectToAttribute:!0,computed:"_computeRTL(hass)"}}}computeStateDisplay(localize,stateObj,language){return Object(compute_state_display.a)(localize,stateObj,language)}computeClassNames(stateObj){const classes=["state",Object(attribute_class_names.a)(stateObj,["unit_of_measurement"])];return classes.join(" ")}_computeRTL(hass){return Object(compute_rtl.a)(hass)}}customElements.define("state-card-display",state_card_display_StateCardDisplay);var iron_resizable_behavior=__webpack_require__(84),paper_input=__webpack_require__(78),legacy_class=__webpack_require__(62),ha_slider=__webpack_require__(247);class state_card_input_number_StateCardInputNumber extends Object(legacy_class.b)([iron_resizable_behavior.a],polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        ha-slider {
          margin-left: auto;
        }
        .state {
          @apply --paper-font-body1;
          color: var(--primary-text-color);

          text-align: right;
          line-height: 40px;
        }
        .sliderstate {
          min-width: 45px;
        }
        ha-slider[hidden] {
          display: none !important;
        }
        paper-input {
          text-align: right;
          margin-left: auto;
        }
      </style>

      <div class="horizontal justified layout" id="input_number_card">
        ${this.stateInfoTemplate}
        <ha-slider
          min="[[min]]"
          max="[[max]]"
          value="{{value}}"
          step="[[step]]"
          hidden="[[hiddenslider]]"
          pin=""
          on-change="selectedValueChanged"
          on-click="stopPropagation"
          id="slider"
          ignore-bar-touch=""
        >
        </ha-slider>
        <paper-input
          no-label-float=""
          auto-validate=""
          pattern="[0-9]+([\\.][0-9]+)?"
          step="[[step]]"
          min="[[min]]"
          max="[[max]]"
          value="{{value}}"
          type="number"
          on-change="selectedValueChanged"
          on-click="stopPropagation"
          hidden="[[hiddenbox]]"
        >
        </paper-input>
        <div class="state" hidden="[[hiddenbox]]">
          [[stateObj.attributes.unit_of_measurement]]
        </div>
        <div
          id="sliderstate"
          class="state sliderstate"
          hidden="[[hiddenslider]]"
        >
          [[value]] [[stateObj.attributes.unit_of_measurement]]
        </div>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}ready(){super.ready();if("function"===typeof ResizeObserver){const ro=new ResizeObserver(entries=>{entries.forEach(()=>{this.hiddenState()})});ro.observe(this.$.input_number_card)}else{this.addEventListener("iron-resize",this.hiddenState)}}static get properties(){return{hass:Object,hiddenbox:{type:Boolean,value:!0},hiddenslider:{type:Boolean,value:!0},inDialog:{type:Boolean,value:!1},stateObj:{type:Object,observer:"stateObjectChanged"},min:{type:Number,value:0},max:{type:Number,value:100},maxlength:{type:Number,value:3},step:Number,value:Number,mode:String}}hiddenState(){if("slider"!==this.mode)return;const sliderwidth=this.$.slider.offsetWidth;if(100>sliderwidth){this.$.sliderstate.hidden=!0}else if(145<=sliderwidth){this.$.sliderstate.hidden=!1}}stateObjectChanged(newVal){const prevMode=this.mode;this.setProperties({min:+newVal.attributes.min,max:+newVal.attributes.max,step:+newVal.attributes.step,value:+newVal.state,mode:newVal.attributes.mode+"",maxlength:(newVal.attributes.max+"").length,hiddenbox:"box"!==newVal.attributes.mode,hiddenslider:"slider"!==newVal.attributes.mode});if("slider"===this.mode&&"slider"!==prevMode){this.hiddenState()}}selectedValueChanged(){if(this.value===+this.stateObj.state){return}this.hass.callService("input_number","set_value",{value:this.value,entity_id:this.stateObj.entity_id})}stopPropagation(ev){ev.stopPropagation()}}customElements.define("state-card-input_number",state_card_input_number_StateCardInputNumber);var paper_dropdown_menu=__webpack_require__(129),paper_item=__webpack_require__(126),paper_listbox=__webpack_require__(128);class state_card_input_select_StateCardInputSelect extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
        }

        state-badge {
          float: left;
          margin-top: 10px;
        }

        paper-dropdown-menu {
          display: block;
          margin-left: 53px;
        }

        paper-item {
          cursor: pointer;
        }
      </style>

      ${this.stateBadgeTemplate}
      <paper-dropdown-menu
        on-click="stopPropagation"
        selected-item-label="{{selectedOption}}"
        label="[[_computeStateName(stateObj)]]"
      >
        <paper-listbox
          slot="dropdown-content"
          selected="[[computeSelected(stateObj)]]"
        >
          <template is="dom-repeat" items="[[stateObj.attributes.options]]">
            <paper-item>[[item]]</paper-item>
          </template>
        </paper-listbox>
      </paper-dropdown-menu>
    `}static get stateBadgeTemplate(){return html_tag.a`
      <state-badge state-obj="[[stateObj]]"></state-badge>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1},selectedOption:{type:String,observer:"selectedOptionChanged"}}}_computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}computeSelected(stateObj){return stateObj.attributes.options.indexOf(stateObj.state)}selectedOptionChanged(option){if(""===option||option===this.stateObj.state){return}this.hass.callService("input_select","select_option",{option:option,entity_id:this.stateObj.entity_id})}stopPropagation(ev){ev.stopPropagation()}}customElements.define("state-card-input_select",state_card_input_select_StateCardInputSelect);class state_card_input_text_StateCardInputText extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        paper-input {
          margin-left: 16px;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <paper-input
          no-label-float=""
          minlength="[[stateObj.attributes.min]]"
          maxlength="[[stateObj.attributes.max]]"
          value="{{value}}"
          auto-validate="[[stateObj.attributes.pattern]]"
          pattern="[[stateObj.attributes.pattern]]"
          type="[[stateObj.attributes.mode]]"
          on-change="selectedValueChanged"
          on-click="stopPropagation"
          placeholder="(empty value)"
        >
        </paper-input>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,inDialog:{type:Boolean,value:!1},stateObj:{type:Object,observer:"stateObjectChanged"},pattern:String,value:String}}stateObjectChanged(newVal){this.value=newVal.state}selectedValueChanged(){if(this.value===this.stateObj.state){return}this.hass.callService("input_text","set_value",{value:this.value,entity_id:this.stateObj.entity_id})}stopPropagation(ev){ev.stopPropagation()}}customElements.define("state-card-input_text",state_card_input_text_StateCardInputText);class state_card_lock_StateCardLock extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <paper-button
          on-click="_callService"
          data-service="unlock"
          hidden$="[[!isLocked]]"
          >[[localize('ui.card.lock.unlock')]]</paper-button
        >
        <paper-button
          on-click="_callService"
          data-service="lock"
          hidden$="[[isLocked]]"
          >[[localize('ui.card.lock.lock')]]</paper-button
        >
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"_stateObjChanged"},inDialog:{type:Boolean,value:!1},isLocked:Boolean}}_stateObjChanged(newVal){if(newVal){this.isLocked="locked"===newVal.state}}_callService(ev){ev.stopPropagation();const service=ev.target.dataset.service,data={entity_id:this.stateObj.entity_id};this.hass.callService("lock",service,data)}}customElements.define("state-card-lock",state_card_lock_StateCardLock);var hass_media_player_model=__webpack_require__(220);class state_card_media_player_StateCardMediaPlayer extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          line-height: 1.5;
        }

        .state {
          @apply --paper-font-common-nowrap;
          @apply --paper-font-body1;
          margin-left: 16px;
          text-align: right;
        }

        .main-text {
          @apply --paper-font-common-nowrap;
          color: var(--primary-text-color);
          text-transform: capitalize;
        }

        .main-text[take-height] {
          line-height: 40px;
        }

        .secondary-text {
          @apply --paper-font-common-nowrap;
          color: var(--secondary-text-color);
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <div class="state">
          <div class="main-text" take-height$="[[!playerObj.secondaryTitle]]">
            [[computePrimaryText(localize, playerObj)]]
          </div>
          <div class="secondary-text">[[playerObj.secondaryTitle]]</div>
        </div>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1},playerObj:{type:Object,computed:"computePlayerObj(hass, stateObj)"}}}computePlayerObj(hass,stateObj){return new hass_media_player_model.a(hass,stateObj)}computePrimaryText(localize,playerObj){return playerObj.primaryTitle||localize(`state.media_player.${playerObj.stateObj.state}`)||localize(`state.default.${playerObj.stateObj.state}`)||playerObj.stateObj.state}}customElements.define("state-card-media_player",state_card_media_player_StateCardMediaPlayer);class state_card_scene_StateCardScene extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <paper-button on-click="activateScene"
          >[[localize('ui.card.scene.activate')]]</paper-button
        >
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}activateScene(ev){ev.stopPropagation();this.hass.callService("scene","turn_on",{entity_id:this.stateObj.entity_id})}}customElements.define("state-card-scene",state_card_scene_StateCardScene);__webpack_require__(202);class state_card_script_StateCardScript extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }

        ha-entity-toggle {
          margin-left: 16px;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <template is="dom-if" if="[[stateObj.attributes.can_cancel]]">
          <ha-entity-toggle
            state-obj="[[stateObj]]"
            hass="[[hass]]"
          ></ha-entity-toggle>
        </template>
        <template is="dom-if" if="[[!stateObj.attributes.can_cancel]]">
          <paper-button on-click="fireScript"
            >[[localize('ui.card.script.execute')]]</paper-button
          >
        </template>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}fireScript(ev){ev.stopPropagation();this.hass.callService("script","turn_on",{entity_id:this.stateObj.entity_id})}}customElements.define("state-card-script",state_card_script_StateCardScript);var timer_time_remaining=__webpack_require__(227),seconds_to_duration=__webpack_require__(219);class state_card_timer_StateCardTimer extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        .state {
          @apply --paper-font-body1;
          color: var(--primary-text-color);

          margin-left: 16px;
          text-align: right;
          line-height: 40px;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <div class="state">[[_secondsToDuration(timeRemaining)]]</div>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"stateObjChanged"},timeRemaining:Number,inDialog:{type:Boolean,value:!1}}}connectedCallback(){super.connectedCallback();this.startInterval(this.stateObj)}disconnectedCallback(){super.disconnectedCallback();this.clearInterval()}stateObjChanged(stateObj){this.startInterval(stateObj)}clearInterval(){if(this._updateRemaining){clearInterval(this._updateRemaining);this._updateRemaining=null}}startInterval(stateObj){this.clearInterval();this.calculateRemaining(stateObj);if("active"===stateObj.state){this._updateRemaining=setInterval(()=>this.calculateRemaining(this.stateObj),1e3)}}calculateRemaining(stateObj){this.timeRemaining=Object(timer_time_remaining.a)(stateObj)}_secondsToDuration(time){return Object(seconds_to_duration.a)(time)}}customElements.define("state-card-timer",state_card_timer_StateCardTimer);class state_card_toggle_StateCardToggle extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        ha-entity-toggle {
          margin: -4px -16px -4px 0;
          padding: 4px 16px;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <ha-entity-toggle
          state-obj="[[stateObj]]"
          hass="[[hass]]"
        ></ha-entity-toggle>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}}customElements.define("state-card-toggle",state_card_toggle_StateCardToggle);const STATES_INTERCEPTABLE={cleaning:{action:"return_to_base",service:"return_to_base"},docked:{action:"start_cleaning",service:"start"},idle:{action:"start_cleaning",service:"start"},off:{action:"turn_on",service:"turn_on"},on:{action:"turn_off",service:"turn_off"},paused:{action:"resume_cleaning",service:"start"}};class ha_vacuum_state_HaVacuumState extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          top: 3px;
          height: 37px;
          margin-right: -0.57em;
        }
        paper-button[disabled] {
          background-color: transparent;
          color: var(--secondary-text-color);
        }
      </style>

      <paper-button on-click="_callService" disabled="[[!_interceptable]]"
        >[[_computeLabel(stateObj.state, _interceptable)]]</paper-button
      >
    `}static get properties(){return{hass:Object,stateObj:Object,_interceptable:{type:Boolean,computed:"_computeInterceptable(stateObj.state, stateObj.attributes.supported_features)"}}}_computeInterceptable(state,supportedFeatures){return state in STATES_INTERCEPTABLE&&0!==supportedFeatures}_computeLabel(state,interceptable){return interceptable?this.localize(`ui.card.vacuum.actions.${STATES_INTERCEPTABLE[state].action}`):this.localize(`state.vacuum.${state}`)}_callService(ev){ev.stopPropagation();const stateObj=this.stateObj,service=STATES_INTERCEPTABLE[stateObj.state].service;this.hass.callService("vacuum",service,{entity_id:stateObj.entity_id})}}customElements.define("ha-vacuum-state",ha_vacuum_state_HaVacuumState);class state_card_vacuum_StateCardVacuum extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <ha-vacuum-state
          hass="[[hass]]"
          state-obj="[[stateObj]]"
        ></ha-vacuum-state>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}}customElements.define("state-card-vacuum",state_card_vacuum_StateCardVacuum);class ha_water_heater_state_HaWaterHeaterState extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: flex;
          flex-direction: column;
          justify-content: center;
          white-space: nowrap;
        }

        .target {
          color: var(--primary-text-color);
        }

        .current {
          color: var(--secondary-text-color);
        }

        .state-label {
          font-weight: bold;
          text-transform: capitalize;
        }
      </style>

      <div class="target">
        <span class="state-label"> [[_localizeState(stateObj.state)]] </span>
        [[computeTarget(hass, stateObj)]]
      </div>

      <template is="dom-if" if="[[currentStatus]]">
        <div class="current">
          [[localize('ui.card.water_heater.currently')]]: [[currentStatus]]
        </div>
      </template>
    `}static get properties(){return{hass:Object,stateObj:Object}}computeTarget(hass,stateObj){if(!hass||!stateObj)return null;if(null!=stateObj.attributes.target_temp_low&&null!=stateObj.attributes.target_temp_high){return`${stateObj.attributes.target_temp_low} - ${stateObj.attributes.target_temp_high} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.temperature){return`${stateObj.attributes.temperature} ${hass.config.unit_system.temperature}`}return""}_localizeState(state){return this.localize(`state.water_heater.${state}`)||state}}customElements.define("ha-water_heater-state",ha_water_heater_state_HaWaterHeaterState);class state_card_water_heater_StateCardWaterHeater extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          @apply --paper-font-body1;
          line-height: 1.5;
        }

        ha-water_heater-state {
          margin-left: 16px;
          text-align: right;
        }
      </style>

      <div class="horizontal justified layout">
        ${this.stateInfoTemplate}
        <ha-water_heater-state
          hass="[[hass]]"
          state-obj="[[stateObj]]"
        ></ha-water_heater-state>
      </div>
    `}static get stateInfoTemplate(){return html_tag.a`
      <state-info
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog="[[inDialog]]"
      ></state-info>
    `}static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}}customElements.define("state-card-water_heater",state_card_water_heater_StateCardWaterHeater);class state_card_weblink_StateCardWeblink extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
        }
        .name {
          @apply --paper-font-common-nowrap;
          @apply --paper-font-body1;
          color: var(--primary-color);

          text-transform: capitalize;
          line-height: 40px;
          margin-left: 16px;
        }
      </style>

      ${this.stateBadgeTemplate}
      <a href$="[[stateObj.state]]" target="_blank" class="name" id="link"
        >[[_computeStateName(stateObj)]]</a
      >
    `}static get stateBadgeTemplate(){return html_tag.a`
      <state-badge state-obj="[[stateObj]]"></state-badge>
    `}static get properties(){return{stateObj:Object,inDialog:{type:Boolean,value:!1}}}ready(){super.ready();this.addEventListener("click",ev=>this.onTap(ev))}_computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}onTap(ev){ev.stopPropagation();ev.preventDefault();window.open(this.stateObj.state,"_blank")}}customElements.define("state-card-weblink",state_card_weblink_StateCardWeblink);var can_toggle_state=__webpack_require__(255),compute_state_domain=__webpack_require__(153),common_const=__webpack_require__(80);function stateCardType(hass,stateObj){if("unavailable"===stateObj.state){return"display"}const domain=Object(compute_state_domain.a)(stateObj);if(common_const.g.includes(domain)){return domain}if(Object(can_toggle_state.a)(hass,stateObj)&&"hidden"!==stateObj.attributes.control){return"toggle"}return"display"}var dynamic_content_updater=__webpack_require__(115);class state_card_content_StateCardContent extends polymer_element.a{static get properties(){return{hass:Object,stateObj:Object,inDialog:{type:Boolean,value:!1}}}static get observers(){return["inputChanged(hass, inDialog, stateObj)"]}inputChanged(hass,inDialog,stateObj){let stateCard;if(!stateObj||!hass)return;if(stateObj.attributes&&"custom_ui_state_card"in stateObj.attributes){stateCard=stateObj.attributes.custom_ui_state_card}else{stateCard="state-card-"+stateCardType(hass,stateObj)}Object(dynamic_content_updater.a)(this,stateCard.toUpperCase(),{hass:hass,stateObj:stateObj,inDialog:inDialog})}}customElements.define("state-card-content",state_card_content_StateCardContent)},274:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return stateMoreInfoType});var _compute_state_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(153),_const__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(80);function stateMoreInfoType(stateObj){const domain=Object(_compute_state_domain__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj);if(_const__WEBPACK_IMPORTED_MODULE_1__.h.includes(domain)){return domain}if(_const__WEBPACK_IMPORTED_MODULE_1__.d.includes(domain)){return"hidden"}return"default"}},275:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_card_paper_card__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(152),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(10),_components_state_history_charts__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(225),_data_ha_state_history_data__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(226),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(105),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(48);class HaHistoryGraphCard extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_6__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style>
        paper-card:not([dialog]) .content {
          padding: 0 16px 16px;
        }
        paper-card[dialog] {
          padding-top: 16px;
          background-color: transparent;
        }
        paper-card {
          width: 100%;
          /* prevent new stacking context, chart tooltip needs to overflow */
          position: static;
        }
        .header {
          @apply --paper-font-headline;
          line-height: 40px;
          color: var(--primary-text-color);
          padding: 20px 16px 12px;
          @apply --paper-font-common-nowrap;
        }
        paper-card[dialog] .header {
          display: none;
        }
      </style>
      <ha-state-history-data
        hass="[[hass]]"
        filter-type="recent-entity"
        entity-id="[[computeHistoryEntities(stateObj)]]"
        data="{{stateHistory}}"
        is-loading="{{stateHistoryLoading}}"
        cache-config="[[cacheConfig]]"
      ></ha-state-history-data>
      <paper-card
        dialog$="[[inDialog]]"
        on-click="cardTapped"
        elevation="[[computeElevation(inDialog)]]"
      >
        <div class="header">[[computeTitle(stateObj)]]</div>
        <div class="content">
          <state-history-charts
            hass="[[hass]]"
            history-data="[[stateHistory]]"
            is-loading-data="[[stateHistoryLoading]]"
            up-to-now
            no-single
          >
          </state-history-charts>
        </div>
      </paper-card>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"stateObjObserver"},inDialog:{type:Boolean,value:!1},stateHistory:Object,stateHistoryLoading:Boolean,cacheConfig:{type:Object,value:{refresh:0,cacheKey:null,hoursToShow:24}}}}stateObjObserver(stateObj){if(!stateObj)return;if(this.cacheConfig.cacheKey!==stateObj.entity_id||this.cacheConfig.refresh!==(stateObj.attributes.refresh||0)||this.cacheConfig.hoursToShow!==(stateObj.attributes.hours_to_show||24)){this.cacheConfig=Object.assign({},{refresh:stateObj.attributes.refresh||0,cacheKey:stateObj.entity_id,hoursToShow:stateObj.attributes.hours_to_show||24})}}computeTitle(stateObj){return Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_5__.a)(stateObj)}computeContentClass(inDialog){return inDialog?"":"content"}computeHistoryEntities(stateObj){return stateObj.attributes.entity_id}computeElevation(inDialog){return inDialog?0:1}cardTapped(ev){const mq=window.matchMedia("(min-width: 610px) and (min-height: 550px)");if(mq.matches){ev.stopPropagation();this.fire("hass-more-info",{entityId:this.stateObj.entity_id})}}}customElements.define("ha-history_graph-card",HaHistoryGraphCard)},295:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathfloor3=Math.floor,_Mathabs2=Math.abs,_Mathmin=Math.min,sizing=__webpack_require__(191),spacing=__webpack_require__(189),menu_overlay=__webpack_require__(300),html_tag=__webpack_require__(1);const $_documentContainer=html_tag.a`<dom-module id="lumo-date-picker-overlay" theme-for="vaadin-date-picker-overlay">
  <template>
    <style include="lumo-menu-overlay">
      [part="overlay"] {
        /*
        Width:
            date cell widths
          + month calendar side padding
          + year scroller width
        */
        width:
          calc(
              var(--lumo-size-m) * 7
            + var(--lumo-space-xs) * 2
            + 57px
          );
        height: 100%;
        max-height: calc(var(--lumo-size-m) * 14);
        overflow: hidden;
        -webkit-tap-highlight-color: transparent;
      }

      [part="content"] {
        padding: 0;
        height: 100%;
        overflow: hidden;
        -webkit-mask-image: none;
        mask-image: none;
      }

      @media (max-width: 420px), (max-height: 420px) {
        [part="overlay"] {
          width: 100vw;
          height: 70vh;
          max-height: 70vh;
        }
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild($_documentContainer.content);var color=__webpack_require__(196),style=__webpack_require__(195),typography=__webpack_require__(207);const vaadin_button_styles_$_documentContainer=document.createElement("template");vaadin_button_styles_$_documentContainer.innerHTML=`<dom-module id="lumo-button" theme-for="vaadin-button">
  <template>
    <style>
      :host {
        /* Sizing */
        --lumo-button-size: var(--lumo-size-m);
        min-width: calc(var(--lumo-button-size) * 2);
        height: var(--lumo-button-size);
        padding: 0 calc(var(--lumo-button-size) / 3 + var(--lumo-border-radius) / 2);
        margin: var(--lumo-space-xs) 0;
        box-sizing: border-box;
        /* Style */
        font-family: var(--lumo-font-family);
        font-size: var(--lumo-font-size-m);
        font-weight: 500;
        color: var(--lumo-primary-text-color);
        background-color: var(--lumo-contrast-5pct);
        border-radius: var(--lumo-border-radius);
        cursor: default;
        -webkit-tap-highlight-color: transparent;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      /* Set only for the internal parts so we don’t affect the host vertical alignment */
      [part="label"],
      [part="prefix"],
      [part="suffix"] {
        line-height: var(--lumo-line-height-xs);
      }

      [part="label"] {
        padding: calc(var(--lumo-button-size) / 6) 0;
      }

      :host([theme~="small"]) {
        font-size: var(--lumo-font-size-s);
        --lumo-button-size: var(--lumo-size-s);
      }

      :host([theme~="large"]) {
        font-size: var(--lumo-font-size-l);
        --lumo-button-size: var(--lumo-size-l);
      }

      /* This needs to be the last selector for it to take priority */
      :host([disabled][disabled]) {
        pointer-events: none;
        color: var(--lumo-disabled-text-color);
        background-color: var(--lumo-contrast-5pct);
      }

      /* For interaction states */
      :host::before,
      :host::after {
        content: "";
        /* We rely on the host always being relative */
        position: absolute;
        z-index: 1;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background-color: currentColor;
        border-radius: inherit;
        opacity: 0;
        transition: opacity 0.2s;
        pointer-events: none;
      }

      /* Hover */

      :host(:hover)::before {
        opacity: 0.05;
      }

      /* Disable hover for touch devices */
      @media (pointer: coarse) {
        :host(:not([active]):hover)::before {
          opacity: 0;
        }
      }

      /* Active */

      :host::after {
        transition: opacity 1.4s, transform 0.1s;
        filter: blur(8px);
      }

      :host([active])::before {
        opacity: 0.1;
        transition-duration: 0s;
      }

      :host([active])::after {
        opacity: 0.1;
        transition-duration: 0s, 0s;
        transform: scale(0);
      }

      /* Keyboard focus */

      :host([focus-ring]) {
        box-shadow: 0 0 0 2px var(--lumo-primary-color-50pct);
      }

      /* Types (primary, tertiary, tertiary-inline */

      :host([theme~="tertiary"]),
      :host([theme~="tertiary-inline"]) {
        background-color: transparent !important;
        transition: opacity 0.2s;
        min-width: 0;
      }

      :host([theme~="tertiary"])::before,
      :host([theme~="tertiary-inline"])::before {
        display: none;
      }

      :host([theme~="tertiary"]) {
        padding: 0 calc(var(--lumo-button-size) / 6);
      }

      @media (hover: hover) {
        :host([theme*="tertiary"]:not([active]):hover) {
          opacity: 0.8;
        }
      }

      :host([theme~="tertiary"][active]),
      :host([theme~="tertiary-inline"][active]) {
        opacity: 0.5;
        transition-duration: 0s;
      }

      :host([theme~="tertiary-inline"]) {
        margin: 0;
        height: auto;
        padding: 0;
        line-height: inherit;
        font-size: inherit;
      }

      :host([theme~="tertiary-inline"]) [part="label"] {
        padding: 0;
        line-height: inherit;
      }

      :host([theme~="primary"]) {
        background-color: var(--lumo-primary-color);
        color: var(--lumo-primary-contrast-color);
        font-weight: 600;
        min-width: calc(var(--lumo-button-size) * 2.5);
      }

      :host([theme~="primary"]:hover)::before {
        opacity: 0.1;
      }

      :host([theme~="primary"][active])::before {
        background-color: var(--lumo-shade-20pct);
      }

      @media (pointer: coarse) {
        :host([theme~="primary"][active])::before {
          background-color: var(--lumo-shade-60pct);
        }

        :host([theme~="primary"]:not([active]):hover)::before {
          opacity: 0;
        }
      }

      :host([theme~="primary"][active])::after {
        opacity: 0.2;
      }

      /* Colors (success, error, contrast) */

      :host([theme~="success"]) {
        color: var(--lumo-success-text-color);
      }

      :host([theme~="success"][theme~="primary"]) {
        background-color: var(--lumo-success-color);
        color: var(--lumo-success-contrast-color);
      }

      :host([theme~="error"]) {
        color: var(--lumo-error-text-color);
      }

      :host([theme~="error"][theme~="primary"]) {
        background-color: var(--lumo-error-color);
        color: var(--lumo-error-contrast-color);
      }

      :host([theme~="contrast"]) {
        color: var(--lumo-contrast);
      }

      :host([theme~="contrast"][theme~="primary"]) {
        background-color: var(--lumo-contrast);
        color: var(--lumo-base-color);
      }

      /* Icons */

      [part] ::slotted(iron-icon) {
        display: inline-block;
        width: var(--lumo-icon-size-m);
        height: var(--lumo-icon-size-m);
      }

      /* Vaadin icons are based on a 16x16 grid (unlike Lumo and Material icons with 24x24), so they look too big by default */
      [part] ::slotted(iron-icon[icon^="vaadin:"]) {
        padding: 0.25em;
        box-sizing: border-box !important;
      }

      [part="prefix"] {
        margin-left: -0.25em;
        margin-right: 0.25em;
      }

      [part="suffix"] {
        margin-left: 0.25em;
        margin-right: -0.25em;
      }

      /* Icon-only */

      :host([theme~="icon"]) {
        min-width: var(--lumo-button-size);
        padding-left: calc(var(--lumo-button-size) / 4);
        padding-right: calc(var(--lumo-button-size) / 4);
      }

      :host([theme~="icon"]) [part="prefix"],
      :host([theme~="icon"]) [part="suffix"] {
        margin-left: 0;
        margin-right: 0;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild(vaadin_button_styles_$_documentContainer.content);var polymer_element=__webpack_require__(10),gesture_event_listeners=__webpack_require__(43),vaadin_themable_mixin=__webpack_require__(184);/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/const TabIndexMixin=superClass=>class extends superClass{static get properties(){var properties={tabindex:{type:Number,value:0,reflectToAttribute:!0,observer:"_tabindexChanged"}};if(window.ShadyDOM){properties.tabIndex=properties.tabindex}return properties}},ControlStateMixin=superClass=>class extends TabIndexMixin(superClass){static get properties(){return{autofocus:{type:Boolean},_previousTabIndex:{type:Number},disabled:{type:Boolean,observer:"_disabledChanged",reflectToAttribute:!0},_isShiftTabbing:{type:Boolean}}}ready(){this.addEventListener("focusin",e=>{if(e.composedPath()[0]===this){this._focus(e)}else if(-1!==e.composedPath().indexOf(this.focusElement)&&!this.disabled){this._setFocused(!0)}});this.addEventListener("focusout",()=>this._setFocused(!1));super.ready();const ensureEventComposed=e=>{if(!e.composed){e.target.dispatchEvent(new CustomEvent(e.type,{bubbles:!0,composed:!0,cancelable:!1}))}};this.shadowRoot.addEventListener("focusin",ensureEventComposed);this.shadowRoot.addEventListener("focusout",ensureEventComposed);this.addEventListener("keydown",e=>{if(!e.defaultPrevented&&e.shiftKey&&9===e.keyCode){this._isShiftTabbing=!0;HTMLElement.prototype.focus.apply(this);this._setFocused(!1);setTimeout(()=>this._isShiftTabbing=!1,0)}});if(this.autofocus&&!this.focused&&!this.disabled){window.requestAnimationFrame(()=>{this._focus();this._setFocused(!0);this.setAttribute("focus-ring","")})}this._boundKeydownListener=this._bodyKeydownListener.bind(this);this._boundKeyupListener=this._bodyKeyupListener.bind(this)}connectedCallback(){super.connectedCallback();document.body.addEventListener("keydown",this._boundKeydownListener,!0);document.body.addEventListener("keyup",this._boundKeyupListener,!0)}disconnectedCallback(){super.disconnectedCallback();document.body.removeEventListener("keydown",this._boundKeydownListener,!0);document.body.removeEventListener("keyup",this._boundKeyupListener,!0);if(this.hasAttribute("focused")){this._setFocused(!1)}}_setFocused(focused){if(focused){this.setAttribute("focused","")}else{this.removeAttribute("focused")}if(focused&&this._tabPressed){this.setAttribute("focus-ring","")}else{this.removeAttribute("focus-ring")}}_bodyKeydownListener(e){this._tabPressed=9===e.keyCode}_bodyKeyupListener(){this._tabPressed=!1}get focusElement(){window.console.warn(`Please implement the 'focusElement' property in <${this.localName}>`);return this}_focus(){if(this._isShiftTabbing){return}this.focusElement.focus();this._setFocused(!0)}focus(){if(this.disabled){return}this.focusElement.focus();this._setFocused(!0)}blur(){this.focusElement.blur();this._setFocused(!1)}_disabledChanged(disabled){this.focusElement.disabled=disabled;if(disabled){this.blur();this._previousTabIndex=this.tabindex;this.tabindex=-1;this.setAttribute("aria-disabled","true")}else{if("undefined"!==typeof this._previousTabIndex){this.tabindex=this._previousTabIndex}this.removeAttribute("aria-disabled")}}_tabindexChanged(tabindex){if(tabindex!==void 0){this.focusElement.tabIndex=tabindex}if(this.disabled&&this.tabindex){if(-1!==this.tabindex){this._previousTabIndex=this.tabindex}this.tabindex=tabindex=void 0}if(window.ShadyDOM){this.setProperties({tabIndex:tabindex,tabindex:tabindex})}}};var utils_async=__webpack_require__(8),debounce=__webpack_require__(14),flush=__webpack_require__(16);const DEV_MODE_CODE_REGEXP=/\/\*\*\s+vaadin-dev-mode:start([\s\S]*)vaadin-dev-mode:end\s+\*\*\//i;function isMinified(){return uncommentAndRun(function(){return!0})}function isDevelopmentMode(){try{return isForcedDevelopmentMode()||isLocalhost()&&!isMinified()&&!isFlowProductionMode()}catch(e){return!1}}function isForcedDevelopmentMode(){return localStorage.getItem("vaadin.developmentmode.force")}function isLocalhost(){return 0<=["localhost","127.0.0.1"].indexOf(window.location.hostname)}function isFlowProductionMode(){if(window.Vaadin&&window.Vaadin.Flow&&window.Vaadin.Flow.clients){const productionModeApps=Object.keys(window.Vaadin.Flow.clients).map(key=>window.Vaadin.Flow.clients[key]).filter(client=>client.productionMode);if(0<productionModeApps.length){return!0}}return!1}function uncommentAndRun(callback,args){if("function"!==typeof callback){return}const match=DEV_MODE_CODE_REGEXP.exec(callback.toString());if(match){try{callback=new Function(match[1])}catch(e){console.log("vaadin-development-mode-detector: uncommentAndRun() failed",e)}}return callback(args)}window.Vaadin=window.Vaadin||{};const runIfDevelopmentMode=function(callback,args){if(window.Vaadin.developmentMode){return uncommentAndRun(callback,args)}};if(window.Vaadin.developmentMode===void 0){window.Vaadin.developmentMode=isDevelopmentMode()}function maybeGatherAndSendStats(){}const usageStatistics=function(){if("function"===typeof runIfDevelopmentMode){return runIfDevelopmentMode(maybeGatherAndSendStats)}};if(!window.Vaadin){window.Vaadin={}}window.Vaadin.registrations=window.Vaadin.registrations||[];window.Vaadin.developmentModeCallback=window.Vaadin.developmentModeCallback||{};window.Vaadin.developmentModeCallback["vaadin-usage-statistics"]=function(){if(usageStatistics){usageStatistics()}};let statsJob;const ElementMixin=superClass=>class extends superClass{static _finalizeClass(){super._finalizeClass();if(this.is){window.Vaadin.registrations.push(this);if(window.Vaadin.developmentModeCallback){statsJob=debounce.a.debounce(statsJob,utils_async.b,()=>{window.Vaadin.developmentModeCallback["vaadin-usage-statistics"]()});Object(flush.a)(statsJob)}}}ready(){super.ready();if(null===document.doctype){console.warn("Vaadin components require the \"standards mode\" declaration. Please add <!DOCTYPE html> to the HTML document.")}}};var gestures=__webpack_require__(25);/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/class vaadin_button_ButtonElement extends ElementMixin(ControlStateMixin(Object(vaadin_themable_mixin.a)(Object(gesture_event_listeners.a)(polymer_element.a)))){static get template(){return html_tag.a`
    <style>
      :host {
        display: inline-block;
        position: relative;
        outline: none;
        white-space: nowrap;
      }

      :host([hidden]) {
        display: none !important;
      }

      /* Ensure the button is always aligned on the baseline */
      .vaadin-button-container::before {
        content: "\\2003";
        display: inline-block;
        width: 0;
      }

      .vaadin-button-container {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        width: 100%;
        height: 100%;
        min-height: inherit;
        text-shadow: inherit;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      [part="prefix"],
      [part="suffix"] {
        flex: none;
      }

      [part="label"] {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      #button {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: inherit;
      }
    </style>
    <div class="vaadin-button-container">
      <div part="prefix">
        <slot name="prefix"></slot>
      </div>
      <div part="label">
        <slot></slot>
      </div>
      <div part="suffix">
        <slot name="suffix"></slot>
      </div>
    </div>
    <button id="button" type="button"></button>
`}static get is(){return"vaadin-button"}static get version(){return"2.1.0"}ready(){super.ready();this.setAttribute("role","button");this.$.button.setAttribute("role","presentation");this._addActiveListeners()}disconnectedCallback(){super.disconnectedCallback();if(this.hasAttribute("active")){this.removeAttribute("active")}}_addActiveListeners(){Object(gestures.b)(this,"down",()=>!this.disabled&&this.setAttribute("active",""));Object(gestures.b)(this,"up",()=>this.removeAttribute("active"));this.addEventListener("keydown",e=>!this.disabled&&0<=[13,32].indexOf(e.keyCode)&&this.setAttribute("active",""));this.addEventListener("keyup",()=>this.removeAttribute("active"));this.addEventListener("blur",()=>this.removeAttribute("active"))}get focusElement(){return this.$.button}}customElements.define(vaadin_button_ButtonElement.is,vaadin_button_ButtonElement);const vaadin_date_picker_overlay_content_styles_$_documentContainer=html_tag.a`<dom-module id="lumo-date-picker-overlay-content" theme-for="vaadin-date-picker-overlay-content">
  <template>
    <style>
      :host {
        position: relative;
        background-color: transparent;
        /* Background for the year scroller, placed here as we are using a mask image on the actual years part */
        background-image: linear-gradient(var(--lumo-shade-5pct), var(--lumo-shade-5pct));
        background-size: 57px 100%;
        background-position: top right;
        background-repeat: no-repeat;
        cursor: default;
      }

      /* Month scroller */

      [part="months"] {
        /* Month calendar height:
              header height + margin-bottom
            + weekdays height + margin-bottom
            + date cell heights
            + small margin between month calendars
        */
        --vaadin-infinite-scroller-item-height:
          calc(
              var(--lumo-font-size-l) + var(--lumo-space-m)
            + var(--lumo-font-size-xs) + var(--lumo-space-s)
            + var(--lumo-size-m) * 6
            + var(--lumo-space-s)
          );
        --vaadin-infinite-scroller-buffer-offset: 20%;
        -webkit-mask-image: linear-gradient(transparent, #000 10%, #000 85%, transparent);
        mask-image: linear-gradient(transparent, #000 10%, #000 85%, transparent);
        position: relative;
        margin-right: 57px;
      }

      /* Year scroller */

      [part="years"] {
        /* TODO get rid of fixed magic number */
        --vaadin-infinite-scroller-buffer-width: 97px;
        width: 57px;
        height: auto;
        top: 0;
        bottom: 0;
        font-size: var(--lumo-font-size-s);
        box-shadow: inset 2px 0 4px 0 var(--lumo-shade-5pct);
        -webkit-mask-image: linear-gradient(transparent, #000 35%, #000 65%, transparent);
        mask-image: linear-gradient(transparent, #000 35%, #000 65%, transparent);
      }

      [part="year-number"],
      [part="year-separator"] {
        opacity: 0.5;
        transition: 0.2s opacity;
      }

      [part="years"]:hover [part="year-number"],
      [part="years"]:hover [part="year-separator"] {
        opacity: 1;
      }

      /* TODO unsupported selector */
      #scrollers {
        position: static;
        display: block;
      }

      /* TODO unsupported selector, should fix this in vaadin-date-picker that it adapts to the
       * width of the year scroller */
      #scrollers[desktop] [part="months"] {
        right: auto;
      }

      /* Year scroller position indicator */
      [part="years"]::before {
        border: none;
        width: 1em;
        height: 1em;
        background-color: var(--lumo-base-color);
        background-image: linear-gradient(var(--lumo-tint-5pct), var(--lumo-tint-5pct));
        transform: translate(-75%, -50%) rotate(45deg);
        border-top-right-radius: calc(var(--lumo-border-radius) / 2);
        box-shadow: 2px -2px 6px 0 var(--lumo-shade-5pct);
        z-index: 1;
      }

      [part="year-number"],
      [part="year-separator"] {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 50%;
        transform: translateY(-50%);
      }

      [part="years"] [part="year-separator"]::after {
        color: var(--lumo-disabled-text-color);
        content: "•";
      }

      /* Current year */

      [part="years"] [part="year-number"][current] {
        color: var(--lumo-primary-text-color);
      }

      /* Toolbar (footer) */

      [part="toolbar"] {
        padding: var(--lumo-space-s);
        box-shadow: 0 -1px 0 0 var(--lumo-contrast-10pct);
        border-bottom-left-radius: var(--lumo-border-radius);
        margin-right: 57px;
      }

      @supports (mask-image: linear-gradient(#000, #000)) or (-webkit-mask-image: linear-gradient(#000, #000)) {
        [part="toolbar"] {
          box-shadow: none;
        }
      }

      /* Today and Cancel buttons */

      /* TODO: Would be great if I could apply the "tertiary" theme from here instead of copying those styles */
      [part="toolbar"] [part\$="button"] {
        background-color: transparent;
        margin: 0;
        min-width: 0;
        padding: 0 0.75em;
      }

      /* Narrow viewport mode (fullscreen) */

      :host([fullscreen]) [part="toolbar"] {
        order: -1;
        background-color: var(--lumo-base-color);
      }

      :host([fullscreen]) [part="overlay-header"] {
        order: -2;
        height: var(--lumo-size-m);
        padding: var(--lumo-space-s);
        position: absolute;
        left: 0;
        right: 0;
        justify-content: center;
      }

      :host([fullscreen]) [part="toggle-button"],
      :host([fullscreen]) [part="clear-button"],
      [part="overlay-header"] [part="label"] {
        display: none;
      }

      /* Very narrow screen (year scroller initially hidden) */

      [part="years-toggle-button"] {
        position: relative;
        right: auto;
        display: flex;
        align-items: center;
        height: var(--lumo-size-s);
        padding: 0 0.5em;
        border-radius: var(--lumo-border-radius);
        z-index: 3;
        color: var(--lumo-primary-text-color);
        font-weight: 500;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }

      :host([years-visible]) [part="years-toggle-button"] {
        background-color: var(--lumo-primary-color);
        color: var(--lumo-primary-contrast-color);
      }

      [part="years-toggle-button"]::before {
        content: none;
      }

      /* TODO magic number (same as used for iron-media-query in vaadin-date-picker-overlay-content) */
      @media screen and (max-width: 374px) {
        :host {
          background-image: none;
        }

        [part="years"] {
          background-color: var(--lumo-shade-5pct);
        }

        [part="toolbar"],
        [part="months"] {
          margin-right: 0;
        }

        /* TODO make date-picker adapt to the width of the years part */
        [part="years"] {
          --vaadin-infinite-scroller-buffer-width: 90px;
          width: 50px;
        }

        :host([years-visible]) [part="months"] {
          padding-left: 50px;
        }
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild(vaadin_date_picker_overlay_content_styles_$_documentContainer.content);const vaadin_month_calendar_styles_$_documentContainer=html_tag.a`<dom-module id="lumo-month-calendar" theme-for="vaadin-month-calendar">
  <template>
    <style>
      :host {
        -moz-user-select: none;
        -ms-user-select: none;
        -webkit-user-select: none;
        -webkit-tap-highlight-color: transparent;
        user-select: none;
        font-size: var(--lumo-font-size-m);
        color: var(--lumo-body-text-color);
        text-align: center;
        padding: 0 var(--lumo-space-xs);
      }

      /* Month header */

      [part="month-header"] {
        color: var(--lumo-header-text-color);
        font-size: var(--lumo-font-size-l);
        line-height: 1;
        font-weight: 500;
        margin-bottom: var(--lumo-space-m);
      }

      /* Week days and numbers */

      [part="weekdays"],
      [part="weekday"],
      [part="week-numbers"] {
        font-size: var(--lumo-font-size-xs);
        line-height: 1;
        color: var(--lumo-tertiary-text-color);
      }

      [part="weekdays"] {
        margin-bottom: var(--lumo-space-s);
      }

      /* TODO should have part="week-number" for the cell in weekdays-container */
      [part="weekday"]:empty,
      [part="week-numbers"] {
        width: var(--lumo-size-xs);
      }

      /* Date and week number cells */

      [part="date"],
      [part="week-number"] {
        box-sizing: border-box;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: var(--lumo-size-m);
        position: relative;
      }

      [part="date"] {
        transition: color 0.1s;
      }

      /* Today date */

      [part="date"][today] {
        color: var(--lumo-primary-text-color);
      }

      /* Focused date */

      [part="date"]::before {
        content: "";
        position: absolute;
        z-index: -1;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        min-width: 2em;
        min-height: 2em;
        width: 80%;
        height: 80%;
        max-height: 100%;
        max-width: 100%;
        border-radius: var(--lumo-border-radius);
      }

      [part="date"][focused]::before {
        box-shadow: 0 0 0 2px var(--lumo-primary-color-50pct);
      }

      :host(:not([focused])) [part="date"][focused]::before {
        animation: vaadin-date-picker-month-calendar-focus-date 1.4s infinite;
      }

      @keyframes vaadin-date-picker-month-calendar-focus-date {
        50% {
          box-shadow: 0 0 0 2px transparent;
        }
      }

      /* TODO should not rely on the role attribute */
      [part="date"][role="button"]:not([disabled]):not([selected]):hover::before {
        background-color: var(--lumo-primary-color-10pct);
      }

      [part="date"][selected] {
        color: var(--lumo-primary-contrast-color);
      }

      [part="date"][selected]::before {
        background-color: var(--lumo-primary-color);
      }

      [part="date"][disabled] {
        color: var(--lumo-disabled-text-color);
      }

      @media (pointer: coarse) {
        [part="date"]:hover:not([selected])::before,
        [part="date"][focused]:not([selected])::before {
          display: none;
        }

        [part="date"][role="button"]:not([disabled]):active::before {
          display: block;
        }

        [part="date"][selected]::before {
          box-shadow: none;
        }
      }

      /* Disabled */

      :host([disabled]) * {
        color: var(--lumo-disabled-text-color) !important;
      }
    </style>
  </template>
</dom-module><custom-style>
  <style>
    @keyframes vaadin-date-picker-month-calendar-focus-date {
      50% {
        box-shadow: 0 0 0 2px transparent;
      }
    }
  </style>
</custom-style>`;document.head.appendChild(vaadin_month_calendar_styles_$_documentContainer.content);__webpack_require__(240);const field_button_$_documentContainer=document.createElement("template");field_button_$_documentContainer.innerHTML=`<dom-module id="lumo-field-button">
  <template>
    <style>
      [part\$="button"] {
        flex: none;
        width: 1em;
        height: 1em;
        line-height: 1;
        font-size: var(--lumo-icon-size-m);
        text-align: center;
        color: var(--lumo-contrast-60pct);
        transition: 0.2s color;
        cursor: default;
      }

      :host(:not([readonly])) [part\$="button"]:hover {
        color: var(--lumo-contrast-90pct);
      }

      :host([disabled]) [part\$="button"],
      :host([readonly]) [part\$="button"] {
        color: var(--lumo-contrast-20pct);
      }

      [part\$="button"]::before {
        font-family: "lumo-icons";
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild(field_button_$_documentContainer.content);const vaadin_text_field_styles_$_documentContainer=document.createElement("template");vaadin_text_field_styles_$_documentContainer.innerHTML=`<dom-module id="lumo-text-field" theme-for="vaadin-text-field">
  <template>
    <style>
      :host {
        --lumo-text-field-size: var(--lumo-size-m);
        color: var(--lumo-body-text-color);
        font-size: var(--lumo-font-size-m);
        font-family: var(--lumo-font-family);
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        -webkit-tap-highlight-color: transparent;
        padding: var(--lumo-space-xs) 0;
      }

      :host::before {
        height: var(--lumo-text-field-size);
        box-sizing: border-box;
        display: inline-flex;
        align-items: center;
      }

      [part="label"] {
        align-self: flex-start;
        color: var(--lumo-secondary-text-color);
        font-weight: 500;
        font-size: var(--lumo-font-size-s);
        margin-left: calc(var(--lumo-border-radius) / 4);
        transition: color 0.2s;
        line-height: 1;
        padding-bottom: 0.5em;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        position: relative;
        max-width: 100%;
        box-sizing: border-box;
      }

      :host([has-label])::before {
        /* Label height + margin */
        margin-top: calc(var(--lumo-font-size-s) * 1.5);
      }

      :host([has-label]) {
        padding-top: var(--lumo-space-m);
      }

      :host([focused]:not([readonly])) [part="label"] {
        color: var(--lumo-primary-text-color);
      }

      :host([required]) [part="label"] {
        padding-right: 1em;
      }

      /* Used for required and invalid indicators */
      [part="label"]::after {
        content: var(--lumo-required-field-indicator, "•");
        transition: opacity 0.2s;
        opacity: 0;
        color: var(--lumo-primary-text-color);
        position: absolute;
        right: 0;
        width: 1em;
        text-align: center;
      }

      [part="value"],
      [part="input-field"] ::slotted([part="value"]) {
        cursor: inherit;
        min-height: var(--lumo-text-field-size);
        padding: 0 0.25em;
        --_lumo-text-field-overflow-mask-image: linear-gradient(to left, transparent, #000 1.25em);
        -webkit-mask-image: var(--_lumo-text-field-overflow-mask-image);
      }

      [part="value"]:focus {
        -webkit-mask-image: none;
        mask-image: none;
      }

      /*
        TODO: CSS custom property in \`mask-image\` causes crash in Edge
        see https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/15415089/
      */
      @-moz-document url-prefix() {
        [part="value"],
        [part="input-field"] ::slotted([part="value"]) {
          mask-image: var(--_lumo-text-field-overflow-mask-image);
        }
      }

      [part="value"]::-webkit-input-placeholder {
        color: inherit;
        transition: opacity 0.175s 0.05s;
        opacity: 0.5;
      }

      [part="value"]:-ms-input-placeholder {
        color: inherit;
        opacity: 0.5;
      }

      [part="value"]::-moz-placeholder {
        color: inherit;
        transition: opacity 0.175s 0.05s;
        opacity: 0.5;
      }

      [part="value"]::placeholder {
        color: inherit;
        transition: opacity 0.175s 0.1s;
        opacity: 0.5;
      }

      [part="input-field"] {
        border-radius: var(--lumo-border-radius);
        background-color: var(--lumo-contrast-10pct);
        padding: 0 calc(0.375em + var(--lumo-border-radius) / 4 - 1px);
        font-weight: 500;
        line-height: 1;
        position: relative;
        cursor: text;
        box-sizing: border-box;
      }

      /* Used for hover and activation effects */
      [part="input-field"]::after {
        content: "";
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        border-radius: inherit;
        pointer-events: none;
        background-color: var(--lumo-contrast-50pct);
        opacity: 0;
        transition: transform 0.15s, opacity 0.2s;
        transform-origin: 100% 0;
      }

      /* Hover */

      :host(:hover:not([readonly]):not([focused])) [part="label"] {
        color: var(--lumo-body-text-color);
      }

      :host(:hover:not([readonly]):not([focused])) [part="input-field"]::after {
        opacity: 0.1;
      }

      /* Touch device adjustment */
      @media (pointer: coarse) {
        :host(:hover:not([readonly]):not([focused])) [part="label"] {
          color: var(--lumo-secondary-text-color);
        }

        :host(:hover:not([readonly]):not([focused])) [part="input-field"]::after {
          opacity: 0;
        }

        :host(:active:not([readonly]):not([focused])) [part="input-field"]::after {
          opacity: 0.2;
        }
      }

      /* Trigger when not focusing using the keyboard */
      :host([focused]:not([focus-ring]):not([readonly])) [part="input-field"]::after {
        transform: scaleX(0);
        transition-duration: 0.15s, 1s;
      }

      /* Focus-ring */

      :host([focus-ring]) [part="input-field"] {
        box-shadow: 0 0 0 2px var(--lumo-primary-color-50pct);
      }

      /* Read-only and disabled */
      :host([readonly]) [part="value"]::-webkit-input-placeholder,
      :host([disabled]) [part="value"]::-webkit-input-placeholder {
        opacity: 0;
      }

      :host([readonly]) [part="value"]:-ms-input-placeholder,
      :host([disabled]) [part="value"]:-ms-input-placeholder {
        opacity: 0;
      }

      :host([readonly]) [part="value"]::-moz-placeholder,
      :host([disabled]) [part="value"]::-moz-placeholder {
        opacity: 0;
      }

      :host([readonly]) [part="value"]::placeholder,
      :host([disabled]) [part="value"]::placeholder {
        opacity: 0;
      }

      /* Read-only */

      :host([readonly]) [part="input-field"] {
        color: var(--lumo-secondary-text-color);
        background-color: transparent;
        cursor: default;
      }

      :host([readonly]) [part="input-field"]::after {
        background-color: transparent;
        opacity: 1;
        border: 1px dashed var(--lumo-contrast-30pct);
      }

      /* Disabled style */

      :host([disabled]) {
        pointer-events: none;
      }

      :host([disabled]) [part="input-field"] {
        background-color: var(--lumo-contrast-5pct);
      }

      :host([disabled]) [part="label"],
      :host([disabled]) [part="value"],
      :host([disabled]) [part="input-field"] ::slotted(*) {
        color: var(--lumo-disabled-text-color);
        -webkit-text-fill-color: var(--lumo-disabled-text-color);
      }

      /* Required field style */

      :host([required]:not([has-value])) [part="label"]::after {
        opacity: 1;
      }

      /* Invalid style */

      :host([invalid]) [part="label"]::after {
        color: var(--lumo-error-text-color);
      }

      :host([invalid]) [part="input-field"] {
        background-color: var(--lumo-error-color-10pct);
      }

      :host([invalid]) [part="input-field"]::after {
        background-color: var(--lumo-error-color-50pct);
      }

      :host([invalid][focus-ring]) [part="input-field"] {
        box-shadow: 0 0 0 2px var(--lumo-error-color-50pct);
      }

      /* Error message */

      [part="error-message"] {
        margin-left: calc(var(--lumo-border-radius) / 4);
        font-size: var(--lumo-font-size-xs);
        line-height: var(--lumo-line-height-xs);
        color: var(--lumo-error-text-color);
        will-change: max-height;
        transition: 0.4s max-height;
        max-height: 5em;
      }

      /* Margin that doesn’t reserve space when there’s no error message */
      [part="error-message"]:not(:empty)::before,
      [part="error-message"]:not(:empty)::after {
        content: "";
        display: block;
        height: 0.4em;
      }

      :host(:not([invalid])) [part="error-message"] {
        max-height: 0;
        overflow: hidden;
      }

      /* Small theme */

      :host([theme~="small"]) {
        font-size: var(--lumo-font-size-s);
        --lumo-text-field-size: var(--lumo-size-s);
      }

      :host([theme~="small"][has-label]) [part="label"] {
        font-size: var(--lumo-font-size-xs);
      }

      :host([theme~="small"][has-label]) [part="error-message"] {
        font-size: var(--lumo-font-size-xxs);
      }

      /* Text align */

      :host([theme~="align-center"]) [part="value"] {
        text-align: center;
        --_lumo-text-field-overflow-mask-image: none;
      }

      :host([theme~="align-right"]) [part="value"] {
        text-align: right;
        --_lumo-text-field-overflow-mask-image: none;
      }

      @-moz-document url-prefix() {
        /* Firefox is smart enough to align overflowing text to right */
        :host([theme~="align-right"]) [part="value"] {
          --_lumo-text-field-overflow-mask-image: linear-gradient(to right, transparent 0.25em, #000 1.5em);
        }
      }

      /* Slotted content */

      [part="input-field"] ::slotted(:not([part]):not(iron-icon)) {
        color: var(--lumo-secondary-text-color);
        font-weight: 400;
      }

      /* Slotted icons */

      [part="input-field"] ::slotted(iron-icon) {
        color: var(--lumo-contrast-60pct);
        width: var(--lumo-icon-size-m);
        height: var(--lumo-icon-size-m);
      }

      /* Vaadin icons are based on a 16x16 grid (unlike Lumo and Material icons with 24x24), so they look too big by default */
      [part="input-field"] ::slotted(iron-icon[icon^="vaadin:"]) {
        padding: 0.25em;
        box-sizing: border-box !important;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild(vaadin_text_field_styles_$_documentContainer.content);/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/const vaadin_text_field_mixin_$_documentContainer=document.createElement("template");vaadin_text_field_mixin_$_documentContainer.innerHTML=`<dom-module id="vaadin-text-field-shared-styles">
  <template>
    <style>
      :host {
        display: inline-flex;
        outline: none;
      }

      :host::before {
        content: "\\2003";
        width: 0;
        display: inline-block;
        /* Size and position this element on the same vertical position as the input-field element
           to make vertical align for the host element work as expected */
      }

      :host([hidden]) {
        display: none !important;
      }

      .vaadin-text-field-container,
      .vaadin-text-area-container {
        display: flex;
        flex-direction: column;
        min-width: 100%;
        max-width: 100%;
        width: var(--vaadin-text-field-default-width, 12em);
      }

      [part="label"]:empty {
        display: none;
      }

      [part="input-field"] {
        display: flex;
        align-items: center;
        flex: auto;
      }

      /* Reset the native input styles */
      [part="value"] {
        -webkit-appearance: none;
        -moz-appearance: none;
        outline: none;
        margin: 0;
        padding: 0;
        border: 0;
        border-radius: 0;
        min-width: 0;
        font: inherit;
        font-size: 1em;
        line-height: normal;
        color: inherit;
        background-color: transparent;
        /* Disable default invalid style in Firefox */
        box-shadow: none;
      }

      [part="input-field"] ::slotted(*) {
        flex: none;
      }

      /* Slotted by vaadin-dropdown-menu-text-field */
      [part="value"],
      [part="input-field"] ::slotted([part="value"]) {
        flex: auto;
        white-space: nowrap;
        overflow: hidden;
        width: 100%;
        height: 100%;
      }

      [part="value"]::-ms-clear {
        display: none;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild(vaadin_text_field_mixin_$_documentContainer.content);const TextFieldMixin=subclass=>class extends ControlStateMixin(subclass){static get properties(){return{autocomplete:{type:String},autocorrect:{type:String},autocapitalize:{type:String},errorMessage:{type:String,value:""},label:{type:String,value:"",observer:"_labelChanged"},maxlength:{type:Number},minlength:{type:Number},name:{type:String},placeholder:{type:String},readonly:{type:Boolean,reflectToAttribute:!0},required:{type:Boolean,reflectToAttribute:!0},value:{type:String,value:"",observer:"_valueChanged",notify:!0},invalid:{type:Boolean,reflectToAttribute:!0,notify:!0,value:!1},preventInvalidInput:{type:Boolean},_labelId:{type:String},_errorId:{type:String}}}get focusElement(){return this.root.querySelector("[part=value]")}_onInput(){if(this.preventInvalidInput){const input=this.focusElement;if(0<input.value.length&&!this.checkValidity()){input.value=this.value||""}}}_onChange(e){const changeEvent=new CustomEvent("change",{detail:{sourceEvent:e},bubbles:e.bubbles,cancelable:e.cancelable});this.dispatchEvent(changeEvent)}_valueChanged(newVal,oldVal){if(""===newVal&&oldVal===void 0){return}if(this.invalid){this.validate()}if(""!==newVal&&null!=newVal){this.setAttribute("has-value","")}else{this.removeAttribute("has-value")}}_labelChanged(label){if(""!==label&&null!=label){this.setAttribute("has-label","")}else{this.removeAttribute("has-label")}}checkValidity(){if(this.required||this.pattern||this.maxlength||this.minlength){return this.focusElement.checkValidity()}else{return!this.invalid}}ready(){super.ready();if(!(window.ShadyCSS&&window.ShadyCSS.nativeCss)){this.updateStyles()}var uniqueId=TextFieldMixin._uniqueId=1+TextFieldMixin._uniqueId||0;this._errorId=`${this.constructor.is}-error-${uniqueId}`;this._labelId=`${this.constructor.is}-label-${uniqueId}`;if(navigator.userAgent.match(/Trident/)){this._addIEListeners()}}validate(){return!(this.invalid=!this.checkValidity())}_addIEListeners(){const prevent=e=>{e.stopImmediatePropagation();this.focusElement.removeEventListener("input",prevent)},shouldPreventInput=()=>this.placeholder&&this.focusElement.addEventListener("input",prevent);this.focusElement.addEventListener("focusin",shouldPreventInput);this.focusElement.addEventListener("focusout",shouldPreventInput);this._createPropertyObserver("placeholder",shouldPreventInput)}_getActiveErrorId(invalid,errorMessage,errorId){return errorMessage&&invalid?errorId:void 0}_getActiveLabelId(label,labelId){return label?labelId:void 0}_getErrorMessageAriaHidden(invalid,errorMessage,errorId){return(!this._getActiveErrorId(invalid,errorMessage,errorId)).toString()}attributeChangedCallback(prop,oldVal,newVal){super.attributeChangedCallback(prop,oldVal,newVal);if(!(window.ShadyCSS&&window.ShadyCSS.nativeCss)&&/^(focused|focus-ring|invalid|disabled|placeholder|has-value)$/.test(prop)){this.updateStyles()}const isSafari=/^((?!chrome|android).)*safari/i.test(navigator.userAgent);if(isSafari&&this.root){const WEBKIT_PROPERTY="-webkit-backface-visibility";this.root.querySelectorAll("*").forEach(el=>{el.style[WEBKIT_PROPERTY]="visible";el.style[WEBKIT_PROPERTY]=""})}}};/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/class vaadin_text_field_TextFieldElement extends ElementMixin(TextFieldMixin(Object(vaadin_themable_mixin.a)(polymer_element.a))){static get template(){return html_tag.a`
    <style include="vaadin-text-field-shared-styles">
      /* polymer-cli linter breaks with empty line */
    </style>

    <div class="vaadin-text-field-container">

      <label part="label" on-click="focus" id="[[_labelId]]">[[label]]</label>

      <div part="input-field">

        <slot name="prefix"></slot>

        <input part="value" autocomplete\$="[[autocomplete]]" autocorrect\$="[[autocorrect]]" autocapitalize\$="[[autocapitalize]]" autofocus\$="[[autofocus]]" disabled\$="[[disabled]]" list="[[list]]" maxlength\$="[[maxlength]]" minlength\$="[[minlength]]" pattern="[[pattern]]" placeholder\$="[[placeholder]]" readonly\$="[[readonly]]" aria-readonly\$="[[readonly]]" required\$="[[required]]" aria-required\$="[[required]]" value="{{value::input}}" title="[[title]]" on-blur="validate" on-input="_onInput" on-change="_onChange" aria-describedby\$="[[_getActiveErrorId(invalid, errorMessage, _errorId)]]" aria-labelledby\$="[[_getActiveLabelId(label, _labelId)]]" aria-invalid\$="[[invalid]]">

        <slot name="suffix"></slot>

      </div>

      <div part="error-message" id="[[_errorId]]" aria-live="assertive" aria-hidden\$="[[_getErrorMessageAriaHidden(invalid, errorMessage, _errorId)]]">[[errorMessage]]</div>

    </div>
`}static get is(){return"vaadin-text-field"}static get version(){return"2.1.2"}static get properties(){return{list:{type:String},pattern:{type:String},title:{type:String}}}}customElements.define(vaadin_text_field_TextFieldElement.is,vaadin_text_field_TextFieldElement);const vaadin_date_picker_styles_$_documentContainer=html_tag.a`<dom-module id="lumo-date-picker" theme-for="vaadin-date-picker">
  <template>
    <style include="lumo-field-button">
      :host {
        outline: none;
      }

      [part="toggle-button"]::before {
        content: var(--lumo-icons-calendar);
      }

      [part="clear-button"]::before {
        content: var(--lumo-icons-cross);
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild(vaadin_date_picker_styles_$_documentContainer.content);var iron_media_query=__webpack_require__(113),vaadin_theme_property_mixin=__webpack_require__(241),vaadin_overlay=__webpack_require__(296);/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/class vaadin_date_picker_overlay_DatePickerOverlayElement extends vaadin_overlay.a{static get is(){return"vaadin-date-picker-overlay"}}customElements.define(vaadin_date_picker_overlay_DatePickerOverlayElement.is,vaadin_date_picker_overlay_DatePickerOverlayElement);var iron_a11y_keys_behavior=__webpack_require__(19),iron_a11y_announcer=__webpack_require__(81),dom_repeat=__webpack_require__(66);/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/const DatePickerHelper=class{static _getISOWeekNumber(date){var dayOfWeek=date.getDay();if(0===dayOfWeek){dayOfWeek=7}var nearestThursdayDiff=4-dayOfWeek,nearestThursday=new Date(date.getTime()+1e3*(3600*(24*nearestThursdayDiff))),firstOfJanuary=new Date(0,0);firstOfJanuary.setFullYear(nearestThursday.getFullYear());var timeDiff=nearestThursday.getTime()-firstOfJanuary.getTime(),daysSinceFirstOfJanuary=Math.round(timeDiff/(1e3*(3600*24)));return _Mathfloor3(daysSinceFirstOfJanuary/7+1)}static _dateEquals(date1,date2){return date1 instanceof Date&&date2 instanceof Date&&date1.getFullYear()===date2.getFullYear()&&date1.getMonth()===date2.getMonth()&&date1.getDate()===date2.getDate()}static _dateAllowed(date,min,max){return(!min||date>=min)&&(!max||date<=max)}static _getClosestDate(date,dates){return dates.filter(date=>date!==void 0).reduce((closestDate,candidate)=>{if(!candidate){return closestDate}if(!closestDate){return candidate}var candidateDiff=_Mathabs2(date.getTime()-candidate.getTime()),closestDateDiff=_Mathabs2(closestDate.getTime()-date.getTime());return candidateDiff<closestDateDiff?candidate:closestDate})}static _extractDateParts(date){return{day:date.getDate(),month:date.getMonth(),year:date.getFullYear()}}};/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/class vaadin_month_calendar_MonthCalendarElement extends Object(vaadin_themable_mixin.a)(Object(gesture_event_listeners.a)(polymer_element.a)){static get template(){return html_tag.a`
    <style>
      :host {
        display: block;
      }

      [part="weekdays"],
      #days {
        display: flex;
        flex-wrap: wrap;
        flex-grow: 1;
      }

      #days-container,
      #weekdays-container {
        display: flex;
      }

      [part="week-numbers"] {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        flex-shrink: 0;
      }

      [part="week-numbers"][hidden],
      [part="weekday"][hidden] {
        display: none;
      }

      [part="weekday"],
      [part="date"] {
        /* Would use calc(100% / 7) but it doesn't work nice on IE */
        width: 14.285714286%;
      }

      [part="weekday"]:empty,
      [part="week-numbers"] {
        width: 12.5%;
        flex-shrink: 0;
      }
    </style>

    <div part="month-header" role="heading">[[_getTitle(month, i18n.monthNames)]]</div>
    <div id="monthGrid" on-tap="_handleTap" on-touchend="_preventDefault" on-touchstart="_onMonthGridTouchStart">
      <div id="weekdays-container">
        <div hidden="[[!_showWeekSeparator(showWeekNumbers, i18n.firstDayOfWeek)]]" part="weekday"></div>
        <div part="weekdays">
          <template is="dom-repeat" items="[[_getWeekDayNames(i18n.weekdays, i18n.weekdaysShort, showWeekNumbers, i18n.firstDayOfWeek)]]">
            <div part="weekday" role="heading" aria-label\$="[[item.weekDay]]">[[item.weekDayShort]]</div>
          </template>
        </div>
      </div>
      <div id="days-container">
        <div part="week-numbers" hidden="[[!_showWeekSeparator(showWeekNumbers, i18n.firstDayOfWeek)]]">
          <template is="dom-repeat" items="[[_getWeekNumbers(_days)]]">
            <div part="week-number" role="heading" aria-label\$="[[i18n.week]] [[item]]">[[item]]</div>
          </template>
        </div>
        <div id="days">
          <template is="dom-repeat" items="[[_days]]">
            <div part="date" today\$="[[_isToday(item)]]" selected\$="[[_dateEquals(item, selectedDate)]]" focused\$="[[_dateEquals(item, focusedDate)]]" date="[[item]]" disabled\$="[[!_dateAllowed(item, minDate, maxDate)]]" role\$="[[_getRole(item)]]" aria-label\$="[[_getAriaLabel(item)]]" aria-disabled\$="[[_getAriaDisabled(item, minDate, maxDate)]]">[[_getDate(item)]]</div>
          </template>
        </div>
      </div>
    </div>
`}static get is(){return"vaadin-month-calendar"}static get properties(){return{month:{type:Date,value:new Date},selectedDate:{type:Date,notify:!0},focusedDate:Date,showWeekNumbers:{type:Boolean,value:!1},i18n:{type:Object},ignoreTaps:Boolean,_notTapping:Boolean,minDate:{type:Date,value:null},maxDate:{type:Date,value:null},_days:{type:Array,computed:"_getDays(month, i18n.firstDayOfWeek, minDate, maxDate)"},disabled:{type:Boolean,reflectToAttribute:!0,computed:"_isDisabled(month, minDate, maxDate)"}}}static get observers(){return["_showWeekNumbersChanged(showWeekNumbers, i18n.firstDayOfWeek)"]}_dateEquals(date1,date2){return DatePickerHelper._dateEquals(date1,date2)}_dateAllowed(date,min,max){return DatePickerHelper._dateAllowed(date,min,max)}_isDisabled(month,minDate,maxDate){var firstDate=new Date(0,0);firstDate.setFullYear(month.getFullYear());firstDate.setMonth(month.getMonth());firstDate.setDate(1);var lastDate=new Date(0,0);lastDate.setFullYear(month.getFullYear());lastDate.setMonth(month.getMonth()+1);lastDate.setDate(-1);if(minDate&&maxDate&&minDate.getMonth()===maxDate.getMonth()&&minDate.getMonth()===month.getMonth()&&0<=maxDate.getDate()-minDate.getDate()){return!1}return!this._dateAllowed(firstDate,minDate,maxDate)&&!this._dateAllowed(lastDate,minDate,maxDate)}_getTitle(month,monthNames){if(month===void 0||monthNames===void 0){return}return this.i18n.formatTitle(monthNames[month.getMonth()],month.getFullYear())}_onMonthGridTouchStart(){this._notTapping=!1;setTimeout(()=>this._notTapping=!0,300)}_dateAdd(date,delta){date.setDate(date.getDate()+delta)}_applyFirstDayOfWeek(weekDayNames,firstDayOfWeek){if(weekDayNames===void 0||firstDayOfWeek===void 0){return}return weekDayNames.slice(firstDayOfWeek).concat(weekDayNames.slice(0,firstDayOfWeek))}_getWeekDayNames(weekDayNames,weekDayNamesShort,showWeekNumbers,firstDayOfWeek){if(weekDayNames===void 0||weekDayNamesShort===void 0||showWeekNumbers===void 0||firstDayOfWeek===void 0){return}weekDayNames=this._applyFirstDayOfWeek(weekDayNames,firstDayOfWeek);weekDayNamesShort=this._applyFirstDayOfWeek(weekDayNamesShort,firstDayOfWeek);weekDayNames=weekDayNames.map((day,index)=>{return{weekDay:day,weekDayShort:weekDayNamesShort[index]}});return weekDayNames}_getDate(date){return date?date.getDate():""}_showWeekNumbersChanged(showWeekNumbers,firstDayOfWeek){if(showWeekNumbers&&1===firstDayOfWeek){this.setAttribute("week-numbers","")}else{this.removeAttribute("week-numbers")}}_showWeekSeparator(showWeekNumbers,firstDayOfWeek){return showWeekNumbers&&1===firstDayOfWeek}_isToday(date){return this._dateEquals(new Date,date)}_getDays(month,firstDayOfWeek){if(month===void 0||firstDayOfWeek===void 0){return}var date=new Date(0,0);date.setFullYear(month.getFullYear());date.setMonth(month.getMonth());date.setDate(1);while(date.getDay()!==firstDayOfWeek){this._dateAdd(date,-1)}var days=[],startMonth=date.getMonth(),targetMonth=month.getMonth();while(date.getMonth()===targetMonth||date.getMonth()===startMonth){days.push(date.getMonth()===targetMonth?new Date(date.getTime()):null);this._dateAdd(date,1)}return days}_getWeekNumber(date,days){if(date===void 0||days===void 0){return}if(!date){date=days.reduce((acc,d)=>{return!acc&&d?d:acc})}return DatePickerHelper._getISOWeekNumber(date)}_getWeekNumbers(dates){return dates.map(date=>this._getWeekNumber(date,dates)).filter((week,index,arr)=>arr.indexOf(week)===index)}_handleTap(e){if(!this.ignoreTaps&&!this._notTapping&&e.target.date&&!e.target.hasAttribute("disabled")){this.selectedDate=e.target.date;this.dispatchEvent(new CustomEvent("date-tap",{bubbles:!0,composed:!0}))}}_preventDefault(e){e.preventDefault()}_getRole(date){return date?"button":"presentation"}_getAriaLabel(date){if(!date){return""}var ariaLabel=this._getDate(date)+" "+this.i18n.monthNames[date.getMonth()]+" "+date.getFullYear()+", "+this.i18n.weekdays[date.getDay()];if(this._isToday(date)){ariaLabel+=", "+this.i18n.today}return ariaLabel}_getAriaDisabled(date,min,max){if(date===void 0||min===void 0||max===void 0){return}return this._dateAllowed(date,min,max)?"false":"true"}}customElements.define(vaadin_month_calendar_MonthCalendarElement.is,vaadin_month_calendar_MonthCalendarElement);var templatize=__webpack_require__(24),render_status=__webpack_require__(34);/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/class vaadin_infinite_scroller_InfiniteScrollerElement extends polymer_element.a{static get template(){return html_tag.a`
    <style>
      :host {
        display: block;
        overflow: hidden;
        height: 500px;
      }

      #scroller {
        position: relative;
        height: 100%;
        overflow: auto;
        outline: none;
        margin-right: -40px;
        -webkit-overflow-scrolling: touch;
        -ms-overflow-style: none;
        overflow-x: hidden;
      }

      #scroller.notouchscroll {
        -webkit-overflow-scrolling: auto;
      }

      #scroller::-webkit-scrollbar {
        display: none;
      }

      .buffer {
        position: absolute;
        width: var(--vaadin-infinite-scroller-buffer-width, 100%);
        box-sizing: border-box;
        padding-right: 40px;
        top: var(--vaadin-infinite-scroller-buffer-offset, 0);
        animation: fadein 0.2s;
      }

      @keyframes fadein {
        from { opacity: 0; }
        to { opacity: 1; }
      }
    </style>

    <div id="scroller" on-scroll="_scroll">
      <div class="buffer"></div>
      <div class="buffer"></div>
      <div id="fullHeight"></div>
    </div>
`}static get is(){return"vaadin-infinite-scroller"}static get properties(){return{bufferSize:{type:Number,value:20},_initialScroll:{value:5e5},_initialIndex:{value:0},_buffers:Array,_preventScrollEvent:Boolean,_mayHaveMomentum:Boolean,_initialized:Boolean,active:{type:Boolean,observer:"_activated"}}}ready(){super.ready();this._buffers=Array.prototype.slice.call(this.root.querySelectorAll(".buffer"));this.$.fullHeight.style.height=2*this._initialScroll+"px";var tpl=this.querySelector("template");this._TemplateClass=Object(templatize.b)(tpl,this,{forwardHostProp:function(prop,value){if("index"!==prop){this._buffers.forEach(buffer=>{[].forEach.call(buffer.children,insertionPoint=>{insertionPoint._itemWrapper.instance[prop]=value})})}}});var isFirefox=-1<navigator.userAgent.toLowerCase().indexOf("firefox");if(isFirefox){this.$.scroller.tabIndex=-1}}_activated(active){if(active&&!this._initialized){this._createPool();this._initialized=!0}}_finishInit(){if(!this._initDone){this._buffers.forEach(buffer=>{[].forEach.call(buffer.children,insertionPoint=>this._ensureStampedInstance(insertionPoint._itemWrapper))},this);if(!this._buffers[0].translateY){this._reset()}this._initDone=!0}}_translateBuffer(up){var index=up?1:0;this._buffers[index].translateY=this._buffers[index?0:1].translateY+this._bufferHeight*(index?-1:1);this._buffers[index].style.transform="translate3d(0, "+this._buffers[index].translateY+"px, 0)";this._buffers[index].updated=!1;this._buffers.reverse()}_scroll(){if(this._scrollDisabled){return}var scrollTop=this.$.scroller.scrollTop;if(scrollTop<this._bufferHeight||scrollTop>2*this._initialScroll-this._bufferHeight){this._initialIndex=~~this.position;this._reset()}var bufferOffset=this.root.querySelector(".buffer").offsetTop,upperThresholdReached=scrollTop>this._buffers[1].translateY+this.itemHeight+bufferOffset,lowerThresholdReached=scrollTop<this._buffers[0].translateY+this.itemHeight+bufferOffset;if(upperThresholdReached||lowerThresholdReached){this._translateBuffer(lowerThresholdReached);this._updateClones()}if(!this._preventScrollEvent){this.dispatchEvent(new CustomEvent("custom-scroll",{bubbles:!1,composed:!0}));this._mayHaveMomentum=!0}this._preventScrollEvent=!1;this._debouncerScrollFinish=debounce.a.debounce(this._debouncerScrollFinish,utils_async.d.after(200),()=>{var scrollerRect=this.$.scroller.getBoundingClientRect();if(!this._isVisible(this._buffers[0],scrollerRect)&&!this._isVisible(this._buffers[1],scrollerRect)){this.position=this.position}})}set position(index){this._preventScrollEvent=!0;if(index>this._firstIndex&&index<this._firstIndex+2*this.bufferSize){this.$.scroller.scrollTop=this.itemHeight*(index-this._firstIndex)+this._buffers[0].translateY}else{this._initialIndex=~~index;this._reset();this._scrollDisabled=!0;this.$.scroller.scrollTop+=index%1*this.itemHeight;this._scrollDisabled=!1}if(this._mayHaveMomentum){this.$.scroller.classList.add("notouchscroll");this._mayHaveMomentum=!1;setTimeout(()=>{this.$.scroller.classList.remove("notouchscroll")},10)}}get position(){return(this.$.scroller.scrollTop-this._buffers[0].translateY)/this.itemHeight+this._firstIndex}get itemHeight(){if(!this._itemHeightVal){const itemHeight=window.ShadyCSS?window.ShadyCSS.getComputedStyleValue(this,"--vaadin-infinite-scroller-item-height"):getComputedStyle(this).getPropertyValue("--vaadin-infinite-scroller-item-height"),tmpStyleProp="background-position";this.$.fullHeight.style.setProperty(tmpStyleProp,itemHeight);const itemHeightPx=getComputedStyle(this.$.fullHeight).getPropertyValue(tmpStyleProp);this.$.fullHeight.style.removeProperty(tmpStyleProp);this._itemHeightVal=parseFloat(itemHeightPx)}return this._itemHeightVal}get _bufferHeight(){return this.itemHeight*this.bufferSize}_reset(){this._scrollDisabled=!0;this.$.scroller.scrollTop=this._initialScroll;this._buffers[0].translateY=this._initialScroll-this._bufferHeight;this._buffers[1].translateY=this._initialScroll;this._buffers.forEach(buffer=>{buffer.style.transform="translate3d(0, "+buffer.translateY+"px, 0)"});this._buffers[0].updated=this._buffers[1].updated=!1;this._updateClones(!0);this._debouncerUpdateClones=debounce.a.debounce(this._debouncerUpdateClones,utils_async.d.after(200),()=>{this._buffers[0].updated=this._buffers[1].updated=!1;this._updateClones()});this._scrollDisabled=!1}_createPool(){var container=this.getBoundingClientRect();this._buffers.forEach(buffer=>{for(var i=0;i<this.bufferSize;i++){const itemWrapper=document.createElement("div");itemWrapper.style.height=this.itemHeight+"px";itemWrapper.instance={};const contentId=vaadin_infinite_scroller_InfiniteScrollerElement._contentIndex=vaadin_infinite_scroller_InfiniteScrollerElement._contentIndex+1||0,slotName="vaadin-infinite-scroller-item-content-"+contentId,insertionPoint=document.createElement("slot");insertionPoint.setAttribute("name",slotName);insertionPoint._itemWrapper=itemWrapper;buffer.appendChild(insertionPoint);itemWrapper.setAttribute("slot",slotName);this.appendChild(itemWrapper);Object(flush.b)();setTimeout(()=>{if(this._isVisible(itemWrapper,container)){this._ensureStampedInstance(itemWrapper)}},1)}},this);setTimeout(()=>{Object(render_status.a)(this,this._finishInit.bind(this))},1)}_ensureStampedInstance(itemWrapper){if(itemWrapper.firstElementChild){return}var tmpInstance=itemWrapper.instance;itemWrapper.instance=new this._TemplateClass({});itemWrapper.appendChild(itemWrapper.instance.root);Object.keys(tmpInstance).forEach(prop=>{itemWrapper.instance.set(prop,tmpInstance[prop])})}_updateClones(viewPortOnly){this._firstIndex=~~((this._buffers[0].translateY-this._initialScroll)/this.itemHeight)+this._initialIndex;var scrollerRect=viewPortOnly?this.$.scroller.getBoundingClientRect():void 0;this._buffers.forEach((buffer,bufferIndex)=>{if(!buffer.updated){var firstIndex=this._firstIndex+this.bufferSize*bufferIndex;[].forEach.call(buffer.children,(insertionPoint,index)=>{const itemWrapper=insertionPoint._itemWrapper;if(!viewPortOnly||this._isVisible(itemWrapper,scrollerRect)){itemWrapper.instance.index=firstIndex+index}});buffer.updated=!0}},this)}_isVisible(element,container){var rect=element.getBoundingClientRect();return rect.bottom>container.top&&rect.top<container.bottom}}customElements.define(vaadin_infinite_scroller_InfiniteScrollerElement.is,vaadin_infinite_scroller_InfiniteScrollerElement);__webpack_require__(85);const src_vaadin_date_picker_styles_$_documentContainer=document.createElement("template");src_vaadin_date_picker_styles_$_documentContainer.innerHTML=`<custom-style>
  <style>
    @font-face {
      font-family: 'vaadin-date-picker-icons';
      src: url(data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAYoAAsAAAAABdwAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABPUy8yAAABCAAAAGAAAABgDxIFqWNtYXAAAAFoAAAAVAAAAFQXVtKKZ2FzcAAAAbwAAAAIAAAACAAAABBnbHlmAAABxAAAAUAAAAFAAtWm1WhlYWQAAAMEAAAANgAAADYNRs5taGhlYQAAAzwAAAAkAAAAJAdCA8lobXR4AAADYAAAACAAAAAgFW4CxGxvY2EAAAOAAAAAEgAAABIBEgDCbWF4cAAAA5QAAAAgAAAAIAAMACNuYW1lAAADtAAAAlIAAAJSbLEfa3Bvc3QAAAYIAAAAIAAAACAAAwAAAAMDfAGQAAUAAAKZAswAAACPApkCzAAAAesAMwEJAAAAAAAAAAAAAAAAAAAAARAAAAAAAAAAAAAAAAAAAAAAQAAA6QMDwP/AAEADwABAAAAAAQAAAAAAAAAAAAAAIAAAAAAAAwAAAAMAAAAcAAEAAwAAABwAAwABAAAAHAAEADgAAAAKAAgAAgACAAEAIOkD//3//wAAAAAAIOkA//3//wAB/+MXBAADAAEAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQFvAKsCqwKrAAUAAAEHFwcXAQGrPMPDPAEAAqs8xMQ8AQAAAQDVAIADKwLVAAsAAAEnBycHFwcXNxc3JwMrPO/vPO/vPO/vPO8CmTzu7jzu7zzv7zzvAAMAgAArA4ADgAADABwAIAAAASMVMwMVITUjFSMiBhURFBYzITI2NRE0JisBNSMTIREhAtXV1Sr+qlUrIzIyIwJWIzIyIytVgP2qAlYBq9YCq1VVVTIk/asjMjIjAlUkMlX9AAHVAAAAAQAAAAADbgNuABMAAAEUDgIjIi4CNTQ+AjMyHgIDbkV3oFtboHdFRXegW1ugd0UBt1ugd0VFd6BbW6B3RUV3oAAAAAABAAAAAQAAvCcusV8PPPUACwQAAAAAANVURPgAAAAA1VRE+AAAAAADgAOAAAAACAACAAAAAAAAAAEAAAPA/8AAAAQAAAAAAAOAAAEAAAAAAAAAAAAAAAAAAAAIBAAAAAAAAAAAAAAAAgAAAAQAAW8EAADVBAAAgANuAAAAAAAAAAoAFAAeADAASgB+AKAAAAABAAAACAAhAAMAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAADgCuAAEAAAAAAAEAGAAAAAEAAAAAAAIABwD5AAEAAAAAAAMAGABpAAEAAAAAAAQAGAEOAAEAAAAAAAUACwBIAAEAAAAAAAYAGACxAAEAAAAAAAoAGgFWAAMAAQQJAAEAMAAYAAMAAQQJAAIADgEAAAMAAQQJAAMAMACBAAMAAQQJAAQAMAEmAAMAAQQJAAUAFgBTAAMAAQQJAAYAMADJAAMAAQQJAAoANAFwdmFhZGluLWRhdGUtcGlja2VyLWljb25zAHYAYQBhAGQAaQBuAC0AZABhAHQAZQAtAHAAaQBjAGsAZQByAC0AaQBjAG8AbgBzVmVyc2lvbiAxLjAAVgBlAHIAcwBpAG8AbgAgADEALgAwdmFhZGluLWRhdGUtcGlja2VyLWljb25zAHYAYQBhAGQAaQBuAC0AZABhAHQAZQAtAHAAaQBjAGsAZQByAC0AaQBjAG8AbgBzdmFhZGluLWRhdGUtcGlja2VyLWljb25zAHYAYQBhAGQAaQBuAC0AZABhAHQAZQAtAHAAaQBjAGsAZQByAC0AaQBjAG8AbgBzUmVndWxhcgBSAGUAZwB1AGwAYQBydmFhZGluLWRhdGUtcGlja2VyLWljb25zAHYAYQBhAGQAaQBuAC0AZABhAHQAZQAtAHAAaQBjAGsAZQByAC0AaQBjAG8AbgBzRm9udCBnZW5lcmF0ZWQgYnkgSWNvTW9vbi4ARgBvAG4AdAAgAGcAZQBuAGUAcgBhAHQAZQBkACAAYgB5ACAASQBjAG8ATQBvAG8AbgAuAAAAAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==) format('woff');
      font-weight: normal;
      font-style: normal;
    }
  </style>
</custom-style><dom-module id="vaadin-date-picker-overlay-styles" theme-for="vaadin-date-picker-overlay">
  <template>
    <style>
      :host {
        align-items: flex-start;
        justify-content: flex-start;
      }

      :host([bottom-aligned]) {
        justify-content: flex-end;
      }

      :host([right-aligned]) {
        align-items: flex-end;
      }

      [part="overlay"] {
        display: flex;
        flex: auto;
      }

      [part~="content"] {
        flex: auto;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild(src_vaadin_date_picker_styles_$_documentContainer.content);/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/class vaadin_date_picker_overlay_content_DatePickerOverlayContentElement extends Object(vaadin_themable_mixin.a)(Object(vaadin_theme_property_mixin.a)(Object(gesture_event_listeners.a)(polymer_element.a))){static get template(){return html_tag.a`
    <style>
      :host {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        outline: none;
        background: #fff;
      }

      [part="overlay-header"] {
        display: flex;
        flex-shrink: 0;
        flex-wrap: nowrap;
        align-items: center;
      }

      :host(:not([fullscreen])) [part="overlay-header"] {
        display: none;
      }

      [part="label"] {
        flex-grow: 1;
      }

      [part="clear-button"],
      [part="toggle-button"],
      [part="years-toggle-button"]::before {
        font-family: 'vaadin-date-picker-icons';
      }

      [part="clear-button"]:not([showclear]) {
        display: none;
      }

      [part="clear-button"]::before {
        content: "\\e901";
      }

      [part="toggle-button"]::before {
        content: "\\e902";
      }

      [part="years-toggle-button"] {
        display: flex;
      }

      [part="years-toggle-button"][desktop] {
        display: none;
      }

      [part="years-toggle-button"]::before {
        content: "\\e900";
      }

      :host(:not([years-visible])) [part="years-toggle-button"]::before {
        transform: rotate(180deg);
      }

      #scrollers {
        display: flex;
        height: 100%;
        width: 100%;
        position: relative;
        overflow: hidden;
      }

      [part="months"],
      [part="years"] {
        height: 100%;
      }

      [part="months"] {
        --vaadin-infinite-scroller-item-height: 270px;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
      }

      #scrollers[desktop] [part="months"] {
        right: 50px;
        transform: none !important;
      }

      [part="years"] {
        --vaadin-infinite-scroller-item-height: 80px;
        width: 50px;
        position: absolute;
        right: 0;
        transform: translateX(100%);
        -webkit-tap-highlight-color: transparent;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        /* Center the year scroller position. */
        --vaadin-infinite-scroller-buffer-offset: 50%;
      }

      #scrollers[desktop] [part="years"] {
        position: absolute;
        transform: none !important;
      }

      [part="years"]::before {
        content: '';
        display: block;
        background: transparent;
        width: 0;
        height: 0;
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        border-width: 6px;
        border-style: solid;
        border-color: transparent;
        border-left-color: #000;
      }

      :host(.animate) [part="months"],
      :host(.animate) [part="years"] {
        transition: all 200ms;
      }

      [part="toolbar"] {
        display: flex;
        justify-content: space-between;
        z-index: 2;
        flex-shrink: 0;
      }

      [part~="overlay-header"]:not([desktop]) {
        padding-bottom: 40px;
      }

      [part~="years-toggle-button"] {
        position: absolute;
        top: auto;
        right: 8px;
        bottom: 0;
        z-index: 1;
        padding: 8px;
      }

      #announcer {
        display: inline-block;
        position: fixed;
        clip: rect(0, 0, 0, 0);
        clip-path: inset(100%);
      }
    </style>

    <div id="announcer" role="alert" aria-live="polite">
      [[i18n.calendar]]
    </div>

    <div part="overlay-header" on-touchend="_preventDefault" desktop\$="[[_desktopMode]]" aria-hidden="true">
      <div part="label">[[_formatDisplayed(selectedDate, i18n.formatDate, label)]]</div>
      <div part="clear-button" on-tap="_clear" showclear\$="[[_showClear(selectedDate)]]"></div>
      <div part="toggle-button" on-tap="_cancel"></div>

      <div part="years-toggle-button" desktop\$="[[_desktopMode]]" on-tap="_toggleYearScroller" aria-hidden="true">
        [[_yearAfterXMonths(_visibleMonthIndex)]]
      </div>
    </div>

    <div id="scrollers" desktop\$="[[_desktopMode]]" on-track="_track">
      <vaadin-infinite-scroller id="monthScroller" on-custom-scroll="_onMonthScroll" on-touchstart="_onMonthScrollTouchStart" buffer-size="3" active="[[initialPosition]]" part="months">
        <template>
          <vaadin-month-calendar i18n="[[i18n]]" month="[[_dateAfterXMonths(index)]]" selected-date="{{selectedDate}}" focused-date="[[focusedDate]]" ignore-taps="[[_ignoreTaps]]" show-week-numbers="[[showWeekNumbers]]" min-date="[[minDate]]" max-date="[[maxDate]]" focused\$="[[_focused]]" part="month" theme\$="[[theme]]">
          </vaadin-month-calendar>
        </template>
      </vaadin-infinite-scroller>
      <vaadin-infinite-scroller id="yearScroller" on-tap="_onYearTap" on-custom-scroll="_onYearScroll" on-touchstart="_onYearScrollTouchStart" buffer-size="12" active="[[initialPosition]]" part="years">
        <template>
          <div part="year-number" role="button" current\$="[[_isCurrentYear(index)]]" selected\$="[[_isSelectedYear(index, selectedDate)]]">
            [[_yearAfterXYears(index)]]
          </div>
          <div part="year-separator" aria-hidden="true"></div>
        </template>
      </vaadin-infinite-scroller>
    </div>

    <div on-touchend="_preventDefault" role="toolbar" part="toolbar">
      <vaadin-button id="todayButton" part="today-button" disabled="[[!_isTodayAllowed(minDate, maxDate)]]" on-tap="_onTodayTap">
        [[i18n.today]]
      </vaadin-button>
      <vaadin-button id="cancelButton" part="cancel-button" on-tap="_cancel">
        [[i18n.cancel]]
      </vaadin-button>
    </div>

    <iron-media-query query="(min-width: 375px)" query-matches="{{_desktopMode}}"></iron-media-query>
`}static get is(){return"vaadin-date-picker-overlay-content"}static get properties(){return{selectedDate:{type:Date,notify:!0},focusedDate:{type:Date,notify:!0,observer:"_focusedDateChanged"},_focusedMonthDate:Number,initialPosition:{type:Date,observer:"_initialPositionChanged"},_originDate:{value:new Date},_visibleMonthIndex:Number,_desktopMode:Boolean,_translateX:{observer:"_translateXChanged"},_yearScrollerWidth:{value:50},i18n:{type:Object},showWeekNumbers:{type:Boolean},_ignoreTaps:Boolean,_notTapping:Boolean,minDate:Date,maxDate:Date,_focused:Boolean,label:String}}ready(){super.ready();this.setAttribute("tabindex",0);this.addEventListener("keydown",this._onKeydown.bind(this));Object(gestures.b)(this,"tap",this._stopPropagation);this.addEventListener("focus",this._onOverlayFocus.bind(this));this.addEventListener("blur",this._onOverlayBlur.bind(this))}connectedCallback(){super.connectedCallback();this._closeYearScroller();this._toggleAnimateClass(!0);Object(gestures.f)(this.$.scrollers,"pan-y");iron_a11y_announcer.a.requestAvailability()}announceFocusedDate(){var focusedDate=this._currentlyFocusedDate(),announce=[];if(DatePickerHelper._dateEquals(focusedDate,new Date)){announce.push(this.i18n.today)}announce=announce.concat([this.i18n.weekdays[focusedDate.getDay()],focusedDate.getDate(),this.i18n.monthNames[focusedDate.getMonth()],focusedDate.getFullYear()]);if(this.showWeekNumbers&&1===this.i18n.firstDayOfWeek){announce.push(this.i18n.week);announce.push(DatePickerHelper._getISOWeekNumber(focusedDate))}this.dispatchEvent(new CustomEvent("iron-announce",{bubbles:!0,composed:!0,detail:{text:announce.join(" ")}}))}focusCancel(){this.$.cancelButton.focus()}scrollToDate(date,animate){this._scrollToPosition(this._differenceInMonths(date,this._originDate),animate)}_focusedDateChanged(focusedDate){this.revealDate(focusedDate)}_isCurrentYear(yearsFromNow){return 0===yearsFromNow}_isSelectedYear(yearsFromNow,selectedDate){if(selectedDate){return selectedDate.getFullYear()===this._originDate.getFullYear()+yearsFromNow}}revealDate(date){if(date){var diff=this._differenceInMonths(date,this._originDate),scrolledAboveViewport=this.$.monthScroller.position>diff,visibleItems=this.$.monthScroller.clientHeight/this.$.monthScroller.itemHeight,scrolledBelowViewport=this.$.monthScroller.position+visibleItems-1<diff;if(scrolledAboveViewport){this._scrollToPosition(diff,!0)}else if(scrolledBelowViewport){this._scrollToPosition(diff-visibleItems+1,!0)}}}_onOverlayFocus(){this._focused=!0}_onOverlayBlur(){this._focused=!1}_initialPositionChanged(initialPosition){this.scrollToDate(initialPosition)}_repositionYearScroller(){this._visibleMonthIndex=_Mathfloor3(this.$.monthScroller.position);this.$.yearScroller.position=(this.$.monthScroller.position+this._originDate.getMonth())/12}_repositionMonthScroller(){this.$.monthScroller.position=12*this.$.yearScroller.position-this._originDate.getMonth();this._visibleMonthIndex=_Mathfloor3(this.$.monthScroller.position)}_onMonthScroll(){this._repositionYearScroller();this._doIgnoreTaps()}_onYearScroll(){this._repositionMonthScroller();this._doIgnoreTaps()}_onYearScrollTouchStart(){this._notTapping=!1;setTimeout(()=>this._notTapping=!0,300);this._repositionMonthScroller()}_onMonthScrollTouchStart(){this._repositionYearScroller()}_doIgnoreTaps(){this._ignoreTaps=!0;this._debouncer=debounce.a.debounce(this._debouncer,utils_async.d.after(300),()=>this._ignoreTaps=!1)}_formatDisplayed(date,formatDate,label){if(date){return formatDate(DatePickerHelper._extractDateParts(date))}else{return label}}_onTodayTap(){var today=new Date;if(this.$.monthScroller.position===this._differenceInMonths(today,this._originDate)){this.selectedDate=today;this._close()}else{this._scrollToCurrentMonth()}}_scrollToCurrentMonth(){if(this.focusedDate){this.focusedDate=new Date}this.scrollToDate(new Date,!0)}_showClear(selectedDate){return!!selectedDate}_onYearTap(e){if(!this._ignoreTaps&&!this._notTapping){var scrollDelta=e.detail.y-(this.$.yearScroller.getBoundingClientRect().top+this.$.yearScroller.clientHeight/2),yearDelta=scrollDelta/this.$.yearScroller.itemHeight;this._scrollToPosition(this.$.monthScroller.position+12*yearDelta,!0)}}_scrollToPosition(targetPosition,animate){if(this._targetPosition!==void 0){this._targetPosition=targetPosition;return}if(!animate){this.$.monthScroller.position=targetPosition;this._targetPosition=void 0;this._repositionYearScroller();return}this._targetPosition=targetPosition;var easingFunction=(t,b,c,d)=>{t/=d/2;if(1>t){return c/2*t*t+b}t--;return-c/2*(t*(t-2)-1)+b},duration=animate?300:0,start=0,initialPosition=this.$.monthScroller.position,smoothScroll=timestamp=>{start=start||timestamp;var currentTime=timestamp-start;if(currentTime<duration){var currentPos=easingFunction(currentTime,initialPosition,this._targetPosition-initialPosition,duration);this.$.monthScroller.position=currentPos;window.requestAnimationFrame(smoothScroll)}else{this.dispatchEvent(new CustomEvent("scroll-animation-finished",{bubbles:!0,composed:!0,detail:{position:this._targetPosition,oldPosition:initialPosition}}));this.$.monthScroller.position=this._targetPosition;this._targetPosition=void 0}setTimeout(this._repositionYearScroller.bind(this),1)};window.requestAnimationFrame(smoothScroll)}_limit(value,range){return _Mathmin(range.max,Math.max(range.min,value))}_handleTrack(e){if(10>_Mathabs2(e.detail.dx)||10<_Mathabs2(e.detail.ddy)){return}if(_Mathabs2(e.detail.ddx)>this._yearScrollerWidth/3){this._toggleAnimateClass(!0)}var newTranslateX=this._translateX+e.detail.ddx;this._translateX=this._limit(newTranslateX,{min:0,max:this._yearScrollerWidth})}_track(e){if(this._desktopMode){return}switch(e.detail.state){case"start":this._toggleAnimateClass(!1);break;case"track":this._handleTrack(e);break;case"end":this._toggleAnimateClass(!0);if(this._translateX>=this._yearScrollerWidth/2){this._closeYearScroller()}else{this._openYearScroller()}break;}}_toggleAnimateClass(enable){if(enable){this.classList.add("animate")}else{this.classList.remove("animate")}}_toggleYearScroller(){this._isYearScrollerVisible()?this._closeYearScroller():this._openYearScroller()}_openYearScroller(){this._translateX=0;this.setAttribute("years-visible","")}_closeYearScroller(){this.removeAttribute("years-visible");this._translateX=this._yearScrollerWidth}_isYearScrollerVisible(){return this._translateX<this._yearScrollerWidth/2}_translateXChanged(x){if(!this._desktopMode){this.$.monthScroller.style.transform="translateX("+(x-this._yearScrollerWidth)+"px)";this.$.yearScroller.style.transform="translateX("+x+"px)"}}_yearAfterXYears(index){var result=new Date(this._originDate);result.setFullYear(parseInt(index)+this._originDate.getFullYear());return result.getFullYear()}_yearAfterXMonths(months){return this._dateAfterXMonths(months).getFullYear()}_dateAfterXMonths(months){var result=new Date(this._originDate);result.setDate(1);result.setMonth(parseInt(months)+this._originDate.getMonth());return result}_differenceInMonths(date1,date2){var months=12*(date1.getFullYear()-date2.getFullYear());return months-date2.getMonth()+date1.getMonth()}_differenceInYears(date1,date2){return this._differenceInMonths(date1,date2)/12}_clear(){this.selectedDate=""}_close(){const overlayContent=this.getRootNode().host,overlay=overlayContent?overlayContent.getRootNode().host:null;if(overlay){overlay.opened=!1}this.dispatchEvent(new CustomEvent("close",{bubbles:!0,composed:!0}))}_cancel(){this.focusedDate=this.selectedDate;this._close()}_preventDefault(e){e.preventDefault()}_eventKey(e){for(var keys=["down","up","right","left","enter","space","home","end","pageup","pagedown","tab","esc"],i=0,k;i<keys.length;i++){k=keys[i];if(iron_a11y_keys_behavior.a.keyboardEventMatchesKeys(e,k)){return k}}}_onKeydown(e){var focus=this._currentlyFocusedDate();const isToday=0<=e.composedPath().indexOf(this.$.todayButton),isCancel=0<=e.composedPath().indexOf(this.$.cancelButton),isScroller=!isToday&&!isCancel;var eventKey=this._eventKey(e);if("tab"===eventKey){e.stopPropagation();const isFullscreen=this.hasAttribute("fullscreen"),isShift=e.shiftKey;if(isFullscreen){e.preventDefault()}else if(isShift&&isScroller||!isShift&&isCancel){e.preventDefault();this.dispatchEvent(new CustomEvent("focus-input",{bubbles:!0,composed:!0}))}else if(isShift&&isToday){this._focused=!0;setTimeout(()=>this.revealDate(this.focusedDate),1)}else{this._focused=!1}}else if(eventKey){e.preventDefault();e.stopPropagation();switch(eventKey){case"down":this._moveFocusByDays(7);this.focus();break;case"up":this._moveFocusByDays(-7);this.focus();break;case"right":if(isScroller){this._moveFocusByDays(1)}break;case"left":if(isScroller){this._moveFocusByDays(-1)}break;case"enter":if(isScroller||isCancel){this._close()}else if(isToday){this._onTodayTap()}break;case"space":if(isCancel){this._close()}else if(isToday){this._onTodayTap()}else{var focusedDate=this.focusedDate;if(DatePickerHelper._dateEquals(focusedDate,this.selectedDate)){this.selectedDate="";this.focusedDate=focusedDate}else{this.selectedDate=focusedDate}}break;case"home":this._moveFocusInsideMonth(focus,"minDate");break;case"end":this._moveFocusInsideMonth(focus,"maxDate");break;case"pagedown":this._moveFocusByMonths(e.shiftKey?12:1);break;case"pageup":this._moveFocusByMonths(e.shiftKey?-12:-1);break;case"esc":this._cancel();break;}}}_currentlyFocusedDate(){return this.focusedDate||this.selectedDate||this.initialPosition||new Date}_focusDate(dateToFocus){this.focusedDate=dateToFocus;this._focusedMonthDate=dateToFocus.getDate()}_focusClosestDate(focus){this._focusDate(DatePickerHelper._getClosestDate(focus,[this.minDate,this.maxDate]))}_moveFocusByDays(days){var focus=this._currentlyFocusedDate(),dateToFocus=new Date(0,0);dateToFocus.setFullYear(focus.getFullYear());dateToFocus.setMonth(focus.getMonth());dateToFocus.setDate(focus.getDate()+days);if(this._dateAllowed(dateToFocus,this.minDate,this.maxDate)){this._focusDate(dateToFocus)}else{if(this._dateAllowed(focus,this.minDate,this.maxDate)){if(0<days){this._focusDate(this.maxDate)}else{this._focusDate(this.minDate)}}else{this._focusClosestDate(focus)}}}_moveFocusByMonths(months){var focus=this._currentlyFocusedDate(),dateToFocus=new Date(0,0);dateToFocus.setFullYear(focus.getFullYear());dateToFocus.setMonth(focus.getMonth()+months);var targetMonth=dateToFocus.getMonth();dateToFocus.setDate(this._focusedMonthDate||(this._focusedMonthDate=focus.getDate()));if(dateToFocus.getMonth()!==targetMonth){dateToFocus.setDate(0)}if(this._dateAllowed(dateToFocus,this.minDate,this.maxDate)){this.focusedDate=dateToFocus}else{if(this._dateAllowed(focus,this.minDate,this.maxDate)){if(0<months){this._focusDate(this.maxDate)}else{this._focusDate(this.minDate)}}else{this._focusClosestDate(focus)}}}_moveFocusInsideMonth(focusedDate,property){var dateToFocus=new Date(0,0);dateToFocus.setFullYear(focusedDate.getFullYear());if("minDate"===property){dateToFocus.setMonth(focusedDate.getMonth());dateToFocus.setDate(1)}else{dateToFocus.setMonth(focusedDate.getMonth()+1);dateToFocus.setDate(0)}if(this._dateAllowed(dateToFocus,this.minDate,this.maxDate)){this._focusDate(dateToFocus)}else{if(this._dateAllowed(focusedDate,this.minDate,this.maxDate)){this._focusDate(this[property])}else{this._focusClosestDate(focusedDate)}}}_dateAllowed(date,min,max){return(!min||date>=min)&&(!max||date<=max)}_isTodayAllowed(min,max){var today=new Date,todayMidnight=new Date(0,0);todayMidnight.setFullYear(today.getFullYear());todayMidnight.setMonth(today.getMonth());todayMidnight.setDate(today.getDate());return this._dateAllowed(todayMidnight,min,max)}_stopPropagation(e){e.stopPropagation()}}customElements.define(vaadin_date_picker_overlay_content_DatePickerOverlayContentElement.is,vaadin_date_picker_overlay_content_DatePickerOverlayContentElement);var iron_resizable_behavior=__webpack_require__(84),legacy_class=__webpack_require__(62);/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/const DatePickerMixin=subclass=>class extends Object(legacy_class.b)([iron_resizable_behavior.a],subclass){static get properties(){return{_selectedDate:{type:Date},_focusedDate:Date,value:{type:String,observer:"_valueChanged",notify:!0,value:""},required:{type:Boolean,value:!1},name:{type:String},initialPosition:String,label:String,opened:{type:Boolean,reflectToAttribute:!0,notify:!0,observer:"_openedChanged"},showWeekNumbers:{type:Boolean},_fullscreen:{value:!1,observer:"_fullscreenChanged"},_fullscreenMediaQuery:{value:"(max-width: 420px), (max-height: 420px)"},_touchPrevented:Array,i18n:{type:Object,value:()=>{return{monthNames:["January","February","March","April","May","June","July","August","September","October","November","December"],weekdays:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],weekdaysShort:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],firstDayOfWeek:0,week:"Week",calendar:"Calendar",clear:"Clear",today:"Today",cancel:"Cancel",formatDate:d=>{const yearStr=(d.year+"").replace(/\d+/,y=>"0000".substr(y.length)+y);return[d.month+1,d.day,yearStr].join("/")},parseDate:text=>{const parts=text.split("/"),today=new Date;let date,month=today.getMonth(),year=today.getFullYear();if(3===parts.length){year=parseInt(parts[2]);if(3>parts[2].length&&0<=year){year+=50>year?2e3:1900}month=parseInt(parts[0])-1;date=parseInt(parts[1])}else if(2===parts.length){month=parseInt(parts[0])-1;date=parseInt(parts[1])}else if(1===parts.length){date=parseInt(parts[0])}if(date!==void 0){return{day:date,month,year}}},formatTitle:(monthName,fullYear)=>{return monthName+" "+fullYear}}}},min:{type:String,observer:"_minChanged"},max:{type:String,observer:"_maxChanged"},_minDate:{type:Date,value:""},_maxDate:{type:Date,value:""},_noInput:{type:Boolean,computed:"_isNoInput(_fullscreen, _ios, i18n, i18n.*)"},_ios:{type:Boolean,value:navigator.userAgent.match(/iP(?:hone|ad;(?: U;)? CPU) OS (\d+)/)},_webkitOverflowScroll:{type:Boolean,value:""===document.createElement("div").style.webkitOverflowScrolling},_ignoreAnnounce:{value:!0},_focusOverlayOnOpen:Boolean}}static get observers(){return["_updateHasValue(value)","_validateInput(_selectedDate, _minDate, _maxDate)","_selectedDateChanged(_selectedDate, i18n.formatDate)","_focusedDateChanged(_focusedDate, i18n.formatDate)","_announceFocusedDate(_focusedDate, opened, _ignoreAnnounce)"]}ready(){super.ready();this._boundOnScroll=this._onScroll.bind(this);this._boundFocus=this._focus.bind(this);this._boundUpdateAlignmentAndPosition=this._updateAlignmentAndPosition.bind(this);Object(gestures.b)(this,"tap",this.open);this.addEventListener("touchend",this._preventDefault.bind(this));this.addEventListener("keydown",this._onKeydown.bind(this));this._overlayContent.addEventListener("close",this._close.bind(this));this._overlayContent.addEventListener("focus-input",this._focusAndSelect.bind(this));this.addEventListener("input",this._onUserInput.bind(this));this.addEventListener("focus",e=>this._noInput&&e.target.blur())}connectedCallback(){super.connectedCallback();this.$.overlay.addEventListener("vaadin-overlay-escape-press",this._boundFocus)}disconnectedCallback(){super.disconnectedCallback();this.$.overlay.removeEventListener("vaadin-overlay-escape-press",this._boundFocus);this.opened=!1}open(){if(!this.disabled&&!this.readonly){this.$.overlay.opened=!0}}_close(e){if(e){e.stopPropagation()}this._focus();this.close()}close(){this.$.overlay.close()}get _inputElement(){return this._input()}get _nativeInput(){if(this._inputElement){return this._inputElement.focusElement?this._inputElement.focusElement:this._inputElement.inputElement?this._inputElement.inputElement:window.unwrap?window.unwrap(this._inputElement):this._inputElement}}_parseDate(str){var parts=/^([-+]\d{1}|\d{2,4}|[-+]\d{6})-(\d{1,2})-(\d{1,2})$/.exec(str);if(!parts){return}var date=new Date(0,0);date.setFullYear(parseInt(parts[1],10));date.setMonth(parseInt(parts[2],10)-1);date.setDate(parseInt(parts[3],10));return date}_isNoInput(fullscreen,ios,i18n){return!this._inputElement||fullscreen||ios||!i18n.parseDate}_formatISO(date){if(!(date instanceof Date)){return""}const pad=(num,fmt="00")=>(fmt+num).substr((fmt+num).length-fmt.length);let yearSign="",yearFmt="0000",yearAbs=date.getFullYear();if(0>yearAbs){yearAbs=-yearAbs;yearSign="-";yearFmt="000000"}else if(1e4<=date.getFullYear()){yearSign="+";yearFmt="000000"}const year=yearSign+pad(yearAbs,yearFmt),month=pad(date.getMonth()+1),day=pad(date.getDate());return[year,month,day].join("-")}_openedChanged(opened){if(!opened){return}this._updateAlignmentAndPosition()}_selectedDateChanged(selectedDate,formatDate){if(selectedDate===void 0||formatDate===void 0){return}if(this.__userInputOccurred){this.__dispatchChange=!0}const inputValue=selectedDate&&formatDate(DatePickerHelper._extractDateParts(selectedDate)),value=this._formatISO(selectedDate);if(value!==this.value){this.validate(inputValue);this.value=value}this.__userInputOccurred=!1;this.__dispatchChange=!1;this._focusedDate=selectedDate;this._inputValue=selectedDate?inputValue:""}_focusedDateChanged(focusedDate,formatDate){if(focusedDate===void 0||formatDate===void 0){return}this.__userInputOccurred=!0;if(!this._ignoreFocusedDateChange&&!this._noInput){this._inputValue=focusedDate?formatDate(DatePickerHelper._extractDateParts(focusedDate)):""}}_updateHasValue(value){if(value){this.setAttribute("has-value","")}else{this.removeAttribute("has-value")}}_handleDateChange(property,value,oldValue){if(!value){this[property]="";return}var date=this._parseDate(value);if(!date){this.value=oldValue;return}if(!DatePickerHelper._dateEquals(this[property],date)){this[property]=date}}_valueChanged(value,oldValue){if(this.__dispatchChange){this.dispatchEvent(new CustomEvent("change",{bubbles:!0}))}this._handleDateChange("_selectedDate",value,oldValue)}_minChanged(value,oldValue){this._handleDateChange("_minDate",value,oldValue)}_maxChanged(value,oldValue){this._handleDateChange("_maxDate",value,oldValue)}_updateAlignmentAndPosition(){if(!this._fullscreen){const inputRect=this._inputElement.getBoundingClientRect(),bottomAlign=inputRect.top>window.innerHeight/2,rightAlign=inputRect.left+this.clientWidth/2>window.innerWidth/2;if(rightAlign){const viewportWidth=_Mathmin(window.innerWidth,document.documentElement.clientWidth);this.$.overlay.setAttribute("right-aligned","");this.$.overlay.style.removeProperty("left");this.$.overlay.style.right=viewportWidth-inputRect.right+"px"}else{this.$.overlay.removeAttribute("right-aligned");this.$.overlay.style.removeProperty("right");this.$.overlay.style.left=inputRect.left+"px"}if(bottomAlign){const viewportHeight=_Mathmin(window.innerHeight,document.documentElement.clientHeight);this.$.overlay.setAttribute("bottom-aligned","");this.$.overlay.style.removeProperty("top");this.$.overlay.style.bottom=viewportHeight-inputRect.top+"px"}else{this.$.overlay.removeAttribute("bottom-aligned");this.$.overlay.style.removeProperty("bottom");this.$.overlay.style.top=inputRect.bottom+"px"}}this._overlayContent._repositionYearScroller()}_fullscreenChanged(){if(this.$.overlay.opened){this._updateAlignmentAndPosition()}}_onOverlayOpened(){this._openedWithFocusRing=this.hasAttribute("focus-ring")||this.focusElement&&this.focusElement.hasAttribute("focus-ring");var parsedInitialPosition=this._parseDate(this.initialPosition),initialPosition=this._selectedDate||this._overlayContent.initialPosition||parsedInitialPosition||new Date;if(parsedInitialPosition||DatePickerHelper._dateAllowed(initialPosition,this._minDate,this._maxDate)){this._overlayContent.initialPosition=initialPosition}else{this._overlayContent.initialPosition=DatePickerHelper._getClosestDate(initialPosition,[this._minDate,this._maxDate])}this._overlayContent.scrollToDate(this._overlayContent.focusedDate||this._overlayContent.initialPosition);this._ignoreFocusedDateChange=!0;this._overlayContent.focusedDate=this._overlayContent.focusedDate||this._overlayContent.initialPosition;this._ignoreFocusedDateChange=!1;window.addEventListener("scroll",this._boundOnScroll,!0);this.addEventListener("iron-resize",this._boundUpdateAlignmentAndPosition);if(this._webkitOverflowScroll){this._touchPrevented=this._preventWebkitOverflowScrollingTouch(this.parentElement)}if(this._focusOverlayOnOpen){this._overlayContent.focus();this._focusOverlayOnOpen=!1}else{this._focus()}if(this._noInput&&this.focusElement){this.focusElement.blur()}this.updateStyles();this._ignoreAnnounce=!1}_preventWebkitOverflowScrollingTouch(element){var result=[];while(element){if("touch"===window.getComputedStyle(element).webkitOverflowScrolling){var oldInlineValue=element.style.webkitOverflowScrolling;element.style.webkitOverflowScrolling="auto";result.push({element:element,oldInlineValue:oldInlineValue})}element=element.parentElement}return result}_onOverlayClosed(){this._ignoreAnnounce=!0;window.removeEventListener("scroll",this._boundOnScroll,!0);this.removeEventListener("iron-resize",this._boundUpdateAlignmentAndPosition);if(this._touchPrevented){this._touchPrevented.forEach(prevented=>prevented.element.style.webkitOverflowScrolling=prevented.oldInlineValue);this._touchPrevented=[]}this.updateStyles();this._ignoreFocusedDateChange=!0;if(this.i18n.parseDate){var inputValue=this._inputValue||"";const dateObject=this.i18n.parseDate(inputValue),parsedDate=dateObject&&this._parseDate(`${dateObject.year}-${dateObject.month+1}-${dateObject.day}`);if(this._isValidDate(parsedDate)){this._selectedDate=parsedDate}else{this._selectedDate=null;this._inputValue=inputValue}}else if(this._focusedDate){this._selectedDate=this._focusedDate}this._ignoreFocusedDateChange=!1;if(this._nativeInput&&this._nativeInput.selectionStart){this._nativeInput.selectionStart=this._nativeInput.selectionEnd}this.validate()}validate(value){this.invalid=!1;value=value!==void 0?value:this._inputValue;return!(this.invalid=!this.checkValidity(value))}checkValidity(value){var inputValid=!value||this._selectedDate&&value===this.i18n.formatDate(DatePickerHelper._extractDateParts(this._selectedDate)),minMaxValid=!this._selectedDate||DatePickerHelper._dateAllowed(this._selectedDate,this._minDate,this._maxDate),inputValidity=!0;if(this._inputElement){if(this._inputElement.checkValidity){inputValidity=this._inputElement.checkValidity(value)}else if(this._inputElement.validate){inputValidity=this._inputElement.validate(value)}}return inputValid&&minMaxValid&&inputValidity}_onScroll(e){if(e.target===window||!this._overlayContent.contains(e.target)){this._updateAlignmentAndPosition()}}_focus(){if(this._noInput){this._overlayContent.focus()}else{this._inputElement.focus()}}_focusAndSelect(){this._focus();this._setSelectionRange(0,this._inputValue.length)}_setSelectionRange(a,b){if(this._nativeInput&&this._nativeInput.setSelectionRange){this._nativeInput.setSelectionRange(a,b)}}_preventDefault(e){e.preventDefault()}_eventKey(e){for(var keys=["down","up","enter","esc","tab"],i=0,k;i<keys.length;i++){k=keys[i];if(iron_a11y_keys_behavior.a.keyboardEventMatchesKeys(e,k)){return k}}}_isValidDate(d){return d&&!isNaN(d.getTime())}_onKeydown(e){if(this._noInput){if(-1===[9].indexOf(e.keyCode)){e.preventDefault()}}switch(this._eventKey(e)){case"down":case"up":e.preventDefault();if(this.opened){this._overlayContent.focus();this._overlayContent._onKeydown(e)}else{this._focusOverlayOnOpen=!0;this.open()}break;case"enter":if(this._overlayContent.focusedDate){this._selectedDate=this._overlayContent.focusedDate}this.close();break;case"esc":this._focusedDate=this._selectedDate;this._close();break;case"tab":if(this.opened){e.preventDefault();this._setSelectionRange(0,0);if(e.shiftKey){this._overlayContent.focusCancel()}else{this._overlayContent.focus();this._overlayContent.revealDate(this._focusedDate)}}break;}}_validateInput(date,min,max){if(date&&(min||max)){this.invalid=!DatePickerHelper._dateAllowed(date,min,max)}}_onUserInput(){if(!this.opened){this.open()}this._userInputValueChanged()}_userInputValueChanged(){if(this.opened&&this._inputValue){const dateObject=this.i18n.parseDate&&this.i18n.parseDate(this._inputValue),parsedDate=dateObject&&this._parseDate(`${dateObject.year}-${dateObject.month+1}-${dateObject.day}`);if(this._isValidDate(parsedDate)){this._ignoreFocusedDateChange=!0;if(!DatePickerHelper._dateEquals(parsedDate,this._focusedDate)){this._focusedDate=parsedDate}this._ignoreFocusedDateChange=!1}}}_announceFocusedDate(_focusedDate,opened,_ignoreAnnounce){if(opened&&!_ignoreAnnounce){this._overlayContent.announceFocusedDate()}}get _overlayContent(){return this.$.overlay.content.querySelector("#overlay-content")}};/**
@license
Copyright (c) 2017 Vaadin Ltd.
This program is available under Apache License Version 2.0, available at https://vaadin.com/license/
*/class vaadin_date_picker_DatePickerElement extends ElementMixin(ControlStateMixin(Object(vaadin_themable_mixin.a)(Object(vaadin_theme_property_mixin.a)(DatePickerMixin(Object(gesture_event_listeners.a)(polymer_element.a)))))){static get template(){return html_tag.a`
    <style>
      :host {
        display: inline-block;
      }

      :host([hidden]) {
        display: none !important;
      }

      :host([opened]) {
        pointer-events: auto;
      }

      [part="text-field"] {
        width: 100%;
        min-width: 0;
      }

      [part="clear-button"],
      [part="toggle-button"] {
        font-family: 'vaadin-date-picker-icons';
      }

      [part="clear-button"]::before {
        content: "\\e901";
      }

      [part="toggle-button"]::before {
        content: "\\e902";
      }

      :host([disabled]) [part="clear-button"],
      :host([readonly]) [part="clear-button"],
      :host(:not([has-value])) [part="clear-button"] {
        display: none;
      }
    </style>


    <vaadin-text-field id="input" role="application" autocomplete="off" on-focus="_focus" value="{{_userInputValue}}" invalid="[[invalid]]" label="[[label]]" name="[[name]]" placeholder="[[placeholder]]" required="[[required]]" disabled="[[disabled]]" readonly="[[readonly]]" error-message="[[errorMessage]]" aria-label\$="[[label]]" part="text-field" theme\$="[[theme]]">
      <slot name="prefix" slot="prefix"></slot>
      <div part="clear-button" slot="suffix" on-touchend="_clearTouchend" on-click="_clear" role="button" aria-label\$="[[i18n.clear]]"></div>
      <div part="toggle-button" slot="suffix" on-tap="_toggle" role="button" aria-label\$="[[i18n.calendar]]" aria-expanded\$="[[_getAriaExpanded(opened)]]"></div>
    </vaadin-text-field>

    <vaadin-date-picker-overlay id="overlay" opened="{{opened}}" fullscreen\$="[[_fullscreen]]" theme\$="[[theme]]" on-vaadin-overlay-open="_onOverlayOpened" on-vaadin-overlay-close="_onOverlayClosed">
      <template>
        <vaadin-date-picker-overlay-content id="overlay-content" i18n="[[i18n]]" fullscreen\$="[[_fullscreen]]" label="[[label]]" selected-date="{{_selectedDate}}" slot="dropdown-content" focused-date="{{_focusedDate}}" show-week-numbers="[[showWeekNumbers]]" min-date="[[_minDate]]" max-date="[[_maxDate]]" role="dialog" on-date-tap="_close" part="overlay-content" theme\$="[[theme]]">
        </vaadin-date-picker-overlay-content>
      </template>
    </vaadin-date-picker-overlay>

    <iron-media-query query="[[_fullscreenMediaQuery]]" query-matches="{{_fullscreen}}">
    </iron-media-query>
`}static get is(){return"vaadin-date-picker"}static get version(){return"3.3.1"}static get properties(){return{disabled:{type:Boolean,value:!1,reflectToAttribute:!0},errorMessage:String,placeholder:String,readonly:{type:Boolean,value:!1,reflectToAttribute:!0},invalid:{type:Boolean,reflectToAttribute:!0,notify:!0,value:!1},_userInputValue:String}}static get observers(){return["_userInputValueChanged(_userInputValue)"]}ready(){super.ready();Object(render_status.a)(this,()=>this._inputElement.validate=()=>{});this._overlayContent.addEventListener("focus",()=>this.focusElement._setFocused(!0));this.$.overlay.addEventListener("vaadin-overlay-close",this._onVaadinOverlayClose.bind(this))}_onVaadinOverlayClose(e){if(this._openedWithFocusRing&&this.hasAttribute("focused")){this.focusElement.setAttribute("focus-ring","")}else if(!this.hasAttribute("focused")){this.focusElement.blur()}if(e.detail.sourceEvent&&-1!==e.detail.sourceEvent.composedPath().indexOf(this)){e.preventDefault()}}_clear(){this.__dispatchChange=!0;this.value="";this.validate();this.focus();Object(gestures.d)("tap");this.__dispatchChange=!1}_clearTouchend(e){this._clear();e.preventDefault();Object(gestures.d)("tap")}_toggle(e){e.stopPropagation();this[this.$.overlay.opened?"close":"open"]()}_input(){return this.$.input}set _inputValue(value){this._inputElement.value=value}get _inputValue(){return this._inputElement.value}_getAriaExpanded(opened){return(!!opened).toString()}get focusElement(){return this._input()||this}}customElements.define(vaadin_date_picker_DatePickerElement.is,vaadin_date_picker_DatePickerElement)},317:function(module,__webpack_exports__){"use strict";const hassAttributeUtil={DOMAIN_DEVICE_CLASS:{binary_sensor:["battery","cold","connectivity","door","garage_door","gas","heat","light","lock","moisture","motion","moving","occupancy","opening","plug","power","presence","problem","safety","smoke","sound","vibration","window"],cover:["garage"],sensor:["battery","humidity","illuminance","temperature","pressure"]},UNKNOWN_TYPE:"json",ADD_TYPE:"key-value",TYPE_TO_TAG:{string:"ha-customize-string",json:"ha-customize-string",icon:"ha-customize-icon",boolean:"ha-customize-boolean",array:"ha-customize-array","key-value":"ha-customize-key-value"}};hassAttributeUtil.LOGIC_STATE_ATTRIBUTES=hassAttributeUtil.LOGIC_STATE_ATTRIBUTES||{entity_picture:void 0,friendly_name:{type:"string",description:"Name"},icon:{type:"icon"},emulated_hue:{type:"boolean",domains:["emulated_hue"]},emulated_hue_name:{type:"string",domains:["emulated_hue"]},haaska_hidden:void 0,haaska_name:void 0,homebridge_hidden:{type:"boolean"},homebridge_name:{type:"string"},supported_features:void 0,attribution:void 0,custom_ui_more_info:{type:"string"},custom_ui_state_card:{type:"string"},device_class:{type:"array",options:hassAttributeUtil.DOMAIN_DEVICE_CLASS,description:"Device class",domains:["binary_sensor","cover","sensor"]},hidden:{type:"boolean",description:"Hide from UI"},assumed_state:{type:"boolean",domains:["switch","light","cover","climate","fan","group","water_heater"]},initial_state:{type:"string",domains:["automation"]},unit_of_measurement:{type:"string"}};__webpack_exports__.a=hassAttributeUtil},324:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_mixin__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(5),_polymer_paper_dialog_behavior_paper_dialog_behavior__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(165),_polymer_polymer_lib_legacy_class__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(62),_events_mixin__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(48);__webpack_exports__.a=Object(_polymer_polymer_lib_utils_mixin__WEBPACK_IMPORTED_MODULE_0__.a)(superClass=>class extends Object(_polymer_polymer_lib_legacy_class__WEBPACK_IMPORTED_MODULE_2__.b)([_events_mixin__WEBPACK_IMPORTED_MODULE_3__.a,_polymer_paper_dialog_behavior_paper_dialog_behavior__WEBPACK_IMPORTED_MODULE_1__.a],superClass){static get properties(){return{withBackdrop:{type:Boolean,value:!0}}}})},755:function(module,__webpack_exports__,__webpack_require__){"use strict";var _MathPI=Math.PI,_Mathmin2=Math.min;__webpack_require__.r(__webpack_exports__);var paper_dialog_shared_styles=__webpack_require__(177),paper_dialog_scrollable=__webpack_require__(186),html_tag=__webpack_require__(1),polymer_element=__webpack_require__(10),ha_style=__webpack_require__(100),app_toolbar=__webpack_require__(108),paper_icon_button=__webpack_require__(99),state_history_charts=__webpack_require__(225),ha_state_history_data=__webpack_require__(226),state_card_content=__webpack_require__(266),iron_flex_layout_classes=__webpack_require__(79),paper_button=__webpack_require__(72),paper_input=__webpack_require__(78),events_mixin=__webpack_require__(48),localize_mixin=__webpack_require__(71);class more_info_alarm_control_panel_MoreInfoAlarmControlPanel extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="iron-flex"></style>
      <style>
        paper-input {
          margin: auto;
          max-width: 200px;
        }
        .pad {
          display: flex;
          justify-content: center;
          margin-bottom: 24px;
        }
        .pad div {
          display: flex;
          flex-direction: column;
        }
        .pad paper-button {
          width: 80px;
        }
        .actions paper-button {
          min-width: 160px;
          margin-bottom: 16px;
          color: var(--primary-color);
        }
        paper-button.disarm {
          color: var(--google-red-500);
        }
      </style>

      <template is="dom-if" if="[[_codeFormat]]">
        <paper-input
          label="[[localize('ui.card.alarm_control_panel.code')]]"
          value="{{_enteredCode}}"
          type="password"
          disabled="[[!_inputEnabled]]"
        ></paper-input>

        <template is="dom-if" if="[[_isNumber(_codeFormat)]]">
          <div class="pad">
            <div>
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="1"
                raised
                >1</paper-button
              >
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="4"
                raised
                >4</paper-button
              >
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="7"
                raised
                >7</paper-button
              >
            </div>
            <div>
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="2"
                raised
                >2</paper-button
              >
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="5"
                raised
                >5</paper-button
              >
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="8"
                raised
                >8</paper-button
              >
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="0"
                raised
                >0</paper-button
              >
            </div>
            <div>
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="3"
                raised
                >3</paper-button
              >
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="6"
                raised
                >6</paper-button
              >
              <paper-button
                on-click="_digitClicked"
                disabled="[[!_inputEnabled]]"
                data-digit="9"
                raised
                >9</paper-button
              >
              <paper-button
                on-click="_clearEnteredCode"
                disabled="[[!_inputEnabled]]"
                raised
              >
                [[localize('ui.card.alarm_control_panel.clear_code')]]
              </paper-button>
            </div>
          </div>
        </template>
      </template>

      <div class="layout horizontal center-justified actions">
        <template is="dom-if" if="[[_disarmVisible]]">
          <paper-button
            raised
            class="disarm"
            on-click="_callService"
            data-service="alarm_disarm"
            disabled="[[!_codeValid]]"
          >
            [[localize('ui.card.alarm_control_panel.disarm')]]
          </paper-button>
        </template>
        <template is="dom-if" if="[[_armVisible]]">
          <paper-button
            raised
            on-click="_callService"
            data-service="alarm_arm_home"
            disabled="[[!_codeValid]]"
          >
            [[localize('ui.card.alarm_control_panel.arm_home')]]
          </paper-button>
          <paper-button
            raised
            on-click="_callService"
            data-service="alarm_arm_away"
            disabled="[[!_codeValid]]"
          >
            [[localize('ui.card.alarm_control_panel.arm_away')]]
          </paper-button>
        </template>
      </div>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"_stateObjChanged"},_enteredCode:{type:String,value:""},_codeFormat:{type:String,value:""},_codeValid:{type:Boolean,computed:"_validateCode(_enteredCode, _codeFormat)"},_disarmVisible:{type:Boolean,value:!1},_armVisible:{type:Boolean,value:!1},_inputEnabled:{type:Boolean,value:!1}}}constructor(){super();this._armedStates=["armed_home","armed_away","armed_night","armed_custom_bypass"]}_stateObjChanged(newVal,oldVal){if(newVal){const state=newVal.state,props={_codeFormat:newVal.attributes.code_format,_armVisible:"disarmed"===state,_disarmVisible:this._armedStates.includes(state)||"pending"===state||"triggered"===state||"arming"===state};props._inputEnabled=props._disarmVisible||props._armVisible;this.setProperties(props)}if(oldVal){setTimeout(()=>{this.fire("iron-resize")},500)}}_isNumber(format){return"Number"===format}_validateCode(code,format){return!format||0<code.length}_digitClicked(ev){this._enteredCode+=ev.target.getAttribute("data-digit")}_clearEnteredCode(){this._enteredCode=""}_callService(ev){const service=ev.target.getAttribute("data-service"),data={entity_id:this.stateObj.entity_id,code:this._enteredCode};this.hass.callService("alarm_control_panel",service,data).then(()=>{this._enteredCode=""})}}customElements.define("more-info-alarm_control_panel",more_info_alarm_control_panel_MoreInfoAlarmControlPanel);__webpack_require__(216);class more_info_automation_MoreInfoAutomation extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
        }
        .flex {
          display: flex;
          justify-content: space-between;
        }
        .actions {
          margin: 36px 0 8px 0;
          text-align: right;
        }
      </style>

      <div class="flex">
        <div>[[localize('ui.card.automation.last_triggered')]]:</div>
        <ha-relative-time
          hass="[[hass]]"
          datetime="[[stateObj.attributes.last_triggered]]"
        ></ha-relative-time>
      </div>

      <div class="actions">
        <paper-button on-click="handleTriggerTapped">
          [[localize('ui.card.automation.trigger')]]
        </paper-button>
      </div>
    `}static get properties(){return{hass:Object,stateObj:Object}}handleTriggerTapped(){this.hass.callService("automation","trigger",{entity_id:this.stateObj.entity_id})}}customElements.define("more-info-automation",more_info_automation_MoreInfoAutomation);var compute_state_name=__webpack_require__(105);class more_info_camera_MoreInfoCamera extends Object(events_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          max-width: 640px;
        }

        .camera-image {
          width: 100%;
        }
      </style>

      <img
        class="camera-image"
        src="[[computeCameraImageUrl(hass, stateObj, isVisible)]]"
        on-load="imageLoaded"
        alt="[[_computeStateName(stateObj)]]"
      />
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object},isVisible:{type:Boolean,value:!0}}}connectedCallback(){super.connectedCallback();this.isVisible=!0}disconnectedCallback(){this.isVisible=!1;super.disconnectedCallback()}imageLoaded(){this.fire("iron-resize")}_computeStateName(stateObj){return Object(compute_state_name.a)(stateObj)}computeCameraImageUrl(hass,stateObj,isVisible){if(hass.demo){return"/demo/webcam.jpg"}if(stateObj&&isVisible){return"/api/camera_proxy_stream/"+stateObj.entity_id+"?token="+stateObj.attributes.access_token}return"data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"}}customElements.define("more-info-camera",more_info_camera_MoreInfoCamera);var paper_dropdown_menu=__webpack_require__(129),paper_item=__webpack_require__(126),paper_listbox=__webpack_require__(128),paper_toggle_button=__webpack_require__(187),utils_async=__webpack_require__(8),debounce=__webpack_require__(14);class ha_climate_control_HaClimateControl extends Object(events_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        /* local DOM styles go here */
        :host {
          @apply --layout-flex;
          @apply --layout-horizontal;
          @apply --layout-justified;
        }
        .in-flux#target_temperature {
          color: var(--google-red-500);
        }
        #target_temperature {
          @apply --layout-self-center;
          font-size: 200%;
        }
        .control-buttons {
          font-size: 200%;
          text-align: right;
        }
        paper-icon-button {
          height: 48px;
          width: 48px;
        }
      </style>

      <!-- local DOM goes here -->
      <div id="target_temperature">[[value]] [[units]]</div>
      <div class="control-buttons">
        <div>
          <paper-icon-button
            icon="hass:chevron-up"
            on-click="incrementValue"
          ></paper-icon-button>
        </div>
        <div>
          <paper-icon-button
            icon="hass:chevron-down"
            on-click="decrementValue"
          ></paper-icon-button>
        </div>
      </div>
    `}static get properties(){return{value:{type:Number,observer:"valueChanged"},units:{type:String},min:{type:Number},max:{type:Number},step:{type:Number,value:1}}}temperatureStateInFlux(inFlux){this.$.target_temperature.classList.toggle("in-flux",inFlux)}_round(val){const s=this.step.toString().split(".");return s[1]?parseFloat(val.toFixed(s[1].length)):Math.round(val)}incrementValue(){const newval=this._round(this.value+this.step);if(this.value<this.max){this.last_changed=Date.now();this.temperatureStateInFlux(!0)}if(newval<=this.max){if(newval<=this.min){this.value=this.min}else{this.value=newval}}else{this.value=this.max}}decrementValue(){const newval=this._round(this.value-this.step);if(this.value>this.min){this.last_changed=Date.now();this.temperatureStateInFlux(!0)}if(newval>=this.min){this.value=newval}else{this.value=this.min}}valueChanged(){if(this.last_changed){window.setTimeout(()=>{const now=Date.now();if(2e3<=now-this.last_changed){this.fire("change");this.temperatureStateInFlux(!1);this.last_changed=null}},2010)}}}customElements.define("ha-climate-control",ha_climate_control_HaClimateControl);var ha_paper_slider=__webpack_require__(137),attribute_class_names=__webpack_require__(221),supports_feature=__webpack_require__(193);function featureClassNames(stateObj,classNames){if(!stateObj||!stateObj.attributes.supported_features){return""}return Object.keys(classNames).map(feature=>Object(supports_feature.a)(stateObj,+feature)?classNames[feature]:"").filter(attr=>""!==attr).join(" ")}class more_info_climate_MoreInfoClimate extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="iron-flex"></style>
      <style>
        :host {
          color: var(--primary-text-color);
        }

        .container-on,
        .container-away_mode,
        .container-aux_heat,
        .container-temperature,
        .container-humidity,
        .container-operation_list,
        .container-fan_list,
        .container-swing_list {
          display: none;
        }

        .has-on .container-on,
        .has-away_mode .container-away_mode,
        .has-aux_heat .container-aux_heat,
        .has-target_temperature .container-temperature,
        .has-target_temperature_low .container-temperature,
        .has-target_temperature_high .container-temperature,
        .has-target_humidity .container-humidity,
        .has-operation_mode .container-operation_list,
        .has-fan_mode .container-fan_list,
        .has-swing_list .container-swing_list,
        .has-swing_mode .container-swing_list {
          display: block;
          margin-bottom: 5px;
        }

        .container-operation_list iron-icon,
        .container-fan_list iron-icon,
        .container-swing_list iron-icon {
          margin: 22px 16px 0 0;
        }

        paper-dropdown-menu {
          width: 100%;
        }

        paper-item {
          cursor: pointer;
        }

        ha-paper-slider {
          width: 100%;
        }

        .container-humidity .single-row {
            display: flex;
            height: 50px;
        }

        .target-humidity {
          width: 90px;
          font-size: 200%;
          margin: auto;
        }

        ha-climate-control.range-control-left,
        ha-climate-control.range-control-right {
          float: left;
          width: 46%;
        }
        ha-climate-control.range-control-left {
          margin-right: 4%;
        }
        ha-climate-control.range-control-right {
          margin-left: 4%;
        }

        .humidity {
          --paper-slider-active-color: var(--paper-blue-400);
          --paper-slider-secondary-color: var(--paper-blue-400);
        }

        .single-row {
          padding: 8px 0;
        }
        }
      </style>

      <div class$="[[computeClassNames(stateObj)]]">
        <template is="dom-if" if="[[supportsOn(stateObj)]]">
          <div class="container-on">
            <div class="center horizontal layout single-row">
              <div class="flex">[[localize('ui.card.climate.on_off')]]</div>
              <paper-toggle-button
                checked="[[onToggleChecked]]"
                on-change="onToggleChanged"
              >
              </paper-toggle-button>
            </div>
          </div>
        </template>

        <div class="container-temperature">
          <div class$="[[stateObj.attributes.operation_mode]]">
            <div hidden$="[[!supportsTemperatureControls(stateObj)]]">
              [[localize('ui.card.climate.target_temperature')]]
            </div>
            <template is="dom-if" if="[[supportsTemperature(stateObj)]]">
              <ha-climate-control
                value="[[stateObj.attributes.temperature]]"
                units="[[hass.config.unit_system.temperature]]"
                step="[[computeTemperatureStepSize(hass, stateObj)]]"
                min="[[stateObj.attributes.min_temp]]"
                max="[[stateObj.attributes.max_temp]]"
                on-change="targetTemperatureChanged"
              >
              </ha-climate-control>
            </template>
            <template is="dom-if" if="[[supportsTemperatureRange(stateObj)]]">
              <ha-climate-control
                value="[[stateObj.attributes.target_temp_low]]"
                units="[[hass.config.unit_system.temperature]]"
                step="[[computeTemperatureStepSize(hass, stateObj)]]"
                min="[[stateObj.attributes.min_temp]]"
                max="[[stateObj.attributes.target_temp_high]]"
                class="range-control-left"
                on-change="targetTemperatureLowChanged"
              >
              </ha-climate-control>
              <ha-climate-control
                value="[[stateObj.attributes.target_temp_high]]"
                units="[[hass.config.unit_system.temperature]]"
                step="[[computeTemperatureStepSize(hass, stateObj)]]"
                min="[[stateObj.attributes.target_temp_low]]"
                max="[[stateObj.attributes.max_temp]]"
                class="range-control-right"
                on-change="targetTemperatureHighChanged"
              >
              </ha-climate-control>
            </template>
          </div>
        </div>

        <template is="dom-if" if="[[supportsHumidity(stateObj)]]">
          <div class="container-humidity">
            <div>[[localize('ui.card.climate.target_humidity')]]</div>
            <div class="single-row">
              <div class="target-humidity">
                [[stateObj.attributes.humidity]] %
              </div>
              <ha-paper-slider
                class="humidity"
                min="[[stateObj.attributes.min_humidity]]"
                max="[[stateObj.attributes.max_humidity]]"
                secondary-progress="[[stateObj.attributes.max_humidity]]"
                step="1"
                pin=""
                value="[[stateObj.attributes.humidity]]"
                on-change="targetHumiditySliderChanged"
                ignore-bar-touch=""
              >
              </ha-paper-slider>
            </div>
          </div>
        </template>

        <template is="dom-if" if="[[supportsOperationMode(stateObj)]]">
          <div class="container-operation_list">
            <div class="controls">
              <paper-dropdown-menu
                label-float=""
                dynamic-align=""
                label="[[localize('ui.card.climate.operation')]]"
              >
                <paper-listbox
                  slot="dropdown-content"
                  selected="{{operationIndex}}"
                >
                  <template
                    is="dom-repeat"
                    items="[[stateObj.attributes.operation_list]]"
                    on-dom-change="handleOperationListUpdate"
                  >
                    <paper-item
                      >[[_localizeOperationMode(localize, item)]]</paper-item
                    >
                  </template>
                </paper-listbox>
              </paper-dropdown-menu>
            </div>
          </div>
        </template>

        <template is="dom-if" if="[[supportsFanMode(stateObj)]]">
          <div class="container-fan_list">
            <paper-dropdown-menu
              label-float=""
              dynamic-align=""
              label="[[localize('ui.card.climate.fan_mode')]]"
            >
              <paper-listbox slot="dropdown-content" selected="{{fanIndex}}">
                <template
                  is="dom-repeat"
                  items="[[stateObj.attributes.fan_list]]"
                  on-dom-change="handleFanListUpdate"
                >
                  <paper-item>[[item]]</paper-item>
                </template>
              </paper-listbox>
            </paper-dropdown-menu>
          </div>
        </template>

        <template is="dom-if" if="[[supportsSwingMode(stateObj)]]">
          <div class="container-swing_list">
            <paper-dropdown-menu
              label-float=""
              dynamic-align=""
              label="[[localize('ui.card.climate.swing_mode')]]"
            >
              <paper-listbox slot="dropdown-content" selected="{{swingIndex}}">
                <template
                  is="dom-repeat"
                  items="[[stateObj.attributes.swing_list]]"
                  on-dom-change="handleSwingListUpdate"
                >
                  <paper-item>[[item]]</paper-item>
                </template>
              </paper-listbox>
            </paper-dropdown-menu>
          </div>
        </template>

        <template is="dom-if" if="[[supportsAwayMode(stateObj)]]">
          <div class="container-away_mode">
            <div class="center horizontal layout single-row">
              <div class="flex">[[localize('ui.card.climate.away_mode')]]</div>
              <paper-toggle-button
                checked="[[awayToggleChecked]]"
                on-change="awayToggleChanged"
              >
              </paper-toggle-button>
            </div>
          </div>
        </template>

        <template is="dom-if" if="[[supportsAuxHeat(stateObj)]]">
          <div class="container-aux_heat">
            <div class="center horizontal layout single-row">
              <div class="flex">[[localize('ui.card.climate.aux_heat')]]</div>
              <paper-toggle-button
                checked="[[auxToggleChecked]]"
                on-change="auxToggleChanged"
              >
              </paper-toggle-button>
            </div>
          </div>
        </template>
      </div>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object,observer:"stateObjChanged"},operationIndex:{type:Number,value:-1,observer:"handleOperationmodeChanged"},fanIndex:{type:Number,value:-1,observer:"handleFanmodeChanged"},swingIndex:{type:Number,value:-1,observer:"handleSwingmodeChanged"},awayToggleChecked:Boolean,auxToggleChecked:Boolean,onToggleChecked:Boolean}}stateObjChanged(newVal,oldVal){if(newVal){this.setProperties({awayToggleChecked:"on"===newVal.attributes.away_mode,auxToggleChecked:"on"===newVal.attributes.aux_heat,onToggleChecked:"off"!==newVal.state})}if(oldVal){this._debouncer=debounce.a.debounce(this._debouncer,utils_async.d.after(500),()=>{this.fire("iron-resize")})}}handleOperationListUpdate(){this.operationIndex=-1;if(this.stateObj.attributes.operation_list){this.operationIndex=this.stateObj.attributes.operation_list.indexOf(this.stateObj.attributes.operation_mode)}}handleSwingListUpdate(){this.swingIndex=-1;if(this.stateObj.attributes.swing_list){this.swingIndex=this.stateObj.attributes.swing_list.indexOf(this.stateObj.attributes.swing_mode)}}handleFanListUpdate(){this.fanIndex=-1;if(this.stateObj.attributes.fan_list){this.fanIndex=this.stateObj.attributes.fan_list.indexOf(this.stateObj.attributes.fan_mode)}}computeTemperatureStepSize(hass,stateObj){if(stateObj.attributes.target_temp_step){return stateObj.attributes.target_temp_step}if(-1!==hass.config.unit_system.temperature.indexOf("F")){return 1}return .5}supportsTemperatureControls(stateObj){return this.supportsTemperature(stateObj)||this.supportsTemperatureRange(stateObj)}supportsTemperature(stateObj){return Object(supports_feature.a)(stateObj,1)&&"number"===typeof stateObj.attributes.temperature}supportsTemperatureRange(stateObj){return Object(supports_feature.a)(stateObj,6)&&("number"===typeof stateObj.attributes.target_temp_low||"number"===typeof stateObj.attributes.target_temp_high)}supportsHumidity(stateObj){return Object(supports_feature.a)(stateObj,8)}supportsFanMode(stateObj){return Object(supports_feature.a)(stateObj,64)}supportsOperationMode(stateObj){return Object(supports_feature.a)(stateObj,128)}supportsSwingMode(stateObj){return Object(supports_feature.a)(stateObj,512)}supportsAwayMode(stateObj){return Object(supports_feature.a)(stateObj,1024)}supportsAuxHeat(stateObj){return Object(supports_feature.a)(stateObj,2048)}supportsOn(stateObj){return Object(supports_feature.a)(stateObj,4096)}computeClassNames(stateObj){var classes=[Object(attribute_class_names.a)(stateObj,["current_temperature","current_humidity"]),featureClassNames(stateObj,{1:"has-target_temperature",2:"has-target_temperature_high",4:"has-target_temperature_low",8:"has-target_humidity",16:"has-target_humidity_high",32:"has-target_humidity_low",64:"has-fan_mode",128:"has-operation_mode",256:"has-hold_mode",512:"has-swing_mode",1024:"has-away_mode",2048:"has-aux_heat",4096:"has-on"}),"more-info-climate"];return classes.join(" ")}targetTemperatureChanged(ev){const temperature=ev.target.value;if(temperature===this.stateObj.attributes.temperature)return;this.callServiceHelper("set_temperature",{temperature:temperature})}targetTemperatureLowChanged(ev){const targetTempLow=ev.currentTarget.value;if(targetTempLow===this.stateObj.attributes.target_temp_low)return;this.callServiceHelper("set_temperature",{target_temp_low:targetTempLow,target_temp_high:this.stateObj.attributes.target_temp_high})}targetTemperatureHighChanged(ev){const targetTempHigh=ev.currentTarget.value;if(targetTempHigh===this.stateObj.attributes.target_temp_high)return;this.callServiceHelper("set_temperature",{target_temp_low:this.stateObj.attributes.target_temp_low,target_temp_high:targetTempHigh})}targetHumiditySliderChanged(ev){const humidity=ev.target.value;if(humidity===this.stateObj.attributes.humidity)return;this.callServiceHelper("set_humidity",{humidity:humidity})}awayToggleChanged(ev){const oldVal="on"===this.stateObj.attributes.away_mode,newVal=ev.target.checked;if(oldVal===newVal)return;this.callServiceHelper("set_away_mode",{away_mode:newVal})}auxToggleChanged(ev){const oldVal="on"===this.stateObj.attributes.aux_heat,newVal=ev.target.checked;if(oldVal===newVal)return;this.callServiceHelper("set_aux_heat",{aux_heat:newVal})}onToggleChanged(ev){const oldVal="off"!==this.stateObj.state,newVal=ev.target.checked;if(oldVal===newVal)return;this.callServiceHelper(newVal?"turn_on":"turn_off",{})}handleFanmodeChanged(fanIndex){if(""===fanIndex||-1===fanIndex)return;const fanInput=this.stateObj.attributes.fan_list[fanIndex];if(fanInput===this.stateObj.attributes.fan_mode)return;this.callServiceHelper("set_fan_mode",{fan_mode:fanInput})}handleOperationmodeChanged(operationIndex){if(""===operationIndex||-1===operationIndex)return;const operationInput=this.stateObj.attributes.operation_list[operationIndex];if(operationInput===this.stateObj.attributes.operation_mode)return;this.callServiceHelper("set_operation_mode",{operation_mode:operationInput})}handleSwingmodeChanged(swingIndex){if(""===swingIndex||-1===swingIndex)return;const swingInput=this.stateObj.attributes.swing_list[swingIndex];if(swingInput===this.stateObj.attributes.swing_mode)return;this.callServiceHelper("set_swing_mode",{swing_mode:swingInput})}callServiceHelper(service,data){data.entity_id=this.stateObj.entity_id;this.hass.callService("climate",service,data).then(()=>{this.stateObjChanged(this.stateObj)})}_localizeOperationMode(localize,mode){return localize(`state.climate.${mode}`)||mode}}customElements.define("more-info-climate",more_info_climate_MoreInfoClimate);var iron_input=__webpack_require__(101),paper_spinner=__webpack_require__(111),ha_markdown=__webpack_require__(201);class more_info_configurator_MoreInfoConfigurator extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex"></style>
      <style>
        p {
          margin: 8px 0;
        }

        a {
          color: var(--primary-color);
        }

        p > img {
          max-width: 100%;
        }

        p.center {
          text-align: center;
        }

        p.error {
          color: #c62828;
        }

        p.submit {
          text-align: center;
          height: 41px;
        }

        paper-spinner {
          width: 14px;
          height: 14px;
          margin-right: 20px;
        }

        [hidden] {
          display: none;
        }
      </style>

      <div class="layout vertical">
        <template is="dom-if" if="[[isConfigurable]]">
          <ha-markdown
            content="[[stateObj.attributes.description]]"
          ></ha-markdown>

          <p class="error" hidden$="[[!stateObj.attributes.errors]]">
            [[stateObj.attributes.errors]]
          </p>

          <template is="dom-repeat" items="[[stateObj.attributes.fields]]">
            <paper-input
              label="[[item.name]]"
              name="[[item.id]]"
              type="[[item.type]]"
              on-change="fieldChanged"
            ></paper-input>
          </template>

          <p class="submit" hidden$="[[!stateObj.attributes.submit_caption]]">
            <paper-button
              raised=""
              disabled="[[isConfiguring]]"
              on-click="submitClicked"
            >
              <paper-spinner
                active="[[isConfiguring]]"
                hidden="[[!isConfiguring]]"
                alt="Configuring"
              ></paper-spinner>
              [[stateObj.attributes.submit_caption]]
            </paper-button>
          </p>
        </template>
      </div>
    `}static get properties(){return{stateObj:{type:Object},action:{type:String,value:"display"},isConfigurable:{type:Boolean,computed:"computeIsConfigurable(stateObj)"},isConfiguring:{type:Boolean,value:!1},fieldInput:{type:Object,value:function(){return{}}}}}computeIsConfigurable(stateObj){return"configure"===stateObj.state}fieldChanged(ev){var el=ev.target;this.fieldInput[el.name]=el.value}submitClicked(){var data={configure_id:this.stateObj.attributes.configure_id,fields:this.fieldInput};this.isConfiguring=!0;this.hass.callService("configurator","configure",data).then(function(){this.isConfiguring=!1}.bind(this),function(){this.isConfiguring=!1}.bind(this))}}customElements.define("more-info-configurator",more_info_configurator_MoreInfoConfigurator);var ha_cover_tilt_controls=__webpack_require__(234),ha_icon=__webpack_require__(159);class ha_labeled_slider_HaLabeledSlider extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
        }

        .title {
          margin-bottom: 16px;
          opacity: var(--dark-primary-opacity);
        }

        ha-icon {
          float: left;
          margin-top: 4px;
          opacity: var(--dark-secondary-opacity);
        }

        ha-paper-slider {
          background-image: var(--ha-slider-background);
        }
      </style>

      <div class="title">[[caption]]</div>
      <div class="extra-container"><slot name="extra"></slot></div>
      <div class="slider-container">
        <ha-icon icon="[[icon]]" hidden$="[[!icon]]"></ha-icon>
        <ha-paper-slider
          min="[[min]]"
          max="[[max]]"
          step="[[step]]"
          pin="[[pin]]"
          disabled="[[disabled]]"
          disabled="[[disabled]]"
          value="{{value}}"
        ></ha-paper-slider>
      </div>
    `}static get properties(){return{caption:String,disabled:Boolean,min:Number,max:Number,pin:Boolean,step:Number,extra:{type:Boolean,value:!1},ignoreBarTouch:{type:Boolean,value:!0},icon:{type:String,value:""},value:{type:Number,notify:!0}}}}customElements.define("ha-labeled-slider",ha_labeled_slider_HaLabeledSlider);var cover_model=__webpack_require__(198);const FEATURE_CLASS_NAMES={128:"has-set_tilt_position"};class more_info_cover_MoreInfoCover extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex"></style>
      <style>
        .current_position,
        .tilt {
          max-height: 0px;
          overflow: hidden;
        }

        .has-current_position .current_position,
        .has-set_tilt_position .tilt,
        .has-current_tilt_position .tilt {
          max-height: 208px;
        }

        [invisible] {
          visibility: hidden !important;
        }
      </style>
      <div class$="[[computeClassNames(stateObj)]]">
        <div class="current_position">
          <ha-labeled-slider
            caption="[[localize('ui.card.cover.position')]]"
            pin=""
            value="{{coverPositionSliderValue}}"
            disabled="[[!entityObj.supportsSetPosition]]"
            on-change="coverPositionSliderChanged"
          ></ha-labeled-slider>
        </div>

        <div class="tilt">
          <ha-labeled-slider
            caption="[[localize('ui.card.cover.tilt_position')]]"
            pin=""
            extra=""
            value="{{coverTiltPositionSliderValue}}"
            disabled="[[!entityObj.supportsSetTiltPosition]]"
            on-change="coverTiltPositionSliderChanged"
          >
            <ha-cover-tilt-controls
              slot="extra"
              hidden$="[[entityObj.isTiltOnly]]"
              hass="[[hass]]"
              state-obj="[[stateObj]]"
            ></ha-cover-tilt-controls>
          </ha-labeled-slider>
        </div>
      </div>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"stateObjChanged"},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"},coverPositionSliderValue:Number,coverTiltPositionSliderValue:Number}}computeEntityObj(hass,stateObj){return new cover_model.a(hass,stateObj)}stateObjChanged(newVal){if(newVal){this.setProperties({coverPositionSliderValue:newVal.attributes.current_position,coverTiltPositionSliderValue:newVal.attributes.current_tilt_position})}}computeClassNames(stateObj){var classes=[Object(attribute_class_names.a)(stateObj,["current_position","current_tilt_position"]),featureClassNames(stateObj,FEATURE_CLASS_NAMES)];return classes.join(" ")}coverPositionSliderChanged(ev){this.entityObj.setCoverPosition(ev.target.value)}coverTiltPositionSliderChanged(ev){this.entityObj.setCoverTiltPosition(ev.target.value)}}customElements.define("more-info-cover",more_info_cover_MoreInfoCover);var hass_attributes_util=__webpack_require__(317);class ha_attributes_HaAttributes extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        .data-entry .value {
          max-width: 200px;
        }
        .attribution {
          color: var(--secondary-text-color);
          text-align: right;
        }
      </style>

      <div class="layout vertical">
        <template
          is="dom-repeat"
          items="[[computeDisplayAttributes(stateObj, filtersArray)]]"
          as="attribute"
        >
          <div class="data-entry layout justified horizontal">
            <div class="key">[[formatAttribute(attribute)]]</div>
            <div class="value">
              [[formatAttributeValue(stateObj, attribute)]]
            </div>
          </div>
        </template>
        <div class="attribution" hidden$="[[!computeAttribution(stateObj)]]">
          [[computeAttribution(stateObj)]]
        </div>
      </div>
    `}static get properties(){return{stateObj:{type:Object},extraFilters:{type:String,value:""},filtersArray:{type:Array,computed:"computeFiltersArray(extraFilters)"}}}computeFiltersArray(extraFilters){return Object.keys(hass_attributes_util.a.LOGIC_STATE_ATTRIBUTES).concat(extraFilters?extraFilters.split(","):[])}computeDisplayAttributes(stateObj,filtersArray){if(!stateObj){return[]}return Object.keys(stateObj.attributes).filter(function(key){return-1===filtersArray.indexOf(key)})}formatAttribute(attribute){return attribute.replace(/_/g," ")}formatAttributeValue(stateObj,attribute){var value=stateObj.attributes[attribute];if(null===value)return"-";if(Array.isArray(value)){return value.join(", ")}return value instanceof Object?JSON.stringify(value,null,2):value}computeAttribution(stateObj){return stateObj.attributes.attribution}}customElements.define("ha-attributes",ha_attributes_HaAttributes);class more_info_default_MoreInfoDefault extends polymer_element.a{static get template(){return html_tag.a`
      <ha-attributes state-obj="[[stateObj]]"></ha-attributes>
    `}static get properties(){return{stateObj:{type:Object}}}}customElements.define("more-info-default",more_info_default_MoreInfoDefault);class more_info_fan_MoreInfoFan extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="iron-flex"></style>
      <style>
        .container-speed_list,
        .container-direction,
        .container-oscillating {
          display: none;
        }

        .has-speed_list .container-speed_list,
        .has-direction .container-direction,
        .has-oscillating .container-oscillating {
          display: block;
        }

        paper-dropdown-menu {
          width: 100%;
        }

        paper-item {
          cursor: pointer;
        }
      </style>

      <div class$="[[computeClassNames(stateObj)]]">
        <div class="container-speed_list">
          <paper-dropdown-menu
            label-float=""
            dynamic-align=""
            label="[[localize('ui.card.fan.speed')]]"
          >
            <paper-listbox slot="dropdown-content" selected="{{speedIndex}}">
              <template
                is="dom-repeat"
                items="[[stateObj.attributes.speed_list]]"
              >
                <paper-item>[[item]]</paper-item>
              </template>
            </paper-listbox>
          </paper-dropdown-menu>
        </div>

        <div class="container-oscillating">
          <div class="center horizontal layout single-row">
            <div class="flex">[[localize('ui.card.fan.oscillate')]]</div>
            <paper-toggle-button
              checked="[[oscillationToggleChecked]]"
              on-change="oscillationToggleChanged"
            >
            </paper-toggle-button>
          </div>
        </div>

        <div class="container-direction">
          <div class="direction">
            <div>[[localize('ui.card.fan.direction')]]</div>
            <paper-icon-button
              icon="hass:rotate-left"
              on-click="onDirectionLeft"
              title="Left"
              disabled="[[computeIsRotatingLeft(stateObj)]]"
            ></paper-icon-button>
            <paper-icon-button
              icon="hass:rotate-right"
              on-click="onDirectionRight"
              title="Right"
              disabled="[[computeIsRotatingRight(stateObj)]]"
            ></paper-icon-button>
          </div>
        </div>
      </div>

      <ha-attributes
        state-obj="[[stateObj]]"
        extra-filters="speed,speed_list,oscillating,direction"
      ></ha-attributes>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object,observer:"stateObjChanged"},speedIndex:{type:Number,value:-1,observer:"speedChanged"},oscillationToggleChecked:{type:Boolean}}}stateObjChanged(newVal,oldVal){if(newVal){this.setProperties({oscillationToggleChecked:newVal.attributes.oscillating,speedIndex:newVal.attributes.speed_list?newVal.attributes.speed_list.indexOf(newVal.attributes.speed):-1})}if(oldVal){setTimeout(()=>{this.fire("iron-resize")},500)}}computeClassNames(stateObj){return"more-info-fan "+Object(attribute_class_names.a)(stateObj,["oscillating","speed_list","direction"])}speedChanged(speedIndex){var speedInput;if(""===speedIndex||-1===speedIndex)return;speedInput=this.stateObj.attributes.speed_list[speedIndex];if(speedInput===this.stateObj.attributes.speed)return;this.hass.callService("fan","turn_on",{entity_id:this.stateObj.entity_id,speed:speedInput})}oscillationToggleChanged(ev){var oldVal=this.stateObj.attributes.oscillating,newVal=ev.target.checked;if(oldVal===newVal)return;this.hass.callService("fan","oscillate",{entity_id:this.stateObj.entity_id,oscillating:newVal})}onDirectionLeft(){this.hass.callService("fan","set_direction",{entity_id:this.stateObj.entity_id,direction:"reverse"})}onDirectionRight(){this.hass.callService("fan","set_direction",{entity_id:this.stateObj.entity_id,direction:"forward"})}computeIsRotatingLeft(stateObj){return"reverse"===stateObj.attributes.direction}computeIsRotatingRight(stateObj){return"forward"===stateObj.attributes.direction}}customElements.define("more-info-fan",more_info_fan_MoreInfoFan);var polymer_dom=__webpack_require__(0),compute_state_domain=__webpack_require__(153),dynamic_content_updater=__webpack_require__(115);class more_info_group_MoreInfoGroup extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        .child-card {
          margin-bottom: 8px;
        }

        .child-card:last-child {
          margin-bottom: 0;
        }
      </style>

      <div id="groupedControlDetails"></div>
      <template is="dom-repeat" items="[[states]]" as="state">
        <div class="child-card">
          <state-card-content
            state-obj="[[state]]"
            hass="[[hass]]"
          ></state-card-content>
        </div>
      </template>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object},states:{type:Array,computed:"computeStates(stateObj, hass)"}}}static get observers(){return["statesChanged(stateObj, states)"]}computeStates(stateObj,hass){for(var states=[],entIds=stateObj.attributes.entity_id||[],i=0,state;i<entIds.length;i++){state=hass.states[entIds[i]];if(state){states.push(state)}}return states}statesChanged(stateObj,states){let groupDomainStateObj=!1,groupDomain=!1;if(states&&0<states.length){const baseStateObj=states.find(s=>"on"===s.state)||states[0];groupDomain=Object(compute_state_domain.a)(baseStateObj);if("group"!==groupDomain){groupDomainStateObj=Object.assign({},baseStateObj,{entity_id:stateObj.entity_id,attributes:Object.assign({},baseStateObj.attributes)});for(let i=0;i<states.length;i++){if(groupDomain!==Object(compute_state_domain.a)(states[i])){groupDomainStateObj=!1;break}}}}if(!groupDomainStateObj){const el=Object(polymer_dom.b)(this.$.groupedControlDetails);if(el.lastChild){el.removeChild(el.lastChild)}}else{Object(dynamic_content_updater.a)(this.$.groupedControlDetails,"MORE-INFO-"+groupDomain.toUpperCase(),{stateObj:groupDomainStateObj,hass:this.hass})}}}customElements.define("more-info-group",more_info_group_MoreInfoGroup);__webpack_require__(275);class more_info_history_graph_MoreInfoHistoryGraph extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          margin-bottom: 6px;
        }
      </style>
      <ha-history_graph-card
        hass="[[hass]]"
        state-obj="[[stateObj]]"
        in-dialog=""
      >
        <ha-attributes state-obj="[[stateObj]]"></ha-attributes>
      </ha-history_graph-card>
    `}static get properties(){return{hass:Object,stateObj:Object}}}customElements.define("more-info-history_graph",more_info_history_graph_MoreInfoHistoryGraph);var polymer_legacy=__webpack_require__(3),vaadin_date_picker=__webpack_require__(295);class paper_time_input_PaperTimeInput extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          @apply --paper-font-common-base;
        }

        paper-input {
          width: 30px;
          text-align: center;
          --paper-input-container-input: {
            /* Damn you firefox
             * Needed to hide spin num in firefox
             * http://stackoverflow.com/questions/3790935/can-i-hide-the-html5-number-input-s-spin-box
             */
            -moz-appearance: textfield;
            @apply --paper-time-input-cotnainer;
          }
          --paper-input-container-input-webkit-spinner: {
            -webkit-appearance: none;
            margin: 0;
            display: none;
          }
        }

        paper-dropdown-menu {
          width: 55px;
          padding: 0;
          /* Force ripple to use the whole container */
          --paper-dropdown-menu-ripple: {
            color: var(
              --paper-time-input-dropdown-ripple-color,
              var(--primary-color)
            );
          }
          --paper-input-container-input: {
            @apply --paper-font-button;
            text-align: center;
            padding-left: 5px;
            @apply --paper-time-dropdown-input-cotnainer;
          }
          --paper-input-container-underline: {
            border-color: transparent;
          }
          --paper-input-container-underline-focus: {
            border-color: transparent;
          }
        }

        paper-item {
          cursor: pointer;
          text-align: center;
          font-size: 14px;
        }

        paper-listbox {
          padding: 0;
        }

        label {
          @apply --paper-font-caption;
        }

        .time-input-wrap {
          @apply --layout-horizontal;
          @apply --layout-no-wrap;
        }

        [hidden] {
          display: none !important;
        }
      </style>

      <label hidden$="[[hideLabel]]">[[label]]</label>
      <div class="time-input-wrap">
        <!-- Hour Input -->
        <paper-input
          id="hour"
          type="number"
          value="{{hour}}"
          on-change="_shouldFormatHour"
          required=""
          auto-validate="[[autoValidate]]"
          prevent-invalid-input=""
          maxlength="2"
          max="[[_computeHourMax(format)]]"
          min="0"
          no-label-float=""
          disabled="[[disabled]]"
        >
          <span suffix="" slot="suffix">:</span>
        </paper-input>

        <!-- Min Input -->
        <paper-input
          id="min"
          type="number"
          value="{{min}}"
          on-change="_formatMin"
          required=""
          auto-validate="[[autoValidate]]"
          prevent-invalid-input=""
          maxlength="2"
          max="59"
          min="0"
          no-label-float=""
          disabled="[[disabled]]"
        >
        </paper-input>

        <!-- Dropdown Menu -->
        <paper-dropdown-menu
          id="dropdown"
          required=""
          hidden$="[[_equal(format, 24)]]"
          no-label-float=""
          disabled="[[disabled]]"
        >
          <paper-listbox
            attr-for-selected="name"
            selected="{{amPm}}"
            slot="dropdown-content"
          >
            <paper-item name="AM">AM</paper-item>
            <paper-item name="PM">PM</paper-item>
          </paper-listbox>
        </paper-dropdown-menu>
      </div>
    `}static get properties(){return{label:{type:String,value:"Time"},autoValidate:{type:Boolean,value:!0},hideLabel:{type:Boolean,value:!1},format:{type:Number,value:12},disabled:{type:Boolean,value:!1},hour:{type:String,notify:!0},min:{type:String,notify:!0},amPm:{type:String,notify:!0,value:"AM"},value:{type:String,notify:!0,readOnly:!0,computed:"_computeTime(min, hour, amPm)"}}}validate(){var valid=!0;if(!this.$.hour.validate()|!this.$.min.validate()){valid=!1}if(12===this.format&&!this.$.dropdown.validate()){valid=!1}return valid}_computeTime(min,hour,amPm){if(hour&&min){if(24===this.format){amPm=""}return hour+":"+min+" "+amPm}}_formatMin(){if(1===this.min.toString().length){this.min=10>this.min?"0"+this.min:this.min}}_shouldFormatHour(){if(24===this.format&&1===this.hour.toString().length){this.hour=10>this.hour?"0"+this.hour:this.hour}}_computeHourMax(format){if(12===format){return format}return 23}_equal(n1,n2){return n1===n2}}customElements.define("paper-time-input",paper_time_input_PaperTimeInput);class more_info_input_datetime_DatetimeInput extends polymer_element.a{static get template(){return html_tag.a`
      <div class$="[[computeClassNames(stateObj)]]">
        <template is="dom-if" if="[[doesHaveDate(stateObj)]]" restamp="">
          <div>
            <vaadin-date-picker
              id="dateInput"
              on-value-changed="dateTimeChanged"
              label="Date"
              value="{{selectedDate}}"
            ></vaadin-date-picker>
          </div>
        </template>
        <template is="dom-if" if="[[doesHaveTime(stateObj)]]" restamp="">
          <div>
            <paper-time-input
              hour="{{selectedHour}}"
              min="{{selectedMinute}}"
              format="24"
            ></paper-time-input>
          </div>
        </template>
      </div>
    `}constructor(){super();this.is_ready=!1}static get properties(){return{hass:{type:Object},stateObj:{type:Object,observer:"stateObjChanged"},selectedDate:{type:String,observer:"dateTimeChanged"},selectedHour:{type:Number,observer:"dateTimeChanged"},selectedMinute:{type:Number,observer:"dateTimeChanged"}}}ready(){super.ready();this.is_ready=!0}getDateString(stateObj){if("unknown"===stateObj.state){return""}var monthFiller;if(10>stateObj.attributes.month){monthFiller="0"}else{monthFiller=""}var dayFiller;if(10>stateObj.attributes.day){dayFiller="0"}else{dayFiller=""}return stateObj.attributes.year+"-"+monthFiller+stateObj.attributes.month+"-"+dayFiller+stateObj.attributes.day}dateTimeChanged(){if(!this.is_ready){return}let changed=!1,minuteFiller;const serviceData={entity_id:this.stateObj.entity_id};if(this.stateObj.attributes.has_time){changed|=parseInt(this.selectedMinute)!==this.stateObj.attributes.minute;changed|=parseInt(this.selectedHour)!==this.stateObj.attributes.hour;if(10>this.selectedMinute){minuteFiller="0"}else{minuteFiller=""}var timeStr=this.selectedHour+":"+minuteFiller+this.selectedMinute;serviceData.time=timeStr}if(this.stateObj.attributes.has_date){if(0===this.selectedDate.length){return}const dateValInput=new Date(this.selectedDate),dateValState=new Date(this.stateObj.attributes.year,this.stateObj.attributes.month-1,this.stateObj.attributes.day);changed|=dateValState!==dateValInput;serviceData.date=this.selectedDate}if(changed){this.hass.callService("input_datetime","set_datetime",serviceData)}}stateObjChanged(newVal){this.is_ready=!1;if(newVal.attributes.has_time){this.selectedHour=newVal.attributes.hour;this.selectedMinute=newVal.attributes.minute}if(newVal.attributes.has_date){this.selectedDate=this.getDateString(newVal)}this.is_ready=!0}doesHaveDate(stateObj){return stateObj.attributes.has_date}doesHaveTime(stateObj){return stateObj.attributes.has_time}computeClassNames(stateObj){return"more-info-input_datetime "+Object(attribute_class_names.a)(stateObj,["has_time","has_date"])}}customElements.define("more-info-input_datetime",more_info_input_datetime_DatetimeInput);class ha_color_picker_HaColorPicker extends Object(events_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          user-select: none;
          -webkit-user-select: none;
        }

        #canvas {
          position: relative;
          width: 100%;
          max-width: 330px;
        }
        #canvas > * {
          display: block;
        }
        #interactionLayer {
          color: white;
          position: absolute;
          cursor: crosshair;
          width: 100%;
          height: 100%;
          overflow: visible;
        }
        #backgroundLayer {
          width: 100%;
          overflow: visible;
          --wheel-bordercolor: var(--ha-color-picker-wheel-bordercolor, white);
          --wheel-borderwidth: var(--ha-color-picker-wheel-borderwidth, 3);
          --wheel-shadow: var(
            --ha-color-picker-wheel-shadow,
            rgb(15, 15, 15) 10px 5px 5px 0px
          );
        }

        #marker {
          fill: currentColor;
          stroke: var(--ha-color-picker-marker-bordercolor, white);
          stroke-width: var(--ha-color-picker-marker-borderwidth, 3);
          filter: url(#marker-shadow);
        }
        .dragging #marker {
        }

        #colorTooltip {
          display: none;
          fill: currentColor;
          stroke: var(--ha-color-picker-tooltip-bordercolor, white);
          stroke-width: var(--ha-color-picker-tooltip-borderwidth, 3);
        }

        .touch.dragging #colorTooltip {
          display: inherit;
        }
      </style>
      <div id="canvas">
        <svg id="interactionLayer">
          <defs>
            <filter
              id="marker-shadow"
              x="-50%"
              y="-50%"
              width="200%"
              height="200%"
              filterUnits="objectBoundingBox"
            >
              <feOffset
                result="offOut"
                in="SourceAlpha"
                dx="2"
                dy="2"
              ></feOffset>
              <feGaussianBlur
                result="blurOut"
                in="offOut"
                stdDeviation="2"
              ></feGaussianBlur>
              <feComponentTransfer in="blurOut" result="alphaOut">
                <feFuncA type="linear" slope="0.3"></feFuncA>
              </feComponentTransfer>
              <feBlend
                in="SourceGraphic"
                in2="alphaOut"
                mode="normal"
              ></feBlend>
            </filter>
          </defs>
        </svg>
        <canvas id="backgroundLayer"></canvas>
      </div>
    `}static get properties(){return{hsColor:{type:Object},desiredHsColor:{type:Object,observer:"applyHsColor"},width:{type:Number,value:500},height:{type:Number,value:500},radius:{type:Number,value:225},hueSegments:{type:Number,value:0},saturationSegments:{type:Number,value:0},ignoreSegments:{type:Boolean,value:!1},throttle:{type:Number,value:500}}}ready(){super.ready();this.setupLayers();this.drawColorWheel();this.drawMarker();this.interactionLayer.addEventListener("mousedown",ev=>this.onMouseDown(ev));this.interactionLayer.addEventListener("touchstart",ev=>this.onTouchStart(ev))}convertToCanvasCoordinates(clientX,clientY){var svgPoint=this.interactionLayer.createSVGPoint();svgPoint.x=clientX;svgPoint.y=clientY;var cc=svgPoint.matrixTransform(this.interactionLayer.getScreenCTM().inverse());return{x:cc.x,y:cc.y}}onMouseDown(ev){const cc=this.convertToCanvasCoordinates(ev.clientX,ev.clientY);if(!this.isInWheel(cc.x,cc.y)){return}this.onMouseSelect(ev);this.canvas.classList.add("mouse","dragging");this.addEventListener("mousemove",this.onMouseSelect);this.addEventListener("mouseup",this.onMouseUp)}onMouseUp(){this.canvas.classList.remove("mouse","dragging");this.removeEventListener("mousemove",this.onMouseSelect)}onMouseSelect(ev){requestAnimationFrame(()=>this.processUserSelect(ev))}onTouchStart(ev){var touch=ev.changedTouches[0];const cc=this.convertToCanvasCoordinates(touch.clientX,touch.clientY);if(!this.isInWheel(cc.x,cc.y)){return}if(ev.target===this.marker){ev.preventDefault();this.canvas.classList.add("touch","dragging");this.addEventListener("touchmove",this.onTouchSelect);this.addEventListener("touchend",this.onTouchEnd);return}this.tapBecameScroll=!1;this.addEventListener("touchend",this.onTap);this.addEventListener("touchmove",()=>{this.tapBecameScroll=!0},{passive:!0})}onTap(ev){if(this.tapBecameScroll){return}ev.preventDefault();this.onTouchSelect(ev)}onTouchEnd(){this.canvas.classList.remove("touch","dragging");this.removeEventListener("touchmove",this.onTouchSelect)}onTouchSelect(ev){requestAnimationFrame(()=>this.processUserSelect(ev.changedTouches[0]))}processUserSelect(ev){var canvasXY=this.convertToCanvasCoordinates(ev.clientX,ev.clientY),hs=this.getColor(canvasXY.x,canvasXY.y);this.onColorSelect(hs)}onColorSelect(hs){this.setMarkerOnColor(hs);if(!this.ignoreSegments){hs=this.applySegmentFilter(hs)}this.applyColorToCanvas(hs);if(this.colorSelectIsThrottled){clearTimeout(this.ensureFinalSelect);this.ensureFinalSelect=setTimeout(()=>{this.fireColorSelected(hs)},this.throttle);return}this.fireColorSelected(hs);this.colorSelectIsThrottled=!0;setTimeout(()=>{this.colorSelectIsThrottled=!1},this.throttle)}fireColorSelected(hs){this.hsColor=hs;this.fire("colorselected",{hs:{h:hs.h,s:hs.s}})}setMarkerOnColor(hs){var dist=hs.s*this.radius,theta=(hs.h-180)/180*_MathPI,markerdX=-dist*Math.cos(theta),markerdY=-dist*Math.sin(theta),translateString=`translate(${markerdX},${markerdY})`;this.marker.setAttribute("transform",translateString);this.tooltip.setAttribute("transform",translateString)}applyColorToCanvas(hs){this.interactionLayer.style.color=`hsl(${hs.h}, 100%, ${100-50*hs.s}%)`}applyHsColor(hs){if(this.hsColor&&this.hsColor.h===hs.h&&this.hsColor.s===hs.s){return}this.setMarkerOnColor(hs);if(!this.ignoreSegments){hs=this.applySegmentFilter(hs)}this.hsColor=hs;this.applyColorToCanvas(hs)}getAngle(dX,dY){var theta=Math.atan2(-dY,-dX);return 180*(theta/_MathPI)+180}isInWheel(x,y){return 1>=this.getDistance(x,y)}getDistance(dX,dY){return Math.sqrt(dX*dX+dY*dY)/this.radius}getColor(x,y){var hue=this.getAngle(x,y),relativeDistance=this.getDistance(x,y),sat=_Mathmin2(relativeDistance,1);return{h:hue,s:sat}}applySegmentFilter(hs){if(this.hueSegments){const angleStep=360/this.hueSegments;hs.h-=angleStep/2;if(0>hs.h){hs.h+=360}const rest=hs.h%angleStep;hs.h-=rest-angleStep}if(this.saturationSegments){if(1===this.saturationSegments){hs.s=1}else{var segmentSize=1/this.saturationSegments,saturationStep=1/(this.saturationSegments-1),calculatedSat=Math.floor(hs.s/segmentSize)*saturationStep;hs.s=_Mathmin2(calculatedSat,1)}}return hs}setupLayers(){this.canvas=this.$.canvas;this.backgroundLayer=this.$.backgroundLayer;this.interactionLayer=this.$.interactionLayer;this.originX=this.width/2;this.originY=this.originX;this.backgroundLayer.width=this.width;this.backgroundLayer.height=this.height;this.interactionLayer.setAttribute("viewBox",`${-this.originX} ${-this.originY} ${this.width} ${this.height}`)}drawColorWheel(){let shadowColor,shadowOffsetX,shadowOffsetY,shadowBlur;const context=this.backgroundLayer.getContext("2d"),cX=this.originX,cY=this.originY,radius=this.radius,wheelStyle=window.getComputedStyle(this.backgroundLayer,null),borderWidth=parseInt(wheelStyle.getPropertyValue("--wheel-borderwidth"),10),borderColor=wheelStyle.getPropertyValue("--wheel-bordercolor").trim(),wheelShadow=wheelStyle.getPropertyValue("--wheel-shadow").trim();if("none"!==wheelShadow){const values=wheelShadow.split("px ");shadowColor=values.pop();shadowOffsetX=parseInt(values[0],10);shadowOffsetY=parseInt(values[1],10);shadowBlur=parseInt(values[2],10)||0}const wheelRadius=radius;function drawShadow(){context.save();context.beginPath();context.arc(cX,cY,radius+borderWidth,0,2*_MathPI,!1);context.shadowColor=shadowColor;context.shadowOffsetX=shadowOffsetX;context.shadowOffsetY=shadowOffsetY;context.shadowBlur=shadowBlur;context.fillStyle="white";context.fill();context.restore()}function drawBorder(){context.beginPath();context.arc(cX,cY,radius+borderWidth/2,0,2*_MathPI,!1);context.lineWidth=borderWidth;context.strokeStyle=borderColor;context.stroke()}if("none"!==wheelStyle.shadow){drawShadow()}(function(hueSegments,saturationSegments){hueSegments=hueSegments||360;const angleStep=360/hueSegments,halfAngleStep=angleStep/2;for(var angle=0;360>=angle;angle+=angleStep){var startAngle=(angle-halfAngleStep)*(_MathPI/180),endAngle=(angle+halfAngleStep+1)*(_MathPI/180);context.beginPath();context.moveTo(cX,cY);context.arc(cX,cY,wheelRadius,startAngle,endAngle,!1);context.closePath();var gradient=context.createRadialGradient(cX,cY,0,cX,cY,wheelRadius);let lightness=100;gradient.addColorStop(0,`hsl(${angle}, 100%, ${lightness}%)`);if(0<saturationSegments){let ratio=0;for(var stop=1,prevLighness;stop<saturationSegments;stop+=1){prevLighness=lightness;ratio=stop*(1/saturationSegments);lightness=100-50*ratio;gradient.addColorStop(ratio,`hsl(${angle}, 100%, ${prevLighness}%)`);gradient.addColorStop(ratio,`hsl(${angle}, 100%, ${lightness}%)`)}gradient.addColorStop(ratio,`hsl(${angle}, 100%, 50%)`)}gradient.addColorStop(1,`hsl(${angle}, 100%, 50%)`);context.fillStyle=gradient;context.fill()}})(this.hueSegments,this.saturationSegments);if(0<borderWidth){drawBorder()}}drawMarker(){const svgElement=this.interactionLayer,markerradius=.08*this.radius,tooltipradius=.15*this.radius;svgElement.marker=document.createElementNS("http://www.w3.org/2000/svg","circle");svgElement.marker.setAttribute("id","marker");svgElement.marker.setAttribute("r",markerradius);this.marker=svgElement.marker;svgElement.appendChild(svgElement.marker);svgElement.tooltip=document.createElementNS("http://www.w3.org/2000/svg","circle");svgElement.tooltip.setAttribute("id","colorTooltip");svgElement.tooltip.setAttribute("r",tooltipradius);svgElement.tooltip.setAttribute("cx",0);svgElement.tooltip.setAttribute("cy",-(3*tooltipradius));this.tooltip=svgElement.tooltip;svgElement.appendChild(svgElement.tooltip)}}customElements.define("ha-color-picker",ha_color_picker_HaColorPicker);const more_info_light_FEATURE_CLASS_NAMES={1:"has-brightness",2:"has-color_temp",4:"has-effect_list",16:"has-color",128:"has-white_value"};class more_info_light_MoreInfoLight extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="iron-flex"></style>
      <style>
        .effect_list,
        .brightness,
        .color_temp,
        .white_value {
          max-height: 0px;
          overflow: hidden;
          transition: max-height 0.5s ease-in;
        }

        .color_temp {
          --ha-slider-background: -webkit-linear-gradient(
            right,
            rgb(255, 160, 0) 0%,
            white 50%,
            rgb(166, 209, 255) 100%
          );
          /* The color temp minimum value shouldn't be rendered differently. It's not "off". */
          --paper-slider-knob-start-border-color: var(--primary-color);
        }

        ha-color-picker {
          display: block;
          width: 100%;

          max-height: 0px;
          overflow: hidden;
          transition: max-height 0.5s ease-in;
        }

        .has-effect_list.is-on .effect_list,
        .has-brightness .brightness,
        .has-color_temp.is-on .color_temp,
        .has-white_value.is-on .white_value {
          max-height: 84px;
        }

        .has-brightness .has-color_temp.is-on,
        .has-white_value.is-on {
          margin-top: -16px;
        }

        .has-brightness .brightness,
        .has-color_temp.is-on .color_temp,
        .has-white_value.is-on .white_value {
          padding-top: 16px;
        }

        .has-color.is-on ha-color-picker {
          max-height: 500px;
          overflow: visible;
          --ha-color-picker-wheel-borderwidth: 5;
          --ha-color-picker-wheel-bordercolor: white;
          --ha-color-picker-wheel-shadow: none;
          --ha-color-picker-marker-borderwidth: 2;
          --ha-color-picker-marker-bordercolor: white;
        }

        .is-unavailable .control {
          max-height: 0px;
        }

        paper-item {
          cursor: pointer;
        }
      </style>

      <div class$="[[computeClassNames(stateObj)]]">
        <div class="control brightness">
          <ha-labeled-slider
            caption="[[localize('ui.card.light.brightness')]]"
            icon="hass:brightness-5"
            min="1"
            max="255"
            value="{{brightnessSliderValue}}"
            on-change="brightnessSliderChanged"
          ></ha-labeled-slider>
        </div>

        <div class="control color_temp">
          <ha-labeled-slider
            caption="[[localize('ui.card.light.color_temperature')]]"
            icon="hass:thermometer"
            min="[[stateObj.attributes.min_mireds]]"
            max="[[stateObj.attributes.max_mireds]]"
            value="{{ctSliderValue}}"
            on-change="ctSliderChanged"
          ></ha-labeled-slider>
        </div>

        <div class="control white_value">
          <ha-labeled-slider
            caption="[[localize('ui.card.light.white_value')]]"
            icon="hass:file-word-box"
            max="255"
            value="{{wvSliderValue}}"
            on-change="wvSliderChanged"
          ></ha-labeled-slider>
        </div>

        <ha-color-picker
          class="control color"
          on-colorselected="colorPicked"
          desired-hs-color="{{colorPickerColor}}"
          throttle="500"
          hue-segments="24"
          saturation-segments="8"
        >
        </ha-color-picker>

        <div class="control effect_list">
          <paper-dropdown-menu
            label-float=""
            dynamic-align=""
            label="[[localize('ui.card.light.effect')]]"
          >
            <paper-listbox slot="dropdown-content" selected="{{effectIndex}}">
              <template
                is="dom-repeat"
                items="[[stateObj.attributes.effect_list]]"
              >
                <paper-item>[[item]]</paper-item>
              </template>
            </paper-listbox>
          </paper-dropdown-menu>
        </div>

        <ha-attributes
          state-obj="[[stateObj]]"
          extra-filters="brightness,color_temp,white_value,effect_list,effect,hs_color,rgb_color,xy_color,min_mireds,max_mireds"
        ></ha-attributes>
      </div>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object,observer:"stateObjChanged"},effectIndex:{type:Number,value:-1,observer:"effectChanged"},brightnessSliderValue:{type:Number,value:0},ctSliderValue:{type:Number,value:0},wvSliderValue:{type:Number,value:0},colorPickerColor:{type:Object}}}stateObjChanged(newVal,oldVal){const props={brightnessSliderValue:0};if(newVal&&"on"===newVal.state){props.brightnessSliderValue=newVal.attributes.brightness;props.ctSliderValue=newVal.attributes.color_temp;props.wvSliderValue=newVal.attributes.white_value;if(newVal.attributes.hs_color){props.colorPickerColor={h:newVal.attributes.hs_color[0],s:newVal.attributes.hs_color[1]/100}}if(newVal.attributes.effect_list){props.effectIndex=newVal.attributes.effect_list.indexOf(newVal.attributes.effect)}else{props.effectIndex=-1}}this.setProperties(props);if(oldVal){setTimeout(()=>{this.fire("iron-resize")},500)}}computeClassNames(stateObj){const classes=[featureClassNames(stateObj,more_info_light_FEATURE_CLASS_NAMES)];if(stateObj&&"on"===stateObj.state){classes.push("is-on")}if(stateObj&&"unavailable"===stateObj.state){classes.push("is-unavailable")}return classes.join(" ")}effectChanged(effectIndex){var effectInput;if(""===effectIndex||-1===effectIndex)return;effectInput=this.stateObj.attributes.effect_list[effectIndex];if(effectInput===this.stateObj.attributes.effect)return;this.hass.callService("light","turn_on",{entity_id:this.stateObj.entity_id,effect:effectInput})}brightnessSliderChanged(ev){var bri=parseInt(ev.target.value,10);if(isNaN(bri))return;this.hass.callService("light","turn_on",{entity_id:this.stateObj.entity_id,brightness:bri})}ctSliderChanged(ev){var ct=parseInt(ev.target.value,10);if(isNaN(ct))return;this.hass.callService("light","turn_on",{entity_id:this.stateObj.entity_id,color_temp:ct})}wvSliderChanged(ev){var wv=parseInt(ev.target.value,10);if(isNaN(wv))return;this.hass.callService("light","turn_on",{entity_id:this.stateObj.entity_id,white_value:wv})}serviceChangeColor(hass,entityId,color){hass.callService("light","turn_on",{entity_id:entityId,hs_color:[color.h,100*color.s]})}colorPicked(ev){this.serviceChangeColor(this.hass,this.stateObj.entity_id,ev.detail.hs)}}customElements.define("more-info-light",more_info_light_MoreInfoLight);class more_info_lock_MoreInfoLock extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        paper-input {
          display: inline-block;
        }
      </style>

      <template is="dom-if" if="[[stateObj.attributes.code_format]]">
        <paper-input
          label="[[localize('ui.card.lock.code')]]"
          value="{{enteredCode}}"
          pattern="[[stateObj.attributes.code_format]]"
          type="password"
        ></paper-input>
        <paper-button
          on-click="callService"
          data-service="unlock"
          hidden$="[[!isLocked]]"
          >[[localize('ui.card.lock.unlock')]]</paper-button
        >
        <paper-button
          on-click="callService"
          data-service="lock"
          hidden$="[[isLocked]]"
          >[[localize('ui.card.lock.lock')]]</paper-button
        >
      </template>
      <ha-attributes
        state-obj="[[stateObj]]"
        extra-filters="code_format"
      ></ha-attributes>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"stateObjChanged"},enteredCode:{type:String,value:""},isLocked:Boolean}}stateObjChanged(newVal){if(newVal){this.isLocked="locked"===newVal.state}}callService(ev){const service=ev.target.getAttribute("data-service"),data={entity_id:this.stateObj.entity_id,code:this.enteredCode};this.hass.callService("lock",service,data)}}customElements.define("more-info-lock",more_info_lock_MoreInfoLock);var iron_icon=__webpack_require__(95),hass_media_player_model=__webpack_require__(220),is_component_loaded=__webpack_require__(185);class more_info_media_player_MoreInfoMediaPlayer extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        .media-state {
          text-transform: capitalize;
        }

        paper-icon-button[highlight] {
          color: var(--accent-color);
        }

        .volume {
          margin-bottom: 8px;

          max-height: 0px;
          overflow: hidden;
          transition: max-height 0.5s ease-in;
        }

        .has-volume_level .volume {
          max-height: 40px;
        }

        iron-icon.source-input {
          padding: 7px;
          margin-top: 15px;
        }

        paper-dropdown-menu.source-input {
          margin-left: 10px;
        }

        [hidden] {
          display: none !important;
        }

        paper-item {
          cursor: pointer;
        }
      </style>

      <div class$="[[computeClassNames(stateObj)]]">
        <div class="layout horizontal">
          <div class="flex">
            <paper-icon-button
              icon="hass:power"
              highlight$="[[playerObj.isOff]]"
              on-click="handleTogglePower"
              hidden$="[[computeHidePowerButton(playerObj)]]"
            ></paper-icon-button>
          </div>
          <div>
            <template
              is="dom-if"
              if="[[computeShowPlaybackControls(playerObj)]]"
            >
              <paper-icon-button
                icon="hass:skip-previous"
                on-click="handlePrevious"
                hidden$="[[!playerObj.supportsPreviousTrack]]"
              ></paper-icon-button>
              <paper-icon-button
                icon="[[computePlaybackControlIcon(playerObj)]]"
                on-click="handlePlaybackControl"
                hidden$="[[!computePlaybackControlIcon(playerObj)]]"
                highlight=""
              ></paper-icon-button>
              <paper-icon-button
                icon="hass:skip-next"
                on-click="handleNext"
                hidden$="[[!playerObj.supportsNextTrack]]"
              ></paper-icon-button>
            </template>
          </div>
        </div>
        <!-- VOLUME -->
        <div
          class="volume_buttons center horizontal layout"
          hidden$="[[computeHideVolumeButtons(playerObj)]]"
        >
          <paper-icon-button
            on-click="handleVolumeTap"
            icon="hass:volume-off"
          ></paper-icon-button>
          <paper-icon-button
            id="volumeDown"
            disabled$="[[playerObj.isMuted]]"
            on-mousedown="handleVolumeDown"
            on-touchstart="handleVolumeDown"
            icon="hass:volume-medium"
          ></paper-icon-button>
          <paper-icon-button
            id="volumeUp"
            disabled$="[[playerObj.isMuted]]"
            on-mousedown="handleVolumeUp"
            on-touchstart="handleVolumeUp"
            icon="hass:volume-high"
          ></paper-icon-button>
        </div>
        <div
          class="volume center horizontal layout"
          hidden$="[[!playerObj.supportsVolumeSet]]"
        >
          <paper-icon-button
            on-click="handleVolumeTap"
            hidden$="[[playerObj.supportsVolumeButtons]]"
            icon="[[computeMuteVolumeIcon(playerObj)]]"
          ></paper-icon-button>
          <ha-paper-slider
            disabled$="[[playerObj.isMuted]]"
            min="0"
            max="100"
            value="[[playerObj.volumeSliderValue]]"
            on-change="volumeSliderChanged"
            class="flex"
            ignore-bar-touch=""
          >
          </ha-paper-slider>
        </div>
        <!-- SOURCE PICKER -->
        <div
          class="controls layout horizontal justified"
          hidden$="[[computeHideSelectSource(playerObj)]]"
        >
          <iron-icon class="source-input" icon="hass:login-variant"></iron-icon>
          <paper-dropdown-menu
            class="flex source-input"
            dynamic-align=""
            label-float=""
            label="[[localize('ui.card.media_player.source')]]"
          >
            <paper-listbox slot="dropdown-content" selected="{{sourceIndex}}">
              <template is="dom-repeat" items="[[playerObj.sourceList]]">
                <paper-item>[[item]]</paper-item>
              </template>
            </paper-listbox>
          </paper-dropdown-menu>
        </div>
        <!-- SOUND MODE PICKER -->
        <template is="dom-if" if="[[!computeHideSelectSoundMode(playerObj)]]">
          <div class="controls layout horizontal justified">
            <iron-icon class="source-input" icon="hass:music-note"></iron-icon>
            <paper-dropdown-menu
              class="flex source-input"
              dynamic-align
              label-float
              label="[[localize('ui.card.media_player.sound_mode')]]"
            >
              <paper-listbox
                slot="dropdown-content"
                attr-for-selected="item-name"
                selected="{{SoundModeInput}}"
              >
                <template is="dom-repeat" items="[[playerObj.soundModeList]]">
                  <paper-item item-name$="[[item]]">[[item]]</paper-item>
                </template>
              </paper-listbox>
            </paper-dropdown-menu>
          </div>
        </template>
        <!-- TTS -->
        <div
          hidden$="[[computeHideTTS(ttsLoaded, playerObj)]]"
          class="layout horizontal end"
        >
          <paper-input
            id="ttsInput"
            label="[[localize('ui.card.media_player.text_to_speak')]]"
            class="flex"
            value="{{ttsMessage}}"
            on-keydown="ttsCheckForEnter"
          ></paper-input>
          <paper-icon-button
            icon="hass:send"
            on-click="sendTTS"
          ></paper-icon-button>
        </div>
      </div>
    `}static get properties(){return{hass:Object,stateObj:Object,playerObj:{type:Object,computed:"computePlayerObj(hass, stateObj)",observer:"playerObjChanged"},sourceIndex:{type:Number,value:0,observer:"handleSourceChanged"},SoundModeInput:{type:String,value:"",observer:"handleSoundModeChanged"},ttsLoaded:{type:Boolean,computed:"computeTTSLoaded(hass)"},ttsMessage:{type:String,value:""}}}computePlayerObj(hass,stateObj){return new hass_media_player_model.a(hass,stateObj)}playerObjChanged(newVal,oldVal){if(newVal&&newVal.sourceList!==void 0){this.sourceIndex=newVal.sourceList.indexOf(newVal.source)}if(newVal&&newVal.soundModeList!==void 0){this.SoundModeInput=newVal.soundMode}if(oldVal){setTimeout(()=>{this.fire("iron-resize")},500)}}computeClassNames(stateObj){return Object(attribute_class_names.a)(stateObj,["volume_level"])}computeMuteVolumeIcon(playerObj){return playerObj.isMuted?"hass:volume-off":"hass:volume-high"}computeHideVolumeButtons(playerObj){return!playerObj.supportsVolumeButtons||playerObj.isOff}computeShowPlaybackControls(playerObj){return!playerObj.isOff&&playerObj.hasMediaControl}computePlaybackControlIcon(playerObj){if(playerObj.isPlaying){return playerObj.supportsPause?"hass:pause":"hass:stop"}if(playerObj.hasMediaControl||playerObj.isOff||playerObj.isIdle){if(playerObj.hasMediaControl&&playerObj.supportsPause&&!playerObj.isPaused){return"hass:play-pause"}return playerObj.supportsPlay?"hass:play":null}return""}computeHidePowerButton(playerObj){return playerObj.isOff?!playerObj.supportsTurnOn:!playerObj.supportsTurnOff}computeHideSelectSource(playerObj){return playerObj.isOff||!playerObj.supportsSelectSource||!playerObj.sourceList}computeHideSelectSoundMode(playerObj){return playerObj.isOff||!playerObj.supportsSelectSoundMode||!playerObj.soundModeList}computeHideTTS(ttsLoaded,playerObj){return!ttsLoaded||!playerObj.supportsPlayMedia}computeTTSLoaded(hass){return Object(is_component_loaded.a)(hass,"tts")}handleTogglePower(){this.playerObj.togglePower()}handlePrevious(){this.playerObj.previousTrack()}handlePlaybackControl(){this.playerObj.mediaPlayPause()}handleNext(){this.playerObj.nextTrack()}handleSourceChanged(sourceIndex,sourceIndexOld){if(!this.playerObj||!this.playerObj.supportsSelectSource||this.playerObj.sourceList===void 0||0>sourceIndex||sourceIndex>=this.playerObj.sourceList||sourceIndexOld===void 0){return}const sourceInput=this.playerObj.sourceList[sourceIndex];if(sourceInput===this.playerObj.source){return}this.playerObj.selectSource(sourceInput)}handleSoundModeChanged(newVal,oldVal){if(oldVal&&newVal!==this.playerObj.soundMode&&this.playerObj.supportsSelectSoundMode){this.playerObj.selectSoundMode(newVal)}}handleVolumeTap(){if(!this.playerObj.supportsVolumeMute){return}this.playerObj.volumeMute(!this.playerObj.isMuted)}handleVolumeUp(){const obj=this.$.volumeUp;this.handleVolumeWorker("volume_up",obj,!0)}handleVolumeDown(){const obj=this.$.volumeDown;this.handleVolumeWorker("volume_down",obj,!0)}handleVolumeWorker(service,obj,force){if(force||obj!==void 0&&obj.pointerDown){this.playerObj.callService(service);setTimeout(()=>this.handleVolumeWorker(service,obj,!1),500)}}volumeSliderChanged(ev){const volPercentage=parseFloat(ev.target.value),volume=0<volPercentage?volPercentage/100:0;this.playerObj.setVolume(volume)}ttsCheckForEnter(ev){if(13===ev.keyCode)this.sendTTS()}sendTTS(){const services=this.hass.services.tts,serviceKeys=Object.keys(services).sort();let service,i;for(i=0;i<serviceKeys.length;i++){if(-1!==serviceKeys[i].indexOf("_say")){service=serviceKeys[i];break}}if(!service){return}this.hass.callService("tts",service,{entity_id:this.stateObj.entity_id,message:this.ttsMessage});this.ttsMessage="";this.$.ttsInput.focus()}}customElements.define("more-info-media_player",more_info_media_player_MoreInfoMediaPlayer);class more_info_script_MoreInfoScript extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>

      <div class="layout vertical">
        <div class="data-entry layout justified horizontal">
          <div class="key">
            [[localize('ui.dialogs.more_info_control.script.last_action')]]
          </div>
          <div class="value">[[stateObj.attributes.last_action]]</div>
        </div>
      </div>
    `}static get properties(){return{stateObj:{type:Object}}}}customElements.define("more-info-script",more_info_script_MoreInfoScript);var format_time=__webpack_require__(188);class more_info_sun_MoreInfoSun extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>

      <template
        is="dom-repeat"
        items="[[computeOrder(risingDate, settingDate)]]"
      >
        <div class="data-entry layout justified horizontal">
          <div class="key">
            <span>[[itemCaption(item)]]</span>
            <ha-relative-time
              hass="[[hass]]"
              datetime-obj="[[itemDate(item)]]"
            ></ha-relative-time>
          </div>
          <div class="value">[[itemValue(item)]]</div>
        </div>
      </template>
      <div class="data-entry layout justified horizontal">
        <div class="key">
          [[localize('ui.dialogs.more_info_control.sun.elevation')]]
        </div>
        <div class="value">[[stateObj.attributes.elevation]]</div>
      </div>
    `}static get properties(){return{hass:Object,stateObj:Object,risingDate:{type:Object,computed:"computeRising(stateObj)"},settingDate:{type:Object,computed:"computeSetting(stateObj)"}}}computeRising(stateObj){return new Date(stateObj.attributes.next_rising)}computeSetting(stateObj){return new Date(stateObj.attributes.next_setting)}computeOrder(risingDate,settingDate){return risingDate>settingDate?["set","ris"]:["ris","set"]}itemCaption(type){if("ris"===type){return this.localize("ui.dialogs.more_info_control.sun.rising")}return this.localize("ui.dialogs.more_info_control.sun.setting")}itemDate(type){return"ris"===type?this.risingDate:this.settingDate}itemValue(type){return Object(format_time.a)(this.itemDate(type),this.hass.language)}}customElements.define("more-info-sun",more_info_sun_MoreInfoSun);class more_info_updater_MoreInfoUpdater extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        .link {
          color: #03a9f4;
        }
      </style>

      <div>
        <a
          class="link"
          href="https://www.home-assistant.io/docs/installation/updating/"
          target="_blank"
          >[[localize('ui.dialogs.more_info_control.updater.title')]]</a
        >
      </div>
    `}static get properties(){return{stateObj:{type:Object}}}computeReleaseNotes(stateObj){return stateObj.attributes.release_notes||"https://www.home-assistant.io/docs/installation/updating/"}}customElements.define("more-info-updater",more_info_updater_MoreInfoUpdater);class more_info_vacuum_MoreInfoVacuum extends polymer_element.a{static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        :host {
          @apply --paper-font-body1;
          line-height: 1.5;
        }

        .status-subtitle {
          color: var(--secondary-text-color);
        }

        paper-item {
          cursor: pointer;
        }
      </style>

      <div class="horizontal justified layout">
        <div hidden$="[[!supportsStatus(stateObj)]]">
          <span class="status-subtitle">Status: </span
          ><span><strong>[[stateObj.attributes.status]]</strong></span>
        </div>
        <div hidden$="[[!supportsBattery(stateObj)]]">
          <span
            ><iron-icon icon="[[stateObj.attributes.battery_icon]]"></iron-icon>
            [[stateObj.attributes.battery_level]] %</span
          >
        </div>
      </div>
      <div hidden$="[[!supportsCommandBar(stateObj)]]">
        <p></p>
        <div class="status-subtitle">Vacuum cleaner commands:</div>
        <div class="horizontal justified layout">
          <template is="dom-if" if="[[supportsStart(stateObj)]]">
            <div>
              <paper-icon-button
                icon="hass:play"
                on-click="onStart"
                title="Start"
              ></paper-icon-button>
            </div>
            <div hidden$="[[!supportsPause(stateObj)]]">
              <paper-icon-button
                icon="hass:pause"
                on-click="onPause"
                title="Pause"
              ></paper-icon-button>
            </div>
          </template>
          <template is="dom-if" if="[[!supportsStart(stateObj)]]">
            <div hidden$="[[!supportsPause(stateObj)]]">
              <paper-icon-button
                icon="hass:play-pause"
                on-click="onPlayPause"
                title="Pause"
              ></paper-icon-button>
            </div>
          </template>

          <div hidden$="[[!supportsStop(stateObj)]]">
            <paper-icon-button
              icon="hass:stop"
              on-click="onStop"
              title="Stop"
            ></paper-icon-button>
          </div>
          <div hidden$="[[!supportsCleanSpot(stateObj)]]">
            <paper-icon-button
              icon="hass:broom"
              on-click="onCleanSpot"
              title="Clean spot"
            ></paper-icon-button>
          </div>
          <div hidden$="[[!supportsLocate(stateObj)]]">
            <paper-icon-button
              icon="hass:map-marker"
              on-click="onLocate"
              title="Locate"
            ></paper-icon-button>
          </div>
          <div hidden$="[[!supportsReturnHome(stateObj)]]">
            <paper-icon-button
              icon="hass:home-map-marker"
              on-click="onReturnHome"
              title="Return home"
            ></paper-icon-button>
          </div>
        </div>
      </div>

      <div hidden$="[[!supportsFanSpeed(stateObj)]]">
        <div class="horizontal justified layout">
          <paper-dropdown-menu
            label-float=""
            dynamic-align=""
            label="Fan speed"
          >
            <paper-listbox slot="dropdown-content" selected="{{fanSpeedIndex}}">
              <template
                is="dom-repeat"
                items="[[stateObj.attributes.fan_speed_list]]"
              >
                <paper-item>[[item]]</paper-item>
              </template>
            </paper-listbox>
          </paper-dropdown-menu>
          <div
            style="justify-content: center; align-self: center; padding-top: 1.3em"
          >
            <span
              ><iron-icon icon="hass:fan"></iron-icon>
              [[stateObj.attributes.fan_speed]]</span
            >
          </div>
        </div>
        <p></p>
      </div>
      <ha-attributes
        state-obj="[[stateObj]]"
        extra-filters="fan_speed,fan_speed_list,status,battery_level,battery_icon"
      ></ha-attributes>
    `}static get properties(){return{hass:{type:Object},inDialog:{type:Boolean,value:!1},stateObj:{type:Object},fanSpeedIndex:{type:Number,value:-1,observer:"fanSpeedChanged"}}}supportsPause(stateObj){return Object(supports_feature.a)(stateObj,4)}supportsStop(stateObj){return Object(supports_feature.a)(stateObj,8)}supportsReturnHome(stateObj){return Object(supports_feature.a)(stateObj,16)}supportsFanSpeed(stateObj){return Object(supports_feature.a)(stateObj,32)}supportsBattery(stateObj){return Object(supports_feature.a)(stateObj,64)}supportsStatus(stateObj){return Object(supports_feature.a)(stateObj,128)}supportsLocate(stateObj){return Object(supports_feature.a)(stateObj,512)}supportsCleanSpot(stateObj){return Object(supports_feature.a)(stateObj,1024)}supportsStart(stateObj){return Object(supports_feature.a)(stateObj,8192)}supportsCommandBar(stateObj){return Object(supports_feature.a)(stateObj,4)|Object(supports_feature.a)(stateObj,8)|Object(supports_feature.a)(stateObj,16)|Object(supports_feature.a)(stateObj,512)|Object(supports_feature.a)(stateObj,1024)|Object(supports_feature.a)(stateObj,8192)}fanSpeedChanged(fanSpeedIndex){var fanSpeedInput;if(""===fanSpeedIndex||-1===fanSpeedIndex)return;fanSpeedInput=this.stateObj.attributes.fan_speed_list[fanSpeedIndex];if(fanSpeedInput===this.stateObj.attributes.fan_speed)return;this.hass.callService("vacuum","set_fan_speed",{entity_id:this.stateObj.entity_id,fan_speed:fanSpeedInput})}onStop(){this.hass.callService("vacuum","stop",{entity_id:this.stateObj.entity_id})}onPlayPause(){this.hass.callService("vacuum","start_pause",{entity_id:this.stateObj.entity_id})}onPause(){this.hass.callService("vacuum","pause",{entity_id:this.stateObj.entity_id})}onStart(){this.hass.callService("vacuum","start",{entity_id:this.stateObj.entity_id})}onLocate(){this.hass.callService("vacuum","locate",{entity_id:this.stateObj.entity_id})}onCleanSpot(){this.hass.callService("vacuum","clean_spot",{entity_id:this.stateObj.entity_id})}onReturnHome(){this.hass.callService("vacuum","return_to_base",{entity_id:this.stateObj.entity_id})}}customElements.define("more-info-vacuum",more_info_vacuum_MoreInfoVacuum);class ha_water_heater_control_HaWaterHeaterControl extends Object(events_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="iron-flex iron-flex-alignment"></style>
      <style>
        /* local DOM styles go here */
        :host {
          @apply --layout-flex;
          @apply --layout-horizontal;
          @apply --layout-justified;
        }
        .in-flux#target_temperature {
          color: var(--google-red-500);
        }
        #target_temperature {
          @apply --layout-self-center;
          font-size: 200%;
        }
        .control-buttons {
          font-size: 200%;
          text-align: right;
        }
        paper-icon-button {
          height: 48px;
          width: 48px;
        }
      </style>

      <!-- local DOM goes here -->
      <div id="target_temperature">[[value]] [[units]]</div>
      <div class="control-buttons">
        <div>
          <paper-icon-button
            icon="hass:chevron-up"
            on-click="incrementValue"
          ></paper-icon-button>
        </div>
        <div>
          <paper-icon-button
            icon="hass:chevron-down"
            on-click="decrementValue"
          ></paper-icon-button>
        </div>
      </div>
    `}static get properties(){return{value:{type:Number,observer:"valueChanged"},units:{type:String},min:{type:Number},max:{type:Number},step:{type:Number,value:1}}}temperatureStateInFlux(inFlux){this.$.target_temperature.classList.toggle("in-flux",inFlux)}incrementValue(){const newval=this.value+this.step;if(this.value<this.max){this.last_changed=Date.now();this.temperatureStateInFlux(!0)}if(newval<=this.max){if(newval<=this.min){this.value=this.min}else{this.value=newval}}else{this.value=this.max}}decrementValue(){const newval=this.value-this.step;if(this.value>this.min){this.last_changed=Date.now();this.temperatureStateInFlux(!0)}if(newval>=this.min){this.value=newval}else{this.value=this.min}}valueChanged(){if(this.last_changed){window.setTimeout(()=>{const now=Date.now();if(2e3<=now-this.last_changed){this.fire("change");this.temperatureStateInFlux(!1);this.last_changed=null}},2010)}}}customElements.define("ha-water_heater-control",ha_water_heater_control_HaWaterHeaterControl);class more_info_water_heater_MoreInfoWaterHeater extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style include="iron-flex"></style>
      <style>
        :host {
          color: var(--primary-text-color);
        }

        .container-away_mode,
        .container-temperature,
        .container-operation_list,

        .has-away_mode .container-away_mode,
        .has-target_temperature .container-temperature,
        .has-operation_mode .container-operation_list,

        .container-operation_list iron-icon,

        paper-dropdown-menu {
          width: 100%;
        }

        paper-item {
          cursor: pointer;
        }

        ha-paper-slider {
          width: 100%;
        }

        ha-water_heater-control.range-control-left,
        ha-water_heater-control.range-control-right {
          float: left;
          width: 46%;
        }
        ha-water_heater-control.range-control-left {
          margin-right: 4%;
        }
        ha-water_heater-control.range-control-right {
          margin-left: 4%;
        }

        .single-row {
          padding: 8px 0;
        }
        }
      </style>

      <div class$="[[computeClassNames(stateObj)]]">
        <div class="container-temperature">
          <div class$="[[stateObj.attributes.operation_mode]]">
            <div hidden$="[[!supportsTemperatureControls(stateObj)]]">
              [[localize('ui.card.water_heater.target_temperature')]]
            </div>
            <template is="dom-if" if="[[supportsTemperature(stateObj)]]">
              <ha-water_heater-control
                value="[[stateObj.attributes.temperature]]"
                units="[[hass.config.unit_system.temperature]]"
                step="[[computeTemperatureStepSize(hass, stateObj)]]"
                min="[[stateObj.attributes.min_temp]]"
                max="[[stateObj.attributes.max_temp]]"
                on-change="targetTemperatureChanged"
              >
              </ha-water_heater-control>
            </template>
          </div>
        </div>

        <template is="dom-if" if="[[supportsOperationMode(stateObj)]]">
          <div class="container-operation_list">
            <div class="controls">
              <paper-dropdown-menu
                label-float=""
                dynamic-align=""
                label="[[localize('ui.card.water_heater.operation')]]"
              >
                <paper-listbox
                  slot="dropdown-content"
                  selected="{{operationIndex}}"
                >
                  <template
                    is="dom-repeat"
                    items="[[stateObj.attributes.operation_list]]"
                    on-dom-change="handleOperationListUpdate"
                  >
                    <paper-item
                      >[[_localizeOperationMode(localize, item)]]</paper-item
                    >
                  </template>
                </paper-listbox>
              </paper-dropdown-menu>
            </div>
          </div>
        </template>

        <template is="dom-if" if="[[supportsAwayMode(stateObj)]]">
          <div class="container-away_mode">
            <div class="center horizontal layout single-row">
              <div class="flex">
                [[localize('ui.card.water_heater.away_mode')]]
              </div>
              <paper-toggle-button
                checked="[[awayToggleChecked]]"
                on-change="awayToggleChanged"
              >
              </paper-toggle-button>
            </div>
          </div>
        </template>
      </div>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object,observer:"stateObjChanged"},operationIndex:{type:Number,value:-1,observer:"handleOperationmodeChanged"},awayToggleChecked:Boolean}}stateObjChanged(newVal,oldVal){if(newVal){this.setProperties({awayToggleChecked:"on"===newVal.attributes.away_mode})}if(oldVal){this._debouncer=debounce.a.debounce(this._debouncer,utils_async.d.after(500),()=>{this.fire("iron-resize")})}}handleOperationListUpdate(){this.operationIndex=-1;if(this.stateObj.attributes.operation_list){this.operationIndex=this.stateObj.attributes.operation_list.indexOf(this.stateObj.attributes.operation_mode)}}computeTemperatureStepSize(hass,stateObj){if(stateObj.attributes.target_temp_step){return stateObj.attributes.target_temp_step}if(-1!==hass.config.unit_system.temperature.indexOf("F")){return 1}return .5}supportsTemperatureControls(stateObj){return this.supportsTemperature(stateObj)}supportsTemperature(stateObj){return Object(supports_feature.a)(stateObj,1)&&"number"===typeof stateObj.attributes.temperature}supportsOperationMode(stateObj){return Object(supports_feature.a)(stateObj,2)}supportsAwayMode(stateObj){return Object(supports_feature.a)(stateObj,4)}computeClassNames(stateObj){var classes=[featureClassNames(stateObj,{1:"has-target_temperature",2:"has-operation_mode",4:"has-away_mode"}),"more-info-water_heater"];return classes.join(" ")}targetTemperatureChanged(ev){const temperature=ev.target.value;if(temperature===this.stateObj.attributes.temperature)return;this.callServiceHelper("set_temperature",{temperature:temperature})}awayToggleChanged(ev){const oldVal="on"===this.stateObj.attributes.away_mode,newVal=ev.target.checked;if(oldVal===newVal)return;this.callServiceHelper("set_away_mode",{away_mode:newVal})}handleOperationmodeChanged(operationIndex){if(""===operationIndex||-1===operationIndex)return;const operationInput=this.stateObj.attributes.operation_list[operationIndex];if(operationInput===this.stateObj.attributes.operation_mode)return;this.callServiceHelper("set_operation_mode",{operation_mode:operationInput})}callServiceHelper(service,data){data.entity_id=this.stateObj.entity_id;this.hass.callService("water_heater",service,data).then(()=>{this.stateObjChanged(this.stateObj)})}_localizeOperationMode(localize,mode){return localize(`state.water_heater.${mode}`)||mode}}customElements.define("more-info-water_heater",more_info_water_heater_MoreInfoWaterHeater);class more_info_weather_MoreInfoWeather extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        iron-icon {
          color: var(--paper-item-icon-color);
        }
        .section {
          margin: 16px 0 8px 0;
          font-size: 1.2em;
        }

        .flex {
          display: flex;
          height: 32px;
          align-items: center;
        }

        .main {
          flex: 1;
          margin-left: 24px;
        }

        .temp,
        .templow {
          min-width: 48px;
          text-align: right;
        }

        .templow {
          margin: 0 16px;
          color: var(--secondary-text-color);
        }

        .attribution {
          color: var(--secondary-text-color);
          text-align: center;
        }
      </style>

      <div class="flex">
        <iron-icon icon="hass:thermometer"></iron-icon>
        <div class="main">
          [[localize('ui.card.weather.attributes.temperature')]]
        </div>
        <div>
          [[stateObj.attributes.temperature]] [[getUnit('temperature')]]
        </div>
      </div>
      <template is="dom-if" if="[[_showValue(stateObj.attributes.pressure)]]">
        <div class="flex">
          <iron-icon icon="hass:gauge"></iron-icon>
          <div class="main">
            [[localize('ui.card.weather.attributes.air_pressure')]]
          </div>
          <div>
            [[stateObj.attributes.pressure]] [[getUnit('air_pressure')]]
          </div>
        </div>
      </template>
      <template is="dom-if" if="[[_showValue(stateObj.attributes.humidity)]]">
        <div class="flex">
          <iron-icon icon="hass:water-percent"></iron-icon>
          <div class="main">
            [[localize('ui.card.weather.attributes.humidity')]]
          </div>
          <div>[[stateObj.attributes.humidity]] %</div>
        </div>
      </template>
      <template is="dom-if" if="[[_showValue(stateObj.attributes.wind_speed)]]">
        <div class="flex">
          <iron-icon icon="hass:weather-windy"></iron-icon>
          <div class="main">
            [[localize('ui.card.weather.attributes.wind_speed')]]
          </div>
          <div>
            [[getWind(stateObj.attributes.wind_speed,
            stateObj.attributes.wind_bearing, localize)]]
          </div>
        </div>
      </template>
      <template is="dom-if" if="[[_showValue(stateObj.attributes.visibility)]]">
        <div class="flex">
          <iron-icon icon="hass:eye"></iron-icon>
          <div class="main">
            [[localize('ui.card.weather.attributes.visibility')]]
          </div>
          <div>[[stateObj.attributes.visibility]] [[getUnit('length')]]</div>
        </div>
      </template>

      <template is="dom-if" if="[[stateObj.attributes.forecast]]">
        <div class="section">[[localize('ui.card.weather.forecast')]]:</div>
        <template is="dom-repeat" items="[[stateObj.attributes.forecast]]">
          <div class="flex">
            <template is="dom-if" if="[[_showValue(item.condition)]]">
              <iron-icon icon="[[getWeatherIcon(item.condition)]]"></iron-icon>
            </template>
            <div class="main">[[computeDateTime(item.datetime)]]</div>
            <template is="dom-if" if="[[_showValue(item.templow)]]">
              <div class="templow">
                [[item.templow]] [[getUnit('temperature')]]
              </div>
            </template>
            <div class="temp">
              [[item.temperature]] [[getUnit('temperature')]]
            </div>
          </div>
        </template>
      </template>

      <template is="dom-if" if="stateObj.attributes.attribution">
        <div class="attribution">[[stateObj.attributes.attribution]]</div>
      </template>
    `}static get properties(){return{hass:Object,stateObj:Object}}constructor(){super();this.cardinalDirections=["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW","N"];this.weatherIcons={"clear-night":"hass:weather-night",cloudy:"hass:weather-cloudy",fog:"hass:weather-fog",hail:"hass:weather-hail",lightning:"hass:weather-lightning","lightning-rainy":"hass:weather-lightning-rainy",partlycloudy:"hass:weather-partlycloudy",pouring:"hass:weather-pouring",rainy:"hass:weather-rainy",snowy:"hass:weather-snowy","snowy-rainy":"hass:weather-snowy-rainy",sunny:"hass:weather-sunny",windy:"hass:weather-windy","windy-variant":"hass:weather-windy-variant"}}computeDateTime(data){const date=new Date(data),provider=this.stateObj.attributes.attribution;if("Powered by Dark Sky"===provider||"Data provided by OpenWeatherMap"===provider){if(new Date().getDay()===date.getDay()){return date.toLocaleTimeString(this.hass.selectedLanguage||this.hass.language,{hour:"numeric"})}return date.toLocaleDateString(this.hass.selectedLanguage||this.hass.language,{weekday:"long",hour:"numeric"})}return date.toLocaleDateString(this.hass.selectedLanguage||this.hass.language,{weekday:"long",month:"short",day:"numeric"})}getUnit(measure){const lengthUnit=this.hass.config.unit_system.length||"";switch(measure){case"air_pressure":return"km"===lengthUnit?"hPa":"inHg";case"length":return lengthUnit;case"precipitation":return"km"===lengthUnit?"mm":"in";default:return this.hass.config.unit_system[measure]||"";}}windBearingToText(degree){const degreenum=parseInt(degree);if(isFinite(degreenum)){return this.cardinalDirections[(0|(degreenum+11.25)/22.5)%16]}return degree}getWind(speed,bearing,localize){if(null!=bearing){const cardinalDirection=this.windBearingToText(bearing);return`${speed} ${this.getUnit("length")}/h (${localize(`ui.card.weather.cardinal_direction.${cardinalDirection.toLowerCase()}`)||cardinalDirection})`}return`${speed} ${this.getUnit("length")}/h`}getWeatherIcon(condition){return this.weatherIcons[condition]}_showValue(item){return"undefined"!==typeof item&&null!==item}}customElements.define("more-info-weather",more_info_weather_MoreInfoWeather);var state_more_info_type=__webpack_require__(274);class more_info_content_MoreInfoContent extends polymer_element.a{static get properties(){return{hass:Object,stateObj:Object}}static get observers(){return["stateObjChanged(stateObj, hass)"]}constructor(){super();this.style.display="block"}stateObjChanged(stateObj,hass){let moreInfoType;if(!stateObj||!hass){if(this.lastChild){this._detachedChild=this.lastChild;this.removeChild(this.lastChild)}return}if(this._detachedChild){this.appendChild(this._detachedChild);this._detachedChild=null}if(stateObj.attributes&&"custom_ui_more_info"in stateObj.attributes){moreInfoType=stateObj.attributes.custom_ui_more_info}else{moreInfoType="more-info-"+Object(state_more_info_type.a)(stateObj)}Object(dynamic_content_updater.a)(this,moreInfoType.toUpperCase(),{hass:hass,stateObj:stateObj})}}customElements.define("more-info-content",more_info_content_MoreInfoContent);var common_const=__webpack_require__(80),compute_rtl=__webpack_require__(112);const DOMAINS_NO_INFO=["camera","configurator","history_graph"];class more_info_controls_MoreInfoControls extends Object(events_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="ha-style-dialog">
        app-toolbar {
          color: var(--more-info-header-color);
          background-color: var(--more-info-header-background);
        }

        app-toolbar [main-title] {
          @apply --ha-more-info-app-toolbar-title;
        }

        state-card-content {
          display: block;
          padding: 16px;
        }

        state-history-charts {
          max-width: 100%;
          margin-bottom: 16px;
        }

        @media all and (min-width: 451px) and (min-height: 501px) {
          .main-title {
            pointer-events: auto;
            cursor: default;
          }
        }

        paper-dialog-scrollable {
          padding-bottom: 16px;
        }

        :host([domain="camera"]) paper-dialog-scrollable {
          margin: 0 -24px -21px;
        }

        :host([rtl]) app-toolbar {
          direction: rtl;
          text-align: right;
        }
      </style>

      <app-toolbar>
        <paper-icon-button
          icon="hass:close"
          dialog-dismiss=""
        ></paper-icon-button>
        <div class="main-title" main-title="" on-click="enlarge">
          [[_computeStateName(stateObj)]]
        </div>
        <template is="dom-if" if="[[canConfigure]]">
          <paper-icon-button
            icon="hass:settings"
            on-click="_gotoSettings"
          ></paper-icon-button>
        </template>
      </app-toolbar>

      <template is="dom-if" if="[[_computeShowStateInfo(stateObj)]]" restamp="">
        <state-card-content
          state-obj="[[stateObj]]"
          hass="[[hass]]"
          in-dialog=""
        ></state-card-content>
      </template>
      <paper-dialog-scrollable dialog-element="[[dialogElement]]">
        <template
          is="dom-if"
          if="[[_computeShowHistoryComponent(hass, stateObj)]]"
          restamp=""
        >
          <ha-state-history-data
            hass="[[hass]]"
            filter-type="recent-entity"
            entity-id="[[stateObj.entity_id]]"
            data="{{_stateHistory}}"
            is-loading="{{_stateHistoryLoading}}"
            cache-config="[[_cacheConfig]]"
          ></ha-state-history-data>
          <state-history-charts
            hass="[[hass]]"
            history-data="[[_stateHistory]]"
            is-loading-data="[[_stateHistoryLoading]]"
            up-to-now
          ></state-history-charts>
        </template>
        <more-info-content
          state-obj="[[stateObj]]"
          hass="[[hass]]"
        ></more-info-content>
      </paper-dialog-scrollable>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"_stateObjChanged"},dialogElement:Object,canConfigure:Boolean,domain:{type:String,reflectToAttribute:!0,computed:"_computeDomain(stateObj)"},_stateHistory:Object,_stateHistoryLoading:Boolean,large:{type:Boolean,value:!1,notify:!0},_cacheConfig:{type:Object,value:{refresh:60,cacheKey:null,hoursToShow:24}},rtl:{type:Boolean,reflectToAttribute:!0,computed:"_computeRTL(hass)"}}}enlarge(){this.large=!this.large}_computeShowStateInfo(stateObj){return!stateObj||!DOMAINS_NO_INFO.includes(Object(compute_state_domain.a)(stateObj))}_computeShowHistoryComponent(hass,stateObj){return hass&&stateObj&&Object(is_component_loaded.a)(hass,"history")&&!common_const.e.includes(Object(compute_state_domain.a)(stateObj))}_computeDomain(stateObj){return stateObj?Object(compute_state_domain.a)(stateObj):""}_computeStateName(stateObj){return stateObj?Object(compute_state_name.a)(stateObj):""}_stateObjChanged(newVal){if(!newVal){return}if(`more_info.${newVal.entity_id}`!==this._cacheConfig.cacheKey){this._cacheConfig=Object.assign({},this._cacheConfig,{cacheKey:`more_info.${newVal.entity_id}`})}}_gotoSettings(){this.fire("more-info-page",{page:"settings"})}_computeRTL(hass){return Object(compute_rtl.a)(hass)}}customElements.define("more-info-controls",more_info_controls_MoreInfoControls);var compute_domain=__webpack_require__(157);class more_info_settings_MoreInfoSettings extends Object(localize_mixin.a)(Object(events_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <style>
        app-toolbar {
          color: var(--more-info-header-color);
          background-color: var(--more-info-header-background);

          /* to fit save button */
          padding-right: 0;
        }

        app-toolbar [main-title] {
          @apply --ha-more-info-app-toolbar-title;
        }

        app-toolbar paper-button {
          font-size: 0.8em;
          margin: 0;
        }

        .form {
          padding: 0 24px 24px;
        }
      </style>

      <app-toolbar>
        <paper-icon-button
          icon="hass:arrow-left"
          on-click="_backTapped"
        ></paper-icon-button>
        <div main-title="">[[_computeStateName(stateObj)]]</div>
        <paper-button on-click="_save" disabled="[[_computeInvalid(_entityId)]]"
          >[[localize('ui.dialogs.more_info_settings.save')]]</paper-button
        >
      </app-toolbar>

      <div class="form">
        <paper-input
          value="{{_name}}"
          label="[[localize('ui.dialogs.more_info_settings.name')]]"
        ></paper-input>
        <paper-input
          value="{{_entityId}}"
          label="[[localize('ui.dialogs.more_info_settings.entity_id')]]"
          error-message="Domain needs to stay the same"
          invalid="[[_computeInvalid(_entityId)]]"
        ></paper-input>
      </div>
    `}static get properties(){return{hass:Object,stateObj:Object,_componentLoaded:{type:Boolean,computed:"_computeComponentLoaded(hass)"},registryInfo:{type:Object,observer:"_registryInfoChanged",notify:!0},_name:String,_entityId:String}}_computeStateName(stateObj){if(!stateObj)return"";return Object(compute_state_name.a)(stateObj)}_computeComponentLoaded(hass){return Object(is_component_loaded.a)(hass,"config.entity_registry")}_computeInvalid(entityId){return Object(compute_domain.a)(this.stateObj.entity_id)!==Object(compute_domain.a)(entityId)}_registryInfoChanged(newVal){if(newVal){this.setProperties({_name:newVal.name,_entityId:newVal.entity_id})}else{this.setProperties({_name:"",_entityId:""})}}_backTapped(){this.fire("more-info-page",{page:null})}async _save(){try{const info=await this.hass.callWS({type:"config/entity_registry/update",entity_id:this.stateObj.entity_id,name:this._name,new_entity_id:this._entityId});this.registryInfo=info;if(this.stateObj.entity_id!==this._entityId){this.fire("hass-more-info",{entityId:this._entityId})}}catch(err){alert(`save failed: ${err.message}`)}}}customElements.define("more-info-settings",more_info_settings_MoreInfoSettings);var dialog_mixin=__webpack_require__(324);class ha_more_info_dialog_HaMoreInfoDialog extends Object(dialog_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style include="ha-style-dialog paper-dialog-shared-styles">
        :host {
          font-size: 14px;
          width: 365px;
          border-radius: 2px;
        }

        more-info-controls,
        more-info-settings {
          --more-info-header-background: var(--secondary-background-color);
          --more-info-header-color: var(--primary-text-color);
          --ha-more-info-app-toolbar-title: {
            /* Design guideline states 24px, changed to 16 to align with state info */
            margin-left: 16px;
            line-height: 1.3em;
            max-height: 2.6em;
            overflow: hidden;
            /* webkit and blink still support simple multiline text-overflow */
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            text-overflow: ellipsis;
          }
        }

        /* overrule the ha-style-dialog max-height on small screens */
        @media all and (max-width: 450px), all and (max-height: 500px) {
          more-info-controls,
          more-info-settings {
            --more-info-header-background: var(--primary-color);
            --more-info-header-color: var(--text-primary-color);
          }
          :host {
            @apply --ha-dialog-fullscreen;
          }
          :host::before {
            content: "";
            position: fixed;
            z-index: -1;
            top: 0px;
            left: 0px;
            right: 0px;
            bottom: 0px;
            background-color: inherit;
          }
        }

        :host([data-domain="camera"]) {
          width: auto;
        }

        :host([data-domain="history_graph"]),
        :host([large]) {
          width: 90%;
        }
      </style>

      <template is="dom-if" if="[[!_page]]">
        <more-info-controls
          class="no-padding"
          hass="[[hass]]"
          state-obj="[[stateObj]]"
          dialog-element="[[_dialogElement]]"
          can-configure="[[_registryInfo]]"
          large="{{large}}"
        ></more-info-controls>
      </template>
      <template is="dom-if" if="[[_equals(_page, &quot;settings&quot;)]]">
        <more-info-settings
          class="no-padding"
          hass="[[hass]]"
          state-obj="[[stateObj]]"
          registry-info="{{_registryInfo}}"
        ></more-info-settings>
      </template>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,computed:"_computeStateObj(hass)",observer:"_stateObjChanged"},large:{type:Boolean,reflectToAttribute:!0,observer:"_largeChanged"},_dialogElement:Object,_registryInfo:Object,_page:{type:String,value:null},dataDomain:{computed:"_computeDomain(stateObj)",reflectToAttribute:!0}}}static get observers(){return["_dialogOpenChanged(opened)"]}ready(){super.ready();this._dialogElement=this;this.addEventListener("more-info-page",ev=>{this._page=ev.detail.page})}_computeDomain(stateObj){return stateObj?Object(compute_state_domain.a)(stateObj):""}_computeStateObj(hass){return hass.states[hass.moreInfoEntityId]||null}async _stateObjChanged(newVal,oldVal){if(!newVal){this.setProperties({opened:!1,_page:null,_registryInfo:null,large:!1});return}requestAnimationFrame(()=>requestAnimationFrame(()=>{this.opened=!0}));if(!Object(is_component_loaded.a)(this.hass,"config.entity_registry")||oldVal&&oldVal.entity_id===newVal.entity_id){return}try{const info=await this.hass.callWS({type:"config/entity_registry/get",entity_id:newVal.entity_id});this._registryInfo=info}catch(err){this._registryInfo=null}}_dialogOpenChanged(newVal){if(!newVal&&this.stateObj){this.fire("hass-more-info",{entityId:null})}}_equals(a,b){return a===b}_largeChanged(){this.notifyResize()}}customElements.define("ha-more-info-dialog",ha_more_info_dialog_HaMoreInfoDialog)},78:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_input_iron_input_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(101),_paper_input_char_counter_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(102),_paper_input_container_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(103),_paper_input_error_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(104),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(52),_polymer_polymer_lib_elements_dom_module_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(30),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(1),_paper_input_behavior_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(83);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_7__.a)({is:"paper-input",_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__.a`
    <style>
      :host {
        display: block;
      }

      :host([focused]) {
        outline: none;
      }

      :host([hidden]) {
        display: none !important;
      }

      input {
        /* Firefox sets a min-width on the input, which can cause layout issues */
        min-width: 0;
      }

      /* In 1.x, the <input> is distributed to paper-input-container, which styles it.
      In 2.x the <iron-input> is distributed to paper-input-container, which styles
      it, but in order for this to work correctly, we need to reset some
      of the native input's properties to inherit (from the iron-input) */
      iron-input > input {
        @apply --paper-input-container-shared-input-style;
        font-family: inherit;
        font-weight: inherit;
        font-size: inherit;
        letter-spacing: inherit;
        word-spacing: inherit;
        line-height: inherit;
        text-shadow: inherit;
        color: inherit;
        cursor: inherit;
      }

      input:disabled {
        @apply --paper-input-container-input-disabled;
      }

      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        @apply --paper-input-container-input-webkit-spinner;
      }

      input::-webkit-clear-button {
        @apply --paper-input-container-input-webkit-clear;
      }

      input::-webkit-calendar-picker-indicator {
        @apply --paper-input-container-input-webkit-calendar-picker-indicator;
      }

      input::-webkit-input-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input:-moz-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input::-moz-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input::-ms-clear {
        @apply --paper-input-container-ms-clear;
      }

      input::-ms-reveal {
        @apply --paper-input-container-ms-reveal;
      }

      input:-ms-input-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      label {
        pointer-events: none;
      }
    </style>

    <paper-input-container id="container" no-label-float="[[noLabelFloat]]" always-float-label="[[_computeAlwaysFloatLabel(alwaysFloatLabel,placeholder)]]" auto-validate\$="[[autoValidate]]" disabled\$="[[disabled]]" invalid="[[invalid]]">

      <slot name="prefix" slot="prefix"></slot>

      <label hidden\$="[[!label]]" aria-hidden="true" for\$="[[_inputId]]" slot="label">[[label]]</label>

      <!-- Need to bind maxlength so that the paper-input-char-counter works correctly -->
      <iron-input bind-value="{{value}}" slot="input" class="input-element" id\$="[[_inputId]]" maxlength\$="[[maxlength]]" allowed-pattern="[[allowedPattern]]" invalid="{{invalid}}" validator="[[validator]]">
        <input aria-labelledby\$="[[_ariaLabelledBy]]" aria-describedby\$="[[_ariaDescribedBy]]" disabled\$="[[disabled]]" title\$="[[title]]" type\$="[[type]]" pattern\$="[[pattern]]" required\$="[[required]]" autocomplete\$="[[autocomplete]]" autofocus\$="[[autofocus]]" inputmode\$="[[inputmode]]" minlength\$="[[minlength]]" maxlength\$="[[maxlength]]" min\$="[[min]]" max\$="[[max]]" step\$="[[step]]" name\$="[[name]]" placeholder\$="[[placeholder]]" readonly\$="[[readonly]]" list\$="[[list]]" size\$="[[size]]" autocapitalize\$="[[autocapitalize]]" autocorrect\$="[[autocorrect]]" on-change="_onChange" tabindex\$="[[tabIndex]]" autosave\$="[[autosave]]" results\$="[[results]]" accept\$="[[accept]]" multiple\$="[[multiple]]">
      </iron-input>

      <slot name="suffix" slot="suffix"></slot>

      <template is="dom-if" if="[[errorMessage]]">
        <paper-input-error aria-live="assertive" slot="add-on">[[errorMessage]]</paper-input-error>
      </template>

      <template is="dom-if" if="[[charCounter]]">
        <paper-input-char-counter slot="add-on"></paper-input-char-counter>
      </template>

    </paper-input-container>
  `,behaviors:[_paper_input_behavior_js__WEBPACK_IMPORTED_MODULE_9__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a],properties:{value:{type:String}},get _focusableElement(){return this.inputElement._inputElement},listeners:{"iron-input-ready":"_onIronInputReady"},_onIronInputReady:function(){if(!this.$.nativeInput){this.$.nativeInput=this.$$("input")}if(this.inputElement&&-1!==this._typesThatHaveText.indexOf(this.$.nativeInput.type)){this.alwaysFloatLabel=!0}if(!!this.inputElement.bindValue){this.$.container._handleValueAndAutoValidate(this.inputElement)}}})},81:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return IronA11yAnnouncer});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronA11yAnnouncer=Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
    <style>
      :host {
        display: inline-block;
        position: fixed;
        clip: rect(0px,0px,0px,0px);
      }
    </style>
    <div aria-live\$="[[mode]]">[[_text]]</div>
`,is:"iron-a11y-announcer",properties:{mode:{type:String,value:"polite"},_text:{type:String,value:""}},created:function(){if(!IronA11yAnnouncer.instance){IronA11yAnnouncer.instance=this}document.body.addEventListener("iron-announce",this._onIronAnnounce.bind(this))},announce:function(text){this._text="";this.async(function(){this._text=text},100)},_onIronAnnounce:function(event){if(event.detail&&event.detail.text){this.announce(event.detail.text)}}});IronA11yAnnouncer.instance=null;IronA11yAnnouncer.requestAvailability=function(){if(!IronA11yAnnouncer.instance){IronA11yAnnouncer.instance=document.createElement("iron-a11y-announcer")}document.body.appendChild(IronA11yAnnouncer.instance)}},97:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return IronRangeBehavior});__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronRangeBehavior={properties:{value:{type:Number,value:0,notify:!0,reflectToAttribute:!0},min:{type:Number,value:0,notify:!0},max:{type:Number,value:100,notify:!0},step:{type:Number,value:1,notify:!0},ratio:{type:Number,value:0,readOnly:!0,notify:!0}},observers:["_update(value, min, max, step)"],_calcRatio:function(value){return(this._clampValue(value)-this.min)/(this.max-this.min)},_clampValue:function(value){return Math.min(this.max,Math.max(this.min,this._calcStep(value)))},_calcStep:function(value){value=parseFloat(value);if(!this.step){return value}var numSteps=Math.round((value-this.min)/this.step);if(1>this.step){return numSteps/(1/this.step)+this.min}else{return numSteps*this.step+this.min}},_validateValue:function(){var v=this._clampValue(this.value);this.value=this.oldValue=isNaN(v)?this.oldValue:v;return this.value!==v},_update:function(){this._validateValue();this._setRatio(100*this._calcRatio(this.value))}}}}]);
//# sourceMappingURL=9310aab5a430e28c2157.chunk.js.map