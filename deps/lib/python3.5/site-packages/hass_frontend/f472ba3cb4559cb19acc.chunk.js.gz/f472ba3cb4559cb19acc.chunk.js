(window.webpackJsonp=window.webpackJsonp||[]).push([[28,7,101],{101:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_a11y_announcer_iron_a11y_announcer_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(81),_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(53),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(0),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__.a`
    <style>
      :host {
        display: inline-block;
      }
    </style>
    <slot id="content"></slot>
`,is:"iron-input",behaviors:[_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a],properties:{bindValue:{type:String,value:""},value:{type:String,computed:"_computeValue(bindValue)"},allowedPattern:{type:String},autoValidate:{type:Boolean,value:!1},_inputElement:Object},observers:["_bindValueChanged(bindValue, _inputElement)"],listeners:{input:"_onInput",keypress:"_onKeypress"},created:function(){_polymer_iron_a11y_announcer_iron_a11y_announcer_js__WEBPACK_IMPORTED_MODULE_1__.a.requestAvailability();this._previousValidInput="";this._patternAlreadyChecked=!1},attached:function(){this._observer=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__.b)(this).observeNodes(function(){this._initSlottedInput()}.bind(this))},detached:function(){if(this._observer){Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_4__.b)(this).unobserveNodes(this._observer);this._observer=null}},get inputElement(){return this._inputElement},_initSlottedInput:function(){this._inputElement=this.getEffectiveChildren()[0];if(this.inputElement&&this.inputElement.value){this.bindValue=this.inputElement.value}this.fire("iron-input-ready")},get _patternRegExp(){var pattern;if(this.allowedPattern){pattern=new RegExp(this.allowedPattern)}else{switch(this.inputElement.type){case"number":pattern=/[0-9.,e-]/;break;}}return pattern},_bindValueChanged:function(bindValue,inputElement){if(!inputElement){return}if(bindValue===void 0){inputElement.value=null}else if(bindValue!==inputElement.value){this.inputElement.value=bindValue}if(this.autoValidate){this.validate()}this.fire("bind-value-changed",{value:bindValue})},_onInput:function(){if(this.allowedPattern&&!this._patternAlreadyChecked){var valid=this._checkPatternValidity();if(!valid){this._announceInvalidCharacter("Invalid string of characters not entered.");this.inputElement.value=this._previousValidInput}}this.bindValue=this._previousValidInput=this.inputElement.value;this._patternAlreadyChecked=!1},_isPrintable:function(event){var anyNonPrintable=8==event.keyCode||9==event.keyCode||13==event.keyCode||27==event.keyCode,mozNonPrintable=19==event.keyCode||20==event.keyCode||45==event.keyCode||46==event.keyCode||144==event.keyCode||145==event.keyCode||32<event.keyCode&&41>event.keyCode||111<event.keyCode&&124>event.keyCode;return!anyNonPrintable&&!(0==event.charCode&&mozNonPrintable)},_onKeypress:function(event){if(!this.allowedPattern&&"number"!==this.inputElement.type){return}var regexp=this._patternRegExp;if(!regexp){return}if(event.metaKey||event.ctrlKey||event.altKey){return}this._patternAlreadyChecked=!0;var thisChar=String.fromCharCode(event.charCode);if(this._isPrintable(event)&&!regexp.test(thisChar)){event.preventDefault();this._announceInvalidCharacter("Invalid character "+thisChar+" not entered.")}},_checkPatternValidity:function(){var regexp=this._patternRegExp;if(!regexp){return!0}for(var i=0;i<this.inputElement.value.length;i++){if(!regexp.test(this.inputElement.value[i])){return!1}}return!0},validate:function(){if(!this.inputElement){this.invalid=!1;return!0}var valid=this.inputElement.checkValidity();if(valid){if(this.required&&""===this.bindValue){valid=!1}else if(this.hasValidator()){valid=_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a.validate.call(this,this.bindValue)}}this.invalid=!valid;this.fire("iron-input-validate");return valid},_announceInvalidCharacter:function(message){this.fire("iron-announce",{text:message})},_computeValue:function(bindValue){return bindValue}})},106:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return PaperItemBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(23),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(18);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperItemBehavior=[_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_1__.a,_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_2__.a,{hostAttributes:{role:"option",tabindex:"0"}}]},107:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const NeonAnimatableBehavior={properties:{animationConfig:{type:Object},entryAnimation:{observer:"_entryAnimationChanged",type:String},exitAnimation:{observer:"_exitAnimationChanged",type:String}},_entryAnimationChanged:function(){this.animationConfig=this.animationConfig||{};this.animationConfig.entry=[{name:this.entryAnimation,node:this}]},_exitAnimationChanged:function(){this.animationConfig=this.animationConfig||{};this.animationConfig.exit=[{name:this.exitAnimation,node:this}]},_copyProperties:function(config1,config2){for(var property in config2){config1[property]=config2[property]}},_cloneConfig:function(config){var clone={isClone:!0};this._copyProperties(clone,config);return clone},_getAnimationConfigRecursive:function(type,map,allConfigs){if(!this.animationConfig){return}if(this.animationConfig.value&&"function"===typeof this.animationConfig.value){this._warn(this._logf("playAnimation","Please put 'animationConfig' inside of your components 'properties' object instead of outside of it."));return}var thisConfig;if(type){thisConfig=this.animationConfig[type]}else{thisConfig=this.animationConfig}if(!Array.isArray(thisConfig)){thisConfig=[thisConfig]}if(thisConfig){for(var config,index=0;config=thisConfig[index];index++){if(config.animatable){config.animatable._getAnimationConfigRecursive(config.type||type,map,allConfigs)}else{if(config.id){var cachedConfig=map[config.id];if(cachedConfig){if(!cachedConfig.isClone){map[config.id]=this._cloneConfig(cachedConfig);cachedConfig=map[config.id]}this._copyProperties(cachedConfig,config)}else{map[config.id]=config}}else{allConfigs.push(config)}}}}},getAnimationConfig:function(type){var map={},allConfigs=[];this._getAnimationConfigRecursive(type,map,allConfigs);for(var key in map){allConfigs.push(map[key])}return allConfigs}};__webpack_require__.d(__webpack_exports__,"a",function(){return NeonAnimationRunnerBehavior});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const NeonAnimationRunnerBehavior=[NeonAnimatableBehavior,{_configureAnimations:function(configs){var results=[],resultsToPlay=[];if(0<configs.length){for(let config,index=0,neonAnimation;config=configs[index];index++){neonAnimation=document.createElement(config.name);if(neonAnimation.isNeonAnimation){let result=null;if(!neonAnimation.configure){neonAnimation.configure=function(){return null}}result=neonAnimation.configure(config);resultsToPlay.push({result:result,config:config,neonAnimation:neonAnimation})}else{console.warn(this.is+":",config.name,"not found!")}}}for(var i=0;i<resultsToPlay.length;i++){let result=resultsToPlay[i].result,config=resultsToPlay[i].config,neonAnimation=resultsToPlay[i].neonAnimation;try{if("function"!=typeof result.cancel){result=document.timeline.play(result)}}catch(e){result=null;console.warn("Couldnt play","(",config.name,").",e)}if(result){results.push({neonAnimation:neonAnimation,config:config,animation:result})}}return results},_shouldComplete:function(activeEntries){for(var finished=!0,i=0;i<activeEntries.length;i++){if("finished"!=activeEntries[i].animation.playState){finished=!1;break}}return finished},_complete:function(activeEntries){for(var i=0;i<activeEntries.length;i++){activeEntries[i].neonAnimation.complete(activeEntries[i].config)}for(var i=0;i<activeEntries.length;i++){activeEntries[i].animation.cancel()}},playAnimation:function(type,cookie){var configs=this.getAnimationConfig(type);if(!configs){return}this._active=this._active||{};if(this._active[type]){this._complete(this._active[type]);delete this._active[type]}var activeEntries=this._configureAnimations(configs);if(0==activeEntries.length){this.fire("neon-animation-finish",cookie,{bubbles:!1});return}this._active[type]=activeEntries;for(var i=0;i<activeEntries.length;i++){activeEntries[i].animation.onfinish=function(){if(this._shouldComplete(activeEntries)){this._complete(activeEntries);delete this._active[type];this.fire("neon-animation-finish",cookie,{bubbles:!1})}}.bind(this)}},cancelAnimation:function(){for(var k in this._active){var entries=this._active[k];for(var j in entries){entries[j].animation.cancel()}}this._active={}}}]},109:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_legacy=__webpack_require__(3),iron_form_element_behavior=__webpack_require__(52),iron_validatable_behavior=__webpack_require__(53);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronCheckedElementBehaviorImpl={properties:{checked:{type:Boolean,value:!1,reflectToAttribute:!0,notify:!0,observer:"_checkedChanged"},toggles:{type:Boolean,value:!0,reflectToAttribute:!0},value:{type:String,value:"on",observer:"_valueChanged"}},observers:["_requiredChanged(required)"],created:function(){this._hasIronCheckedElementBehavior=!0},_getValidity:function(){return this.disabled||!this.required||this.checked},_requiredChanged:function(){if(this.required){this.setAttribute("aria-required","true")}else{this.removeAttribute("aria-required")}},_checkedChanged:function(){this.active=this.checked;this.fire("iron-change")},_valueChanged:function(){if(this.value===void 0||null===this.value){this.value="on"}}},IronCheckedElementBehavior=[iron_form_element_behavior.a,iron_validatable_behavior.a,IronCheckedElementBehaviorImpl];var paper_inky_focus_behavior=__webpack_require__(51),paper_ripple_behavior=__webpack_require__(40);__webpack_require__.d(__webpack_exports__,"a",function(){return PaperCheckedElementBehavior});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const PaperCheckedElementBehavior=[paper_inky_focus_behavior.a,IronCheckedElementBehavior,{_checkedChanged:function(){IronCheckedElementBehaviorImpl._checkedChanged.call(this);if(this.hasRipple()){if(this.checked){this._ripple.setAttribute("checked","")}else{this._ripple.removeAttribute("checked")}}},_buttonStateChanged:function(){paper_ripple_behavior.a._buttonStateChanged.call(this);if(this.disabled){return}if(this.isAttached){this.checked=this.active}}}]},126:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_paper_item_shared_styles_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(127),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(1),_paper_item_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(106);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__.a`
    <style include="paper-item-shared-styles">
      :host {
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-subhead;

        @apply --paper-item;
      }
    </style>
    <slot></slot>
`,is:"paper-item",behaviors:[_paper_item_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a]})},127:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(33),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(58),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_1__),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(39),_polymer_paper_styles_typography_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(50);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<dom-module id="paper-item-shared-styles">
  <template>
    <style>
      :host, .paper-item {
        display: block;
        position: relative;
        min-height: var(--paper-item-min-height, 48px);
        padding: 0px 16px;
      }

      .paper-item {
        @apply --paper-font-subhead;
        border:none;
        outline: none;
        background: white;
        width: 100%;
        text-align: left;
      }

      :host([hidden]), .paper-item[hidden] {
        display: none !important;
      }

      :host(.iron-selected), .paper-item.iron-selected {
        font-weight: var(--paper-item-selected-weight, bold);

        @apply --paper-item-selected;
      }

      :host([disabled]), .paper-item[disabled] {
        color: var(--paper-item-disabled-color, var(--disabled-text-color));

        @apply --paper-item-disabled;
      }

      :host(:focus), .paper-item:focus {
        position: relative;
        outline: 0;

        @apply --paper-item-focused;
      }

      :host(:focus):before, .paper-item:focus:before {
        @apply --layout-fit;

        background: currentColor;
        content: '';
        opacity: var(--dark-divider-opacity);
        pointer-events: none;

        @apply --paper-item-focused-before;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild($_documentContainer.content)},128:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(39),_polymer_iron_menu_behavior_iron_menu_behavior_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(110),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_3__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_4__.a`
    <style>
      :host {
        display: block;
        padding: 8px 0;

        background: var(--paper-listbox-background-color, var(--primary-background-color));
        color: var(--paper-listbox-color, var(--primary-text-color));

        @apply --paper-listbox;
      }
    </style>

    <slot></slot>
`,is:"paper-listbox",behaviors:[_polymer_iron_menu_behavior_iron_menu_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a],hostAttributes:{role:"listbox"}})},129:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(19),_polymer_iron_icon_iron_icon_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(95),_polymer_paper_input_paper_input_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(78),_polymer_paper_menu_button_paper_menu_button_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(130),_polymer_paper_ripple_paper_ripple_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(76),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(39),_paper_dropdown_menu_icons_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(131),_paper_dropdown_menu_shared_styles_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(132),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(23),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_10__=__webpack_require__(18),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_11__=__webpack_require__(52),_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_12__=__webpack_require__(53),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_13__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_14__=__webpack_require__(0),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_15__=__webpack_require__(25),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_16__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_13__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_16__.a`
    <style include="paper-dropdown-menu-shared-styles"></style>

    <!-- this div fulfills an a11y requirement for combobox, do not remove -->
    <span role="button"></span>
    <paper-menu-button id="menuButton" vertical-align="[[verticalAlign]]" horizontal-align="[[horizontalAlign]]" dynamic-align="[[dynamicAlign]]" vertical-offset="[[_computeMenuVerticalOffset(noLabelFloat, verticalOffset)]]" disabled="[[disabled]]" no-animations="[[noAnimations]]" on-iron-select="_onIronSelect" on-iron-deselect="_onIronDeselect" opened="{{opened}}" close-on-activate allow-outside-scroll="[[allowOutsideScroll]]" restore-focus-on-close="[[restoreFocusOnClose]]">
      <!-- support hybrid mode: user might be using paper-menu-button 1.x which distributes via <content> -->
      <div class="dropdown-trigger" slot="dropdown-trigger">
        <paper-ripple></paper-ripple>
        <!-- paper-input has type="text" for a11y, do not remove -->
        <paper-input type="text" invalid="[[invalid]]" readonly disabled="[[disabled]]" value="[[value]]" placeholder="[[placeholder]]" error-message="[[errorMessage]]" always-float-label="[[alwaysFloatLabel]]" no-label-float="[[noLabelFloat]]" label="[[label]]">
          <!-- support hybrid mode: user might be using paper-input 1.x which distributes via <content> -->
          <iron-icon icon="paper-dropdown-menu:arrow-drop-down" suffix slot="suffix"></iron-icon>
        </paper-input>
      </div>
      <slot id="content" name="dropdown-content" slot="dropdown-content"></slot>
    </paper-menu-button>
`,is:"paper-dropdown-menu",behaviors:[_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_9__.a,_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_10__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_11__.a,_polymer_iron_validatable_behavior_iron_validatable_behavior_js__WEBPACK_IMPORTED_MODULE_12__.a],properties:{selectedItemLabel:{type:String,notify:!0,readOnly:!0},selectedItem:{type:Object,notify:!0,readOnly:!0},value:{type:String,notify:!0},label:{type:String},placeholder:{type:String},errorMessage:{type:String},opened:{type:Boolean,notify:!0,value:!1,observer:"_openedChanged"},allowOutsideScroll:{type:Boolean,value:!1},noLabelFloat:{type:Boolean,value:!1,reflectToAttribute:!0},alwaysFloatLabel:{type:Boolean,value:!1},noAnimations:{type:Boolean,value:!1},horizontalAlign:{type:String,value:"right"},verticalAlign:{type:String,value:"top"},verticalOffset:Number,dynamicAlign:{type:Boolean},restoreFocusOnClose:{type:Boolean,value:!0}},listeners:{tap:"_onTap"},keyBindings:{"up down":"open",esc:"close"},hostAttributes:{role:"combobox","aria-autocomplete":"none","aria-haspopup":"true"},observers:["_selectedItemChanged(selectedItem)"],attached:function(){var contentElement=this.contentElement;if(contentElement&&contentElement.selectedItem){this._setSelectedItem(contentElement.selectedItem)}},get contentElement(){for(var nodes=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_14__.b)(this.$.content).getDistributedNodes(),i=0,l=nodes.length;i<l;i++){if(nodes[i].nodeType===Node.ELEMENT_NODE){return nodes[i]}}},open:function(){this.$.menuButton.open()},close:function(){this.$.menuButton.close()},_onIronSelect:function(event){this._setSelectedItem(event.detail.item)},_onIronDeselect:function(){this._setSelectedItem(null)},_onTap:function(event){if(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_15__.c(event)===this){this.open()}},_selectedItemChanged:function(selectedItem){var value="";if(!selectedItem){value=""}else{value=selectedItem.label||selectedItem.getAttribute("label")||selectedItem.textContent.trim()}this.value=value;this._setSelectedItemLabel(value)},_computeMenuVerticalOffset:function(noLabelFloat,opt_verticalOffset){if(opt_verticalOffset){return opt_verticalOffset}return noLabelFloat?-4:8},_getValidity:function(){return this.disabled||!this.required||this.required&&!!this.value},_openedChanged:function(){var openState=this.opened?"true":"false",e=this.contentElement;if(e){e.setAttribute("aria-expanded",openState)}}})},130:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_legacy=__webpack_require__(3),iron_a11y_keys_behavior=__webpack_require__(19),iron_control_state=__webpack_require__(18),iron_overlay_behavior=__webpack_require__(73),neon_animation_runner_behavior=__webpack_require__(107),polymer_fn=__webpack_require__(4),polymer_dom=__webpack_require__(0),html_tag=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({_template:html_tag.a`
    <style>
      :host {
        position: fixed;
      }

      #contentWrapper ::slotted(*) {
        overflow: auto;
      }

      #contentWrapper.animating ::slotted(*) {
        overflow: hidden;
        pointer-events: none;
      }
    </style>

    <div id="contentWrapper">
      <slot id="content" name="dropdown-content"></slot>
    </div>
`,is:"iron-dropdown",behaviors:[iron_control_state.a,iron_a11y_keys_behavior.a,iron_overlay_behavior.a,neon_animation_runner_behavior.a],properties:{horizontalAlign:{type:String,value:"left",reflectToAttribute:!0},verticalAlign:{type:String,value:"top",reflectToAttribute:!0},openAnimationConfig:{type:Object},closeAnimationConfig:{type:Object},focusTarget:{type:Object},noAnimations:{type:Boolean,value:!1},allowOutsideScroll:{type:Boolean,value:!1,observer:"_allowOutsideScrollChanged"}},listeners:{"neon-animation-finish":"_onNeonAnimationFinish"},observers:["_updateOverlayPosition(positionTarget, verticalAlign, horizontalAlign, verticalOffset, horizontalOffset)"],get containedElement(){for(var nodes=Object(polymer_dom.b)(this.$.content).getDistributedNodes(),i=0,l=nodes.length;i<l;i++){if(nodes[i].nodeType===Node.ELEMENT_NODE){return nodes[i]}}},ready:function(){if(!this.scrollAction){this.scrollAction=this.allowOutsideScroll?"refit":"lock"}this._readied=!0},attached:function(){if(!this.sizingTarget||this.sizingTarget===this){this.sizingTarget=this.containedElement||this}},detached:function(){this.cancelAnimation()},_openedChanged:function(){if(this.opened&&this.disabled){this.cancel()}else{this.cancelAnimation();this._updateAnimationConfig();iron_overlay_behavior.b._openedChanged.apply(this,arguments)}},_renderOpened:function(){if(!this.noAnimations&&this.animationConfig.open){this.$.contentWrapper.classList.add("animating");this.playAnimation("open")}else{iron_overlay_behavior.b._renderOpened.apply(this,arguments)}},_renderClosed:function(){if(!this.noAnimations&&this.animationConfig.close){this.$.contentWrapper.classList.add("animating");this.playAnimation("close")}else{iron_overlay_behavior.b._renderClosed.apply(this,arguments)}},_onNeonAnimationFinish:function(){this.$.contentWrapper.classList.remove("animating");if(this.opened){this._finishRenderOpened()}else{this._finishRenderClosed()}},_updateAnimationConfig:function(){for(var animationNode=this.containedElement,animations=[].concat(this.openAnimationConfig||[]).concat(this.closeAnimationConfig||[]),i=0;i<animations.length;i++){animations[i].node=animationNode}this.animationConfig={open:this.openAnimationConfig,close:this.closeAnimationConfig}},_updateOverlayPosition:function(){if(this.isAttached){this.notifyResize()}},_allowOutsideScrollChanged:function(allowOutsideScroll){if(!this._readied){return}if(!allowOutsideScroll){this.scrollAction="lock"}else if(!this.scrollAction||"lock"===this.scrollAction){this.scrollAction="refit"}},_applyFocus:function(){var focusTarget=this.focusTarget||this.containedElement;if(focusTarget&&this.opened&&!this.noAutoFocus){focusTarget.focus()}else{iron_overlay_behavior.b._applyFocus.apply(this,arguments)}}});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const NeonAnimationBehavior={properties:{animationTiming:{type:Object,value:function(){return{duration:500,easing:"cubic-bezier(0.4, 0, 0.2, 1)",fill:"both"}}}},isNeonAnimation:!0,created:function(){if(!document.body.animate){console.warn("No web animations detected. This element will not"+" function without a web animations polyfill.")}},timingFromConfig:function(config){if(config.timing){for(var property in config.timing){this.animationTiming[property]=config.timing[property]}}return this.animationTiming},setPrefixedProperty:function(node,property,value){for(var map={transform:["webkitTransform"],transformOrigin:["mozTransformOrigin","webkitTransformOrigin"]},prefixes=map[property],prefix,index=0;prefix=prefixes[index];index++){node.style[prefix]=value}node.style[property]=value},complete:function(){}};/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({is:"fade-in-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node;this._effect=new KeyframeEffect(node,[{opacity:"0"},{opacity:"1"}],this.timingFromConfig(config));return this._effect}});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({is:"fade-out-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node;this._effect=new KeyframeEffect(node,[{opacity:"1"},{opacity:"0"}],this.timingFromConfig(config));return this._effect}});var default_theme=__webpack_require__(39),shadow=__webpack_require__(61);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({is:"paper-menu-grow-height-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node,rect=node.getBoundingClientRect(),height=rect.height;this._effect=new KeyframeEffect(node,[{height:height/2+"px"},{height:height+"px"}],this.timingFromConfig(config));return this._effect}});Object(polymer_fn.a)({is:"paper-menu-grow-width-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node,rect=node.getBoundingClientRect(),width=rect.width;this._effect=new KeyframeEffect(node,[{width:width/2+"px"},{width:width+"px"}],this.timingFromConfig(config));return this._effect}});Object(polymer_fn.a)({is:"paper-menu-shrink-width-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node,rect=node.getBoundingClientRect(),width=rect.width;this._effect=new KeyframeEffect(node,[{width:width+"px"},{width:width-width/20+"px"}],this.timingFromConfig(config));return this._effect}});Object(polymer_fn.a)({is:"paper-menu-shrink-height-animation",behaviors:[NeonAnimationBehavior],configure:function(config){var node=config.node,rect=node.getBoundingClientRect(),height=rect.height;this.setPrefixedProperty(node,"transformOrigin","0 0");this._effect=new KeyframeEffect(node,[{height:height+"px",transform:"translateY(0)"},{height:height/2+"px",transform:"translateY(-20px)"}],this.timingFromConfig(config));return this._effect}});/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/var config={ANIMATION_CUBIC_BEZIER:"cubic-bezier(.3,.95,.5,1)",MAX_ANIMATION_TIME_MS:400};const PaperMenuButton=Object(polymer_fn.a)({_template:html_tag.a`
    <style>
      :host {
        display: inline-block;
        position: relative;
        padding: 8px;
        outline: none;

        @apply --paper-menu-button;
      }

      :host([disabled]) {
        cursor: auto;
        color: var(--disabled-text-color);

        @apply --paper-menu-button-disabled;
      }

      iron-dropdown {
        @apply --paper-menu-button-dropdown;
      }

      .dropdown-content {
        @apply --shadow-elevation-2dp;

        position: relative;
        border-radius: 2px;
        background-color: var(--paper-menu-button-dropdown-background, var(--primary-background-color));

        @apply --paper-menu-button-content;
      }

      :host([vertical-align="top"]) .dropdown-content {
        margin-bottom: 20px;
        margin-top: -10px;
        top: 10px;
      }

      :host([vertical-align="bottom"]) .dropdown-content {
        bottom: 10px;
        margin-bottom: -10px;
        margin-top: 20px;
      }

      #trigger {
        cursor: pointer;
      }
    </style>

    <div id="trigger" on-tap="toggle">
      <slot name="dropdown-trigger"></slot>
    </div>

    <iron-dropdown id="dropdown" opened="{{opened}}" horizontal-align="[[horizontalAlign]]" vertical-align="[[verticalAlign]]" dynamic-align="[[dynamicAlign]]" horizontal-offset="[[horizontalOffset]]" vertical-offset="[[verticalOffset]]" no-overlap="[[noOverlap]]" open-animation-config="[[openAnimationConfig]]" close-animation-config="[[closeAnimationConfig]]" no-animations="[[noAnimations]]" focus-target="[[_dropdownContent]]" allow-outside-scroll="[[allowOutsideScroll]]" restore-focus-on-close="[[restoreFocusOnClose]]" on-iron-overlay-canceled="__onIronOverlayCanceled">
      <div slot="dropdown-content" class="dropdown-content">
        <slot id="content" name="dropdown-content"></slot>
      </div>
    </iron-dropdown>
`,is:"paper-menu-button",behaviors:[iron_a11y_keys_behavior.a,iron_control_state.a],properties:{opened:{type:Boolean,value:!1,notify:!0,observer:"_openedChanged"},horizontalAlign:{type:String,value:"left",reflectToAttribute:!0},verticalAlign:{type:String,value:"top",reflectToAttribute:!0},dynamicAlign:{type:Boolean},horizontalOffset:{type:Number,value:0,notify:!0},verticalOffset:{type:Number,value:0,notify:!0},noOverlap:{type:Boolean},noAnimations:{type:Boolean,value:!1},ignoreSelect:{type:Boolean,value:!1},closeOnActivate:{type:Boolean,value:!1},openAnimationConfig:{type:Object,value:function(){return[{name:"fade-in-animation",timing:{delay:100,duration:200}},{name:"paper-menu-grow-width-animation",timing:{delay:100,duration:150,easing:config.ANIMATION_CUBIC_BEZIER}},{name:"paper-menu-grow-height-animation",timing:{delay:100,duration:275,easing:config.ANIMATION_CUBIC_BEZIER}}]}},closeAnimationConfig:{type:Object,value:function(){return[{name:"fade-out-animation",timing:{duration:150}},{name:"paper-menu-shrink-width-animation",timing:{delay:100,duration:50,easing:config.ANIMATION_CUBIC_BEZIER}},{name:"paper-menu-shrink-height-animation",timing:{duration:200,easing:"ease-in"}}]}},allowOutsideScroll:{type:Boolean,value:!1},restoreFocusOnClose:{type:Boolean,value:!0},_dropdownContent:{type:Object}},hostAttributes:{role:"group","aria-haspopup":"true"},listeners:{"iron-activate":"_onIronActivate","iron-select":"_onIronSelect"},get contentElement(){for(var nodes=Object(polymer_dom.b)(this.$.content).getDistributedNodes(),i=0,l=nodes.length;i<l;i++){if(nodes[i].nodeType===Node.ELEMENT_NODE){return nodes[i]}}},toggle:function(){if(this.opened){this.close()}else{this.open()}},open:function(){if(this.disabled){return}this.$.dropdown.open()},close:function(){this.$.dropdown.close()},_onIronSelect:function(){if(!this.ignoreSelect){this.close()}},_onIronActivate:function(){if(this.closeOnActivate){this.close()}},_openedChanged:function(opened,oldOpened){if(opened){this._dropdownContent=this.contentElement;this.fire("paper-dropdown-open")}else if(null!=oldOpened){this.fire("paper-dropdown-close")}},_disabledChanged:function(disabled){iron_control_state.a._disabledChanged.apply(this,arguments);if(disabled&&this.opened){this.close()}},__onIronOverlayCanceled:function(event){var uiEvent=event.detail,trigger=this.$.trigger,path=Object(polymer_dom.b)(uiEvent).path;if(-1<path.indexOf(trigger)){event.preventDefault()}}});Object.keys(config).forEach(function(key){PaperMenuButton[key]=config[key]})},131:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(74);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<iron-iconset-svg name="paper-dropdown-menu" size="24">
<svg><defs>
<g id="arrow-drop-down"><path d="M7 10l5 5 5-5z"></path></g>
</defs></svg>
</iron-iconset-svg>`;document.head.appendChild($_documentContainer.content)},132:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(39);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const $_documentContainer=document.createElement("template");$_documentContainer.setAttribute("style","display: none;");$_documentContainer.innerHTML=`<dom-module id="paper-dropdown-menu-shared-styles">
  <template>
    <style>
      :host {
        display: inline-block;
        position: relative;
        text-align: left;

        /* NOTE(cdata): Both values are needed, since some phones require the
         * value to be \`transparent\`.
         */
        -webkit-tap-highlight-color: rgba(0,0,0,0);
        -webkit-tap-highlight-color: transparent;

        --paper-input-container-input: {
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          max-width: 100%;
          box-sizing: border-box;
          cursor: pointer;
        };

        @apply --paper-dropdown-menu;
      }

      :host([disabled]) {
        @apply --paper-dropdown-menu-disabled;
      }

      :host([noink]) paper-ripple {
        display: none;
      }

      :host([no-label-float]) paper-ripple {
        top: 8px;
      }

      paper-ripple {
        top: 12px;
        left: 0px;
        bottom: 8px;
        right: 0px;

        @apply --paper-dropdown-menu-ripple;
      }

      paper-menu-button {
        display: block;
        padding: 0;

        @apply --paper-dropdown-menu-button;
      }

      paper-input {
        @apply --paper-dropdown-menu-input;
      }

      iron-icon {
        color: var(--disabled-text-color);

        @apply --paper-dropdown-menu-icon;
      }
    </style>
  </template>
</dom-module>`;document.head.appendChild($_documentContainer.content)},134:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(39),_polymer_paper_behaviors_paper_checked_element_behavior_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(109),_polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(51),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(1),_polymer_polymer_lib_utils_render_status_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(34);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__.a`<style>
  :host {
    display: inline-block;
    white-space: nowrap;
    cursor: pointer;
    --calculated-paper-checkbox-size: var(--paper-checkbox-size, 18px);
    /* -1px is a sentinel for the default and is replaced in \`attached\`. */
    --calculated-paper-checkbox-ink-size: var(--paper-checkbox-ink-size, -1px);
    @apply --paper-font-common-base;
    line-height: 0;
    -webkit-tap-highlight-color: transparent;
  }

  :host([hidden]) {
    display: none !important;
  }

  :host(:focus) {
    outline: none;
  }

  .hidden {
    display: none;
  }

  #checkboxContainer {
    display: inline-block;
    position: relative;
    width: var(--calculated-paper-checkbox-size);
    height: var(--calculated-paper-checkbox-size);
    min-width: var(--calculated-paper-checkbox-size);
    margin: var(--paper-checkbox-margin, initial);
    vertical-align: var(--paper-checkbox-vertical-align, middle);
    background-color: var(--paper-checkbox-unchecked-background-color, transparent);
  }

  #ink {
    position: absolute;

    /* Center the ripple in the checkbox by negative offsetting it by
     * (inkWidth - rippleWidth) / 2 */
    top: calc(0px - (var(--calculated-paper-checkbox-ink-size) - var(--calculated-paper-checkbox-size)) / 2);
    left: calc(0px - (var(--calculated-paper-checkbox-ink-size) - var(--calculated-paper-checkbox-size)) / 2);
    width: var(--calculated-paper-checkbox-ink-size);
    height: var(--calculated-paper-checkbox-ink-size);
    color: var(--paper-checkbox-unchecked-ink-color, var(--primary-text-color));
    opacity: 0.6;
    pointer-events: none;
  }

  #ink:dir(rtl) {
    right: calc(0px - (var(--calculated-paper-checkbox-ink-size) - var(--calculated-paper-checkbox-size)) / 2);
    left: auto;
  }

  #ink[checked] {
    color: var(--paper-checkbox-checked-ink-color, var(--primary-color));
  }

  #checkbox {
    position: relative;
    box-sizing: border-box;
    height: 100%;
    border: solid 2px;
    border-color: var(--paper-checkbox-unchecked-color, var(--primary-text-color));
    border-radius: 2px;
    pointer-events: none;
    -webkit-transition: background-color 140ms, border-color 140ms;
    transition: background-color 140ms, border-color 140ms;

    -webkit-transition-duration: var(--paper-checkbox-animation-duration, 140ms);
    transition-duration: var(--paper-checkbox-animation-duration, 140ms);
  }

  /* checkbox checked animations */
  #checkbox.checked #checkmark {
    -webkit-animation: checkmark-expand 140ms ease-out forwards;
    animation: checkmark-expand 140ms ease-out forwards;

    -webkit-animation-duration: var(--paper-checkbox-animation-duration, 140ms);
    animation-duration: var(--paper-checkbox-animation-duration, 140ms);
  }

  @-webkit-keyframes checkmark-expand {
    0% {
      -webkit-transform: scale(0, 0) rotate(45deg);
    }
    100% {
      -webkit-transform: scale(1, 1) rotate(45deg);
    }
  }

  @keyframes checkmark-expand {
    0% {
      transform: scale(0, 0) rotate(45deg);
    }
    100% {
      transform: scale(1, 1) rotate(45deg);
    }
  }

  #checkbox.checked {
    background-color: var(--paper-checkbox-checked-color, var(--primary-color));
    border-color: var(--paper-checkbox-checked-color, var(--primary-color));
  }

  #checkmark {
    position: absolute;
    width: 36%;
    height: 70%;
    border-style: solid;
    border-top: none;
    border-left: none;
    border-right-width: calc(2/15 * var(--calculated-paper-checkbox-size));
    border-bottom-width: calc(2/15 * var(--calculated-paper-checkbox-size));
    border-color: var(--paper-checkbox-checkmark-color, white);
    -webkit-transform-origin: 97% 86%;
    transform-origin: 97% 86%;
    box-sizing: content-box; /* protect against page-level box-sizing */
  }

  #checkmark:dir(rtl) {
    -webkit-transform-origin: 50% 14%;
    transform-origin: 50% 14%;
  }

  /* label */
  #checkboxLabel {
    position: relative;
    display: inline-block;
    vertical-align: middle;
    padding-left: var(--paper-checkbox-label-spacing, 8px);
    white-space: normal;
    line-height: normal;
    color: var(--paper-checkbox-label-color, var(--primary-text-color));
    @apply --paper-checkbox-label;
  }

  :host([checked]) #checkboxLabel {
    color: var(--paper-checkbox-label-checked-color, var(--paper-checkbox-label-color, var(--primary-text-color)));
    @apply --paper-checkbox-label-checked;
  }

  #checkboxLabel:dir(rtl) {
    padding-right: var(--paper-checkbox-label-spacing, 8px);
    padding-left: 0;
  }

  #checkboxLabel[hidden] {
    display: none;
  }

  /* disabled state */

  :host([disabled]) #checkbox {
    opacity: 0.5;
    border-color: var(--paper-checkbox-unchecked-color, var(--primary-text-color));
  }

  :host([disabled][checked]) #checkbox {
    background-color: var(--paper-checkbox-unchecked-color, var(--primary-text-color));
    opacity: 0.5;
  }

  :host([disabled]) #checkboxLabel  {
    opacity: 0.65;
  }

  /* invalid state */
  #checkbox.invalid:not(.checked) {
    border-color: var(--paper-checkbox-error-color, var(--error-color));
  }
</style>

<div id="checkboxContainer">
  <div id="checkbox" class$="[[_computeCheckboxClass(checked, invalid)]]">
    <div id="checkmark" class$="[[_computeCheckmarkClass(checked)]]"></div>
  </div>
</div>

<div id="checkboxLabel"><slot></slot></div>`;template.setAttribute("strip-whitespace","");Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__.a)({_template:template,is:"paper-checkbox",behaviors:[_polymer_paper_behaviors_paper_checked_element_behavior_js__WEBPACK_IMPORTED_MODULE_2__.a],hostAttributes:{role:"checkbox","aria-checked":!1,tabindex:0},properties:{ariaActiveAttribute:{type:String,value:"aria-checked"}},attached:function(){Object(_polymer_polymer_lib_utils_render_status_js__WEBPACK_IMPORTED_MODULE_6__.a)(this,function(){var inkSize=this.getComputedStyleValue("--calculated-paper-checkbox-ink-size").trim();if("-1px"===inkSize){var checkboxSizeText=this.getComputedStyleValue("--calculated-paper-checkbox-size").trim(),units="px",unitsMatches=checkboxSizeText.match(/[A-Za-z]+$/);if(null!==unitsMatches){units=unitsMatches[0]}var checkboxSize=parseFloat(checkboxSizeText),defaultInkSize=8/3*checkboxSize;if("px"===units){defaultInkSize=Math.floor(defaultInkSize);if(defaultInkSize%2!==checkboxSize%2){defaultInkSize++}}this.updateStyles({"--paper-checkbox-ink-size":defaultInkSize+units})}})},_computeCheckboxClass:function(checked,invalid){var className="";if(checked){className+="checked "}if(invalid){className+="invalid"}return className},_computeCheckmarkClass:function(checked){return checked?"":"hidden"},_createRipple:function(){this._rippleContainer=this.$.checkboxContainer;return _polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_3__.b._createRipple.call(this)}})},135:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(58),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__),_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(97),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_4__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_5__.a`
    <style>
      :host {
        display: block;
        width: 200px;
        position: relative;
        overflow: hidden;
      }

      :host([hidden]), [hidden] {
        display: none !important;
      }

      #progressContainer {
        @apply --paper-progress-container;
        position: relative;
      }

      #progressContainer,
      /* the stripe for the indeterminate animation*/
      .indeterminate::after {
        height: var(--paper-progress-height, 4px);
      }

      #primaryProgress,
      #secondaryProgress,
      .indeterminate::after {
        @apply --layout-fit;
      }

      #progressContainer,
      .indeterminate::after {
        background: var(--paper-progress-container-color, var(--google-grey-300));
      }

      :host(.transiting) #primaryProgress,
      :host(.transiting) #secondaryProgress {
        -webkit-transition-property: -webkit-transform;
        transition-property: transform;

        /* Duration */
        -webkit-transition-duration: var(--paper-progress-transition-duration, 0.08s);
        transition-duration: var(--paper-progress-transition-duration, 0.08s);

        /* Timing function */
        -webkit-transition-timing-function: var(--paper-progress-transition-timing-function, ease);
        transition-timing-function: var(--paper-progress-transition-timing-function, ease);

        /* Delay */
        -webkit-transition-delay: var(--paper-progress-transition-delay, 0s);
        transition-delay: var(--paper-progress-transition-delay, 0s);
      }

      #primaryProgress,
      #secondaryProgress {
        @apply --layout-fit;
        -webkit-transform-origin: left center;
        transform-origin: left center;
        -webkit-transform: scaleX(0);
        transform: scaleX(0);
        will-change: transform;
      }

      #primaryProgress {
        background: var(--paper-progress-active-color, var(--google-green-500));
      }

      #secondaryProgress {
        background: var(--paper-progress-secondary-color, var(--google-green-100));
      }

      :host([disabled]) #primaryProgress {
        background: var(--paper-progress-disabled-active-color, var(--google-grey-500));
      }

      :host([disabled]) #secondaryProgress {
        background: var(--paper-progress-disabled-secondary-color, var(--google-grey-300));
      }

      :host(:not([disabled])) #primaryProgress.indeterminate {
        -webkit-transform-origin: right center;
        transform-origin: right center;
        -webkit-animation: indeterminate-bar var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
        animation: indeterminate-bar var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
      }

      :host(:not([disabled])) #primaryProgress.indeterminate::after {
        content: "";
        -webkit-transform-origin: center center;
        transform-origin: center center;

        -webkit-animation: indeterminate-splitter var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
        animation: indeterminate-splitter var(--paper-progress-indeterminate-cycle-duration, 2s) linear infinite;
      }

      @-webkit-keyframes indeterminate-bar {
        0% {
          -webkit-transform: scaleX(1) translateX(-100%);
        }
        50% {
          -webkit-transform: scaleX(1) translateX(0%);
        }
        75% {
          -webkit-transform: scaleX(1) translateX(0%);
          -webkit-animation-timing-function: cubic-bezier(.28,.62,.37,.91);
        }
        100% {
          -webkit-transform: scaleX(0) translateX(0%);
        }
      }

      @-webkit-keyframes indeterminate-splitter {
        0% {
          -webkit-transform: scaleX(.75) translateX(-125%);
        }
        30% {
          -webkit-transform: scaleX(.75) translateX(-125%);
          -webkit-animation-timing-function: cubic-bezier(.42,0,.6,.8);
        }
        90% {
          -webkit-transform: scaleX(.75) translateX(125%);
        }
        100% {
          -webkit-transform: scaleX(.75) translateX(125%);
        }
      }

      @keyframes indeterminate-bar {
        0% {
          transform: scaleX(1) translateX(-100%);
        }
        50% {
          transform: scaleX(1) translateX(0%);
        }
        75% {
          transform: scaleX(1) translateX(0%);
          animation-timing-function: cubic-bezier(.28,.62,.37,.91);
        }
        100% {
          transform: scaleX(0) translateX(0%);
        }
      }

      @keyframes indeterminate-splitter {
        0% {
          transform: scaleX(.75) translateX(-125%);
        }
        30% {
          transform: scaleX(.75) translateX(-125%);
          animation-timing-function: cubic-bezier(.42,0,.6,.8);
        }
        90% {
          transform: scaleX(.75) translateX(125%);
        }
        100% {
          transform: scaleX(.75) translateX(125%);
        }
      }
    </style>

    <div id="progressContainer">
      <div id="secondaryProgress" hidden\$="[[_hideSecondaryProgress(secondaryRatio)]]"></div>
      <div id="primaryProgress"></div>
    </div>
`,is:"paper-progress",behaviors:[_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_3__.a],properties:{secondaryProgress:{type:Number,value:0},secondaryRatio:{type:Number,value:0,readOnly:!0},indeterminate:{type:Boolean,value:!1,observer:"_toggleIndeterminate"},disabled:{type:Boolean,value:!1,reflectToAttribute:!0,observer:"_disabledChanged"}},observers:["_progressChanged(secondaryProgress, value, min, max, indeterminate)"],hostAttributes:{role:"progressbar"},_toggleIndeterminate:function(indeterminate){this.toggleClass("indeterminate",indeterminate,this.$.primaryProgress)},_transformProgress:function(progress,ratio){progress.style.transform=progress.style.webkitTransform="scaleX("+ratio/100+")"},_mainRatioChanged:function(ratio){this._transformProgress(this.$.primaryProgress,ratio)},_progressChanged:function(secondaryProgress,value,min,max,indeterminate){secondaryProgress=this._clampValue(secondaryProgress);value=this._clampValue(value);var secondaryRatio=100*this._calcRatio(secondaryProgress),mainRatio=100*this._calcRatio(value);this._setSecondaryRatio(secondaryRatio);this._transformProgress(this.$.secondaryProgress,secondaryRatio);this._transformProgress(this.$.primaryProgress,mainRatio);this.secondaryProgress=secondaryProgress;if(indeterminate){this.removeAttribute("aria-valuenow")}else{this.setAttribute("aria-valuenow",value)}this.setAttribute("aria-valuemin",min);this.setAttribute("aria-valuemax",max)},_disabledChanged:function(disabled){this.setAttribute("aria-disabled",disabled?"true":"false")},_hideSecondaryProgress:function(secondaryRatio){return 0===secondaryRatio}})},136:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(33),_polymer_paper_input_paper_input_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(78),_polymer_paper_progress_paper_progress_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(135),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(58),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_3__),_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(19),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(52),_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(97),_polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(51),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(4),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(25),_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_10__=__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_10__.c`
  <style>
    :host {
      @apply --layout;
      @apply --layout-justified;
      @apply --layout-center;
      width: 200px;
      cursor: default;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
      --paper-progress-active-color: var(--paper-slider-active-color, var(--google-blue-700));
      --paper-progress-secondary-color: var(--paper-slider-secondary-color, var(--google-blue-300));
      --paper-progress-disabled-active-color: var(--paper-slider-disabled-active-color, var(--paper-grey-400));
      --paper-progress-disabled-secondary-color: var(--paper-slider-disabled-secondary-color, var(--paper-grey-400));
      --calculated-paper-slider-height: var(--paper-slider-height, 2px);
    }

    /* focus shows the ripple */
    :host(:focus) {
      outline: none;
    }

    /**
      * NOTE(keanulee): Though :host-context is not universally supported, some pages
      * still rely on paper-slider being flipped when dir="rtl" is set on body. For full
      * compatibility, dir="rtl" must be explicitly set on paper-slider.
      */
    :dir(rtl) #sliderContainer {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
    }

    /**
      * NOTE(keanulee): This is separate from the rule above because :host-context may
      * not be recognized.
      */
    :host([dir="rtl"]) #sliderContainer {
      -webkit-transform: scaleX(-1);
      transform: scaleX(-1);
    }

    /**
      * NOTE(keanulee): Needed to override the :host-context rule (where supported)
      * to support LTR sliders in RTL pages.
      */
    :host([dir="ltr"]) #sliderContainer {
      -webkit-transform: scaleX(1);
      transform: scaleX(1);
    }

    #sliderContainer {
      position: relative;
      width: 100%;
      height: calc(30px + var(--calculated-paper-slider-height));
      margin-left: calc(15px + var(--calculated-paper-slider-height)/2);
      margin-right: calc(15px + var(--calculated-paper-slider-height)/2);
    }

    #sliderContainer:focus {
      outline: 0;
    }

    #sliderContainer.editable {
      margin-top: 12px;
      margin-bottom: 12px;
    }

    .bar-container {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      overflow: hidden;
    }

    .ring > .bar-container {
      left: calc(5px + var(--calculated-paper-slider-height)/2);
      transition: left 0.18s ease;
    }

    .ring.expand.dragging > .bar-container {
      transition: none;
    }

    .ring.expand:not(.pin) > .bar-container {
      left: calc(8px + var(--calculated-paper-slider-height)/2);
    }

    #sliderBar {
      padding: 15px 0;
      width: 100%;
      background-color: var(--paper-slider-bar-color, transparent);
      --paper-progress-container-color: var(--paper-slider-container-color, var(--paper-grey-400));
      --paper-progress-height: var(--calculated-paper-slider-height);
    }

    .slider-markers {
      position: absolute;
      /* slider-knob is 30px + the slider-height so that the markers should start at a offset of 15px*/
      top: 15px;
      height: var(--calculated-paper-slider-height);
      left: 0;
      right: -1px;
      box-sizing: border-box;
      pointer-events: none;
      @apply --layout-horizontal;
    }

    .slider-marker {
      @apply --layout-flex;
    }
    .slider-markers::after,
    .slider-marker::after {
      content: "";
      display: block;
      margin-left: -1px;
      width: 2px;
      height: var(--calculated-paper-slider-height);
      border-radius: 50%;
      background-color: var(--paper-slider-markers-color, #000);
    }

    .slider-knob {
      position: absolute;
      left: 0;
      top: 0;
      margin-left: calc(-15px - var(--calculated-paper-slider-height)/2);
      width: calc(30px + var(--calculated-paper-slider-height));
      height: calc(30px + var(--calculated-paper-slider-height));
    }

    .transiting > .slider-knob {
      transition: left 0.08s ease;
    }

    .slider-knob:focus {
      outline: none;
    }

    .slider-knob.dragging {
      transition: none;
    }

    .snaps > .slider-knob.dragging {
      transition: -webkit-transform 0.08s ease;
      transition: transform 0.08s ease;
    }

    .slider-knob-inner {
      margin: 10px;
      width: calc(100% - 20px);
      height: calc(100% - 20px);
      background-color: var(--paper-slider-knob-color, var(--google-blue-700));
      border: 2px solid var(--paper-slider-knob-color, var(--google-blue-700));
      border-radius: 50%;

      -moz-box-sizing: border-box;
      box-sizing: border-box;

      transition-property: -webkit-transform, background-color, border;
      transition-property: transform, background-color, border;
      transition-duration: 0.18s;
      transition-timing-function: ease;
    }

    .expand:not(.pin) > .slider-knob > .slider-knob-inner {
      -webkit-transform: scale(1.5);
      transform: scale(1.5);
    }

    .ring > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-knob-start-color, transparent);
      border: 2px solid var(--paper-slider-knob-start-border-color, var(--paper-grey-400));
    }

    .slider-knob-inner::before {
      background-color: var(--paper-slider-pin-color, var(--google-blue-700));
    }

    .pin > .slider-knob > .slider-knob-inner::before {
      content: "";
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -13px;
      width: 26px;
      height: 26px;
      border-radius: 50% 50% 50% 0;

      -webkit-transform: rotate(-45deg) scale(0) translate(0);
      transform: rotate(-45deg) scale(0) translate(0);
    }

    .slider-knob-inner::before,
    .slider-knob-inner::after {
      transition: -webkit-transform .18s ease, background-color .18s ease;
      transition: transform .18s ease, background-color .18s ease;
    }

    .pin.ring > .slider-knob > .slider-knob-inner::before {
      background-color: var(--paper-slider-pin-start-color, var(--paper-grey-400));
    }

    .pin.expand > .slider-knob > .slider-knob-inner::before {
      -webkit-transform: rotate(-45deg) scale(1) translate(17px, -17px);
      transform: rotate(-45deg) scale(1) translate(17px, -17px);
    }

    .pin > .slider-knob > .slider-knob-inner::after {
      content: attr(value);
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -16px;
      width: 32px;
      height: 26px;
      text-align: center;
      color: var(--paper-slider-font-color, #fff);
      font-size: 10px;

      -webkit-transform: scale(0) translate(0);
      transform: scale(0) translate(0);
    }

    .pin.expand > .slider-knob > .slider-knob-inner::after {
      -webkit-transform: scale(1) translate(0, -17px);
      transform: scale(1) translate(0, -17px);
    }

    /* paper-input */
    .slider-input {
      width: 50px;
      overflow: hidden;
      --paper-input-container-input: {
        text-align: center;
        @apply --paper-slider-input-container-input;
      };
      @apply --paper-slider-input;
    }

    /* disabled state */
    #sliderContainer.disabled {
      pointer-events: none;
    }

    .disabled > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-disabled-knob-color, var(--paper-grey-400));
      border: 2px solid var(--paper-slider-disabled-knob-color, var(--paper-grey-400));
      -webkit-transform: scale3d(0.75, 0.75, 1);
      transform: scale3d(0.75, 0.75, 1);
    }

    .disabled.ring > .slider-knob > .slider-knob-inner {
      background-color: var(--paper-slider-knob-start-color, transparent);
      border: 2px solid var(--paper-slider-knob-start-border-color, var(--paper-grey-400));
    }

    paper-ripple {
      color: var(--paper-slider-knob-color, var(--google-blue-700));
    }
  </style>

  <div id="sliderContainer" class\$="[[_getClassNames(disabled, pin, snaps, immediateValue, min, expand, dragging, transiting, editable)]]">
    <div class="bar-container">
      <paper-progress disabled\$="[[disabled]]" id="sliderBar" aria-hidden="true" min="[[min]]" max="[[max]]" step="[[step]]" value="[[immediateValue]]" secondary-progress="[[secondaryProgress]]" on-down="_bardown" on-up="_resetKnob" on-track="_bartrack" on-tap="_barclick">
      </paper-progress>
    </div>

    <template is="dom-if" if="[[snaps]]">
      <div class="slider-markers">
        <template is="dom-repeat" items="[[markers]]">
          <div class="slider-marker"></div>
        </template>
      </div>
    </template>

    <div id="sliderKnob" class="slider-knob" on-down="_knobdown" on-up="_resetKnob" on-track="_onTrack" on-transitionend="_knobTransitionEnd">
        <div class="slider-knob-inner" value\$="[[immediateValue]]"></div>
    </div>
  </div>

  <template is="dom-if" if="[[editable]]">
    <paper-input id="input" type="number" step="[[step]]" min="[[min]]" max="[[max]]" class="slider-input" disabled\$="[[disabled]]" value="[[immediateValue]]" on-change="_changeValue" on-keydown="_inputKeyDown" no-label-float>
    </paper-input>
  </template>
`;template.setAttribute("strip-whitespace","");Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_8__.a)({_template:template,is:"paper-slider",behaviors:[_polymer_iron_a11y_keys_behavior_iron_a11y_keys_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a,_polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__.a,_polymer_iron_range_behavior_iron_range_behavior_js__WEBPACK_IMPORTED_MODULE_6__.a],properties:{value:{type:Number,value:0},snaps:{type:Boolean,value:!1,notify:!0},pin:{type:Boolean,value:!1,notify:!0},secondaryProgress:{type:Number,value:0,notify:!0,observer:"_secondaryProgressChanged"},editable:{type:Boolean,value:!1},immediateValue:{type:Number,value:0,readOnly:!0,notify:!0},maxMarkers:{type:Number,value:0,notify:!0},expand:{type:Boolean,value:!1,readOnly:!0},ignoreBarTouch:{type:Boolean,value:!1},dragging:{type:Boolean,value:!1,readOnly:!0,notify:!0},transiting:{type:Boolean,value:!1,readOnly:!0},markers:{type:Array,readOnly:!0,value:function(){return[]}}},observers:["_updateKnob(value, min, max, snaps, step)","_valueChanged(value)","_immediateValueChanged(immediateValue)","_updateMarkers(maxMarkers, min, max, snaps)"],hostAttributes:{role:"slider",tabindex:0},keyBindings:{left:"_leftKey",right:"_rightKey","down pagedown home":"_decrementKey","up pageup end":"_incrementKey"},ready:function(){if(this.ignoreBarTouch){Object(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_9__.f)(this.$.sliderBar,"auto")}},increment:function(){this.value=this._clampValue(this.value+this.step)},decrement:function(){this.value=this._clampValue(this.value-this.step)},_updateKnob:function(value,min,max){this.setAttribute("aria-valuemin",min);this.setAttribute("aria-valuemax",max);this.setAttribute("aria-valuenow",value);this._positionKnob(100*this._calcRatio(value))},_valueChanged:function(){this.fire("value-change",{composed:!0})},_immediateValueChanged:function(){if(this.dragging){this.fire("immediate-value-change",{composed:!0})}else{this.value=this.immediateValue}},_secondaryProgressChanged:function(){this.secondaryProgress=this._clampValue(this.secondaryProgress)},_expandKnob:function(){this._setExpand(!0)},_resetKnob:function(){this.cancelDebouncer("expandKnob");this._setExpand(!1)},_positionKnob:function(ratio){this._setImmediateValue(this._calcStep(this._calcKnobPosition(ratio)));this._setRatio(100*this._calcRatio(this.immediateValue));this.$.sliderKnob.style.left=this.ratio+"%";if(this.dragging){this._knobstartx=this.ratio*this._w/100;this.translate3d(0,0,0,this.$.sliderKnob)}},_calcKnobPosition:function(ratio){return(this.max-this.min)*ratio/100+this.min},_onTrack:function(event){event.stopPropagation();switch(event.detail.state){case"start":this._trackStart(event);break;case"track":this._trackX(event);break;case"end":this._trackEnd();break;}},_trackStart:function(){this._setTransiting(!1);this._w=this.$.sliderBar.offsetWidth;this._x=this.ratio*this._w/100;this._startx=this._x;this._knobstartx=this._startx;this._minx=-this._startx;this._maxx=this._w-this._startx;this.$.sliderKnob.classList.add("dragging");this._setDragging(!0)},_trackX:function(event){if(!this.dragging){this._trackStart(event)}var direction=this._isRTL?-1:1,dx=Math.min(this._maxx,Math.max(this._minx,event.detail.dx*direction));this._x=this._startx+dx;var immediateValue=this._calcStep(this._calcKnobPosition(100*(this._x/this._w)));this._setImmediateValue(immediateValue);var translateX=this._calcRatio(this.immediateValue)*this._w-this._knobstartx;this.translate3d(translateX+"px",0,0,this.$.sliderKnob)},_trackEnd:function(){var s=this.$.sliderKnob.style;this.$.sliderKnob.classList.remove("dragging");this._setDragging(!1);this._resetKnob();this.value=this.immediateValue;s.transform=s.webkitTransform="";this.fire("change",{composed:!0})},_knobdown:function(event){this._expandKnob();event.preventDefault();this.focus()},_bartrack:function(event){if(this._allowBarEvent(event)){this._onTrack(event)}},_barclick:function(event){this._w=this.$.sliderBar.offsetWidth;var rect=this.$.sliderBar.getBoundingClientRect(),ratio=100*((event.detail.x-rect.left)/this._w);if(this._isRTL){ratio=100-ratio}var prevRatio=this.ratio;this._setTransiting(!0);this._positionKnob(ratio);if(prevRatio===this.ratio){this._setTransiting(!1)}this.async(function(){this.fire("change",{composed:!0})});event.preventDefault();this.focus()},_bardown:function(event){if(this._allowBarEvent(event)){this.debounce("expandKnob",this._expandKnob,60);this._barclick(event)}},_knobTransitionEnd:function(event){if(event.target===this.$.sliderKnob){this._setTransiting(!1)}},_updateMarkers:function(maxMarkers,min,max,snaps){if(!snaps){this._setMarkers([])}var steps=Math.round((max-min)/this.step);if(steps>maxMarkers){steps=maxMarkers}if(0>steps||!isFinite(steps)){steps=0}this._setMarkers(Array(steps))},_mergeClasses:function(classes){return Object.keys(classes).filter(function(className){return classes[className]}).join(" ")},_getClassNames:function(){return this._mergeClasses({disabled:this.disabled,pin:this.pin,snaps:this.snaps,ring:this.immediateValue<=this.min,expand:this.expand,dragging:this.dragging,transiting:this.transiting,editable:this.editable})},_allowBarEvent:function(event){return!this.ignoreBarTouch||event.detail.sourceEvent instanceof MouseEvent},get _isRTL(){if(this.__isRTL===void 0){this.__isRTL="rtl"===window.getComputedStyle(this).direction}return this.__isRTL},_leftKey:function(event){if(this._isRTL)this._incrementKey(event);else this._decrementKey(event)},_rightKey:function(event){if(this._isRTL)this._decrementKey(event);else this._incrementKey(event)},_incrementKey:function(event){if(!this.disabled){if("end"===event.detail.key){this.value=this.max}else{this.increment()}this.fire("change");event.preventDefault()}},_decrementKey:function(event){if(!this.disabled){if("home"===event.detail.key){this.value=this.min}else{this.decrement()}this.fire("change");event.preventDefault()}},_changeValue:function(event){this.value=event.target.value;this.fire("change",{composed:!0})},_inputKeyDown:function(event){event.stopPropagation()},_createRipple:function(){this._rippleContainer=this.$.sliderKnob;return _polymer_paper_behaviors_paper_inky_focus_behavior_js__WEBPACK_IMPORTED_MODULE_7__.b._createRipple.call(this)},_focusedChanged:function(receivedFocusFromKeyboard){if(receivedFocusFromKeyboard){this.ensureRipple()}if(this.hasRipple()){if(receivedFocusFromKeyboard){this._ripple.style.display=""}else{this._ripple.style.display="none"}this._ripple.holdDown=receivedFocusFromKeyboard}}})},153:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return computeStateDomain});var _compute_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(157);function computeStateDomain(stateObj){return Object(_compute_domain__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj.entity_id)}},154:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return hassLocalizeLitMixin});var _localize_base_mixin__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(63);const empty=()=>"",hassLocalizeLitMixin=(superClass)=>class extends Object(_localize_base_mixin__WEBPACK_IMPORTED_MODULE_0__.a)(superClass){static get properties(){return{hass:{},localize:{}}}constructor(){super();this.localize=empty}connectedCallback(){super.connectedCallback();if(this.localize===empty){let language,resources;if(this.hass){language=this.hass.language;resources=this.hass.resources}this.localize=this.__computeLocalize(language,resources)}}updated(changedProperties){super.updated(changedProperties);if(!changedProperties.has("hass")){return}let oldLanguage,oldResources;const hass=changedProperties.get("hass");if(hass){oldLanguage=hass.language;oldResources=hass.resources}let language,resources;if(this.hass){language=this.hass.language;resources=this.hass.resources}if(oldLanguage!==language||oldResources!==resources){this.localize=this.__computeLocalize(language,resources)}}}},156:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return domainIcon});var _const__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(80);const fixedIcons={alert:"hass:alert",automation:"hass:playlist-play",calendar:"hass:calendar",camera:"hass:video",climate:"hass:thermostat",configurator:"hass:settings",conversation:"hass:text-to-speech",device_tracker:"hass:account",fan:"hass:fan",group:"hass:google-circles-communities",history_graph:"hass:chart-line",homeassistant:"hass:home-assistant",homekit:"hass:home-automation",image_processing:"hass:image-filter-frames",input_boolean:"hass:drawing",input_datetime:"hass:calendar-clock",input_number:"hass:ray-vertex",input_select:"hass:format-list-bulleted",input_text:"hass:textbox",light:"hass:lightbulb",mailbox:"hass:mailbox",notify:"hass:comment-alert",plant:"hass:flower",proximity:"hass:apple-safari",remote:"hass:remote",scene:"hass:google-pages",script:"hass:file-document",sensor:"hass:eye",simple_alarm:"hass:bell",sun:"hass:white-balance-sunny",switch:"hass:flash",timer:"hass:timer",updater:"hass:cloud-upload",vacuum:"hass:robot-vacuum",water_heater:"hass:thermometer",weblink:"hass:open-in-new"};function domainIcon(domain,state){if(domain in fixedIcons){return fixedIcons[domain]}switch(domain){case"alarm_control_panel":switch(state){case"armed_home":return"hass:bell-plus";case"armed_night":return"hass:bell-sleep";case"disarmed":return"hass:bell-outline";case"triggered":return"hass:bell-ring";default:return"hass:bell";}case"binary_sensor":return state&&"off"===state?"hass:radiobox-blank":"hass:checkbox-marked-circle";case"cover":return"closed"===state?"hass:window-closed":"hass:window-open";case"lock":return state&&"unlocked"===state?"hass:lock-open":"hass:lock";case"media_player":return state&&"off"!==state&&"idle"!==state?"hass:cast-connected":"hass:cast";case"zwave":switch(state){case"dead":return"hass:emoticon-dead";case"sleeping":return"hass:sleep";case"initializing":return"hass:timer-sand";default:return"hass:z-wave";}default:console.warn("Unable to find icon for domain "+domain+" ("+state+")");return _const__WEBPACK_IMPORTED_MODULE_0__.a;}}},157:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return computeDomain});function computeDomain(entityId){return entityId.substr(0,entityId.indexOf("."))}},159:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__(95);const IronIconClass=customElements.get("iron-icon");let loaded=!1;customElements.define("ha-icon",class extends IronIconClass{listen(...args){super.listen(...args);if(!loaded&&"mdi"===this._iconsetName){loaded=!0;__webpack_require__.e(49).then(__webpack_require__.bind(null,212))}}})},161:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_ha_icon__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(159),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(153),_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(175);class StateBadge extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        :host {
          position: relative;
          display: inline-block;
          width: 40px;
          color: var(--paper-item-icon-color, #44739e);
          border-radius: 50%;
          height: 40px;
          text-align: center;
          background-size: cover;
          line-height: 40px;
        }

        ha-icon {
          transition: color 0.3s ease-in-out, filter 0.3s ease-in-out;
        }

        /* Color the icon if light or sun is on */
        ha-icon[data-domain="light"][data-state="on"],
        ha-icon[data-domain="switch"][data-state="on"],
        ha-icon[data-domain="binary_sensor"][data-state="on"],
        ha-icon[data-domain="fan"][data-state="on"],
        ha-icon[data-domain="sun"][data-state="above_horizon"] {
          color: var(--paper-item-icon-active-color, #fdd835);
        }

        /* Color the icon if unavailable */
        ha-icon[data-state="unavailable"] {
          color: var(--state-icon-unavailable-color);
        }
      </style>

      <ha-icon
        id="icon"
        data-domain$="[[_computeDomain(stateObj)]]"
        data-state$="[[stateObj.state]]"
        icon="[[_computeIcon(stateObj, overrideIcon)]]"
      ></ha-icon>
    `}static get properties(){return{stateObj:{type:Object,observer:"_updateIconAppearance"},overrideIcon:String}}_computeDomain(stateObj){return Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_3__.a)(stateObj)}_computeIcon(stateObj,overrideIcon){return overrideIcon||Object(_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_4__.a)(stateObj)}_updateIconAppearance(newVal){var errorMessage=null;const iconStyle={color:"",filter:""},hostStyle={backgroundImage:""};if(newVal.attributes.entity_picture){hostStyle.backgroundImage="url("+newVal.attributes.entity_picture+")";iconStyle.display="none"}else{if(newVal.attributes.hs_color){const hue=newVal.attributes.hs_color[0],sat=newVal.attributes.hs_color[1];if(10<sat)iconStyle.color=`hsl(${hue}, 100%, ${100-sat/2}%)`}if(newVal.attributes.brightness){const brightness=newVal.attributes.brightness;if("number"!==typeof brightness){errorMessage=`Type error: state-badge expected number, but type of ${newVal.entity_id}.attributes.brightness is ${typeof brightness} (${brightness})`;console.warn(errorMessage)}iconStyle.filter=`brightness(${(brightness+245)/5}%)`}}Object.assign(this.$.icon.style,iconStyle);Object.assign(this.style,hostStyle);if(errorMessage){throw new Error(`Frontend error: ${errorMessage}`)}}}customElements.define("state-badge",StateBadge)},164:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1),_polymer_polymer_lib_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(11);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
    <style>
      :host {
        display: inline-block;
        overflow: hidden;
        position: relative;
      }

      #baseURIAnchor {
        display: none;
      }

      #sizedImgDiv {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        display: none;
      }

      #img {
        display: block;
        width: var(--iron-image-width, auto);
        height: var(--iron-image-height, auto);
      }

      :host([sizing]) #sizedImgDiv {
        display: block;
      }

      :host([sizing]) #img {
        display: none;
      }

      #placeholder {
        position: absolute;
        top: 0px;
        right: 0px;
        bottom: 0px;
        left: 0px;

        background-color: inherit;
        opacity: 1;

        @apply --iron-image-placeholder;
      }

      #placeholder.faded-out {
        transition: opacity 0.5s linear;
        opacity: 0;
      }
    </style>

    <a id="baseURIAnchor" href="#"></a>
    <div id="sizedImgDiv" role="img" hidden\$="[[_computeImgDivHidden(sizing)]]" aria-hidden\$="[[_computeImgDivARIAHidden(alt)]]" aria-label\$="[[_computeImgDivARIALabel(alt, src)]]"></div>
    <img id="img" alt\$="[[alt]]" hidden\$="[[_computeImgHidden(sizing)]]" crossorigin\$="[[crossorigin]]" on-load="_imgOnLoad" on-error="_imgOnError">
    <div id="placeholder" hidden\$="[[_computePlaceholderHidden(preload, fade, loading, loaded)]]" class\$="[[_computePlaceholderClassName(preload, fade, loading, loaded)]]"></div>
`,is:"iron-image",properties:{src:{type:String,value:""},alt:{type:String,value:null},crossorigin:{type:String,value:null},preventLoad:{type:Boolean,value:!1},sizing:{type:String,value:null,reflectToAttribute:!0},position:{type:String,value:"center"},preload:{type:Boolean,value:!1},placeholder:{type:String,value:null,observer:"_placeholderChanged"},fade:{type:Boolean,value:!1},loaded:{notify:!0,readOnly:!0,type:Boolean,value:!1},loading:{notify:!0,readOnly:!0,type:Boolean,value:!1},error:{notify:!0,readOnly:!0,type:Boolean,value:!1},width:{observer:"_widthChanged",type:Number,value:null},height:{observer:"_heightChanged",type:Number,value:null}},observers:["_transformChanged(sizing, position)","_loadStateObserver(src, preventLoad)"],created:function(){this._resolvedSrc=""},_imgOnLoad:function(){if(this.$.img.src!==this._resolveSrc(this.src)){return}this._setLoading(!1);this._setLoaded(!0);this._setError(!1)},_imgOnError:function(){if(this.$.img.src!==this._resolveSrc(this.src)){return}this.$.img.removeAttribute("src");this.$.sizedImgDiv.style.backgroundImage="";this._setLoading(!1);this._setLoaded(!1);this._setError(!0)},_computePlaceholderHidden:function(){return!this.preload||!this.fade&&!this.loading&&this.loaded},_computePlaceholderClassName:function(){return this.preload&&this.fade&&!this.loading&&this.loaded?"faded-out":""},_computeImgDivHidden:function(){return!this.sizing},_computeImgDivARIAHidden:function(){return""===this.alt?"true":void 0},_computeImgDivARIALabel:function(){if(null!==this.alt){return this.alt}if(""===this.src){return""}var resolved=this._resolveSrc(this.src);return resolved.replace(/[?|#].*/g,"").split("/").pop()},_computeImgHidden:function(){return!!this.sizing},_widthChanged:function(){this.style.width=isNaN(this.width)?this.width:this.width+"px"},_heightChanged:function(){this.style.height=isNaN(this.height)?this.height:this.height+"px"},_loadStateObserver:function(src,preventLoad){var newResolvedSrc=this._resolveSrc(src);if(newResolvedSrc===this._resolvedSrc){return}this._resolvedSrc="";this.$.img.removeAttribute("src");this.$.sizedImgDiv.style.backgroundImage="";if(""===src||preventLoad){this._setLoading(!1);this._setLoaded(!1);this._setError(!1)}else{this._resolvedSrc=newResolvedSrc;this.$.img.src=this._resolvedSrc;this.$.sizedImgDiv.style.backgroundImage="url(\""+this._resolvedSrc+"\")";this._setLoading(!0);this._setLoaded(!1);this._setError(!1)}},_placeholderChanged:function(){this.$.placeholder.style.backgroundImage=this.placeholder?"url(\""+this.placeholder+"\")":""},_transformChanged:function(){var sizedImgDivStyle=this.$.sizedImgDiv.style,placeholderStyle=this.$.placeholder.style;sizedImgDivStyle.backgroundSize=placeholderStyle.backgroundSize=this.sizing;sizedImgDivStyle.backgroundPosition=placeholderStyle.backgroundPosition=this.sizing?this.position:"";sizedImgDivStyle.backgroundRepeat=placeholderStyle.backgroundRepeat=this.sizing?"no-repeat":""},_resolveSrc:function(testSrc){var resolved=Object(_polymer_polymer_lib_utils_resolve_url_js__WEBPACK_IMPORTED_MODULE_3__.c)(testSrc,this.$.baseURIAnchor.href);if("/"===resolved[0]){resolved=(location.origin||location.protocol+"//"+location.host)+resolved}return resolved}})},168:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_styles_element_styles_paper_material_styles__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(82),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(10);class HaCard extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style include="paper-material-styles">
        :host {
          @apply --paper-material-elevation-1;
          display: block;
          border-radius: 2px;
          transition: all 0.3s ease-out;
          background-color: var(--paper-card-background-color, white);
          color: var(--primary-text-color);
        }
        .header {
          @apply --paper-font-headline;
          @apply --paper-font-common-expensive-kerning;
          opacity: var(--dark-primary-opacity);
          padding: 24px 16px 16px;
        }
      </style>

      <template is="dom-if" if="[[header]]">
        <div class="header">[[header]]</div>
      </template>
      <slot></slot>
    `}static get properties(){return{header:String}}}customElements.define("ha-card",HaCard)},170:function(module,__webpack_exports__){"use strict";var _Mathabs=Math.abs,_Mathround=Math.round,fecha={},token=/d{1,4}|M{1,4}|YY(?:YY)?|S{1,3}|Do|ZZ|([HhMsDm])\1?|[aA]|"[^"]*"|'[^']*'/g,twoDigits="\\d\\d?",word="[^\\s]+",literal=/\[([^]*?)\]/gm,noop=function(){};function regexEscape(str){return str.replace(/[|\\{()[^$+*?.-]/g,"\\$&")}function shorten(arr,sLen){for(var newArr=[],i=0,len=arr.length;i<len;i++){newArr.push(arr[i].substr(0,sLen))}return newArr}function monthUpdate(arrName){return function(d,v,i18n){var index=i18n[arrName].indexOf(v.charAt(0).toUpperCase()+v.substr(1).toLowerCase());if(~index){d.month=index}}}function pad(val,len){val=val+"";len=len||2;while(val.length<len){val="0"+val}return val}var dayNames=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],monthNames=["January","February","March","April","May","June","July","August","September","October","November","December"],monthNamesShort=shorten(monthNames,3),dayNamesShort=shorten(dayNames,3);fecha.i18n={dayNamesShort:dayNamesShort,dayNames:dayNames,monthNamesShort:monthNamesShort,monthNames:monthNames,amPm:["am","pm"],DoFn:function(D){return D+["th","st","nd","rd"][3<D%10?0:(10!==D-D%10)*D%10]}};var formatFlags={D:function(dateObj){return dateObj.getDate()},DD:function(dateObj){return pad(dateObj.getDate())},Do:function(dateObj,i18n){return i18n.DoFn(dateObj.getDate())},d:function(dateObj){return dateObj.getDay()},dd:function(dateObj){return pad(dateObj.getDay())},ddd:function(dateObj,i18n){return i18n.dayNamesShort[dateObj.getDay()]},dddd:function(dateObj,i18n){return i18n.dayNames[dateObj.getDay()]},M:function(dateObj){return dateObj.getMonth()+1},MM:function(dateObj){return pad(dateObj.getMonth()+1)},MMM:function(dateObj,i18n){return i18n.monthNamesShort[dateObj.getMonth()]},MMMM:function(dateObj,i18n){return i18n.monthNames[dateObj.getMonth()]},YY:function(dateObj){return pad(dateObj.getFullYear()+"",4).substr(2)},YYYY:function(dateObj){return pad(dateObj.getFullYear(),4)},h:function(dateObj){return dateObj.getHours()%12||12},hh:function(dateObj){return pad(dateObj.getHours()%12||12)},H:function(dateObj){return dateObj.getHours()},HH:function(dateObj){return pad(dateObj.getHours())},m:function(dateObj){return dateObj.getMinutes()},mm:function(dateObj){return pad(dateObj.getMinutes())},s:function(dateObj){return dateObj.getSeconds()},ss:function(dateObj){return pad(dateObj.getSeconds())},S:function(dateObj){return _Mathround(dateObj.getMilliseconds()/100)},SS:function(dateObj){return pad(_Mathround(dateObj.getMilliseconds()/10),2)},SSS:function(dateObj){return pad(dateObj.getMilliseconds(),3)},a:function(dateObj,i18n){return 12>dateObj.getHours()?i18n.amPm[0]:i18n.amPm[1]},A:function(dateObj,i18n){return 12>dateObj.getHours()?i18n.amPm[0].toUpperCase():i18n.amPm[1].toUpperCase()},ZZ:function(dateObj){var o=dateObj.getTimezoneOffset();return(0<o?"-":"+")+pad(100*Math.floor(_Mathabs(o)/60)+_Mathabs(o)%60,4)}},parseFlags={D:[twoDigits,function(d,v){d.day=v}],Do:[twoDigits+word,function(d,v){d.day=parseInt(v,10)}],M:[twoDigits,function(d,v){d.month=v-1}],YY:[twoDigits,function(d,v){var da=new Date,cent=+(""+da.getFullYear()).substr(0,2);d.year=""+(68<v?cent-1:cent)+v}],h:[twoDigits,function(d,v){d.hour=v}],m:[twoDigits,function(d,v){d.minute=v}],s:[twoDigits,function(d,v){d.second=v}],YYYY:["\\d{4}",function(d,v){d.year=v}],S:["\\d",function(d,v){d.millisecond=100*v}],SS:["\\d{2}",function(d,v){d.millisecond=10*v}],SSS:["\\d{3}",function(d,v){d.millisecond=v}],d:[twoDigits,noop],ddd:[word,noop],MMM:[word,monthUpdate("monthNamesShort")],MMMM:[word,monthUpdate("monthNames")],a:[word,function(d,v,i18n){var val=v.toLowerCase();if(val===i18n.amPm[0]){d.isPm=!1}else if(val===i18n.amPm[1]){d.isPm=!0}}],ZZ:["[^\\s]*?[\\+\\-]\\d\\d:?\\d\\d|[^\\s]*?Z",function(d,v){var parts=(v+"").match(/([\+\-]|\d\d)/gi),minutes;if(parts){minutes=+(60*parts[1])+parseInt(parts[2],10);d.timezoneOffset="+"===parts[0]?minutes:-minutes}}]};parseFlags.dd=parseFlags.d;parseFlags.dddd=parseFlags.ddd;parseFlags.DD=parseFlags.D;parseFlags.mm=parseFlags.m;parseFlags.hh=parseFlags.H=parseFlags.HH=parseFlags.h;parseFlags.MM=parseFlags.M;parseFlags.ss=parseFlags.s;parseFlags.A=parseFlags.a;fecha.masks={default:"ddd MMM DD YYYY HH:mm:ss",shortDate:"M/D/YY",mediumDate:"MMM D, YYYY",longDate:"MMMM D, YYYY",fullDate:"dddd, MMMM D, YYYY",shortTime:"HH:mm",mediumTime:"HH:mm:ss",longTime:"HH:mm:ss.SSS"};fecha.format=function(dateObj,mask,i18nSettings){var i18n=i18nSettings||fecha.i18n;if("number"===typeof dateObj){dateObj=new Date(dateObj)}if("[object Date]"!==Object.prototype.toString.call(dateObj)||isNaN(dateObj.getTime())){throw new Error("Invalid Date in fecha.format")}mask=fecha.masks[mask]||mask||fecha.masks["default"];var literals=[];mask=mask.replace(literal,function($0,$1){literals.push($1);return"??"});mask=mask.replace(token,function($0){return $0 in formatFlags?formatFlags[$0](dateObj,i18n):$0.slice(1,$0.length-1)});return mask.replace(/\?\?/g,function(){return literals.shift()})};fecha.parse=function(dateStr,format,i18nSettings){var i18n=i18nSettings||fecha.i18n;if("string"!==typeof format){throw new Error("Invalid format in fecha.parse")}format=fecha.masks[format]||format;if(1e3<dateStr.length){return null}var dateInfo={},parseInfo=[],newFormat=regexEscape(format).replace(token,function($0){if(parseFlags[$0]){var info=parseFlags[$0];parseInfo.push(info[1]);return"("+info[0]+")"}return $0}),matches=dateStr.match(new RegExp(newFormat,"i"));if(!matches){return null}for(var i=1;i<matches.length;i++){parseInfo[i-1](dateInfo,matches[i],i18n)}var today=new Date;if(!0===dateInfo.isPm&&null!=dateInfo.hour&&12!==+dateInfo.hour){dateInfo.hour=+dateInfo.hour+12}else if(!1===dateInfo.isPm&&12===+dateInfo.hour){dateInfo.hour=0}var date;if(null!=dateInfo.timezoneOffset){dateInfo.minute=+(dateInfo.minute||0)-+dateInfo.timezoneOffset;date=new Date(Date.UTC(dateInfo.year||today.getFullYear(),dateInfo.month||0,dateInfo.day||1,dateInfo.hour||0,dateInfo.minute||0,dateInfo.second||0,dateInfo.millisecond||0))}else{date=new Date(dateInfo.year||today.getFullYear(),dateInfo.month||0,dateInfo.day||1,dateInfo.hour||0,dateInfo.minute||0,dateInfo.second||0,dateInfo.millisecond||0)}return date};__webpack_exports__.a=fecha},173:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(170);__webpack_exports__.a=function(){try{new Date().toLocaleString("i")}catch(e){return"RangeError"===e.name}return!1}()?(dateObj,locales)=>dateObj.toLocaleString(locales,{year:"numeric",month:"long",day:"numeric",hour:"numeric",minute:"2-digit"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"haDateTime")},175:function(module,__webpack_exports__,__webpack_require__){"use strict";var common_const=__webpack_require__(80),compute_domain=__webpack_require__(157),domain_icon=__webpack_require__(156);const fixedDeviceClassIcons={humidity:"hass:water-percent",illuminance:"hass:brightness-5",temperature:"hass:thermometer",pressure:"hass:gauge"};function sensorIcon(state){const dclass=state.attributes.device_class;if(dclass&&dclass in fixedDeviceClassIcons){return fixedDeviceClassIcons[dclass]}if("battery"===dclass){const battery=+state.state;if(isNaN(battery)){return"hass:battery-unknown"}const batteryRound=10*Math.round(battery/10);if(100<=batteryRound){return"hass:battery"}if(0>=batteryRound){return"hass:battery-alert"}return`${"hass"}:battery-${batteryRound}`}const unit=state.attributes.unit_of_measurement;if(unit===common_const.j||unit===common_const.k){return"hass:thermometer"}return Object(domain_icon.a)("sensor")}__webpack_require__.d(__webpack_exports__,"a",function(){return stateIcon});const domainIcons={binary_sensor:function(state){const activated=state.state&&"off"===state.state;switch(state.attributes.device_class){case"battery":return activated?"hass:battery":"hass:battery-outline";case"cold":return activated?"hass:thermometer":"hass:snowflake";case"connectivity":return activated?"hass:server-network-off":"hass:server-network";case"door":return activated?"hass:door-closed":"hass:door-open";case"garage_door":return activated?"hass:garage":"hass:garage-open";case"gas":case"power":case"problem":case"safety":case"smoke":return activated?"hass:verified":"hass:alert";case"heat":return activated?"hass:thermometer":"hass:fire";case"light":return activated?"hass:brightness-5":"hass:brightness-7";case"lock":return activated?"hass:lock":"hass:lock-open";case"moisture":return activated?"hass:water-off":"hass:water";case"motion":return activated?"hass:walk":"hass:run";case"occupancy":return activated?"hass:home-outline":"hass:home";case"opening":return activated?"hass:square":"hass:square-outline";case"plug":return activated?"hass:power-plug-off":"hass:power-plug";case"presence":return activated?"hass:home-outline":"hass:home";case"sound":return activated?"hass:music-note-off":"hass:music-note";case"vibration":return activated?"hass:crop-portrait":"hass:vibrate";case"window":return activated?"hass:window-closed":"hass:window-open";default:return activated?"hass:radiobox-blank":"hass:checkbox-marked-circle";}},cover:function(state){const open="closed"!==state.state;switch(state.attributes.device_class){case"garage":return open?"hass:garage-open":"hass:garage";default:return Object(domain_icon.a)("cover",state.state);}},sensor:sensorIcon,input_datetime:function(state){if(!state.attributes.has_date){return"hass:clock"}if(!state.attributes.has_time){return"hass:calendar"}return Object(domain_icon.a)("input_datetime")}};function stateIcon(state){if(!state){return common_const.a}if(state.attributes.icon){return state.attributes.icon}const domain=Object(compute_domain.a)(state.entity_id);if(domain in domainIcons){return domainIcons[domain](state)}return Object(domain_icon.a)(domain,state.state)}},185:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return isComponentLoaded});function isComponentLoaded(hass,component){return hass&&-1!==hass.config.components.indexOf(component)}},187:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(58),_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2___default=__webpack_require__.n(_polymer_paper_styles_color_js__WEBPACK_IMPORTED_MODULE_2__),_polymer_paper_styles_default_theme_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(39),_polymer_paper_behaviors_paper_checked_element_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(109),_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(40),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(4),_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(25),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(1),_polymer_polymer_lib_utils_render_status_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(34);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const template=_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__.a`

    <style>
      :host {
        display: inline-block;
        @apply --layout-horizontal;
        @apply --layout-center;
        @apply --paper-font-common-base;
      }

      :host([disabled]) {
        pointer-events: none;
      }

      :host(:focus) {
        outline:none;
      }

      .toggle-bar {
        position: absolute;
        height: 100%;
        width: 100%;
        border-radius: 8px;
        pointer-events: none;
        opacity: 0.4;
        transition: background-color linear .08s;
        background-color: var(--paper-toggle-button-unchecked-bar-color, #000000);

        @apply --paper-toggle-button-unchecked-bar;
      }

      .toggle-button {
        position: absolute;
        top: -3px;
        left: 0;
        height: 20px;
        width: 20px;
        border-radius: 50%;
        box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.6);
        transition: -webkit-transform linear .08s, background-color linear .08s;
        transition: transform linear .08s, background-color linear .08s;
        will-change: transform;
        background-color: var(--paper-toggle-button-unchecked-button-color, var(--paper-grey-50));

        @apply --paper-toggle-button-unchecked-button;
      }

      .toggle-button.dragging {
        -webkit-transition: none;
        transition: none;
      }

      :host([checked]:not([disabled])) .toggle-bar {
        opacity: 0.5;
        background-color: var(--paper-toggle-button-checked-bar-color, var(--primary-color));

        @apply --paper-toggle-button-checked-bar;
      }

      :host([disabled]) .toggle-bar {
        background-color: #000;
        opacity: 0.12;
      }

      :host([checked]) .toggle-button {
        -webkit-transform: translate(16px, 0);
        transform: translate(16px, 0);
      }

      :host([checked]:not([disabled])) .toggle-button {
        background-color: var(--paper-toggle-button-checked-button-color, var(--primary-color));

        @apply --paper-toggle-button-checked-button;
      }

      :host([disabled]) .toggle-button {
        background-color: #bdbdbd;
        opacity: 1;
      }

      .toggle-ink {
        position: absolute;
        top: -14px;
        left: -14px;
        right: auto;
        bottom: auto;
        width: 48px;
        height: 48px;
        opacity: 0.5;
        pointer-events: none;
        color: var(--paper-toggle-button-unchecked-ink-color, var(--primary-text-color));

        @apply --paper-toggle-button-unchecked-ink;
      }

      :host([checked]) .toggle-ink {
        color: var(--paper-toggle-button-checked-ink-color, var(--primary-color));

        @apply --paper-toggle-button-checked-ink;
      }

      .toggle-container {
        display: inline-block;
        position: relative;
        width: 36px;
        height: 14px;
        /* The toggle button has an absolute position of -3px; The extra 1px
        /* accounts for the toggle button shadow box. */
        margin: 4px 1px;
      }

      .toggle-label {
        position: relative;
        display: inline-block;
        vertical-align: middle;
        padding-left: var(--paper-toggle-button-label-spacing, 8px);
        pointer-events: none;
        color: var(--paper-toggle-button-label-color, var(--primary-text-color));
      }

      /* invalid state */
      :host([invalid]) .toggle-bar {
        background-color: var(--paper-toggle-button-invalid-bar-color, var(--error-color));
      }

      :host([invalid]) .toggle-button {
        background-color: var(--paper-toggle-button-invalid-button-color, var(--error-color));
      }

      :host([invalid]) .toggle-ink {
        color: var(--paper-toggle-button-invalid-ink-color, var(--error-color));
      }
    </style>

    <div class="toggle-container">
      <div id="toggleBar" class="toggle-bar"></div>
      <div id="toggleButton" class="toggle-button"></div>
    </div>

    <div class="toggle-label"><slot></slot></div>

  `;template.setAttribute("strip-whitespace","");Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_6__.a)({_template:template,is:"paper-toggle-button",behaviors:[_polymer_paper_behaviors_paper_checked_element_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a],hostAttributes:{role:"button","aria-pressed":"false",tabindex:0},properties:{},listeners:{track:"_ontrack"},attached:function(){Object(_polymer_polymer_lib_utils_render_status_js__WEBPACK_IMPORTED_MODULE_9__.a)(this,function(){Object(_polymer_polymer_lib_utils_gestures_js__WEBPACK_IMPORTED_MODULE_7__.f)(this,"pan-y")})},_ontrack:function(event){var track=event.detail;if("start"===track.state){this._trackStart(track)}else if("track"===track.state){this._trackMove(track)}else if("end"===track.state){this._trackEnd(track)}},_trackStart:function(){this._width=this.$.toggleBar.offsetWidth/2;this._trackChecked=this.checked;this.$.toggleButton.classList.add("dragging")},_trackMove:function(track){var dx=track.dx;this._x=Math.min(this._width,Math.max(0,this._trackChecked?this._width+dx:dx));this.translate3d(this._x+"px",0,0,this.$.toggleButton);this._userActivate(this._x>this._width/2)},_trackEnd:function(){this.$.toggleButton.classList.remove("dragging");this.transform("",this.$.toggleButton)},_createRipple:function(){this._rippleContainer=this.$.toggleButton;var ripple=_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a._createRipple();ripple.id="ink";ripple.setAttribute("recenters","");ripple.classList.add("circle","toggle-ink");return ripple}})},188:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(170);__webpack_exports__.a=function(){try{new Date().toLocaleTimeString("i")}catch(e){return"RangeError"===e.name}return!1}()?(dateObj,locales)=>dateObj.toLocaleTimeString(locales,{hour:"numeric",minute:"2-digit"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"shortTime")},190:function(module,__webpack_exports__,__webpack_require__){"use strict";var _compute_state_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(153),_datetime_format_date_time__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(173),_datetime_format_date__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(208),_datetime_format_time__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(188);__webpack_exports__.a=(localize,stateObj,language)=>{let display;const domain=Object(_compute_state_domain__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj);if("binary_sensor"===domain){if(stateObj.attributes.device_class){display=localize(`state.${domain}.${stateObj.attributes.device_class}.${stateObj.state}`)}if(!display){display=localize(`state.${domain}.default.${stateObj.state}`)}}else if(stateObj.attributes.unit_of_measurement&&!["unknown","unavailable"].includes(stateObj.state)){display=stateObj.state+" "+stateObj.attributes.unit_of_measurement}else if("input_datetime"===domain){let date;if(!stateObj.attributes.has_time){date=new Date(stateObj.attributes.year,stateObj.attributes.month-1,stateObj.attributes.day);display=Object(_datetime_format_date__WEBPACK_IMPORTED_MODULE_2__.a)(date,language)}else if(!stateObj.attributes.has_date){const now=new Date;date=new Date(now.getFullYear(),now.getMonth(),now.getDay(),stateObj.attributes.hour,stateObj.attributes.minute);display=Object(_datetime_format_time__WEBPACK_IMPORTED_MODULE_3__.a)(date,language)}else{date=new Date(stateObj.attributes.year,stateObj.attributes.month-1,stateObj.attributes.day,stateObj.attributes.hour,stateObj.attributes.minute);display=Object(_datetime_format_date_time__WEBPACK_IMPORTED_MODULE_1__.a)(date,language)}}else if("zwave"===domain){if(["initializing","dead"].includes(stateObj.state)){display=localize(`state.zwave.query_stage.${stateObj.state}`,"query_stage",stateObj.attributes.query_stage)}else{display=localize(`state.zwave.default.${stateObj.state}`)}}else{display=localize(`state.${domain}.${stateObj.state}`)}if(!display){display=localize(`state.default.${stateObj.state}`)||localize(`component.${domain}.state.${stateObj.state}`)||stateObj.state}return display}},192:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return classMap});var _lit_html_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(31);/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */if(window.navigator.userAgent.match("Trident")){DOMTokenList.prototype.toggle=function(token,force){if(force===void 0||force){this.add(token)}else{this.remove(token)}return force===void 0?!0:force}}const classMapCache=new WeakMap,classMapStatics=new WeakMap,classMap=classInfo=>Object(_lit_html_js__WEBPACK_IMPORTED_MODULE_0__.f)(part=>{if(!(part instanceof _lit_html_js__WEBPACK_IMPORTED_MODULE_0__.a)||part instanceof _lit_html_js__WEBPACK_IMPORTED_MODULE_0__.c||"class"!==part.committer.name||1<part.committer.parts.length){throw new Error("The `classMap` directive must be used in the `class` attribute "+"and must be the only part in the attribute.")}if(!classMapStatics.has(part)){part.committer.element.className=part.committer.strings.join(" ");classMapStatics.set(part,!0)}const oldInfo=classMapCache.get(part);for(const name in oldInfo){if(!(name in classInfo)){part.committer.element.classList.remove(name)}}for(const name in classInfo){if(!oldInfo||oldInfo[name]!==classInfo[name]){part.committer.element.classList.toggle(name,!!classInfo[name])}}classMapCache.set(part,classInfo)})},193:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return supportsFeature});const supportsFeature=(stateObj,feature)=>{return 0!==(stateObj.attributes.supported_features&feature)}},198:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return CoverEntity});__webpack_require__.d(__webpack_exports__,"b",function(){return isTiltOnly});var _common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(193);class CoverEntity{constructor(hass,stateObj){this.hass=hass;this.stateObj=stateObj;this._attr=stateObj.attributes;this._feat=this._attr.supported_features}get isFullyOpen(){if(this._attr.current_position!==void 0){return 100===this._attr.current_position}return"open"===this.stateObj.state}get isFullyClosed(){if(this._attr.current_position!==void 0){return 0===this._attr.current_position}return"closed"===this.stateObj.state}get isFullyOpenTilt(){return 100===this._attr.current_tilt_position}get isFullyClosedTilt(){return 0===this._attr.current_tilt_position}get isOpening(){return"opening"===this.stateObj.state}get isClosing(){return"closing"===this.stateObj.state}get supportsOpen(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1)}get supportsClose(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,2)}get supportsSetPosition(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,4)}get supportsStop(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,8)}get supportsOpenTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16)}get supportsCloseTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,32)}get supportsStopTilt(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,64)}get supportsSetTiltPosition(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,128)}get isTiltOnly(){const supportsCover=this.supportsOpen||this.supportsClose||this.supportsStop,supportsTilt=this.supportsOpenTilt||this.supportsCloseTilt||this.supportsStopTilt;return supportsTilt&&!supportsCover}openCover(){this.callService("open_cover")}closeCover(){this.callService("close_cover")}stopCover(){this.callService("stop_cover")}openCoverTilt(){this.callService("open_cover_tilt")}closeCoverTilt(){this.callService("close_cover_tilt")}stopCoverTilt(){this.callService("stop_cover_tilt")}setCoverPosition(position){this.callService("set_cover_position",{position})}setCoverTiltPosition(tiltPosition){this.callService("set_cover_tilt_position",{tilt_position:tiltPosition})}callService(service,data={}){data.entity_id=this.stateObj.entity_id;this.hass.callService("cover",service,data)}}const supportsOpen=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,1),supportsClose=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,2),supportsStop=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,8),supportsOpenTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,16),supportsCloseTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,32),supportsStopTilt=stateObj=>Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(stateObj,64);function isTiltOnly(stateObj){const supportsCover=supportsOpen(stateObj)||supportsClose(stateObj)||supportsStop(stateObj),supportsTilt=supportsOpenTilt(stateObj)||supportsCloseTilt(stateObj)||supportsStopTilt(stateObj);return supportsTilt&&!supportsCover}},199:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_button_paper_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(72),_polymer_paper_spinner_paper_spinner__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(111),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(10);class HaProgressButton extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__.a`
      <style>
        .container {
          position: relative;
          display: inline-block;
        }

        paper-button {
          transition: all 1s;
        }

        .success paper-button {
          color: white;
          background-color: var(--google-green-500);
          transition: none;
        }

        .error paper-button {
          color: white;
          background-color: var(--google-red-500);
          transition: none;
        }

        paper-button[disabled] {
          color: #c8c8c8;
        }

        .progress {
          @apply --layout;
          @apply --layout-center-center;
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
        }
      </style>
      <div class="container" id="container">
        <paper-button
          id="button"
          disabled="[[computeDisabled(disabled, progress)]]"
          on-click="buttonTapped"
        >
          <slot></slot>
        </paper-button>
        <template is="dom-if" if="[[progress]]">
          <div class="progress"><paper-spinner active=""></paper-spinner></div>
        </template>
      </div>
    `}static get properties(){return{hass:{type:Object},progress:{type:Boolean,value:!1},disabled:{type:Boolean,value:!1}}}tempClass(className){var classList=this.$.container.classList;classList.add(className);setTimeout(()=>{classList.remove(className)},1e3)}ready(){super.ready();this.addEventListener("click",ev=>this.buttonTapped(ev))}buttonTapped(ev){if(this.progress)ev.stopPropagation()}actionSuccess(){this.tempClass("success")}actionError(){this.tempClass("error")}computeDisabled(disabled,progress){return disabled||progress}}customElements.define("ha-progress-button",HaProgressButton)},200:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_app_layout_app_header_layout_app_header_layout__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(178),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(10);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/class HaAppLayout extends customElements.get("app-header-layout"){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style>
        :host {
          display: block;
          /**
         * Force app-header-layout to have its own stacking context so that its parent can
         * control the stacking of it relative to other elements (e.g. app-drawer-layout).
         * This could be done using \`isolation: isolate\`, but that's not well supported
         * across browsers.
         */
          position: relative;
          z-index: 0;
        }

        #wrapper ::slotted([slot="header"]) {
          @apply --layout-fixed-top;
          z-index: 1;
        }

        #wrapper.initializing ::slotted([slot="header"]) {
          position: relative;
        }

        :host([has-scrolling-region]) {
          height: 100%;
        }

        :host([has-scrolling-region]) #wrapper ::slotted([slot="header"]) {
          position: absolute;
        }

        :host([has-scrolling-region])
          #wrapper.initializing
          ::slotted([slot="header"]) {
          position: relative;
        }

        :host([has-scrolling-region]) #wrapper #contentContainer {
          @apply --layout-fit;
          overflow-y: auto;
          -webkit-overflow-scrolling: touch;
        }

        :host([has-scrolling-region]) #wrapper.initializing #contentContainer {
          position: relative;
        }

        #contentContainer {
          /* Create a stacking context here so that all children appear below the header. */
          position: relative;
          z-index: 0;
          /* Using 'transform' will cause 'position: fixed' elements to behave like
           'position: absolute' relative to this element. */
          transform: translate(0);
        }

        @media print {
          :host([has-scrolling-region]) #wrapper #contentContainer {
            overflow-y: visible;
          }
        }
      </style>

      <div id="wrapper" class="initializing">
        <slot id="headerSlot" name="header"></slot>

        <div id="contentContainer"><slot></slot></div>
        <slot id="fab" name="fab"></slot>
      </div>
    `}}customElements.define("ha-app-layout",HaAppLayout)},201:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(10),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(48);let loaded=null;const svgWhiteList=["svg","path"];class HaMarkdown extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_1__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_0__.a){static get properties(){return{content:{type:String,observer:"_render"},allowSvg:{type:Boolean,value:!1}}}connectedCallback(){super.connectedCallback();this._scriptLoaded=0;this._renderScheduled=!1;this._resize=()=>this.fire("iron-resize");if(!loaded){loaded=Promise.all([__webpack_require__.e(99),__webpack_require__.e(63)]).then(__webpack_require__.bind(null,252))}loaded.then(({marked,filterXSS})=>{this.marked=marked;this.filterXSS=filterXSS;this._scriptLoaded=1},()=>{this._scriptLoaded=2}).then(()=>this._render())}_render(){if(0===this._scriptLoaded||this._renderScheduled)return;this._renderScheduled=!0;Promise.resolve().then(()=>{this._renderScheduled=!1;if(1===this._scriptLoaded){this.innerHTML=this.filterXSS(this.marked(this.content,{gfm:!0,tables:!0,breaks:!0}),{onIgnoreTag:this.allowSvg?(tag,html)=>0<=svgWhiteList.indexOf(tag)?html:null:null});this._resize();const walker=document.createTreeWalker(this,1,null,!1);while(walker.nextNode()){const node=walker.currentNode;if("A"===node.tagName&&node.host!==document.location.host){node.target="_blank"}else if("IMG"===node.tagName){node.addEventListener("load",this._resize)}}}else if(2===this._scriptLoaded){this.innerText=this.content}})}}customElements.define("ha-markdown",HaMarkdown)},202:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(99),_polymer_paper_toggle_button_paper_toggle_button__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(187),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(10),_common_const__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(80),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(153);class HaEntityToggle extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__.a`
      <style>
        :host {
          white-space: nowrap;
          min-width: 38px;
        }
        paper-icon-button {
          color: var(
            --paper-icon-button-inactive-color,
            var(--primary-text-color)
          );
          transition: color 0.5s;
        }
        paper-icon-button[state-active] {
          color: var(--paper-icon-button-active-color, var(--primary-color));
        }
        paper-toggle-button {
          cursor: pointer;
          --paper-toggle-button-label-spacing: 0;
          padding: 13px 5px;
          margin: -4px -5px;
        }
      </style>

      <template is="dom-if" if="[[stateObj.attributes.assumed_state]]">
        <paper-icon-button
          icon="hass:flash-off"
          on-click="turnOff"
          state-active$="[[!isOn]]"
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:flash"
          on-click="turnOn"
          state-active$="[[isOn]]"
        ></paper-icon-button>
      </template>
      <template is="dom-if" if="[[!stateObj.attributes.assumed_state]]">
        <paper-toggle-button
          checked="[[toggleChecked]]"
          on-change="toggleChanged"
        ></paper-toggle-button>
      </template>
    `}static get properties(){return{hass:Object,stateObj:{type:Object,observer:"stateObjObserver"},toggleChecked:{type:Boolean,value:!1},isOn:{type:Boolean,computed:"computeIsOn(stateObj)",observer:"isOnChanged"}}}ready(){super.ready();this.addEventListener("click",ev=>this.onTap(ev));this.forceStateChange()}onTap(ev){ev.stopPropagation()}toggleChanged(ev){const newVal=ev.target.checked;if(newVal&&!this.isOn){this.callService(!0)}else if(!newVal&&this.isOn){this.callService(!1)}}isOnChanged(newVal){this.toggleChecked=newVal}forceStateChange(){if(this.toggleChecked===this.isOn){this.toggleChecked=!this.toggleChecked}this.toggleChecked=this.isOn}turnOn(){this.callService(!0)}turnOff(){this.callService(!1)}computeIsOn(stateObj){return stateObj&&!_common_const__WEBPACK_IMPORTED_MODULE_4__.i.includes(stateObj.state)}stateObjObserver(newVal,oldVal){if(!oldVal||!newVal)return;if(this.computeIsOn(newVal)===this.computeIsOn(oldVal)){this.forceStateChange()}}callService(turnOn){const stateDomain=Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_5__.a)(this.stateObj);let serviceDomain,service;if("lock"===stateDomain){serviceDomain="lock";service=turnOn?"unlock":"lock"}else if("cover"===stateDomain){serviceDomain="cover";service=turnOn?"open_cover":"close_cover"}else if("group"===stateDomain){serviceDomain="homeassistant";service=turnOn?"turn_on":"turn_off"}else{serviceDomain=stateDomain;service=turnOn?"turn_on":"turn_off"}const currentState=this.stateObj;this.hass.callService(serviceDomain,service,{entity_id:this.stateObj.entity_id}).then(()=>{setTimeout(()=>{if(this.stateObj===currentState){this.forceStateChange()}},2e3)})}}customElements.define("ha-entity-toggle",HaEntityToggle)},203:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"c",function(){return fetchRecent});__webpack_require__.d(__webpack_exports__,"b",function(){return fetchDate});__webpack_require__.d(__webpack_exports__,"a",function(){return computeHistory});var _common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(105),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(153),_common_entity_compute_state_display__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(190);const DOMAINS_USE_LAST_UPDATED=["climate","water_heater"],LINE_ATTRIBUTES_TO_KEEP=["temperature","current_temperature","target_temp_low","target_temp_high"],fetchRecent=(hass,entityId,startTime,endTime,skipInitialState=!1)=>{let url="history/period";if(startTime){url+="/"+startTime.toISOString()}url+="?filter_entity_id="+entityId;if(endTime){url+="&end_time="+endTime.toISOString()}if(skipInitialState){url+="&skip_initial_state"}return hass.callApi("GET",url)},fetchDate=(hass,startTime,endTime)=>{return hass.callApi("GET",`history/period/${startTime.toISOString()}?end_time=${endTime.toISOString()}`)},equalState=(obj1,obj2)=>obj1.state===obj2.state&&(!obj1.attributes||LINE_ATTRIBUTES_TO_KEEP.every(attr=>obj1.attributes[attr]===obj2.attributes[attr])),processTimelineEntity=(localize,language,states)=>{const data=[];for(const state of states){if(0<data.length&&state.state===data[data.length-1].state){continue}data.push({state_localize:Object(_common_entity_compute_state_display__WEBPACK_IMPORTED_MODULE_2__.a)(localize,state,language),state:state.state,last_changed:state.last_changed})}return{name:Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__.a)(states[0]),entity_id:states[0].entity_id,data}},processLineChartEntities=(unit,entities)=>{const data=[];for(const states of entities){const last=states[states.length-1],domain=Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(last),processedStates=[];for(const state of states){let processedState;if(DOMAINS_USE_LAST_UPDATED.includes(domain)){processedState={state:state.state,last_changed:state.last_updated,attributes:{}};for(const attr of LINE_ATTRIBUTES_TO_KEEP){if(attr in state.attributes){processedState.attributes[attr]=state.attributes[attr]}}}else{processedState=state}if(1<processedStates.length&&equalState(processedState,processedStates[processedStates.length-1])&&equalState(processedState,processedStates[processedStates.length-2])){continue}processedStates.push(processedState)}data.push({domain,name:Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_0__.a)(last),entity_id:last.entity_id,states:processedStates})}return{unit,identifier:entities.map(states=>states[0].entity_id).join(""),data}},computeHistory=(hass,stateHistory,localize,language)=>{const lineChartDevices={},timelineDevices=[];if(!stateHistory){return{line:[],timeline:[]}}stateHistory.forEach(stateInfo=>{if(0===stateInfo.length){return}const stateWithUnit=stateInfo.find(state=>"unit_of_measurement"in state.attributes);let unit;if(stateWithUnit){unit=stateWithUnit.attributes.unit_of_measurement}else if("climate"===Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(stateInfo[0])){unit=hass.config.unit_system.temperature}else if("water_heater"===Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_1__.a)(stateInfo[0])){unit=hass.config.unit_system.temperature}if(!unit){timelineDevices.push(processTimelineEntity(localize,language,stateInfo))}else if(unit in lineChartDevices){lineChartDevices[unit].push(stateInfo)}else{lineChartDevices[unit]=[stateInfo]}});const unitStates=Object.keys(lineChartDevices).map(unit=>processLineChartEntities(unit,lineChartDevices[unit]));return{line:unitStates,timeline:timelineDevices}}},206:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_ha_progress_button__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(199),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(48);class HaCallServiceButton extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_3__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <ha-progress-button
        id="progress"
        progress="[[progress]]"
        on-click="buttonTapped"
        ><slot></slot
      ></ha-progress-button>
    `}static get properties(){return{hass:{type:Object},progress:{type:Boolean,value:!1},domain:{type:String},service:{type:String},serviceData:{type:Object,value:{}}}}buttonTapped(){this.progress=!0;var el=this,eventData={domain:this.domain,service:this.service,serviceData:this.serviceData};this.hass.callService(this.domain,this.service,this.serviceData).then(function(){el.progress=!1;el.$.progress.actionSuccess();eventData.success=!0},function(){el.progress=!1;el.$.progress.actionError();eventData.success=!1}).then(function(){el.fire("hass-service-called",eventData)})}}customElements.define("ha-call-service-button",HaCallServiceButton)},208:function(module,__webpack_exports__,__webpack_require__){"use strict";var fecha__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(170);__webpack_exports__.a=function(){try{new Date().toLocaleDateString("i")}catch(e){return"RangeError"===e.name}return!1}()?(dateObj,locales)=>dateObj.toLocaleDateString(locales,{year:"numeric",month:"long",day:"numeric"}):dateObj=>fecha__WEBPACK_IMPORTED_MODULE_0__.a.format(dateObj,"mediumDate")},213:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_flex_layout_iron_flex_layout_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(33),_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(23),_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(18),_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(40),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(0),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_5__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_7__.a`
    <style>
      :host {
        @apply --layout-inline;
        @apply --layout-center;
        @apply --layout-center-justified;
        @apply --layout-flex-auto;

        position: relative;
        padding: 0 12px;
        overflow: hidden;
        cursor: pointer;
        vertical-align: middle;

        @apply --paper-font-common-base;
        @apply --paper-tab;
      }

      :host(:focus) {
        outline: none;
      }

      :host([link]) {
        padding: 0;
      }

      .tab-content {
        height: 100%;
        transform: translateZ(0);
          -webkit-transform: translateZ(0);
        transition: opacity 0.1s cubic-bezier(0.4, 0.0, 1, 1);
        @apply --layout-horizontal;
        @apply --layout-center-center;
        @apply --layout-flex-auto;
        @apply --paper-tab-content;
      }

      :host(:not(.iron-selected)) > .tab-content {
        opacity: 0.8;

        @apply --paper-tab-content-unselected;
      }

      :host(:focus) .tab-content {
        opacity: 1;
        font-weight: 700;
      }

      paper-ripple {
        color: var(--paper-tab-ink, var(--paper-yellow-a100));
      }

      .tab-content > ::slotted(a) {
        @apply --layout-flex-auto;

        height: 100%;
      }
    </style>

    <div class="tab-content">
      <slot></slot>
    </div>
`,is:"paper-tab",behaviors:[_polymer_iron_behaviors_iron_control_state_js__WEBPACK_IMPORTED_MODULE_3__.a,_polymer_iron_behaviors_iron_button_state_js__WEBPACK_IMPORTED_MODULE_2__.a,_polymer_paper_behaviors_paper_ripple_behavior_js__WEBPACK_IMPORTED_MODULE_4__.a],properties:{link:{type:Boolean,value:!1,reflectToAttribute:!0}},hostAttributes:{role:"tab"},listeners:{down:"_updateNoink",tap:"_onTap"},attached:function(){this._updateNoink()},get _parentNoink(){var parent=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_6__.b)(this).parentNode;return!!parent&&!!parent.noink},_updateNoink:function(){this.noink=!!this.noink||!!this._parentNoink},_onTap:function(event){if(this.link){var anchor=this.queryEffectiveChildren("a");if(!anchor){return}if(event.target===anchor){return}anchor.click()}}})},215:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"b",function(){return IronMenubarBehaviorImpl});__webpack_require__.d(__webpack_exports__,"a",function(){return IronMenubarBehavior});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_iron_menu_behavior_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(110);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronMenubarBehaviorImpl={hostAttributes:{role:"menubar"},keyBindings:{left:"_onLeftKey",right:"_onRightKey"},_onUpKey:function(event){this.focusedItem.click();event.detail.keyboardEvent.preventDefault()},_onDownKey:function(event){this.focusedItem.click();event.detail.keyboardEvent.preventDefault()},get _isRTL(){return"rtl"===window.getComputedStyle(this).direction},_onLeftKey:function(event){if(this._isRTL){this._focusNext()}else{this._focusPrevious()}event.detail.keyboardEvent.preventDefault()},_onRightKey:function(event){if(this._isRTL){this._focusPrevious()}else{this._focusNext()}event.detail.keyboardEvent.preventDefault()},_onKeydown:function(event){if(this.keyboardEventMatchesKeys(event,"up down left right esc")){return}this._focusWithKeyboardEvent(event)}},IronMenubarBehavior=[_iron_menu_behavior_js__WEBPACK_IMPORTED_MODULE_1__.a,IronMenubarBehaviorImpl]},216:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_legacy_polymer_dom__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(0),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_common_datetime_relative_time__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(231),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(71);class HaRelativeTime extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_3__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get properties(){return{hass:Object,datetime:{type:String,observer:"datetimeChanged"},datetimeObj:{type:Object,observer:"datetimeObjChanged"},parsedDateTime:Object}}constructor(){super();this.updateRelative=this.updateRelative.bind(this)}connectedCallback(){super.connectedCallback();this.updateInterval=setInterval(this.updateRelative,6e4)}disconnectedCallback(){super.disconnectedCallback();clearInterval(this.updateInterval)}datetimeChanged(newVal){this.parsedDateTime=newVal?new Date(newVal):null;this.updateRelative()}datetimeObjChanged(newVal){this.parsedDateTime=newVal;this.updateRelative()}updateRelative(){const root=Object(_polymer_polymer_lib_legacy_polymer_dom__WEBPACK_IMPORTED_MODULE_0__.b)(this);if(!this.parsedDateTime){root.innerHTML=this.localize("ui.components.relative_time.never")}else{root.innerHTML=Object(_common_datetime_relative_time__WEBPACK_IMPORTED_MODULE_2__.a)(this.parsedDateTime,this.localize)}}}customElements.define("ha-relative-time",HaRelativeTime)},219:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathfloor=Math.floor;__webpack_require__.d(__webpack_exports__,"a",function(){return secondsToDuration});const leftPad=num=>10>num?`0${num}`:num;function secondsToDuration(d){const h=_Mathfloor(d/3600),m=_Mathfloor(d%3600/60),s=_Mathfloor(d%3600%60);if(0<h){return`${h}:${leftPad(m)}:${leftPad(s)}`}if(0<m){return`${m}:${leftPad(s)}`}if(0<s){return""+s}return null}},220:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return MediaPlayerEntity});var _common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(193);class MediaPlayerEntity{constructor(hass,stateObj){this.hass=hass;this.stateObj=stateObj;this._attr=stateObj.attributes;this._feat=this._attr.supported_features}get isOff(){return"off"===this.stateObj.state}get isIdle(){return"idle"===this.stateObj.state}get isMuted(){return this._attr.is_volume_muted}get isPaused(){return"paused"===this.stateObj.state}get isPlaying(){return"playing"===this.stateObj.state}get isMusic(){return"music"===this._attr.media_content_type}get isTVShow(){return"tvshow"===this._attr.media_content_type}get hasMediaControl(){return-1!==["playing","paused","unknown"].indexOf(this.stateObj.state)}get volumeSliderValue(){return 100*this._attr.volume_level}get showProgress(){return(this.isPlaying||this.isPaused)&&"media_duration"in this.stateObj.attributes&&"media_position"in this.stateObj.attributes&&"media_position_updated_at"in this.stateObj.attributes}get currentProgress(){var progress=this._attr.media_position;if(this.isPlaying){progress+=(Date.now()-new Date(this._attr.media_position_updated_at).getTime())/1e3}return progress}get supportsPause(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1)}get supportsVolumeSet(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,4)}get supportsVolumeMute(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,8)}get supportsPreviousTrack(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16)}get supportsNextTrack(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,32)}get supportsTurnOn(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,128)}get supportsTurnOff(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,256)}get supportsPlayMedia(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,512)}get supportsVolumeButtons(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,1024)}get supportsSelectSource(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,2048)}get supportsSelectSoundMode(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,65536)}get supportsPlay(){return Object(_common_entity_supports_feature__WEBPACK_IMPORTED_MODULE_0__.a)(this.stateObj,16384)}get primaryTitle(){return this._attr.media_title}get secondaryTitle(){if(this.isMusic){return this._attr.media_artist}if(this.isTVShow){var text=this._attr.media_series_title;if(this._attr.media_season){text+=" S"+this._attr.media_season;if(this._attr.media_episode){text+="E"+this._attr.media_episode}}return text}if(this._attr.app_name){return this._attr.app_name}return""}get source(){return this._attr.source}get sourceList(){return this._attr.source_list}get soundMode(){return this._attr.sound_mode}get soundModeList(){return this._attr.sound_mode_list}mediaPlayPause(){this.callService("media_play_pause")}nextTrack(){this.callService("media_next_track")}playbackControl(){this.callService("media_play_pause")}previousTrack(){this.callService("media_previous_track")}setVolume(volume){this.callService("volume_set",{volume_level:volume})}togglePower(){if(this.isOff){this.turnOn()}else{this.turnOff()}}turnOff(){this.callService("turn_off")}turnOn(){this.callService("turn_on")}volumeDown(){this.callService("volume_down")}volumeMute(mute){if(!this.supportsVolumeMute){throw new Error("Muting volume not supported")}this.callService("volume_mute",{is_volume_muted:mute})}volumeUp(){this.callService("volume_up")}selectSource(source){this.callService("select_source",{source})}selectSoundMode(soundMode){this.callService("select_sound_mode",{sound_mode:soundMode})}callService(service,data={}){data.entity_id=this.stateObj.entity_id;this.hass.callService("media_player",service,data)}}},225:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathmax=Math.max,paper_spinner=__webpack_require__(111),html_tag=__webpack_require__(1),polymer_element=__webpack_require__(10),debounce=__webpack_require__(14),iron_resizable_behavior=__webpack_require__(84),paper_icon_button=__webpack_require__(99),utils_async=__webpack_require__(8),legacy_class=__webpack_require__(62),format_time=__webpack_require__(188);let scriptsLoaded=null;class ha_chart_base_HaChartBase extends Object(legacy_class.b)([iron_resizable_behavior.a],polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
        }
        .chartHeader {
          padding: 6px 0 0 0;
          width: 100%;
          display: flex;
          flex-direction: row;
        }
        .chartHeader > div {
          vertical-align: top;
          padding: 0 8px;
        }
        .chartHeader > div.chartTitle {
          padding-top: 8px;
          flex: 0 0 0;
          max-width: 30%;
        }
        .chartHeader > div.chartLegend {
          flex: 1 1;
          min-width: 70%;
        }
        :root {
          user-select: none;
          -moz-user-select: none;
          -webkit-user-select: none;
          -ms-user-select: none;
        }
        .chartTooltip {
          font-size: 90%;
          opacity: 1;
          position: absolute;
          background: rgba(80, 80, 80, 0.9);
          color: white;
          border-radius: 3px;
          pointer-events: none;
          transform: translate(-50%, 12px);
          z-index: 1000;
          width: 200px;
          transition: opacity 0.15s ease-in-out;
        }
        .chartLegend ul,
        .chartTooltip ul {
          display: inline-block;
          padding: 0 0px;
          margin: 5px 0 0 0;
          width: 100%;
        }
        .chartTooltip li {
          display: block;
          white-space: pre-line;
        }
        .chartTooltip .title {
          text-align: center;
          font-weight: 500;
        }
        .chartLegend li {
          display: inline-block;
          padding: 0 6px;
          max-width: 49%;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          box-sizing: border-box;
        }
        .chartLegend li:nth-child(odd):last-of-type {
          /* Make last item take full width if it is odd-numbered. */
          max-width: 100%;
        }
        .chartLegend li[data-hidden] {
          text-decoration: line-through;
        }
        .chartLegend em,
        .chartTooltip em {
          border-radius: 5px;
          display: inline-block;
          height: 10px;
          margin-right: 4px;
          width: 10px;
        }
        paper-icon-button {
          color: var(--secondary-text-color);
        }
      </style>
      <template is="dom-if" if="[[unit]]">
        <div class="chartHeader">
          <div class="chartTitle">[[unit]]</div>
          <div class="chartLegend">
            <ul>
              <template is="dom-repeat" items="[[metas]]">
                <li on-click="_legendClick" data-hidden$="[[item.hidden]]">
                  <em style$="background-color:[[item.bgColor]]"></em>
                  [[item.label]]
                </li>
              </template>
            </ul>
          </div>
        </div>
      </template>
      <div id="chartTarget" style="height:40px; width:100%">
        <canvas id="chartCanvas"></canvas>
        <div
          class$="chartTooltip [[tooltip.yAlign]]"
          style$="opacity:[[tooltip.opacity]]; top:[[tooltip.top]]; left:[[tooltip.left]]; padding:[[tooltip.yPadding]]px [[tooltip.xPadding]]px"
        >
          <div class="title">[[tooltip.title]]</div>
          <div>
            <ul>
              <template is="dom-repeat" items="[[tooltip.lines]]">
                <li>
                  <em style$="background-color:[[item.bgColor]]"></em
                  >[[item.text]]
                </li>
              </template>
            </ul>
          </div>
        </div>
      </div>
    `}get chart(){return this._chart}static get properties(){return{data:Object,identifier:String,rendered:{type:Boolean,notify:!0,value:!1,readOnly:!0},metas:{type:Array,value:()=>[]},tooltip:{type:Object,value:()=>({opacity:"0",left:"0",top:"0",xPadding:"5",yPadding:"3"})},unit:Object}}static get observers(){return["onPropsChange(data)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.onPropsChange();this._resizeListener=()=>{this._debouncer=debounce.a.debounce(this._debouncer,utils_async.d.after(10),()=>{if(this._isAttached){this.resizeChart()}})};if("function"===typeof ResizeObserver){this.resizeObserver=new ResizeObserver(entries=>{entries.forEach(()=>{this._resizeListener()})});this.resizeObserver.observe(this.$.chartTarget)}else{this.addEventListener("iron-resize",this._resizeListener)}if(null===scriptsLoaded){scriptsLoaded=Promise.all([__webpack_require__.e(95),__webpack_require__.e(69)]).then(__webpack_require__.bind(null,735))}scriptsLoaded.then(ChartModule=>{this.ChartClass=ChartModule.default;this.onPropsChange()})}disconnectedCallback(){super.disconnectedCallback();this._isAttached=!1;if(this.resizeObserver){this.resizeObserver.unobserve(this.$.chartTarget)}this.removeEventListener("iron-resize",this._resizeListener);if(this._resizeTimer!==void 0){clearInterval(this._resizeTimer);this._resizeTimer=void 0}}onPropsChange(){if(!this._isAttached||!this.ChartClass||!this.data){return}this.drawChart()}_customTooltips(tooltip){if(0===tooltip.opacity){this.set(["tooltip","opacity"],0);return}if(tooltip.yAlign){this.set(["tooltip","yAlign"],tooltip.yAlign)}else{this.set(["tooltip","yAlign"],"no-transform")}const title=tooltip.title?tooltip.title[0]||"":"";this.set(["tooltip","title"],title);const bodyLines=tooltip.body.map(n=>n.lines);if(tooltip.body){this.set(["tooltip","lines"],bodyLines.map((body,i)=>{const colors=tooltip.labelColors[i];return{color:colors.borderColor,bgColor:colors.backgroundColor,text:body.join("\n")}}))}const parentWidth=this.$.chartTarget.clientWidth;let positionX=tooltip.caretX;const positionY=this._chart.canvas.offsetTop+tooltip.caretY;if(tooltip.caretX+100>parentWidth){positionX=parentWidth-100}else if(100>tooltip.caretX){positionX=100}positionX+=this._chart.canvas.offsetLeft;this.tooltip=Object.assign({},this.tooltip,{opacity:1,left:`${positionX}px`,top:`${positionY}px`})}_legendClick(event){event=event||window.event;event.stopPropagation();let target=event.target||event.srcElement;while("LI"!==target.nodeName){target=target.parentElement}const index=event.model.itemsIndex,meta=this._chart.getDatasetMeta(index);meta.hidden=null===meta.hidden?!this._chart.data.datasets[index].hidden:null;this.set(["metas",index,"hidden"],this._chart.isDatasetVisible(index)?null:"hidden");this._chart.update()}_drawLegend(){const chart=this._chart,preserveVisibility=this._oldIdentifier&&this.identifier===this._oldIdentifier;this._oldIdentifier=this.identifier;this.set("metas",this._chart.data.datasets.map((x,i)=>({label:x.label,color:x.color,bgColor:x.backgroundColor,hidden:preserveVisibility&&i<this.metas.length?this.metas[i].hidden:!chart.isDatasetVisible(i)})));let updateNeeded=!1;if(preserveVisibility){for(let i=0;i<this.metas.length;i++){const meta=chart.getDatasetMeta(i);if(!!meta.hidden!==!!this.metas[i].hidden)updateNeeded=!0;meta.hidden=this.metas[i].hidden?!0:null}}if(updateNeeded){chart.update()}this.unit=this.data.unit}_formatTickValue(value,index,values){if(0===values.length){return value}const date=new Date(values[index].value);return Object(format_time.a)(date)}drawChart(){const data=this.data.data,ctx=this.$.chartCanvas;if((!data.datasets||!data.datasets.length)&&!this._chart){return}if("timeline"!==this.data.type&&0<data.datasets.length){const cnt=data.datasets.length,colors=this.constructor.getColorList(cnt);for(let loopI=0;loopI<cnt;loopI++){data.datasets[loopI].borderColor=colors[loopI].rgbString();data.datasets[loopI].backgroundColor=colors[loopI].alpha(.6).rgbaString()}}if(this._chart){this._customTooltips({opacity:0});this._chart.data=data;this._chart.update({duration:0});if(this.isTimeline){this._chart.options.scales.yAxes[0].gridLines.display=1<data.length}else if(!0===this.data.legend){this._drawLegend()}this.resizeChart()}else{if(!data.datasets){return}this._customTooltips({opacity:0});let options={responsive:!0,maintainAspectRatio:!1,animation:{duration:0},hover:{animationDuration:0},responsiveAnimationDuration:0,tooltips:{enabled:!1,custom:this._customTooltips.bind(this)},legend:{display:!1},line:{spanGaps:!0},elements:{font:"12px 'Roboto', 'sans-serif'"},ticks:{fontFamily:"'Roboto', 'sans-serif'"}};options=Chart.helpers.merge(options,this.data.options);options.scales.xAxes[0].ticks.callback=this._formatTickValue;if("timeline"===this.data.type){this.set("isTimeline",!0);if(this.data.colors!==void 0){this._colorFunc=this.constructor.getColorGenerator(this.data.colors.staticColors,this.data.colors.staticColorIndex)}if(this._colorFunc!==void 0){options.elements.colorFunction=this._colorFunc}if(1===data.datasets.length){if(options.scales.yAxes[0].ticks){options.scales.yAxes[0].ticks.display=!1}else{options.scales.yAxes[0].ticks={display:!1}}if(options.scales.yAxes[0].gridLines){options.scales.yAxes[0].gridLines.display=!1}else{options.scales.yAxes[0].gridLines={display:!1}}}this.$.chartTarget.style.height="50px"}else{this.$.chartTarget.style.height="160px"}const chartData={type:this.data.type,data:this.data.data,options:options,plugins:[{afterRender:()=>this._setRendered(!0)}]};this._chart=new this.ChartClass(ctx,chartData);if(!0!==this.isTimeline&&!0===this.data.legend){this._drawLegend()}this.resizeChart()}}resizeChart(){if(!this._chart)return;if(this._resizeTimer===void 0){this._resizeTimer=setInterval(this.resizeChart.bind(this),10);return}clearInterval(this._resizeTimer);this._resizeTimer=void 0;this._resizeChart()}_resizeChart(){const chartTarget=this.$.chartTarget,options=this.data,data=options.data;if(0===data.datasets.length){return}if(!this.isTimeline){this._chart.resize();return}const areaTop=this._chart.chartArea.top,areaBot=this._chart.chartArea.bottom,height1=this._chart.canvas.clientHeight;if(0<areaBot){this._axisHeight=height1-areaBot+areaTop}if(!this._axisHeight){chartTarget.style.height="50px";this._chart.resize();this.resizeChart();return}if(this._axisHeight){const cnt=data.datasets.length,targetHeight=30*cnt+this._axisHeight+"px";if(chartTarget.style.height!==targetHeight){chartTarget.style.height=targetHeight}this._chart.resize()}}static getColorList(count){let processL=!1;if(10<count){processL=!0;count=Math.ceil(count/2)}const h1=360/count,result=[];for(let loopI=0;loopI<count;loopI++){result[loopI]=Color().hsl(h1*loopI,80,38);if(processL){result[loopI+count]=Color().hsl(h1*loopI,80,62)}}return result}static getColorGenerator(staticColors,startIndex){const palette=["ff0029","66a61e","377eb8","984ea3","00d2d5","ff7f00","af8d00","7f80cd","b3e900","c42e60","a65628","f781bf","8dd3c7","bebada","fb8072","80b1d3","fdb462","fccde5","bc80bd","ffed6f","c4eaff","cf8c00","1b9e77","d95f02","e7298a","e6ab02","a6761d","0097ff","00d067","f43600","4ba93b","5779bb","927acc","97ee3f","bf3947","9f5b00","f48758","8caed6","f2b94f","eff26e","e43872","d9b100","9d7a00","698cff","d9d9d9","00d27e","d06800","009f82","c49200","cbe8ff","fecddf","c27eb6","8cd2ce","c4b8d9","f883b0","a49100","f48800","27d0df","a04a9b"];function getColorIndex(idx){return Color("#"+palette[idx%palette.length])}const colorDict={};let colorIndex=0;if(0<startIndex)colorIndex=startIndex;if(staticColors){Object.keys(staticColors).forEach(c=>{const c1=staticColors[c];if(isFinite(c1)){colorDict[c.toLowerCase()]=getColorIndex(c1)}else{colorDict[c.toLowerCase()]=Color(staticColors[c])}})}function getColor(__,data){let ret;const name=data[3];if(null===name)return Color().hsl(0,40,38);if(name===void 0)return Color().hsl(120,40,38);const name1=name.toLowerCase();if(ret===void 0){ret=colorDict[name1]}if(ret===void 0){ret=getColorIndex(colorIndex);colorIndex++;colorDict[name1]=ret}return ret}return getColor}}customElements.define("ha-chart-base",ha_chart_base_HaChartBase);var localize_mixin=__webpack_require__(71),format_date_time=__webpack_require__(173);class state_history_chart_line_StateHistoryChartLine extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          overflow: hidden;
          height: 0;
          transition: height 0.3s ease-in-out;
        }
      </style>
      <ha-chart-base
        id="chart"
        data="[[chartData]]"
        identifier="[[identifier]]"
        rendered="{{rendered}}"
      ></ha-chart-base>
    `}static get properties(){return{chartData:Object,data:Object,names:Object,unit:String,identifier:String,isSingleDevice:{type:Boolean,value:!1},endTime:Object,rendered:{type:Boolean,value:!1,observer:"_onRenderedChanged"}}}static get observers(){return["dataChanged(data, endTime, isSingleDevice)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.drawChart()}dataChanged(){this.drawChart()}_onRenderedChanged(rendered){if(rendered)this.animateHeight()}animateHeight(){requestAnimationFrame(()=>requestAnimationFrame(()=>{this.style.height=this.$.chart.scrollHeight+"px"}))}drawChart(){const unit=this.unit,deviceStates=this.data,datasets=[];let endTime;if(!this._isAttached){return}if(0===deviceStates.length){return}function safeParseFloat(value){const parsed=parseFloat(value);return isFinite(parsed)?parsed:null}endTime=this.endTime||new Date(_Mathmax.apply(null,deviceStates.map(devSts=>new Date(devSts.states[devSts.states.length-1].last_changed))));if(endTime>new Date){endTime=new Date}const names=this.names||{};deviceStates.forEach(states=>{const domain=states.domain,name=names[states.entity_id]||states.name;let prevValues;const data=[];function pushData(timestamp,datavalues){if(!datavalues)return;if(timestamp>endTime){return}data.forEach((d,i)=>{d.data.push({x:timestamp,y:datavalues[i]})});prevValues=datavalues}function addColumn(nameY,step,fill){let dataFill=!1,dataStep=!1;if(fill){dataFill="origin"}if(step){dataStep="before"}data.push({label:nameY,fill:dataFill,steppedLine:dataStep,pointRadius:0,data:[],unitText:unit})}if("thermostat"===domain||"climate"===domain||"water_heater"===domain){const hasTargetRange=states.states.some(state=>state.attributes&&state.attributes.target_temp_high!==state.attributes.target_temp_low),hasHeat=states.states.some(state=>"heat"===state.state),hasCool=states.states.some(state=>"cool"===state.state);addColumn(name+" current temperature",!0);if(hasHeat){addColumn(name+" heating",!0,!0)}if(hasCool){addColumn(name+" cooling",!0,!0)}if(hasTargetRange){addColumn(name+" target temperature high",!0);addColumn(name+" target temperature low",!0)}else{addColumn(name+" target temperature",!0)}states.states.forEach(state=>{if(!state.attributes)return;const curTemp=safeParseFloat(state.attributes.current_temperature),series=[curTemp];if(hasHeat){series.push("heat"===state.state?curTemp:null)}if(hasCool){series.push("cool"===state.state?curTemp:null)}if(hasTargetRange){const targetHigh=safeParseFloat(state.attributes.target_temp_high),targetLow=safeParseFloat(state.attributes.target_temp_low);series.push(targetHigh,targetLow);pushData(new Date(state.last_changed),series)}else{const target=safeParseFloat(state.attributes.temperature);series.push(target);pushData(new Date(state.last_changed),series)}})}else{addColumn(name,"sensor"===domain);let lastValue=null,lastDate=null,lastNullDate=null;states.states.forEach(state=>{const value=safeParseFloat(state.state),date=new Date(state.last_changed);if(null!==value&&null!==lastNullDate){const dateTime=date.getTime(),lastNullDateTime=lastNullDate.getTime(),lastDateTime=lastDate.getTime(),tmpValue=(value-lastValue)*((lastNullDateTime-lastDateTime)/(dateTime-lastDateTime))+lastValue;pushData(lastNullDate,[tmpValue]);pushData(new Date(lastNullDateTime+1),[null]);pushData(date,[value]);lastDate=date;lastValue=value;lastNullDate=null}else if(null!==value&&null===lastNullDate){pushData(date,[value]);lastDate=date;lastValue=value}else if(null===value&&null===lastNullDate&&null!==lastValue){lastNullDate=date}})}pushData(endTime,prevValues,!1);Array.prototype.push.apply(datasets,data)});const chartOptions={type:"line",unit:unit,legend:!this.isSingleDevice,options:{scales:{xAxes:[{type:"time",ticks:{major:{fontStyle:"bold"}}}],yAxes:[{ticks:{maxTicksLimit:7}}]},tooltips:{mode:"neareach",callbacks:{title:(items,data)=>{const item=items[0],date=data.datasets[item.datasetIndex].data[item.index].x;return Object(format_date_time.a)(date,this.hass.language)}}},hover:{mode:"neareach"},layout:{padding:{top:5}},elements:{line:{tension:.1,pointRadius:0,borderWidth:1.5},point:{hitRadius:5}},plugins:{filler:{propagate:!0}}},data:{labels:[],datasets:datasets}};this.chartData=chartOptions}}customElements.define("state-history-chart-line",state_history_chart_line_StateHistoryChartLine);class state_history_chart_timeline_StateHistoryChartTimeline extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          opacity: 0;
          transition: opacity 0.3s ease-in-out;
        }
        :host([rendered]) {
          opacity: 1;
        }
      </style>
      <ha-chart-base
        data="[[chartData]]"
        rendered="{{rendered}}"
      ></ha-chart-base>
    `}static get properties(){return{hass:{type:Object},chartData:Object,data:{type:Object,observer:"dataChanged"},names:Object,noSingle:Boolean,endTime:Date,rendered:{type:Boolean,value:!1,reflectToAttribute:!0}}}static get observers(){return["dataChanged(data, endTime, localize, language)"]}connectedCallback(){super.connectedCallback();this._isAttached=!0;this.drawChart()}dataChanged(){this.drawChart()}drawChart(){let stateHistory=this.data;if(!this._isAttached){return}if(!stateHistory){stateHistory=[]}const startTime=new Date(stateHistory.reduce((minTime,stateInfo)=>Math.min(minTime,new Date(stateInfo.data[0].last_changed)),new Date));let endTime=this.endTime||new Date(stateHistory.reduce((maxTime,stateInfo)=>_Mathmax(maxTime,new Date(stateInfo.data[stateInfo.data.length-1].last_changed)),startTime));if(endTime>new Date){endTime=new Date}const labels=[],datasets=[],names=this.names||{};stateHistory.forEach(stateInfo=>{let newLastChanged,prevState=null,locState=null,prevLastChanged=startTime;const entityDisplay=names[stateInfo.entity_id]||stateInfo.name,dataRow=[];stateInfo.data.forEach(state=>{let newState=state.state;const timeStamp=new Date(state.last_changed);if(newState===void 0||""===newState){newState=null}if(timeStamp>endTime){return}if(null!==prevState&&newState!==prevState){newLastChanged=new Date(state.last_changed);dataRow.push([prevLastChanged,newLastChanged,locState,prevState]);prevState=newState;locState=state.state_localize;prevLastChanged=newLastChanged}else if(null===prevState){prevState=newState;locState=state.state_localize;prevLastChanged=new Date(state.last_changed)}});if(null!==prevState){dataRow.push([prevLastChanged,endTime,locState,prevState])}datasets.push({data:dataRow});labels.push(entityDisplay)});this.chartData={type:"timeline",options:{tooltips:{callbacks:{label:(item,data)=>{const values=data.datasets[item.datasetIndex].data[item.index],start=Object(format_date_time.a)(values[0],this.hass.language),end=Object(format_date_time.a)(values[1],this.hass.language),state=values[2];return[state,start,end]}}},scales:{xAxes:[{ticks:{major:{fontStyle:"bold"}}}],yAxes:[{afterSetDimensions:yaxe=>{yaxe.maxWidth=.18*yaxe.chart.width}}]}},data:{labels:labels,datasets:datasets},colors:{staticColors:{on:1,off:0,unavailable:"#a0a0a0",unknown:"#606060",idle:2},staticColorIndex:3}}}}customElements.define("state-history-chart-timeline",state_history_chart_timeline_StateHistoryChartTimeline);class state_history_charts_StateHistoryCharts extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          display: block;
          /* height of single timeline chart = 58px */
          min-height: 58px;
        }
        .info {
          text-align: center;
          line-height: 58px;
          color: var(--secondary-text-color);
        }
      </style>
      <template
        is="dom-if"
        class="info"
        if="[[_computeIsLoading(isLoadingData)]]"
      >
        <div class="info">
          [[localize('ui.components.history_charts.loading_history')]]
        </div>
      </template>

      <template
        is="dom-if"
        class="info"
        if="[[_computeIsEmpty(isLoadingData, historyData)]]"
      >
        <div class="info">
          [[localize('ui.components.history_charts.no_history_found')]]
        </div>
      </template>

      <template is="dom-if" if="[[historyData.timeline.length]]">
        <state-history-chart-timeline
          hass="[[hass]]"
          data="[[historyData.timeline]]"
          end-time="[[_computeEndTime(endTime, upToNow, historyData)]]"
          no-single="[[noSingle]]"
          names="[[names]]"
        ></state-history-chart-timeline>
      </template>

      <template is="dom-repeat" items="[[historyData.line]]">
        <state-history-chart-line
          hass="[[hass]]"
          unit="[[item.unit]]"
          data="[[item.data]]"
          identifier="[[item.identifier]]"
          is-single-device="[[_computeIsSingleLineChart(item.data, noSingle)]]"
          end-time="[[_computeEndTime(endTime, upToNow, historyData)]]"
          names="[[names]]"
        ></state-history-chart-line>
      </template>
    `}static get properties(){return{hass:Object,historyData:{type:Object,value:null},names:Object,isLoadingData:Boolean,endTime:{type:Object},upToNow:Boolean,noSingle:Boolean}}_computeIsSingleLineChart(data,noSingle){return!noSingle&&data&&1===data.length}_computeIsEmpty(isLoadingData,historyData){const historyDataEmpty=!historyData||!historyData.timeline||!historyData.line||0===historyData.timeline.length&&0===historyData.line.length;return!isLoadingData&&historyDataEmpty}_computeIsLoading(isLoading){return isLoading&&!this.historyData}_computeEndTime(endTime,upToNow){return upToNow?new Date:endTime}}customElements.define("state-history-charts",state_history_charts_StateHistoryCharts)},226:function(module,__webpack_exports__,__webpack_require__){"use strict";var utils_async=__webpack_require__(8),debounce=__webpack_require__(14),polymer_element=__webpack_require__(10),localize_mixin=__webpack_require__(71),data_history=__webpack_require__(203);const RECENT_CACHE={},stateHistoryCache={},getRecent=(hass,entityId,startTime,endTime,localize,language)=>{const cacheKey=entityId,cache=RECENT_CACHE[cacheKey];if(cache&&Date.now()-cache.created<6e4&&cache.language===language){return cache.data}const prom=Object(data_history.c)(hass,entityId,startTime,endTime).then(stateHistory=>Object(data_history.a)(hass,stateHistory,localize,language),err=>{delete RECENT_CACHE[entityId];throw err});RECENT_CACHE[cacheKey]={created:Date.now(),language,data:prom};return prom};function getEmptyCache(language,startTime,endTime){return{prom:Promise.resolve({line:[],timeline:[]}),language,startTime,endTime,data:{line:[],timeline:[]}}}const getRecentWithCache=(hass,entityId,cacheConfig,localize,language)=>{const cacheKey=cacheConfig.cacheKey,endTime=new Date,startTime=new Date(endTime);startTime.setHours(startTime.getHours()-cacheConfig.hoursToShow);let toFetchStartTime=startTime,appendingToCache=!1,cache=stateHistoryCache[cacheKey];if(cache&&toFetchStartTime>=cache.startTime&&toFetchStartTime<=cache.endTime&&cache.language===language){toFetchStartTime=cache.endTime;appendingToCache=!0;if(endTime<=cache.endTime){return cache.prom}}else{cache=stateHistoryCache[cacheKey]=getEmptyCache(language,startTime,endTime)}const curCacheProm=cache.prom,genProm=async()=>{let fetchedHistory;try{const results=await Promise.all([curCacheProm,Object(data_history.c)(hass,entityId,toFetchStartTime,endTime,appendingToCache)]);fetchedHistory=results[1]}catch(err){delete stateHistoryCache[cacheKey];throw err}const stateHistory=Object(data_history.a)(hass,fetchedHistory,localize,language);if(appendingToCache){mergeLine(stateHistory.line,cache.data.line);mergeTimeline(stateHistory.timeline,cache.data.timeline);pruneStartTime(startTime,cache.data)}else{cache.data=stateHistory}return cache.data};cache.prom=genProm();cache.startTime=startTime;cache.endTime=endTime;return cache.prom},mergeLine=(historyLines,cacheLines)=>{historyLines.forEach(line=>{const unit=line.unit,oldLine=cacheLines.find(cacheLine=>cacheLine.unit===unit);if(oldLine){line.data.forEach(entity=>{const oldEntity=oldLine.data.find(cacheEntity=>entity.entity_id===cacheEntity.entity_id);if(oldEntity){oldEntity.states=oldEntity.states.concat(entity.states)}else{oldLine.data.push(entity)}})}else{cacheLines.push(line)}})},mergeTimeline=(historyTimelines,cacheTimelines)=>{historyTimelines.forEach(timeline=>{const oldTimeline=cacheTimelines.find(cacheTimeline=>cacheTimeline.entity_id===timeline.entity_id);if(oldTimeline){oldTimeline.data=oldTimeline.data.concat(timeline.data)}else{cacheTimelines.push(timeline)}})},pruneArray=(originalStartTime,arr)=>{if(0===arr.length){return arr}const changedAfterStartTime=arr.findIndex(state=>new Date(state.last_changed)>originalStartTime);if(0===changedAfterStartTime){return arr}const updateIndex=-1===changedAfterStartTime?arr.length-1:changedAfterStartTime-1;arr[updateIndex].last_changed=originalStartTime;return arr.slice(updateIndex)},pruneStartTime=(originalStartTime,cacheData)=>{cacheData.line.forEach(line=>{line.data.forEach(entity=>{entity.states=pruneArray(originalStartTime,entity.states)})});cacheData.timeline.forEach(timeline=>{timeline.data=pruneArray(originalStartTime,timeline.data)})};class ha_state_history_data_HaStateHistoryData extends Object(localize_mixin.a)(polymer_element.a){static get properties(){return{hass:{type:Object,observer:"hassChanged"},filterType:String,cacheConfig:Object,startTime:Date,endTime:Date,entityId:String,isLoading:{type:Boolean,value:!0,readOnly:!0,notify:!0},data:{type:Object,value:null,readOnly:!0,notify:!0}}}static get observers(){return["filterChangedDebouncer(filterType, entityId, startTime, endTime, cacheConfig, localize)"]}connectedCallback(){super.connectedCallback();this.filterChangedDebouncer(this.filterType,this.entityId,this.startTime,this.endTime,this.cacheConfig,this.localize)}disconnectedCallback(){if(this._refreshTimeoutId){window.clearInterval(this._refreshTimeoutId);this._refreshTimeoutId=null}super.disconnectedCallback()}hassChanged(newHass,oldHass){if(!oldHass&&!this._madeFirstCall){this.filterChangedDebouncer(this.filterType,this.entityId,this.startTime,this.endTime,this.cacheConfig,this.localize)}}filterChangedDebouncer(...args){this._debounceFilterChanged=debounce.a.debounce(this._debounceFilterChanged,utils_async.d.after(0),()=>{this.filterChanged(...args)})}filterChanged(filterType,entityId,startTime,endTime,cacheConfig,localize){if(!this.hass){return}if(cacheConfig&&!cacheConfig.cacheKey){return}if(!localize){return}this._madeFirstCall=!0;const language=this.hass.language;let data;if("date"===filterType){if(!startTime||!endTime)return;data=Object(data_history.b)(this.hass,startTime,endTime).then(dateHistory=>Object(data_history.a)(this.hass,dateHistory,localize,language))}else if("recent-entity"===filterType){if(!entityId)return;if(cacheConfig){data=this.getRecentWithCacheRefresh(entityId,cacheConfig,localize,language)}else{data=getRecent(this.hass,entityId,startTime,endTime,localize,language)}}else{return}this._setIsLoading(!0);data.then(stateHistory=>{this._setData(stateHistory);this._setIsLoading(!1)})}getRecentWithCacheRefresh(entityId,cacheConfig,localize,language){if(this._refreshTimeoutId){window.clearInterval(this._refreshTimeoutId);this._refreshTimeoutId=null}if(cacheConfig.refresh){this._refreshTimeoutId=window.setInterval(()=>{getRecentWithCache(this.hass,entityId,cacheConfig,localize,language).then(stateHistory=>{this._setData(Object.assign({},stateHistory))})},1e3*cacheConfig.refresh)}return getRecentWithCache(this.hass,entityId,cacheConfig,localize,language)}}customElements.define("ha-state-history-data",ha_state_history_data_HaStateHistoryData)},227:function(module,__webpack_exports__,__webpack_require__){"use strict";function durationToSeconds(duration){const parts=duration.split(":").map(Number);return 3600*parts[0]+60*parts[1]+parts[2]}__webpack_require__.d(__webpack_exports__,"a",function(){return timerTimeRemaining});function timerTimeRemaining(stateObj){let timeRemaining=durationToSeconds(stateObj.attributes.remaining);if("active"===stateObj.state){const now=new Date().getTime(),madeActive=new Date(stateObj.last_changed).getTime();timeRemaining=Math.max(timeRemaining-(now-madeActive)/1e3,0)}return timeRemaining}},231:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathfloor2=Math.floor;__webpack_require__.d(__webpack_exports__,"a",function(){return relativeTime});const tests=[60,60,24,7],langKey=["second","minute","hour","day"];function relativeTime(dateObj,localize,options={}){const compareTime=options.compareTime||new Date;let delta=(compareTime.getTime()-dateObj.getTime())/1e3;const tense=0<=delta?"past":"future";delta=Math.abs(delta);let timeDesc;for(let i=0;i<tests.length;i++){if(delta<tests[i]){delta=_Mathfloor2(delta);timeDesc=localize(`ui.components.relative_time.duration.${langKey[i]}`,"count",delta);break}delta/=tests[i]}if(timeDesc===void 0){delta=_Mathfloor2(delta);timeDesc=localize("ui.components.relative_time.duration.week","count",delta)}return!1===options.includeTense?timeDesc:localize(`ui.components.relative_time.${tense}`,"time",timeDesc)}},232:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(57),lit_html__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(31),lit_html_directives_classMap__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(192),_ha_icon__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(159);class HaLabelBadge extends _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.a{static get properties(){return{value:{},icon:{},label:{},description:{},image:{}}}render(){return lit_html__WEBPACK_IMPORTED_MODULE_1__.g`
      ${this.renderStyle()}
      <div class="badge-container">
        <div class="label-badge" id="badge">
          <div
            class="${Object(lit_html_directives_classMap__WEBPACK_IMPORTED_MODULE_2__.a)({value:!0,big:!!(this.value&&4<this.value.length)})}"
          >
            ${this.icon&&!this.value&&!this.image?lit_html__WEBPACK_IMPORTED_MODULE_1__.g`
                    <ha-icon .icon="${this.icon}"></ha-icon>
                  `:""}
            ${this.value&&!this.image?lit_html__WEBPACK_IMPORTED_MODULE_1__.g`
                    <span>${this.value}</span>
                  `:""}
          </div>
          ${this.label?lit_html__WEBPACK_IMPORTED_MODULE_1__.g`
                  <div
                    class="${Object(lit_html_directives_classMap__WEBPACK_IMPORTED_MODULE_2__.a)({label:!0,big:5<this.label.length})}"
                  >
                    <span>${this.label}</span>
                  </div>
                `:""}
        </div>
        ${this.description?lit_html__WEBPACK_IMPORTED_MODULE_1__.g`
                <div class="title">${this.description}</div>
              `:""}
      </div>
    `}renderStyle(){return lit_html__WEBPACK_IMPORTED_MODULE_1__.g`
      <style>
        .badge-container {
          display: inline-block;
          text-align: center;
          vertical-align: top;
        }
        .label-badge {
          position: relative;
          display: block;
          margin: 0 auto;
          width: var(--ha-label-badge-size, 2.5em);
          text-align: center;
          height: var(--ha-label-badge-size, 2.5em);
          line-height: var(--ha-label-badge-size, 2.5em);
          font-size: var(--ha-label-badge-font-size, 1.5em);
          border-radius: 50%;
          border: 0.1em solid var(--ha-label-badge-color, var(--primary-color));
          color: var(--label-badge-text-color, rgb(76, 76, 76));

          white-space: nowrap;
          background-color: var(--label-badge-background-color, white);
          background-size: cover;
          transition: border 0.3s ease-in-out;
        }
        .label-badge .value {
          font-size: 90%;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .label-badge .value.big {
          font-size: 70%;
        }
        .label-badge .label {
          position: absolute;
          bottom: -1em;
          /* Make the label as wide as container+border. (parent_borderwidth / font-size) */
          left: -0.2em;
          right: -0.2em;
          line-height: 1em;
          font-size: 0.5em;
        }
        .label-badge .label span {
          box-sizing: border-box;
          max-width: 100%;
          display: inline-block;
          background-color: var(--ha-label-badge-color, var(--primary-color));
          color: var(--ha-label-badge-label-color, white);
          border-radius: 1em;
          padding: 9% 16% 8% 16%; /* mostly apitalized text, not much descenders => bit more top margin */
          font-weight: 500;
          overflow: hidden;
          text-transform: uppercase;
          text-overflow: ellipsis;
          transition: background-color 0.3s ease-in-out;
          text-transform: var(--ha-label-badge-label-text-transform, uppercase);
        }
        .label-badge .label.big span {
          font-size: 90%;
          padding: 10% 12% 7% 12%; /* push smaller text a bit down to center vertically */
        }
        .badge-container .title {
          margin-top: 1em;
          font-size: var(--ha-label-badge-title-font-size, 0.9em);
          width: var(--ha-label-badge-title-width, 5em);
          font-weight: var(--ha-label-badge-title-font-weight, 400);
          overflow: hidden;
          text-overflow: ellipsis;
          line-height: normal;
        }
      </style>
    `}updated(changedProperties){super.updated(changedProperties);if(changedProperties.has("image")){this.shadowRoot.getElementById("badge").style.backgroundImage=this.image?`url(${this.image})`:""}}}customElements.define("ha-label-badge",HaLabelBadge)},233:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"b",function(){return createErrorCardElement});__webpack_require__.d(__webpack_exports__,"a",function(){return createErrorCardConfig});var _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(57);const createErrorCardElement=config=>{const el=document.createElement("hui-error-card");el.setConfig(config);return el},createErrorCardConfig=(error,origConfig)=>({type:"error",error,origConfig});class HuiErrorCard extends _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.a{static get properties(){return{_config:{}}}getCardSize(){return 4}setConfig(config){this._config=config}render(){if(!this._config){return _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.c``}return _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.c`
      ${this.renderStyle()} ${this._config.error}
      <pre>${this._toStr(this._config.origConfig)}</pre>
    `}renderStyle(){return _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.c`
      <style>
        :host {
          display: block;
          background-color: #ef5350;
          color: white;
          padding: 8px;
          font-weight: 500;
        }
      </style>
    `}_toStr(config){return JSON.stringify(config,null,2)}}customElements.define("hui-error-card",HuiErrorCard)},234:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_classes__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(79),_polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(99),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(10),_util_cover_model__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(198);class HaCoverTiltControls extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_3__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_2__.a`
      <style include="iron-flex"></style>
      <style>
        :host {
          white-space: nowrap;
        }
        [invisible] {
          visibility: hidden !important;
        }
      </style>
      <paper-icon-button
        icon="hass:arrow-top-right"
        on-click="onOpenTiltTap"
        title="Open tilt"
        invisible$="[[!entityObj.supportsOpenTilt]]"
        disabled="[[computeOpenDisabled(stateObj, entityObj)]]"
      ></paper-icon-button>
      <paper-icon-button
        icon="hass:stop"
        on-click="onStopTiltTap"
        invisible$="[[!entityObj.supportsStopTilt]]"
        title="Stop tilt"
      ></paper-icon-button>
      <paper-icon-button
        icon="hass:arrow-bottom-left"
        on-click="onCloseTiltTap"
        title="Close tilt"
        invisible$="[[!entityObj.supportsCloseTilt]]"
        disabled="[[computeClosedDisabled(stateObj, entityObj)]]"
      ></paper-icon-button>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"}}}computeEntityObj(hass,stateObj){return new _util_cover_model__WEBPACK_IMPORTED_MODULE_4__.a(hass,stateObj)}computeOpenDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return entityObj.isFullyOpenTilt&&!assumedState}computeClosedDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return entityObj.isFullyClosedTilt&&!assumedState}onOpenTiltTap(ev){ev.stopPropagation();this.entityObj.openCoverTilt()}onCloseTiltTap(ev){ev.stopPropagation();this.entityObj.closeCoverTilt()}onStopTiltTap(ev){ev.stopPropagation();this.entityObj.stopCoverTilt()}}customElements.define("ha-cover-tilt-controls",HaCoverTiltControls)},239:function(module,__webpack_exports__,__webpack_require__){"use strict";var polymer_legacy=__webpack_require__(3),iron_flex_layout=__webpack_require__(33),iron_icon=__webpack_require__(95),paper_icon_button=__webpack_require__(99),empty=__webpack_require__(58),iron_iconset_svg=__webpack_require__(74),html_tag=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const template=html_tag.a`<iron-iconset-svg name="paper-tabs" size="24">
<svg><defs>
<g id="chevron-left"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path></g>
<g id="chevron-right"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path></g>
</defs></svg>
</iron-iconset-svg>`;document.head.appendChild(template.content);var paper_tab=__webpack_require__(213),iron_menu_behavior=__webpack_require__(110),iron_menubar_behavior=__webpack_require__(215),iron_resizable_behavior=__webpack_require__(84),polymer_fn=__webpack_require__(4),polymer_dom=__webpack_require__(0);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/Object(polymer_fn.a)({_template:html_tag.a`
    <style>
      :host {
        @apply --layout;
        @apply --layout-center;

        height: 48px;
        font-size: 14px;
        font-weight: 500;
        overflow: hidden;
        -moz-user-select: none;
        -ms-user-select: none;
        -webkit-user-select: none;
        user-select: none;

        /* NOTE: Both values are needed, since some phones require the value to be \`transparent\`. */
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-tap-highlight-color: transparent;

        @apply --paper-tabs;
      }

      :host(:dir(rtl)) {
        @apply --layout-horizontal-reverse;
      }

      #tabsContainer {
        position: relative;
        height: 100%;
        white-space: nowrap;
        overflow: hidden;
        @apply --layout-flex-auto;
        @apply --paper-tabs-container;
      }

      #tabsContent {
        height: 100%;
        -moz-flex-basis: auto;
        -ms-flex-basis: auto;
        flex-basis: auto;
        @apply --paper-tabs-content;
      }

      #tabsContent.scrollable {
        position: absolute;
        white-space: nowrap;
      }

      #tabsContent:not(.scrollable),
      #tabsContent.scrollable.fit-container {
        @apply --layout-horizontal;
      }

      #tabsContent.scrollable.fit-container {
        min-width: 100%;
      }

      #tabsContent.scrollable.fit-container > ::slotted(*) {
        /* IE - prevent tabs from compressing when they should scroll. */
        -ms-flex: 1 0 auto;
        -webkit-flex: 1 0 auto;
        flex: 1 0 auto;
      }

      .hidden {
        display: none;
      }

      .not-visible {
        opacity: 0;
        cursor: default;
      }

      paper-icon-button {
        width: 48px;
        height: 48px;
        padding: 12px;
        margin: 0 4px;
      }

      #selectionBar {
        position: absolute;
        height: 0;
        bottom: 0;
        left: 0;
        right: 0;
        border-bottom: 2px solid var(--paper-tabs-selection-bar-color, var(--paper-yellow-a100));
          -webkit-transform: scale(0);
        transform: scale(0);
          -webkit-transform-origin: left center;
        transform-origin: left center;
          transition: -webkit-transform;
        transition: transform;

        @apply --paper-tabs-selection-bar;
      }

      #selectionBar.align-bottom {
        top: 0;
        bottom: auto;
      }

      #selectionBar.expand {
        transition-duration: 0.15s;
        transition-timing-function: cubic-bezier(0.4, 0.0, 1, 1);
      }

      #selectionBar.contract {
        transition-duration: 0.18s;
        transition-timing-function: cubic-bezier(0.0, 0.0, 0.2, 1);
      }

      #tabsContent > ::slotted(:not(#selectionBar)) {
        height: 100%;
      }
    </style>

    <paper-icon-button icon="paper-tabs:chevron-left" class\$="[[_computeScrollButtonClass(_leftHidden, scrollable, hideScrollButtons)]]" on-up="_onScrollButtonUp" on-down="_onLeftScrollButtonDown" tabindex="-1"></paper-icon-button>

    <div id="tabsContainer" on-track="_scroll" on-down="_down">
      <div id="tabsContent" class\$="[[_computeTabsContentClass(scrollable, fitContainer)]]">
        <div id="selectionBar" class\$="[[_computeSelectionBarClass(noBar, alignBottom)]]" on-transitionend="_onBarTransitionEnd"></div>
        <slot></slot>
      </div>
    </div>

    <paper-icon-button icon="paper-tabs:chevron-right" class\$="[[_computeScrollButtonClass(_rightHidden, scrollable, hideScrollButtons)]]" on-up="_onScrollButtonUp" on-down="_onRightScrollButtonDown" tabindex="-1"></paper-icon-button>
`,is:"paper-tabs",behaviors:[iron_resizable_behavior.a,iron_menubar_behavior.a],properties:{noink:{type:Boolean,value:!1,observer:"_noinkChanged"},noBar:{type:Boolean,value:!1},noSlide:{type:Boolean,value:!1},scrollable:{type:Boolean,value:!1},fitContainer:{type:Boolean,value:!1},disableDrag:{type:Boolean,value:!1},hideScrollButtons:{type:Boolean,value:!1},alignBottom:{type:Boolean,value:!1},selectable:{type:String,value:"paper-tab"},autoselect:{type:Boolean,value:!1},autoselectDelay:{type:Number,value:0},_step:{type:Number,value:10},_holdDelay:{type:Number,value:1},_leftHidden:{type:Boolean,value:!1},_rightHidden:{type:Boolean,value:!1},_previousTab:{type:Object}},hostAttributes:{role:"tablist"},listeners:{"iron-resize":"_onTabSizingChanged","iron-items-changed":"_onTabSizingChanged","iron-select":"_onIronSelect","iron-deselect":"_onIronDeselect"},keyBindings:{"left:keyup right:keyup":"_onArrowKeyup"},created:function(){this._holdJob=null;this._pendingActivationItem=void 0;this._pendingActivationTimeout=void 0;this._bindDelayedActivationHandler=this._delayedActivationHandler.bind(this);this.addEventListener("blur",this._onBlurCapture.bind(this),!0)},ready:function(){this.setScrollDirection("y",this.$.tabsContainer)},detached:function(){this._cancelPendingActivation()},_noinkChanged:function(noink){var childTabs=Object(polymer_dom.b)(this).querySelectorAll("paper-tab");childTabs.forEach(noink?this._setNoinkAttribute:this._removeNoinkAttribute)},_setNoinkAttribute:function(element){element.setAttribute("noink","")},_removeNoinkAttribute:function(element){element.removeAttribute("noink")},_computeScrollButtonClass:function(hideThisButton,scrollable,hideScrollButtons){if(!scrollable||hideScrollButtons){return"hidden"}if(hideThisButton){return"not-visible"}return""},_computeTabsContentClass:function(scrollable,fitContainer){return scrollable?"scrollable"+(fitContainer?" fit-container":""):" fit-container"},_computeSelectionBarClass:function(noBar,alignBottom){if(noBar){return"hidden"}else if(alignBottom){return"align-bottom"}return""},_onTabSizingChanged:function(){this.debounce("_onTabSizingChanged",function(){this._scroll();this._tabChanged(this.selectedItem)},10)},_onIronSelect:function(event){this._tabChanged(event.detail.item,this._previousTab);this._previousTab=event.detail.item;this.cancelDebouncer("tab-changed")},_onIronDeselect:function(){this.debounce("tab-changed",function(){this._tabChanged(null,this._previousTab);this._previousTab=null},1)},_activateHandler:function(){this._cancelPendingActivation();iron_menu_behavior.b._activateHandler.apply(this,arguments)},_scheduleActivation:function(item,delay){this._pendingActivationItem=item;this._pendingActivationTimeout=this.async(this._bindDelayedActivationHandler,delay)},_delayedActivationHandler:function(){var item=this._pendingActivationItem;this._pendingActivationItem=void 0;this._pendingActivationTimeout=void 0;item.fire(this.activateEvent,null,{bubbles:!0,cancelable:!0})},_cancelPendingActivation:function(){if(this._pendingActivationTimeout!==void 0){this.cancelAsync(this._pendingActivationTimeout);this._pendingActivationItem=void 0;this._pendingActivationTimeout=void 0}},_onArrowKeyup:function(){if(this.autoselect){this._scheduleActivation(this.focusedItem,this.autoselectDelay)}},_onBlurCapture:function(event){if(event.target===this._pendingActivationItem){this._cancelPendingActivation()}},get _tabContainerScrollSize(){return Math.max(0,this.$.tabsContainer.scrollWidth-this.$.tabsContainer.offsetWidth)},_scroll:function(e,detail){if(!this.scrollable){return}var ddx=detail&&-detail.ddx||0;this._affectScroll(ddx)},_down:function(){this.async(function(){if(this._defaultFocusAsync){this.cancelAsync(this._defaultFocusAsync);this._defaultFocusAsync=null}},1)},_affectScroll:function(dx){this.$.tabsContainer.scrollLeft+=dx;var scrollLeft=this.$.tabsContainer.scrollLeft;this._leftHidden=0===scrollLeft;this._rightHidden=scrollLeft===this._tabContainerScrollSize},_onLeftScrollButtonDown:function(){this._scrollToLeft();this._holdJob=setInterval(this._scrollToLeft.bind(this),this._holdDelay)},_onRightScrollButtonDown:function(){this._scrollToRight();this._holdJob=setInterval(this._scrollToRight.bind(this),this._holdDelay)},_onScrollButtonUp:function(){clearInterval(this._holdJob);this._holdJob=null},_scrollToLeft:function(){this._affectScroll(-this._step)},_scrollToRight:function(){this._affectScroll(this._step)},_tabChanged:function(tab,old){if(!tab){this.$.selectionBar.classList.remove("expand");this.$.selectionBar.classList.remove("contract");this._positionBar(0,0);return}var r=this.$.tabsContent.getBoundingClientRect(),w=r.width,tabRect=tab.getBoundingClientRect(),tabOffsetLeft=tabRect.left-r.left;this._pos={width:this._calcPercent(tabRect.width,w),left:this._calcPercent(tabOffsetLeft,w)};if(this.noSlide||null==old){this.$.selectionBar.classList.remove("expand");this.$.selectionBar.classList.remove("contract");this._positionBar(this._pos.width,this._pos.left);return}var oldRect=old.getBoundingClientRect(),oldIndex=this.items.indexOf(old),index=this.items.indexOf(tab),m=5;this.$.selectionBar.classList.add("expand");var moveRight=oldIndex<index,isRTL=this._isRTL;if(isRTL){moveRight=!moveRight}if(moveRight){this._positionBar(this._calcPercent(tabRect.left+tabRect.width-oldRect.left,w)-m,this._left)}else{this._positionBar(this._calcPercent(oldRect.left+oldRect.width-tabRect.left,w)-m,this._calcPercent(tabOffsetLeft,w)+m)}if(this.scrollable){this._scrollToSelectedIfNeeded(tabRect.width,tabOffsetLeft)}},_scrollToSelectedIfNeeded:function(tabWidth,tabOffsetLeft){var l=tabOffsetLeft-this.$.tabsContainer.scrollLeft;if(0>l){this.$.tabsContainer.scrollLeft+=l}else{l+=tabWidth-this.$.tabsContainer.offsetWidth;if(0<l){this.$.tabsContainer.scrollLeft+=l}}},_calcPercent:function(w,w0){return 100*w/w0},_positionBar:function(width,left){width=width||0;left=left||0;this._width=width;this._left=left;this.transform("translateX("+left+"%) scaleX("+width/100+")",this.$.selectionBar)},_onBarTransitionEnd:function(){var cl=this.$.selectionBar.classList;if(cl.contains("expand")){cl.remove("expand");cl.add("contract");this._positionBar(this._pos.width,this._pos.left)}else if(cl.contains("contract")){cl.remove("contract")}}})},242:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(99),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(10),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(48),_common_config_is_component_loaded__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(185);class HaStartVoiceButton extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_3__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <paper-icon-button
        icon="hass:microphone"
        hidden$="[[!canListen]]"
        on-click="handleListenClick"
      ></paper-icon-button>
    `}static get properties(){return{hass:{type:Object,value:null},canListen:{type:Boolean,computed:"computeCanListen(hass)",notify:!0}}}computeCanListen(hass){return"webkitSpeechRecognition"in window&&Object(_common_config_is_component_loaded__WEBPACK_IMPORTED_MODULE_4__.a)(hass,"conversation")}handleListenClick(){this.fire("hass-start-voice")}}customElements.define("ha-start-voice-button",HaStartVoiceButton)},243:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathmax2=Math.max,_polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(0),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_3__.a`
    <style>
      :host {
        display: block;
        position: absolute;
        outline: none;
        z-index: 1002;
        -moz-user-select: none;
        -ms-user-select: none;
        -webkit-user-select: none;
        user-select: none;
        cursor: default;
      }

      #tooltip {
        display: block;
        outline: none;
        @apply --paper-font-common-base;
        font-size: 10px;
        line-height: 1;
        background-color: var(--paper-tooltip-background, #616161);
        color: var(--paper-tooltip-text-color, white);
        padding: 8px;
        border-radius: 2px;
        @apply --paper-tooltip;
      }

      @keyframes keyFrameScaleUp {
        0% {
          transform: scale(0.0);
        }
        100% {
          transform: scale(1.0);
        }
      }

      @keyframes keyFrameScaleDown {
        0% {
          transform: scale(1.0);
        }
        100% {
          transform: scale(0.0);
        }
      }

      @keyframes keyFrameFadeInOpacity {
        0% {
          opacity: 0;
        }
        100% {
          opacity: var(--paper-tooltip-opacity, 0.9);
        }
      }

      @keyframes keyFrameFadeOutOpacity {
        0% {
          opacity: var(--paper-tooltip-opacity, 0.9);
        }
        100% {
          opacity: 0;
        }
      }

      @keyframes keyFrameSlideDownIn {
        0% {
          transform: translateY(-2000px);
          opacity: 0;
        }
        10% {
          opacity: 0.2;
        }
        100% {
          transform: translateY(0);
          opacity: var(--paper-tooltip-opacity, 0.9);
        }
      }

      @keyframes keyFrameSlideDownOut {
        0% {
          transform: translateY(0);
          opacity: var(--paper-tooltip-opacity, 0.9);
        }
        10% {
          opacity: 0.2;
        }
        100% {
          transform: translateY(-2000px);
          opacity: 0;
        }
      }

      .fade-in-animation {
        opacity: 0;
        animation-delay: var(--paper-tooltip-delay-in, 500ms);
        animation-name: keyFrameFadeInOpacity;
        animation-iteration-count: 1;
        animation-timing-function: ease-in;
        animation-duration: var(--paper-tooltip-duration-in, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .fade-out-animation {
        opacity: var(--paper-tooltip-opacity, 0.9);
        animation-delay: var(--paper-tooltip-delay-out, 0ms);
        animation-name: keyFrameFadeOutOpacity;
        animation-iteration-count: 1;
        animation-timing-function: ease-in;
        animation-duration: var(--paper-tooltip-duration-out, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .scale-up-animation {
        transform: scale(0);
        opacity: var(--paper-tooltip-opacity, 0.9);
        animation-delay: var(--paper-tooltip-delay-in, 500ms);
        animation-name: keyFrameScaleUp;
        animation-iteration-count: 1;
        animation-timing-function: ease-in;
        animation-duration: var(--paper-tooltip-duration-in, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .scale-down-animation {
        transform: scale(1);
        opacity: var(--paper-tooltip-opacity, 0.9);
        animation-delay: var(--paper-tooltip-delay-out, 500ms);
        animation-name: keyFrameScaleDown;
        animation-iteration-count: 1;
        animation-timing-function: ease-in;
        animation-duration: var(--paper-tooltip-duration-out, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .slide-down-animation {
        transform: translateY(-2000px);
        opacity: 0;
        animation-delay: var(--paper-tooltip-delay-out, 500ms);
        animation-name: keyFrameSlideDownIn;
        animation-iteration-count: 1;
        animation-timing-function: cubic-bezier(0.0, 0.0, 0.2, 1);
        animation-duration: var(--paper-tooltip-duration-out, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .slide-down-animation-out {
        transform: translateY(0);
        opacity: var(--paper-tooltip-opacity, 0.9);
        animation-delay: var(--paper-tooltip-delay-out, 500ms);
        animation-name: keyFrameSlideDownOut;
        animation-iteration-count: 1;
        animation-timing-function: cubic-bezier(0.4, 0.0, 1, 1);
        animation-duration: var(--paper-tooltip-duration-out, 500ms);
        animation-fill-mode: forwards;
        @apply --paper-tooltip-animation;
      }

      .cancel-animation {
        animation-delay: -30s !important;
      }

      /* Thanks IE 10. */

      .hidden {
        display: none !important;
      }
    </style>

    <div id="tooltip" class="hidden">
      <slot></slot>
    </div>
`,is:"paper-tooltip",hostAttributes:{role:"tooltip",tabindex:-1},properties:{for:{type:String,observer:"_findTarget"},manualMode:{type:Boolean,value:!1,observer:"_manualModeChanged"},position:{type:String,value:"bottom"},fitToVisibleBounds:{type:Boolean,value:!1},offset:{type:Number,value:14},marginTop:{type:Number,value:14},animationDelay:{type:Number,value:500,observer:"_delayChange"},animationEntry:{type:String,value:""},animationExit:{type:String,value:""},animationConfig:{type:Object,value:function(){return{entry:[{name:"fade-in-animation",node:this,timing:{delay:0}}],exit:[{name:"fade-out-animation",node:this}]}}},_showing:{type:Boolean,value:!1}},listeners:{webkitAnimationEnd:"_onAnimationEnd"},get target(){var parentNode=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_2__.b)(this).parentNode,ownerRoot=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_2__.b)(this).getOwnerRoot(),target;if(this.for){target=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_2__.b)(ownerRoot).querySelector("#"+this.for)}else{target=parentNode.nodeType==Node.DOCUMENT_FRAGMENT_NODE?ownerRoot.host:parentNode}return target},attached:function(){this._findTarget()},detached:function(){if(!this.manualMode)this._removeListeners()},playAnimation:function(type){if("entry"===type){this.show()}else if("exit"===type){this.hide()}},cancelAnimation:function(){this.$.tooltip.classList.add("cancel-animation")},show:function(){if(this._showing)return;if(""===Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_2__.b)(this).textContent.trim()){for(var allChildrenEmpty=!0,effectiveChildren=Object(_polymer_polymer_lib_legacy_polymer_dom_js__WEBPACK_IMPORTED_MODULE_2__.b)(this).getEffectiveChildNodes(),i=0;i<effectiveChildren.length;i++){if(""!==effectiveChildren[i].textContent.trim()){allChildrenEmpty=!1;break}}if(allChildrenEmpty){return}}this._showing=!0;this.$.tooltip.classList.remove("hidden");this.$.tooltip.classList.remove("cancel-animation");this.$.tooltip.classList.remove(this._getAnimationType("exit"));this.updatePosition();this._animationPlaying=!0;this.$.tooltip.classList.add(this._getAnimationType("entry"))},hide:function(){if(!this._showing){return}if(this._animationPlaying){this._showing=!1;this._cancelAnimation();return}else{this._onAnimationFinish()}this._showing=!1;this._animationPlaying=!0},updatePosition:function(){if(!this._target||!this.offsetParent)return;var offset=this.offset;if(14!=this.marginTop&&14==this.offset)offset=this.marginTop;var parentRect=this.offsetParent.getBoundingClientRect(),targetRect=this._target.getBoundingClientRect(),thisRect=this.getBoundingClientRect(),horizontalCenterOffset=(targetRect.width-thisRect.width)/2,verticalCenterOffset=(targetRect.height-thisRect.height)/2,targetLeft=targetRect.left-parentRect.left,targetTop=targetRect.top-parentRect.top,tooltipLeft,tooltipTop;switch(this.position){case"top":tooltipLeft=targetLeft+horizontalCenterOffset;tooltipTop=targetTop-thisRect.height-offset;break;case"bottom":tooltipLeft=targetLeft+horizontalCenterOffset;tooltipTop=targetTop+targetRect.height+offset;break;case"left":tooltipLeft=targetLeft-thisRect.width-offset;tooltipTop=targetTop+verticalCenterOffset;break;case"right":tooltipLeft=targetLeft+targetRect.width+offset;tooltipTop=targetTop+verticalCenterOffset;break;}if(this.fitToVisibleBounds){if(parentRect.left+tooltipLeft+thisRect.width>window.innerWidth){this.style.right="0px";this.style.left="auto"}else{this.style.left=_Mathmax2(0,tooltipLeft)+"px";this.style.right="auto"}if(parentRect.top+tooltipTop+thisRect.height>window.innerHeight){this.style.bottom=parentRect.height-targetTop+offset+"px";this.style.top="auto"}else{this.style.top=_Mathmax2(-parentRect.top,tooltipTop)+"px";this.style.bottom="auto"}}else{this.style.left=tooltipLeft+"px";this.style.top=tooltipTop+"px"}},_addListeners:function(){if(this._target){this.listen(this._target,"mouseenter","show");this.listen(this._target,"focus","show");this.listen(this._target,"mouseleave","hide");this.listen(this._target,"blur","hide");this.listen(this._target,"tap","hide")}this.listen(this.$.tooltip,"animationend","_onAnimationEnd");this.listen(this,"mouseenter","hide")},_findTarget:function(){if(!this.manualMode)this._removeListeners();this._target=this.target;if(!this.manualMode)this._addListeners()},_delayChange:function(newValue){if(500!==newValue){this.updateStyles({"--paper-tooltip-delay-in":newValue+"ms"})}},_manualModeChanged:function(){if(this.manualMode)this._removeListeners();else this._addListeners()},_cancelAnimation:function(){this.$.tooltip.classList.remove(this._getAnimationType("entry"));this.$.tooltip.classList.remove(this._getAnimationType("exit"));this.$.tooltip.classList.remove("cancel-animation");this.$.tooltip.classList.add("hidden")},_onAnimationFinish:function(){if(this._showing){this.$.tooltip.classList.remove(this._getAnimationType("entry"));this.$.tooltip.classList.remove("cancel-animation");this.$.tooltip.classList.add(this._getAnimationType("exit"))}},_onAnimationEnd:function(){this._animationPlaying=!1;if(!this._showing){this.$.tooltip.classList.remove(this._getAnimationType("exit"));this.$.tooltip.classList.add("hidden")}},_getAnimationType:function(type){if("entry"===type&&""!==this.animationEntry){return this.animationEntry}if("exit"===type&&""!==this.animationExit){return this.animationExit}if(this.animationConfig[type]&&"string"===typeof this.animationConfig[type][0].name){if(this.animationConfig[type][0].timing&&this.animationConfig[type][0].timing.delay&&0!==this.animationConfig[type][0].timing.delay){var timingDelay=this.animationConfig[type][0].timing.delay;if("entry"===type){this.updateStyles({"--paper-tooltip-delay-in":timingDelay+"ms"})}else if("exit"===type){this.updateStyles({"--paper-tooltip-delay-out":timingDelay+"ms"})}}return this.animationConfig[type][0].name}},_removeListeners:function(){if(this._target){this.unlisten(this._target,"mouseenter","show");this.unlisten(this._target,"focus","show");this.unlisten(this._target,"mouseleave","hide");this.unlisten(this._target,"blur","hide");this.unlisten(this._target,"tap","hide")}this.unlisten(this.$.tooltip,"animationend","_onAnimationEnd");this.unlisten(this,"mouseenter","hide")}})},244:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(57),lit_html_directives_classMap__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(192),_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(153),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(105),_common_entity_domain_icon__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(156),_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(175),_common_entity_timer_time_remaining__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(227),_common_datetime_seconds_to_duration__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(219),_common_dom_fire_event__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(65),_mixins_lit_localize_mixin__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(154),_ha_label_badge__WEBPACK_IMPORTED_MODULE_10__=__webpack_require__(232);class HaStateLabelBadge extends Object(_mixins_lit_localize_mixin__WEBPACK_IMPORTED_MODULE_9__.a)(_polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.a){connectedCallback(){super.connectedCallback();this._connected=!0;this.startInterval(this.state)}disconnectedCallback(){super.disconnectedCallback();this._connected=!1;this.clearInterval()}render(){const state=this.state;if(!state){return _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.c`
        ${this.renderStyle()}
        <ha-label-badge label="not found"></ha-label-badge>
      `}const domain=Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_2__.a)(state);return _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.c`
      ${this.renderStyle()}
      <ha-label-badge
        class="${Object(lit_html_directives_classMap__WEBPACK_IMPORTED_MODULE_1__.a)({[domain]:!0,"has-unit_of_measurement":"unit_of_measurement"in state.attributes})}"
        .value="${this._computeValue(domain,state)}"
        .icon="${this._computeIcon(domain,state)}"
        .image="${state.attributes.entity_picture}"
        .label="${this._computeLabel(domain,state,this._timerTimeRemaining)}"
        .description="${Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_3__.a)(state)}"
      ></ha-label-badge>
    `}static get properties(){return{hass:{},state:{},_timerTimeRemaining:{}}}firstUpdated(changedProperties){super.firstUpdated(changedProperties);this.addEventListener("click",ev=>{ev.stopPropagation();if(this.state){Object(_common_dom_fire_event__WEBPACK_IMPORTED_MODULE_8__.a)(this,"hass-more-info",{entityId:this.state.entity_id})}})}updated(changedProperties){super.updated(changedProperties);if(this._connected&&changedProperties.has("state")){this.startInterval(this.state)}}_computeValue(domain,state){switch(domain){case"binary_sensor":case"device_tracker":case"updater":case"sun":case"alarm_control_panel":case"timer":return null;case"sensor":default:return"unknown"===state.state?"-":this.localize(`component.${domain}.state.${state.state}`)||state.state;}}_computeIcon(domain,state){if("unavailable"===state.state){return null}switch(domain){case"alarm_control_panel":if("pending"===state.state){return"hass:clock-fast"}if("armed_away"===state.state){return"hass:nature"}if("armed_home"===state.state){return"hass:home-variant"}if("armed_night"===state.state){return"hass:weather-night"}if("armed_custom_bypass"===state.state){return"hass:security-home"}if("triggered"===state.state){return"hass:alert-circle"}return Object(_common_entity_domain_icon__WEBPACK_IMPORTED_MODULE_4__.a)(domain,state.state);case"binary_sensor":case"device_tracker":case"updater":return Object(_common_entity_state_icon__WEBPACK_IMPORTED_MODULE_5__.a)(state);case"sun":return"above_horizon"===state.state?Object(_common_entity_domain_icon__WEBPACK_IMPORTED_MODULE_4__.a)(domain):"hass:brightness-3";case"timer":return"active"===state.state?"hass:timer":"hass:timer-off";default:return null;}}_computeLabel(domain,state,_timerTimeRemaining){if("unavailable"===state.state||["device_tracker","alarm_control_panel"].includes(domain)){return this.localize(`state_badge.${domain}.${state.state}`)||this.localize(`state_badge.default.${state.state}`)||state.state}if("timer"===domain){return Object(_common_datetime_seconds_to_duration__WEBPACK_IMPORTED_MODULE_7__.a)(_timerTimeRemaining)}return state.attributes.unit_of_measurement||null}clearInterval(){if(this._updateRemaining){clearInterval(this._updateRemaining);this._updateRemaining=void 0}}startInterval(stateObj){this.clearInterval();if(stateObj&&"timer"===Object(_common_entity_compute_state_domain__WEBPACK_IMPORTED_MODULE_2__.a)(stateObj)){this.calculateTimerRemaining(stateObj);if("active"===stateObj.state){this._updateRemaining=window.setInterval(()=>this.calculateTimerRemaining(this.state),1e3)}}}calculateTimerRemaining(stateObj){this._timerTimeRemaining=Object(_common_entity_timer_time_remaining__WEBPACK_IMPORTED_MODULE_6__.a)(stateObj)}renderStyle(){return _polymer_lit_element__WEBPACK_IMPORTED_MODULE_0__.c`
      <style>
        :host {
          cursor: pointer;
        }

        ha-label-badge {
          --ha-label-badge-color: var(--label-badge-red, #df4c1e);
        }
        ha-label-badge.has-unit_of_measurement {
          --ha-label-badge-label-text-transform: none;
        }

        ha-label-badge.binary_sensor,
        ha-label-badge.updater {
          --ha-label-badge-color: var(--label-badge-blue, #039be5);
        }

        .red {
          --ha-label-badge-color: var(--label-badge-red, #df4c1e);
        }

        .blue {
          --ha-label-badge-color: var(--label-badge-blue, #039be5);
        }

        .green {
          --ha-label-badge-color: var(--label-badge-green, #0da035);
        }

        .yellow {
          --ha-label-badge-color: var(--label-badge-yellow, #f4b400);
        }

        .grey {
          --ha-label-badge-color: var(
            --label-badge-grey,
            var(--paper-grey-500)
          );
        }
      </style>
    `}}customElements.define("ha-state-label-badge",HaStateLabelBadge)},245:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(71);class HaClimateState extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_2__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        :host {
          display: flex;
          flex-direction: column;
          justify-content: center;
          white-space: nowrap;
        }

        .target {
          color: var(--primary-text-color);
        }

        .current {
          color: var(--secondary-text-color);
        }

        .state-label {
          font-weight: bold;
          text-transform: capitalize;
        }
      </style>

      <div class="target">
        <template is="dom-if" if="[[_hasKnownState(stateObj.state)]]">
          <span class="state-label"> [[_localizeState(stateObj.state)]] </span>
        </template>
        [[computeTarget(hass, stateObj)]]
      </div>

      <template is="dom-if" if="[[currentStatus]]">
        <div class="current">
          [[localize('ui.card.climate.currently')]]: [[currentStatus]]
        </div>
      </template>
    `}static get properties(){return{hass:Object,stateObj:Object,currentStatus:{type:String,computed:"computeCurrentStatus(hass, stateObj)"}}}computeCurrentStatus(hass,stateObj){if(!hass||!stateObj)return null;if(null!=stateObj.attributes.current_temperature){return`${stateObj.attributes.current_temperature} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.current_humidity){return`${stateObj.attributes.current_humidity} %`}return null}computeTarget(hass,stateObj){if(!hass||!stateObj)return null;if(null!=stateObj.attributes.target_temp_low&&null!=stateObj.attributes.target_temp_high){return`${stateObj.attributes.target_temp_low} - ${stateObj.attributes.target_temp_high} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.temperature){return`${stateObj.attributes.temperature} ${hass.config.unit_system.temperature}`}if(null!=stateObj.attributes.target_humidity_low&&null!=stateObj.attributes.target_humidity_high){return`${stateObj.attributes.target_humidity_low} - ${stateObj.attributes.target_humidity_high} %`}if(null!=stateObj.attributes.humidity){return`${stateObj.attributes.humidity} %`}return""}_hasKnownState(state){return"unknown"!==state}_localizeState(state){return this.localize(`state.climate.${state}`)||state}}customElements.define("ha-climate-state",HaClimateState)},246:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(99),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(10),_util_cover_model__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(198);class HaCoverControls extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style>
        .state {
          white-space: nowrap;
        }
        [invisible] {
          visibility: hidden !important;
        }
      </style>

      <div class="state">
        <paper-icon-button
          icon="hass:arrow-up"
          on-click="onOpenTap"
          invisible$="[[!entityObj.supportsOpen]]"
          disabled="[[computeOpenDisabled(stateObj, entityObj)]]"
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:stop"
          on-click="onStopTap"
          invisible$="[[!entityObj.supportsStop]]"
        ></paper-icon-button>
        <paper-icon-button
          icon="hass:arrow-down"
          on-click="onCloseTap"
          invisible$="[[!entityObj.supportsClose]]"
          disabled="[[computeClosedDisabled(stateObj, entityObj)]]"
        ></paper-icon-button>
      </div>
    `}static get properties(){return{hass:{type:Object},stateObj:{type:Object},entityObj:{type:Object,computed:"computeEntityObj(hass, stateObj)"}}}computeEntityObj(hass,stateObj){return new _util_cover_model__WEBPACK_IMPORTED_MODULE_3__.a(hass,stateObj)}computeOpenDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return(entityObj.isFullyOpen||entityObj.isOpening)&&!assumedState}computeClosedDisabled(stateObj,entityObj){var assumedState=!0===stateObj.attributes.assumed_state;return(entityObj.isFullyClosed||entityObj.isClosing)&&!assumedState}onOpenTap(ev){ev.stopPropagation();this.entityObj.openCover()}onCloseTap(ev){ev.stopPropagation();this.entityObj.closeCover()}onStopTap(ev){ev.stopPropagation();this.entityObj.stopCover()}}customElements.define("ha-cover-controls",HaCoverControls)},247:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathround2=Math.round,_polymer_paper_slider__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(136);const PaperSliderClass=customElements.get("paper-slider");customElements.define("ha-slider",class extends PaperSliderClass{_calcStep(value){if(!this.step){return parseFloat(value)}const numSteps=_Mathround2((value-this.min)/this.step),stepStr=this.step.toString(),stepPointAt=stepStr.indexOf(".");if(-1!==stepPointAt){const precision=10**(stepStr.length-stepPointAt-1);return _Mathround2((numSteps*this.step+this.min)*precision)/precision}return numSteps*this.step+this.min}})},248:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return getGroupEntities});function getGroupEntities(entities,group){const result={};group.attributes.entity_id.forEach(entityId=>{const entity=entities[entityId];if(entity){result[entity.entity_id]=entity}});return result}},257:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return processConfigEntities});var _common_entity_valid_entity_id__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(327);const processConfigEntities=entities=>{if(!entities||!Array.isArray(entities)){throw new Error("Entities need to be an array")}return entities.map((entityConf,index)=>{if("object"===typeof entityConf&&!Array.isArray(entityConf)&&entityConf.type){return entityConf}let config;if("string"===typeof entityConf){config={entity:entityConf}}else if("object"===typeof entityConf&&!Array.isArray(entityConf)){if(!entityConf.entity){throw new Error(`Entity object at position ${index} is missing entity field.`)}config=entityConf}else{throw new Error(`Invalid entity specified at position ${index}.`)}if(!Object(_common_entity_valid_entity_id__WEBPACK_IMPORTED_MODULE_0__.a)(config.entity)){throw new Error(`Invalid entity ID at position ${index}: ${config.entity}`)}return config})}},267:function(module,__webpack_exports__,__webpack_require__){"use strict";var _app_scroll_effects_behavior_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(298),_helpers_helpers_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(299);/**
@license
Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_helpers_helpers_js__WEBPACK_IMPORTED_MODULE_1__.b)("waterfall",{run:function(){this.shadow=this.isOnScreen()&&this.isContentBelow()}})},268:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_flex_layout_iron_flex_layout_classes__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(79),_polymer_paper_icon_button_paper_icon_button__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(99),_polymer_paper_progress_paper_progress__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(135),_polymer_paper_styles_element_styles_paper_material_styles__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(82),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(10),_util_hass_media_player_model__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(220),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(105),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(48),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(71);class HaMediaPlayerCard extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_9__.a)(Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_8__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_5__.a)){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_4__.a`
      <style
        include="paper-material-styles iron-flex iron-flex-alignment iron-positioning"
      >
        :host {
          @apply --paper-material-elevation-1;
          display: block;
          position: relative;
          font-size: 0px;
          border-radius: 2px;
        }

        .banner {
          position: relative;
          background-color: white;
          border-top-left-radius: 2px;
          border-top-right-radius: 2px;
        }

        .banner:before {
          display: block;
          content: "";
          width: 100%;
          /* removed .25% from 16:9 ratio to fix YT black bars */
          padding-top: 56%;
          transition: padding-top 0.8s;
        }

        .banner.no-cover {
          background-position: center center;
          background-image: url(/static/images/card_media_player_bg.png);
          background-repeat: no-repeat;
          background-color: var(--primary-color);
        }

        .banner.content-type-music:before {
          padding-top: 100%;
        }

        .banner.no-cover:before {
          padding-top: 88px;
        }

        .banner > .cover {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;

          border-top-left-radius: 2px;
          border-top-right-radius: 2px;

          background-position: center center;
          background-size: cover;
          transition: opacity 0.8s;
          opacity: 1;
        }

        .banner.is-off > .cover {
          opacity: 0;
        }

        .banner > .caption {
          @apply --paper-font-caption;

          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;

          background-color: rgba(0, 0, 0, var(--dark-secondary-opacity));

          padding: 8px 16px;

          font-size: 14px;
          font-weight: 500;
          color: white;

          transition: background-color 0.5s;
        }

        .banner.is-off > .caption {
          background-color: initial;
        }

        .banner > .caption .title {
          @apply --paper-font-common-nowrap;
          font-size: 1.2em;
          margin: 8px 0 4px;
        }

        .progress {
          width: 100%;
          height: var(--paper-progress-height, 4px);
          margin-top: calc(-1 * var(--paper-progress-height, 4px));
          --paper-progress-active-color: var(--accent-color);
          --paper-progress-container-color: rgba(200, 200, 200, 0.5);
        }

        .controls {
          position: relative;
          @apply --paper-font-body1;
          padding: 8px;
          border-bottom-left-radius: 2px;
          border-bottom-right-radius: 2px;
          background-color: var(--paper-card-background-color, white);
        }

        .controls paper-icon-button {
          width: 44px;
          height: 44px;
        }

        paper-icon-button {
          opacity: var(--dark-primary-opacity);
        }

        paper-icon-button[disabled] {
          opacity: var(--dark-disabled-opacity);
        }

        paper-icon-button.primary {
          width: 56px !important;
          height: 56px !important;
          background-color: var(--primary-color);
          color: white;
          border-radius: 50%;
          padding: 8px;
          transition: background-color 0.5s;
        }

        paper-icon-button.primary[disabled] {
          background-color: rgba(0, 0, 0, var(--dark-disabled-opacity));
        }

        [invisible] {
          visibility: hidden !important;
        }
      </style>

      <div class$="[[computeBannerClasses(playerObj)]]">
        <div class="cover" id="cover"></div>

        <div class="caption">
          [[_computeStateName(stateObj)]]
          <div class="title">[[computePrimaryText(localize, playerObj)]]</div>
          [[playerObj.secondaryTitle]]<br />
        </div>
      </div>

      <paper-progress
        max="[[stateObj.attributes.media_duration]]"
        value="[[playbackPosition]]"
        hidden$="[[computeHideProgress(playerObj)]]"
        class="progress"
      ></paper-progress>

      <div class="controls layout horizontal justified">
        <paper-icon-button
          icon="hass:power"
          on-click="handleTogglePower"
          invisible$="[[computeHidePowerButton(playerObj)]]"
          class="self-center secondary"
        ></paper-icon-button>

        <div>
          <paper-icon-button
            icon="hass:skip-previous"
            invisible$="[[!playerObj.supportsPreviousTrack]]"
            disabled="[[playerObj.isOff]]"
            on-click="handlePrevious"
          ></paper-icon-button>
          <paper-icon-button
            class="primary"
            icon="[[computePlaybackControlIcon(playerObj)]]"
            invisible$="[[!computePlaybackControlIcon(playerObj)]]"
            disabled="[[playerObj.isOff]]"
            on-click="handlePlaybackControl"
          ></paper-icon-button>
          <paper-icon-button
            icon="hass:skip-next"
            invisible$="[[!playerObj.supportsNextTrack]]"
            disabled="[[playerObj.isOff]]"
            on-click="handleNext"
          ></paper-icon-button>
        </div>

        <paper-icon-button
          icon="hass:dots-vertical"
          on-click="handleOpenMoreInfo"
          class="self-center secondary"
        ></paper-icon-button>
      </div>
    `}static get properties(){return{hass:Object,stateObj:Object,playerObj:{type:Object,computed:"computePlayerObj(hass, stateObj)",observer:"playerObjChanged"},playbackControlIcon:{type:String,computed:"computePlaybackControlIcon(playerObj)"},playbackPosition:Number}}async playerObjChanged(playerObj,oldPlayerObj){if(playerObj.isPlaying&&playerObj.showProgress){if(!this._positionTracking){this._positionTracking=setInterval(()=>this.updatePlaybackPosition(),1e3)}}else if(this._positionTracking){clearInterval(this._positionTracking);this._positionTracking=null}if(playerObj.showProgress){this.updatePlaybackPosition()}const picture=playerObj.stateObj.attributes.entity_picture,oldPicture=oldPlayerObj&&oldPlayerObj.stateObj.attributes.entity_picture;if(picture!==oldPicture&&!picture){this.$.cover.style.backgroundImage="";return}if(picture===oldPicture){return}try{const{content_type:contentType,content}=await this.hass.callWS({type:"media_player_thumbnail",entity_id:playerObj.stateObj.entity_id});this.$.cover.style.backgroundImage=`url(data:${contentType};base64,${content})`}catch(err){this.$.cover.style.backgroundImage="";this.$.cover.parentElement.classList.add("no-cover")}}updatePlaybackPosition(){this.playbackPosition=this.playerObj.currentProgress}computeBannerClasses(playerObj){var cls="banner";if(playerObj.isOff||playerObj.isIdle){cls+=" is-off no-cover"}else if(!playerObj.stateObj.attributes.entity_picture){cls+=" no-cover"}else if("music"===playerObj.stateObj.attributes.media_content_type){cls+=" content-type-music"}return cls}computeHideProgress(playerObj){return!playerObj.showProgress}computeHidePowerButton(playerObj){return playerObj.isOff?!playerObj.supportsTurnOn:!playerObj.supportsTurnOff}computePlayerObj(hass,stateObj){return new _util_hass_media_player_model__WEBPACK_IMPORTED_MODULE_6__.a(hass,stateObj)}computePrimaryText(localize,playerObj){return playerObj.primaryTitle||localize(`state.media_player.${playerObj.stateObj.state}`)||localize(`state.default.${playerObj.stateObj.state}`)||playerObj.stateObj.state}computePlaybackControlIcon(playerObj){if(playerObj.isPlaying){return playerObj.supportsPause?"hass:pause":"hass:stop"}if(playerObj.hasMediaControl||playerObj.isOff||playerObj.isIdle){if(playerObj.hasMediaControl&&playerObj.supportsPause&&!playerObj.isPaused){return"hass:play-pause"}return playerObj.supportsPlay?"hass:play":null}return""}_computeStateName(stateObj){return Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_7__.a)(stateObj)}handleNext(ev){ev.stopPropagation();this.playerObj.nextTrack()}handleOpenMoreInfo(ev){ev.stopPropagation();this.fire("hass-more-info",{entityId:this.stateObj.entity_id})}handlePlaybackControl(ev){ev.stopPropagation();this.playerObj.mediaPlayPause()}handlePrevious(ev){ev.stopPropagation();this.playerObj.previousTrack()}handleTogglePower(ev){ev.stopPropagation();this.playerObj.togglePower()}}customElements.define("ha-media_player-card",HaMediaPlayerCard)},269:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_components_ha_card__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(168),_components_ha_icon__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(159),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(105),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(48);class HaPlantCard extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_5__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        .banner {
          display: flex;
          align-items: flex-end;
          background-repeat: no-repeat;
          background-size: cover;
          background-position: center;
          padding-top: 12px;
        }
        .has-plant-image .banner {
          padding-top: 30%;
        }
        .header {
          @apply --paper-font-headline;
          line-height: 40px;
          padding: 8px 16px;
        }
        .has-plant-image .header {
          font-size: 16px;
          font-weight: 500;
          line-height: 16px;
          padding: 16px;
          color: white;
          width: 100%;
          background: rgba(0, 0, 0, var(--dark-secondary-opacity));
        }
        .content {
          display: flex;
          justify-content: space-between;
          padding: 16px 32px 24px 32px;
        }
        .has-plant-image .content {
          padding-bottom: 16px;
        }
        ha-icon {
          color: var(--paper-item-icon-color);
          margin-bottom: 8px;
        }
        .attributes {
          cursor: pointer;
        }
        .attributes div {
          text-align: center;
        }
        .problem {
          color: var(--google-red-500);
          font-weight: bold;
        }
        .uom {
          color: var(--secondary-text-color);
        }
      </style>

      <ha-card
        class$="[[computeImageClass(stateObj.attributes.entity_picture)]]"
      >
        <div
          class="banner"
          style="background-image:url([[stateObj.attributes.entity_picture]])"
        >
          <div class="header">[[computeTitle(stateObj)]]</div>
        </div>
        <div class="content">
          <template
            is="dom-repeat"
            items="[[computeAttributes(stateObj.attributes)]]"
          >
            <div class="attributes" on-click="attributeClicked">
              <div>
                <ha-icon
                  icon="[[computeIcon(item, stateObj.attributes.battery)]]"
                ></ha-icon>
              </div>
              <div
                class$="[[computeAttributeClass(stateObj.attributes.problem, item)]]"
              >
                [[computeValue(stateObj.attributes, item)]]
              </div>
              <div class="uom">
                [[computeUom(stateObj.attributes.unit_of_measurement_dict,
                item)]]
              </div>
            </div>
          </template>
        </div>
      </ha-card>
    `}static get properties(){return{hass:Object,stateObj:Object,config:Object}}constructor(){super();this.sensors={moisture:"hass:water",temperature:"hass:thermometer",brightness:"hass:white-balance-sunny",conductivity:"hass:emoticon-poop",battery:"hass:battery"}}computeTitle(stateObj){return this.config&&this.config.name||Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_4__.a)(stateObj)}computeAttributes(data){return Object.keys(this.sensors).filter(key=>key in data)}computeIcon(attr,batLvl){const icon=this.sensors[attr];if("battery"===attr){if(5>=batLvl){return`${icon}-alert`}if(95>batLvl){return`${icon}-${10*Math.round(batLvl/10-.01)}`}}return icon}computeValue(attributes,attr){return attributes[attr]}computeUom(dict,attr){return dict[attr]||""}computeAttributeClass(problem,attr){return-1===problem.indexOf(attr)?"":"problem"}computeImageClass(entityPicture){return entityPicture?"has-plant-image":""}attributeClicked(ev){this.fire("hass-more-info",{entityId:this.stateObj.attributes.sensors[ev.model.item]})}}customElements.define("ha-plant-card",HaPlantCard)},270:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(10),_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(105),_components_ha_card__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(168),_components_ha_icon__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(159),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(48),_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(71),_common_util_compute_rtl__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(112);class HaWeatherCard extends Object(_mixins_localize_mixin__WEBPACK_IMPORTED_MODULE_6__.a)(Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_5__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a)){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <style>
        :host {
          cursor: pointer;
        }

        .content {
          padding: 0 20px 20px;
        }

        ha-icon {
          color: var(--paper-item-icon-color);
        }

        .header {
          font-family: var(--paper-font-headline_-_font-family);
          -webkit-font-smoothing: var(
            --paper-font-headline_-_-webkit-font-smoothing
          );
          font-size: var(--paper-font-headline_-_font-size);
          font-weight: var(--paper-font-headline_-_font-weight);
          letter-spacing: var(--paper-font-headline_-_letter-spacing);
          line-height: var(--paper-font-headline_-_line-height);
          text-rendering: var(
            --paper-font-common-expensive-kerning_-_text-rendering
          );
          opacity: var(--dark-primary-opacity);
          padding: 24px 16px 16px;
          display: flex;
          align-items: baseline;
        }

        .name {
          margin-left: 16px;
          font-size: 16px;
          color: var(--secondary-text-color);
        }

        :host([rtl]) .name {
          margin-left: 0px;
          margin-right: 16px;
        }

        .now {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
        }

        .main {
          display: flex;
          align-items: center;
          margin-right: 32px;
        }

        :host([rtl]) .main {
          margin-right: 0px;
        }

        .main ha-icon {
          --iron-icon-height: 72px;
          --iron-icon-width: 72px;
          margin-right: 8px;
        }

        :host([rtl]) .main ha-icon {
          margin-right: 0px;
        }

        .main .temp {
          font-size: 52px;
          line-height: 1em;
          position: relative;
        }

        :host([rtl]) .main .temp {
          direction: ltr;
          margin-right: 28px;
        }

        .main .temp span {
          font-size: 24px;
          line-height: 1em;
          position: absolute;
          top: 4px;
        }

        .measurand {
          display: inline-block;
        }

        :host([rtl]) .measurand {
          direction: ltr;
        }

        .forecast {
          margin-top: 16px;
          display: flex;
          justify-content: space-between;
        }

        .forecast div {
          flex: 0 0 auto;
          text-align: center;
        }

        .forecast .icon {
          margin: 4px 0;
          text-align: center;
        }

        :host([rtl]) .forecast .temp {
          direction: ltr;
        }

        .weekday {
          font-weight: bold;
        }

        .attributes,
        .templow,
        .precipitation {
          color: var(--secondary-text-color);
        }
      </style>
      <ha-card>
        <div class="header">
          [[computeState(stateObj.state, localize)]]
          <div class="name">[[computeName(stateObj)]]</div>
        </div>
        <div class="content">
          <div class="now">
            <div class="main">
              <template is="dom-if" if="[[showWeatherIcon(stateObj.state)]]">
                <ha-icon icon="[[getWeatherIcon(stateObj.state)]]"></ha-icon>
              </template>
              <div class="temp">
                [[stateObj.attributes.temperature]]<span
                  >[[getUnit('temperature')]]</span
                >
              </div>
            </div>
            <div class="attributes">
              <template
                is="dom-if"
                if="[[_showValue(stateObj.attributes.pressure)]]"
              >
                <div>
                  [[localize('ui.card.weather.attributes.air_pressure')]]:
                  <span class="measurand">
                    [[stateObj.attributes.pressure]] [[getUnit('air_pressure')]]
                  </span>
                </div>
              </template>
              <template
                is="dom-if"
                if="[[_showValue(stateObj.attributes.humidity)]]"
              >
                <div>
                  [[localize('ui.card.weather.attributes.humidity')]]:
                  <span class="measurand"
                    >[[stateObj.attributes.humidity]] %</span
                  >
                </div>
              </template>
              <template
                is="dom-if"
                if="[[_showValue(stateObj.attributes.wind_speed)]]"
              >
                <div>
                  [[localize('ui.card.weather.attributes.wind_speed')]]:
                  <span class="measurand">
                    [[getWindSpeed(stateObj.attributes.wind_speed)]]
                  </span>
                  [[getWindBearing(stateObj.attributes.wind_bearing, localize)]]
                </div>
              </template>
            </div>
          </div>
          <template is="dom-if" if="[[forecast]]">
            <div class="forecast">
              <template is="dom-repeat" items="[[forecast]]">
                <div>
                  <div class="weekday">
                    [[computeDate(item.datetime)]]<br />
                    <template is="dom-if" if="[[!_showValue(item.templow)]]">
                      [[computeTime(item.datetime)]]
                    </template>
                  </div>
                  <template is="dom-if" if="[[_showValue(item.condition)]]">
                    <div class="icon">
                      <ha-icon
                        icon="[[getWeatherIcon(item.condition)]]"
                      ></ha-icon>
                    </div>
                  </template>
                  <div class="temp">
                    [[item.temperature]] [[getUnit('temperature')]]
                  </div>
                  <template is="dom-if" if="[[_showValue(item.templow)]]">
                    <div class="templow">
                      [[item.templow]] [[getUnit('temperature')]]
                    </div>
                  </template>
                  <template is="dom-if" if="[[_showValue(item.precipitation)]]">
                    <div class="precipitation">
                      [[item.precipitation]] [[getUnit('precipitation')]]
                    </div>
                  </template>
                </div>
              </template>
            </div>
          </template>
        </div>
      </ha-card>
    `}static get properties(){return{hass:Object,config:Object,stateObj:Object,forecast:{type:Array,computed:"computeForecast(stateObj.attributes.forecast)"},rtl:{type:Boolean,reflectToAttribute:!0,computed:"_computeRTL(hass)"}}}constructor(){super();this.cardinalDirections=["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW","N"];this.weatherIcons={"clear-night":"hass:weather-night",cloudy:"hass:weather-cloudy",fog:"hass:weather-fog",hail:"hass:weather-hail",lightning:"hass:weather-lightning","lightning-rainy":"hass:weather-lightning-rainy",partlycloudy:"hass:weather-partlycloudy",pouring:"hass:weather-pouring",rainy:"hass:weather-rainy",snowy:"hass:weather-snowy","snowy-rainy":"hass:weather-snowy-rainy",sunny:"hass:weather-sunny",windy:"hass:weather-windy","windy-variant":"hass:weather-windy-variant"}}ready(){this.addEventListener("click",this._onClick);super.ready()}_onClick(){this.fire("hass-more-info",{entityId:this.stateObj.entity_id})}computeForecast(forecast){return forecast&&forecast.slice(0,5)}getUnit(measure){const lengthUnit=this.hass.config.unit_system.length||"";switch(measure){case"air_pressure":return"km"===lengthUnit?"hPa":"inHg";case"length":return lengthUnit;case"precipitation":return"km"===lengthUnit?"mm":"in";default:return this.hass.config.unit_system[measure]||"";}}computeState(state,localize){return localize(`state.weather.${state}`)||state}computeName(stateObj){return this.config&&this.config.name||Object(_common_entity_compute_state_name__WEBPACK_IMPORTED_MODULE_2__.a)(stateObj)}showWeatherIcon(condition){return condition in this.weatherIcons}getWeatherIcon(condition){return this.weatherIcons[condition]}windBearingToText(degree){const degreenum=parseInt(degree);if(isFinite(degreenum)){return this.cardinalDirections[(0|(degreenum+11.25)/22.5)%16]}return degree}getWindSpeed(speed){return`${speed} ${this.getUnit("length")}/h`}getWindBearing(bearing,localize){if(null!=bearing){const cardinalDirection=this.windBearingToText(bearing);return`(${localize(`ui.card.weather.cardinal_direction.${cardinalDirection.toLowerCase()}`)||cardinalDirection})`}return``}_showValue(item){return"undefined"!==typeof item&&null!==item}computeDate(data){const date=new Date(data);return date.toLocaleDateString(this.hass.selectedLanguage||this.hass.language,{weekday:"short"})}computeTime(data){const date=new Date(data);return date.toLocaleTimeString(this.hass.selectedLanguage||this.hass.language,{hour:"numeric"})}_computeRTL(hass){return Object(_common_util_compute_rtl__WEBPACK_IMPORTED_MODULE_7__.a)(hass)}}customElements.define("ha-weather-card",HaWeatherCard)},271:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return extractViews});var _const__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(80);function extractViews(entities){const views=[];Object.keys(entities).forEach(entityId=>{const entity=entities[entityId];if(entity.attributes.view){views.push(entity)}});views.sort((view1,view2)=>{if(view1.entity_id===_const__WEBPACK_IMPORTED_MODULE_0__.c){return-1}if(view2.entity_id===_const__WEBPACK_IMPORTED_MODULE_0__.c){return 1}return view1.attributes.order-view2.attributes.order});return views}},272:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return getViewEntities});var _compute_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(157),_get_group_entities__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(248);function getViewEntities(entities,view){const viewEntities={};view.attributes.entity_id.forEach(entityId=>{const entity=entities[entityId];if(entity&&!entity.attributes.hidden){viewEntities[entity.entity_id]=entity;if("group"===Object(_compute_domain__WEBPACK_IMPORTED_MODULE_0__.a)(entity.entity_id)){const groupEntities=Object(_get_group_entities__WEBPACK_IMPORTED_MODULE_1__.a)(entities,entity);Object.keys(groupEntities).forEach(grEntityId=>{const grEntity=groupEntities[grEntityId];if(!grEntity.attributes.hidden){viewEntities[grEntityId]=grEntity}})}}});return viewEntities}},273:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return splitByGroups});var _compute_domain__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(157);function splitByGroups(entities){const groups=[],ungrouped={};Object.keys(entities).forEach(entityId=>{const entity=entities[entityId];if("group"===Object(_compute_domain__WEBPACK_IMPORTED_MODULE_0__.a)(entityId)){groups.push(entity)}else{ungrouped[entityId]=entity}});groups.forEach(group=>group.attributes.entity_id.forEach(entityId=>{delete ungrouped[entityId]}));return{groups,ungrouped}}},301:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return computeCardSize});const computeCardSize=card=>{return"function"===typeof card.getCardSize?card.getCardSize():1}},302:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return repeat});var _lit_html_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(31);/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */const createAndInsertPart=(containerPart,beforePart)=>{const container=containerPart.startNode.parentNode,beforeNode=beforePart===void 0?containerPart.endNode:beforePart.startNode,startNode=container.insertBefore(Object(_lit_html_js__WEBPACK_IMPORTED_MODULE_0__.e)(),beforeNode);container.insertBefore(Object(_lit_html_js__WEBPACK_IMPORTED_MODULE_0__.e)(),beforeNode);const newPart=new _lit_html_js__WEBPACK_IMPORTED_MODULE_0__.b(containerPart.options);newPart.insertAfterNode(startNode);return newPart},updatePart=(part,value)=>{part.setValue(value);part.commit();return part},insertPartBefore=(containerPart,part,ref)=>{const container=containerPart.startNode.parentNode,beforeNode=ref?ref.startNode:containerPart.endNode,endNode=part.endNode.nextSibling;if(endNode!==beforeNode){Object(_lit_html_js__WEBPACK_IMPORTED_MODULE_0__.j)(container,part.startNode,endNode,beforeNode)}},removePart=part=>{Object(_lit_html_js__WEBPACK_IMPORTED_MODULE_0__.i)(part.startNode.parentNode,part.startNode,part.endNode.nextSibling)},generateMap=(list,start,end)=>{const map=new Map;for(let i=start;i<=end;i++){map.set(list[i],i)}return map},partListCache=new WeakMap,keyListCache=new WeakMap;function repeat(items,keyFnOrTemplate,template){let keyFn;if(2===arguments.length){template=keyFnOrTemplate}else if(3===arguments.length){keyFn=keyFnOrTemplate}return Object(_lit_html_js__WEBPACK_IMPORTED_MODULE_0__.f)(containerPart=>{const oldParts=partListCache.get(containerPart)||[],oldKeys=keyListCache.get(containerPart)||[],newParts=[],newValues=[],newKeys=[];let index=0;for(const item of items){newKeys[index]=keyFn?keyFn(item,index):index;newValues[index]=template(item,index);index++}let newKeyToIndexMap,oldKeyToIndexMap,oldHead=0,oldTail=oldParts.length-1,newHead=0,newTail=newValues.length-1;while(oldHead<=oldTail&&newHead<=newTail){if(null===oldParts[oldHead]){oldHead++}else if(null===oldParts[oldTail]){oldTail--}else if(oldKeys[oldHead]===newKeys[newHead]){newParts[newHead]=updatePart(oldParts[oldHead],newValues[newHead]);oldHead++;newHead++}else if(oldKeys[oldTail]===newKeys[newTail]){newParts[newTail]=updatePart(oldParts[oldTail],newValues[newTail]);oldTail--;newTail--}else if(oldKeys[oldHead]===newKeys[newTail]){newParts[newTail]=updatePart(oldParts[oldHead],newValues[newTail]);insertPartBefore(containerPart,oldParts[oldHead],newParts[newTail+1]);oldHead++;newTail--}else if(oldKeys[oldTail]===newKeys[newHead]){newParts[newHead]=updatePart(oldParts[oldTail],newValues[newHead]);insertPartBefore(containerPart,oldParts[oldTail],oldParts[oldHead]);oldTail--;newHead++}else{if(newKeyToIndexMap===void 0){newKeyToIndexMap=generateMap(newKeys,newHead,newTail);oldKeyToIndexMap=generateMap(oldKeys,oldHead,oldTail)}if(!newKeyToIndexMap.has(oldKeys[oldHead])){removePart(oldParts[oldHead]);oldHead++}else if(!newKeyToIndexMap.has(oldKeys[oldTail])){removePart(oldParts[oldTail]);oldTail--}else{const oldIndex=oldKeyToIndexMap.get(newKeys[newHead]),oldPart=oldIndex!==void 0?oldParts[oldIndex]:null;if(null===oldPart){const newPart=createAndInsertPart(containerPart,oldParts[oldHead]);updatePart(newPart,newValues[newHead]);newParts[newHead]=newPart}else{newParts[newHead]=updatePart(oldPart,newValues[newHead]);insertPartBefore(containerPart,oldPart,oldParts[oldHead]);oldParts[oldIndex]=null}newHead++}}}while(newHead<=newTail){const newPart=createAndInsertPart(containerPart,newParts[newTail+1]);updatePart(newPart,newValues[newHead]);newParts[newHead++]=newPart}while(oldHead<=oldTail){const oldPart=oldParts[oldHead++];if(null!==oldPart){removePart(oldPart)}}partListCache.set(containerPart,newParts);keyListCache.set(containerPart,newKeys)})}},322:function(module,__webpack_exports__,__webpack_require__){"use strict";var _Mathround3=Math.round,_Mathmin=Math.min,_Mathmax3=Math.max,_Mathfloor3=Math.floor,fire_event=__webpack_require__(65),lit_element=__webpack_require__(57),classMap=__webpack_require__(192);const callAlarmAction=(hass,entity,action,code)=>{hass.callService("alarm_control_panel","alarm_"+action,{entity_id:entity,code})};var lit_localize_mixin=__webpack_require__(154),ha_card=__webpack_require__(168),ha_label_badge=__webpack_require__(232),hui_error_card=__webpack_require__(233);const ICONS={armed_away:"hass:security-lock",armed_custom_bypass:"hass:security",armed_home:"hass:security-home",armed_night:"hass:security-home",disarmed:"hass:verified",pending:"hass:shield-outline",triggered:"hass:bell-ring"},BUTTONS=["1","2","3","4","5","6","7","8","9","","0","clear"];class hui_alarm_panel_card_HuiAlarmPanelCard extends Object(lit_localize_mixin.a)(lit_element.a){static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(107),__webpack_require__.e(65)]).then(__webpack_require__.bind(null,731));return document.createElement("hui-alarm-panel-card-editor")}static getStubConfig(){return{states:["arm_home","arm_away"]}}static get properties(){return{hass:{},_config:{},_code:{}}}getCardSize(){return 4}setConfig(config){if(!config||!config.entity||"alarm_control_panel"!==config.entity.split(".")[0]){throw new Error("Invalid card configuration")}this._config=Object.assign({},{states:["arm_away","arm_home"]},config);this._code=""}shouldUpdate(changedProps){if(changedProps.has("_config")||changedProps.has("_code")){return!0}const oldHass=changedProps.get("hass");if(oldHass){return oldHass.states[this._config.entity]!==this.hass.states[this._config.entity]}return!0}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){const element=Object(hui_error_card.b)(Object(hui_error_card.a)("Entity not Found!",this._config));return lit_element.c`
        ${element}
      `}return lit_element.c`
      ${this.renderStyle()}
      <ha-card .header="${this._config.name||this._label(stateObj.state)}">
        <ha-label-badge
          class="${Object(classMap.a)({[stateObj.state]:!0})}"
          .icon="${ICONS[stateObj.state]||"hass:shield-outline"}"
          .label="${this._stateIconLabel(stateObj.state)}"
        ></ha-label-badge>
        <div id="armActions" class="actions">
          ${("disarmed"===stateObj.state?this._config.states:["disarm"]).map(state=>{return lit_element.c`
                <paper-button
                  noink
                  raised
                  .action="${state}"
                  @click="${this._handleActionClick}"
                  >${this._label(state)}</paper-button
                >
              `})}
        </div>
        ${!stateObj.attributes.code_format?lit_element.c``:lit_element.c`
                <paper-input
                  label="Alarm Code"
                  type="password"
                  .value="${this._code}"
                ></paper-input>
              `}
        ${"Number"!==stateObj.attributes.code_format?lit_element.c``:lit_element.c`
                <div id="keypad">
                  ${BUTTONS.map(value=>{return""===value?lit_element.c`
                            <paper-button disabled></paper-button>
                          `:lit_element.c`
                            <paper-button
                              noink
                              raised
                              .value="${value}"
                              @click="${this._handlePadClick}"
                              >${"clear"===value?this._label("clear_code"):value}</paper-button
                            >
                          `})}
                </div>
              `}
      </ha-card>
    `}_stateIconLabel(state){const stateLabel=state.split("_").pop();return"disarmed"===stateLabel||"triggered"===stateLabel||!stateLabel?"":stateLabel}_label(state){return this.localize(`state.alarm_control_panel.${state}`)||this.localize(`ui.card.alarm_control_panel.${state}`)}_handlePadClick(e){const val=e.currentTarget.value;this._code="clear"===val?"":this._code+val}_handleActionClick(e){callAlarmAction(this.hass,this._config.entity_id,e.currentTarget.action,this._code);this._code=""}renderStyle(){return lit_element.c`
      <style>
        ha-card {
          padding-bottom: 16px;
          position: relative;
          --alarm-color-disarmed: var(--label-badge-green);
          --alarm-color-pending: var(--label-badge-yellow);
          --alarm-color-triggered: var(--label-badge-red);
          --alarm-color-armed: var(--label-badge-red);
          --alarm-color-autoarm: rgba(0, 153, 255, 0.1);
          --alarm-state-color: var(--alarm-color-armed);
          --base-unit: 15px;
          font-size: calc(var(--base-unit));
        }
        ha-label-badge {
          --ha-label-badge-color: var(--alarm-state-color);
          --label-badge-text-color: var(--alarm-state-color);
          --label-badge-background-color: var(--paper-card-background-color);
          color: var(--alarm-state-color);
          position: absolute;
          right: 12px;
          top: 12px;
        }
        .disarmed {
          --alarm-state-color: var(--alarm-color-disarmed);
        }
        .triggered {
          --alarm-state-color: var(--alarm-color-triggered);
          animation: pulse 1s infinite;
        }
        .arming {
          --alarm-state-color: var(--alarm-color-pending);
          animation: pulse 1s infinite;
        }
        .pending {
          --alarm-state-color: var(--alarm-color-pending);
          animation: pulse 1s infinite;
        }
        @keyframes pulse {
          0% {
            --ha-label-badge-color: var(--alarm-state-color);
          }
          100% {
            --ha-label-badge-color: rgba(255, 153, 0, 0.3);
          }
        }
        paper-input {
          margin: 0 auto 8px;
          max-width: 150px;
          font-size: calc(var(--base-unit));
          text-align: center;
        }
        .state {
          margin-left: 16px;
          font-size: calc(var(--base-unit) * 0.9);
          position: relative;
          bottom: 16px;
          color: var(--alarm-state-color);
          animation: none;
        }
        #keypad {
          display: flex;
          justify-content: center;
          flex-wrap: wrap;
          margin: auto;
          width: 300px;
        }
        #keypad paper-button {
          margin-bottom: 5%;
          width: 30%;
          padding: calc(var(--base-unit));
          font-size: calc(var(--base-unit) * 1.1);
        }
        .actions {
          margin: 0 8px;
          padding-top: 20px;
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          font-size: calc(var(--base-unit) * 1);
        }
        .actions paper-button {
          min-width: calc(var(--base-unit) * 9);
          color: var(--primary-color);
        }
        paper-button#disarm {
          color: var(--google-red-500);
        }
      </style>
    `}}customElements.define("hui-alarm-panel-card",hui_alarm_panel_card_HuiAlarmPanelCard);var compute_card_size=__webpack_require__(301);class hui_conditional_card_HuiConditionalCard extends HTMLElement{setConfig(config){if(!config.card||!config.conditions||!Array.isArray(config.conditions)||!config.conditions.every(c=>c.entity&&(c.state||c.state_not))){throw new Error("Error in card configuration.")}if(this._card&&this._card.parentElement){this.removeChild(this._card)}this._config=config;this._card=createCardElement(config.card);if(this._hass){this.hass=this._hass}}set hass(hass){this._hass=hass;if(!this._card){return}const visible=this._config&&this._config.conditions.every(c=>{if(!(c.entity in hass.states)){return!1}if(c.state){return hass.states[c.entity].state===c.state}return hass.states[c.entity].state!==c.state_not});if(visible){this._card.hass=hass;if(!this._card.parentElement){this.appendChild(this._card)}}else if(this._card.parentElement){this.removeChild(this._card)}this.style.setProperty("display",visible?"":"none")}getCardSize(){return Object(compute_card_size.a)(this._card)}}customElements.define("hui-conditional-card",hui_conditional_card_HuiConditionalCard);var hui_entities_card=__webpack_require__(439),lit_html=__webpack_require__(31);/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */const styleMapCache=new WeakMap,styleMapStatics=new WeakMap,styleMap=styleInfo=>Object(lit_html.f)(part=>{if(!(part instanceof lit_html.a)||part instanceof lit_html.c||"style"!==part.committer.name||1<part.committer.parts.length){throw new Error("The `styleMap` directive must be used in the style attribute "+"and must be the only part in the attribute.")}if(!styleMapStatics.has(part)){part.committer.element.style.cssText=part.committer.strings.join(" ");styleMapStatics.set(part,!0)}const oldInfo=styleMapCache.get(part);for(const name in oldInfo){if(!(name in styleInfo)){part.committer.element.style[name]=null}}Object.assign(part.committer.element.style,styleInfo);styleMapCache.set(part,styleInfo)});var valid_entity_id=__webpack_require__(327),state_icon=__webpack_require__(175),compute_state_domain=__webpack_require__(153),compute_state_name=__webpack_require__(105),apply_themes_on_element=__webpack_require__(114);/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */class MDCFoundation{static get cssClasses(){return{}}static get strings(){return{}}static get numbers(){return{}}static get defaultAdapter(){return{}}constructor(adapter={}){this.adapter_=adapter}init(){}destroy(){}}/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *//**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */const cssClasses={ROOT:"mdc-ripple-upgraded",UNBOUNDED:"mdc-ripple-upgraded--unbounded",BG_FOCUSED:"mdc-ripple-upgraded--background-focused",FG_ACTIVATION:"mdc-ripple-upgraded--foreground-activation",FG_DEACTIVATION:"mdc-ripple-upgraded--foreground-deactivation"},strings={VAR_LEFT:"--mdc-ripple-left",VAR_TOP:"--mdc-ripple-top",VAR_FG_SIZE:"--mdc-ripple-fg-size",VAR_FG_SCALE:"--mdc-ripple-fg-scale",VAR_FG_TRANSLATE_START:"--mdc-ripple-fg-translate-start",VAR_FG_TRANSLATE_END:"--mdc-ripple-fg-translate-end"},numbers={PADDING:10,INITIAL_ORIGIN_SCALE:.6,DEACTIVATION_TIMEOUT_MS:225,FG_DEACTIVATION_MS:150,TAP_DELAY_MS:300};/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */let supportsCssVariables_,supportsPassive_;function detectEdgePseudoVarBug(windowObj){const document=windowObj.document,node=document.createElement("div");node.className="mdc-ripple-surface--test-edge-var-bug";document.body.appendChild(node);const computedStyle=windowObj.getComputedStyle(node),hasPseudoVarBug=null!==computedStyle&&"solid"===computedStyle.borderTopStyle;node.remove();return hasPseudoVarBug}function supportsCssVariables(windowObj,forceRefresh=!1){let supportsCssVariables=supportsCssVariables_;if("boolean"===typeof supportsCssVariables_&&!forceRefresh){return supportsCssVariables}const supportsFunctionPresent=windowObj.CSS&&"function"===typeof windowObj.CSS.supports;if(!supportsFunctionPresent){return}const explicitlySupportsCssVars=windowObj.CSS.supports("--css-vars","yes"),weAreFeatureDetectingSafari10plus=windowObj.CSS.supports("(--css-vars: yes)")&&windowObj.CSS.supports("color","#00000000");if(explicitlySupportsCssVars||weAreFeatureDetectingSafari10plus){supportsCssVariables=!detectEdgePseudoVarBug(windowObj)}else{supportsCssVariables=!1}if(!forceRefresh){supportsCssVariables_=supportsCssVariables}return supportsCssVariables}function applyPassive(globalObj=window,forceRefresh=!1){if(supportsPassive_===void 0||forceRefresh){let isSupported=!1;try{globalObj.document.addEventListener("test",null,{get passive(){isSupported=!0;return isSupported}})}catch(e){}supportsPassive_=isSupported}return supportsPassive_?{passive:!0}:!1}function getMatchesProperty(HTMLElementPrototype){const matchesMethods=["matches","webkitMatchesSelector","msMatchesSelector"];let method="matches";for(let i=0;i<matchesMethods.length;i++){const matchesMethod=matchesMethods[i];if(matchesMethod in HTMLElementPrototype){method=matchesMethod;break}}return method}function getNormalizedEventCoords(ev,pageOffset,clientRect){const{x,y}=pageOffset,documentX=x+clientRect.left,documentY=y+clientRect.top;let normalizedX,normalizedY;if("touchstart"===ev.type){ev=ev;normalizedX=ev.changedTouches[0].pageX-documentX;normalizedY=ev.changedTouches[0].pageY-documentY}else{ev=ev;normalizedX=ev.pageX-documentX;normalizedY=ev.pageY-documentY}return{x:normalizedX,y:normalizedY}}/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */const ACTIVATION_EVENT_TYPES=["touchstart","pointerdown","mousedown","keydown"],POINTER_DEACTIVATION_EVENT_TYPES=["touchend","pointerup","mouseup"];let activatedTargets=[];class foundation_MDCRippleFoundation extends MDCFoundation{static get cssClasses(){return cssClasses}static get strings(){return strings}static get numbers(){return numbers}static get defaultAdapter(){return{browserSupportsCssVars:()=>{},isUnbounded:()=>{},isSurfaceActive:()=>{},isSurfaceDisabled:()=>{},addClass:()=>{},removeClass:()=>{},containsEventTarget:()=>{},registerInteractionHandler:()=>{},deregisterInteractionHandler:()=>{},registerDocumentInteractionHandler:()=>{},deregisterDocumentInteractionHandler:()=>{},registerResizeHandler:()=>{},deregisterResizeHandler:()=>{},updateCssVariable:()=>{},computeBoundingRect:()=>{},getWindowPageOffset:()=>{}}}constructor(adapter){super(Object.assign(foundation_MDCRippleFoundation.defaultAdapter,adapter));this.layoutFrame_=0;this.frame_={width:0,height:0};this.activationState_=this.defaultActivationState_();this.initialSize_=0;this.maxRadius_=0;this.activateHandler_=e=>this.activate_(e);this.deactivateHandler_=()=>this.deactivate_();this.focusHandler_=()=>this.handleFocus();this.blurHandler_=()=>this.handleBlur();this.resizeHandler_=()=>this.layout();this.unboundedCoords_={left:0,top:0};this.fgScale_=0;this.activationTimer_=0;this.fgDeactivationRemovalTimer_=0;this.activationAnimationHasEnded_=!1;this.activationTimerCallback_=()=>{this.activationAnimationHasEnded_=!0;this.runDeactivationUXLogicIfReady_()};this.previousActivationEvent_}supportsPressRipple_(){return this.adapter_.browserSupportsCssVars()}defaultActivationState_(){return{isActivated:!1,hasDeactivationUXRun:!1,wasActivatedByPointer:!1,wasElementMadeActive:!1,activationEvent:void 0,isProgrammatic:!1}}init(){const supportsPressRipple=this.supportsPressRipple_();this.registerRootHandlers_(supportsPressRipple);if(supportsPressRipple){const{ROOT,UNBOUNDED}=foundation_MDCRippleFoundation.cssClasses;requestAnimationFrame(()=>{this.adapter_.addClass(ROOT);if(this.adapter_.isUnbounded()){this.adapter_.addClass(UNBOUNDED);this.layoutInternal_()}})}}destroy(){if(this.supportsPressRipple_()){if(this.activationTimer_){clearTimeout(this.activationTimer_);this.activationTimer_=0;this.adapter_.removeClass(foundation_MDCRippleFoundation.cssClasses.FG_ACTIVATION)}if(this.fgDeactivationRemovalTimer_){clearTimeout(this.fgDeactivationRemovalTimer_);this.fgDeactivationRemovalTimer_=0;this.adapter_.removeClass(foundation_MDCRippleFoundation.cssClasses.FG_DEACTIVATION)}const{ROOT,UNBOUNDED}=foundation_MDCRippleFoundation.cssClasses;requestAnimationFrame(()=>{this.adapter_.removeClass(ROOT);this.adapter_.removeClass(UNBOUNDED);this.removeCssVars_()})}this.deregisterRootHandlers_();this.deregisterDeactivationHandlers_()}registerRootHandlers_(supportsPressRipple){if(supportsPressRipple){ACTIVATION_EVENT_TYPES.forEach(type=>{this.adapter_.registerInteractionHandler(type,this.activateHandler_)});if(this.adapter_.isUnbounded()){this.adapter_.registerResizeHandler(this.resizeHandler_)}}this.adapter_.registerInteractionHandler("focus",this.focusHandler_);this.adapter_.registerInteractionHandler("blur",this.blurHandler_)}registerDeactivationHandlers_(e){if("keydown"===e.type){this.adapter_.registerInteractionHandler("keyup",this.deactivateHandler_)}else{POINTER_DEACTIVATION_EVENT_TYPES.forEach(type=>{this.adapter_.registerDocumentInteractionHandler(type,this.deactivateHandler_)})}}deregisterRootHandlers_(){ACTIVATION_EVENT_TYPES.forEach(type=>{this.adapter_.deregisterInteractionHandler(type,this.activateHandler_)});this.adapter_.deregisterInteractionHandler("focus",this.focusHandler_);this.adapter_.deregisterInteractionHandler("blur",this.blurHandler_);if(this.adapter_.isUnbounded()){this.adapter_.deregisterResizeHandler(this.resizeHandler_)}}deregisterDeactivationHandlers_(){this.adapter_.deregisterInteractionHandler("keyup",this.deactivateHandler_);POINTER_DEACTIVATION_EVENT_TYPES.forEach(type=>{this.adapter_.deregisterDocumentInteractionHandler(type,this.deactivateHandler_)})}removeCssVars_(){const{strings}=foundation_MDCRippleFoundation;Object.keys(strings).forEach(k=>{if(0===k.indexOf("VAR_")){this.adapter_.updateCssVariable(strings[k],null)}})}activate_(e){if(this.adapter_.isSurfaceDisabled()){return}const activationState=this.activationState_;if(activationState.isActivated){return}const previousActivationEvent=this.previousActivationEvent_,isSameInteraction=previousActivationEvent&&e!==void 0&&previousActivationEvent.type!==e.type;if(isSameInteraction){return}activationState.isActivated=!0;activationState.isProgrammatic=e===void 0;activationState.activationEvent=e;activationState.wasActivatedByPointer=activationState.isProgrammatic?!1:e!==void 0&&("mousedown"===e.type||"touchstart"===e.type||"pointerdown"===e.type);const hasActivatedChild=e!==void 0&&0<activatedTargets.length&&activatedTargets.some(target=>this.adapter_.containsEventTarget(target));if(hasActivatedChild){this.resetActivationState_();return}if(e!==void 0){activatedTargets.push(e.target);this.registerDeactivationHandlers_(e)}activationState.wasElementMadeActive=this.checkElementMadeActive_(e);if(activationState.wasElementMadeActive){this.animateActivation_()}requestAnimationFrame(()=>{activatedTargets=[];if(!activationState.wasElementMadeActive&&e!==void 0&&(" "===e.key||32===e.keyCode)){activationState.wasElementMadeActive=this.checkElementMadeActive_(e);if(activationState.wasElementMadeActive){this.animateActivation_()}}if(!activationState.wasElementMadeActive){this.activationState_=this.defaultActivationState_()}})}checkElementMadeActive_(e){return e!==void 0&&"keydown"===e.type?this.adapter_.isSurfaceActive():!0}activate(event){this.activate_(event)}animateActivation_(){const{VAR_FG_TRANSLATE_START,VAR_FG_TRANSLATE_END}=foundation_MDCRippleFoundation.strings,{FG_DEACTIVATION,FG_ACTIVATION}=foundation_MDCRippleFoundation.cssClasses,{DEACTIVATION_TIMEOUT_MS}=foundation_MDCRippleFoundation.numbers;this.layoutInternal_();let translateStart="",translateEnd="";if(!this.adapter_.isUnbounded()){const{startPoint,endPoint}=this.getFgTranslationCoordinates_();translateStart=`${startPoint.x}px, ${startPoint.y}px`;translateEnd=`${endPoint.x}px, ${endPoint.y}px`}this.adapter_.updateCssVariable(VAR_FG_TRANSLATE_START,translateStart);this.adapter_.updateCssVariable(VAR_FG_TRANSLATE_END,translateEnd);clearTimeout(this.activationTimer_);clearTimeout(this.fgDeactivationRemovalTimer_);this.rmBoundedActivationClasses_();this.adapter_.removeClass(FG_DEACTIVATION);this.adapter_.computeBoundingRect();this.adapter_.addClass(FG_ACTIVATION);this.activationTimer_=setTimeout(()=>this.activationTimerCallback_(),DEACTIVATION_TIMEOUT_MS)}getFgTranslationCoordinates_(){const{activationEvent,wasActivatedByPointer}=this.activationState_;let startPoint;if(wasActivatedByPointer){startPoint=getNormalizedEventCoords(activationEvent,this.adapter_.getWindowPageOffset(),this.adapter_.computeBoundingRect())}else{startPoint={x:this.frame_.width/2,y:this.frame_.height/2}}startPoint={x:startPoint.x-this.initialSize_/2,y:startPoint.y-this.initialSize_/2};const endPoint={x:this.frame_.width/2-this.initialSize_/2,y:this.frame_.height/2-this.initialSize_/2};return{startPoint,endPoint}}runDeactivationUXLogicIfReady_(){const{FG_DEACTIVATION}=foundation_MDCRippleFoundation.cssClasses,{hasDeactivationUXRun,isActivated}=this.activationState_;if((hasDeactivationUXRun||!isActivated)&&this.activationAnimationHasEnded_){this.rmBoundedActivationClasses_();this.adapter_.addClass(FG_DEACTIVATION);this.fgDeactivationRemovalTimer_=setTimeout(()=>{this.adapter_.removeClass(FG_DEACTIVATION)},numbers.FG_DEACTIVATION_MS)}}rmBoundedActivationClasses_(){const{FG_ACTIVATION}=foundation_MDCRippleFoundation.cssClasses;this.adapter_.removeClass(FG_ACTIVATION);this.activationAnimationHasEnded_=!1;this.adapter_.computeBoundingRect()}resetActivationState_(){this.previousActivationEvent_=this.activationState_.activationEvent;this.activationState_=this.defaultActivationState_();setTimeout(()=>this.previousActivationEvent_=void 0,foundation_MDCRippleFoundation.numbers.TAP_DELAY_MS)}deactivate_(){const activationState=this.activationState_;if(!activationState.isActivated){return}const state=Object.assign({},activationState);if(activationState.isProgrammatic){requestAnimationFrame(()=>this.animateDeactivation_(state));this.resetActivationState_()}else{this.deregisterDeactivationHandlers_();requestAnimationFrame(()=>{this.activationState_.hasDeactivationUXRun=!0;this.animateDeactivation_(state);this.resetActivationState_()})}}deactivate(){this.deactivate_()}animateDeactivation_({wasActivatedByPointer,wasElementMadeActive}){if(wasActivatedByPointer||wasElementMadeActive){this.runDeactivationUXLogicIfReady_()}}layout(){if(this.layoutFrame_){cancelAnimationFrame(this.layoutFrame_)}this.layoutFrame_=requestAnimationFrame(()=>{this.layoutInternal_();this.layoutFrame_=0})}layoutInternal_(){this.frame_=this.adapter_.computeBoundingRect();const maxDim=_Mathmax3(this.frame_.height,this.frame_.width);this.maxRadius_=this.adapter_.isUnbounded()?maxDim:(()=>{var _Mathpow=Math.pow;const hypotenuse=Math.sqrt(_Mathpow(this.frame_.width,2)+_Mathpow(this.frame_.height,2));return hypotenuse+foundation_MDCRippleFoundation.numbers.PADDING})();this.initialSize_=_Mathfloor3(maxDim*foundation_MDCRippleFoundation.numbers.INITIAL_ORIGIN_SCALE);this.fgScale_=this.maxRadius_/this.initialSize_;this.updateLayoutCssVars_()}updateLayoutCssVars_(){const{VAR_FG_SIZE,VAR_LEFT,VAR_TOP,VAR_FG_SCALE}=foundation_MDCRippleFoundation.strings;this.adapter_.updateCssVariable(VAR_FG_SIZE,`${this.initialSize_}px`);this.adapter_.updateCssVariable(VAR_FG_SCALE,this.fgScale_);if(this.adapter_.isUnbounded()){this.unboundedCoords_={left:_Mathround3(this.frame_.width/2-this.initialSize_/2),top:_Mathround3(this.frame_.height/2-this.initialSize_/2)};this.adapter_.updateCssVariable(VAR_LEFT,`${this.unboundedCoords_.left}px`);this.adapter_.updateCssVariable(VAR_TOP,`${this.unboundedCoords_.top}px`)}}setUnbounded(unbounded){const{UNBOUNDED}=foundation_MDCRippleFoundation.cssClasses;if(unbounded){this.adapter_.addClass(UNBOUNDED)}else{this.adapter_.removeClass(UNBOUNDED)}}handleFocus(){requestAnimationFrame(()=>this.adapter_.addClass(foundation_MDCRippleFoundation.cssClasses.BG_FOCUSED))}handleBlur(){requestAnimationFrame(()=>this.adapter_.removeClass(foundation_MDCRippleFoundation.cssClasses.BG_FOCUSED))}}/**
@license
Copyright 2018 Google Inc. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/const style=lit_element.c`<style>@keyframes mdc-ripple-fg-radius-in{from{animation-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transform:translate(var(--mdc-ripple-fg-translate-start, 0)) scale(1)}to{transform:translate(var(--mdc-ripple-fg-translate-end, 0)) scale(var(--mdc-ripple-fg-scale, 1))}}@keyframes mdc-ripple-fg-opacity-in{from{animation-timing-function:linear;opacity:0}to{opacity:var(--mdc-ripple-fg-opacity, 0)}}@keyframes mdc-ripple-fg-opacity-out{from{animation-timing-function:linear;opacity:var(--mdc-ripple-fg-opacity, 0)}to{opacity:0}}</style>`,MATCHES=getMatchesProperty(HTMLElement.prototype),ripple_directive_supportsCssVariables=supportsCssVariables(window),isSafari=navigator.userAgent.match(/Safari/);/**
@license
Copyright 2018 Google Inc. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/let didApplyRippleStyle=!1;const applyRippleStyle=()=>{didApplyRippleStyle=!0;const part=new lit_html.b({templateFactory:lit_html.l});part.appendInto(document.head);part.setValue(style);part.commit()},rippleNode=options=>{if(isSafari&&!didApplyRippleStyle){applyRippleStyle()}const surfaceNode=options.surfaceNode,interactionNode=options.interactionNode||surfaceNode;if(interactionNode.getRootNode()!==surfaceNode.getRootNode()){if(""===interactionNode.style.position){interactionNode.style.position="relative"}}const rippleFoundation=new foundation_MDCRippleFoundation({browserSupportsCssVars:()=>ripple_directive_supportsCssVariables,isUnbounded:()=>options.unbounded===void 0?!0:options.unbounded,isSurfaceActive:()=>interactionNode[MATCHES](":active"),isSurfaceDisabled:()=>!!options.disabled,addClass:className=>surfaceNode.classList.add(className),removeClass:className=>surfaceNode.classList.remove(className),containsEventTarget:target=>interactionNode.contains(target),registerInteractionHandler:(type,handler)=>interactionNode.addEventListener(type,handler,applyPassive()),deregisterInteractionHandler:(type,handler)=>interactionNode.removeEventListener(type,handler,applyPassive()),registerDocumentInteractionHandler:(evtType,handler)=>document.documentElement.addEventListener(evtType,handler,applyPassive()),deregisterDocumentInteractionHandler:(evtType,handler)=>document.documentElement.removeEventListener(evtType,handler,applyPassive()),registerResizeHandler:handler=>window.addEventListener("resize",handler),deregisterResizeHandler:handler=>window.removeEventListener("resize",handler),updateCssVariable:(varName,value)=>surfaceNode.style.setProperty(varName,value),computeBoundingRect:()=>interactionNode.getBoundingClientRect(),getWindowPageOffset:()=>({x:window.pageXOffset,y:window.pageYOffset})});rippleFoundation.init();return rippleFoundation},rippleInteractionNodes=new WeakMap,ripple=(options={})=>Object(lit_html.f)(part=>{const surfaceNode=part.committer.element,interactionNode=options.interactionNode||surfaceNode;let rippleFoundation=part.value;const existingInteractionNode=rippleInteractionNodes.get(rippleFoundation);if(existingInteractionNode!==void 0&&existingInteractionNode!==interactionNode){rippleFoundation.destroy();rippleFoundation=lit_html.h}if(rippleFoundation===lit_html.h){rippleFoundation=rippleNode(Object.assign({},options,{surfaceNode}));rippleInteractionNodes.set(rippleFoundation,interactionNode);part.setValue(rippleFoundation)}else{if(options.unbounded!==void 0){rippleFoundation.setUnbounded(options.unbounded)}if(options.disabled!==void 0){rippleFoundation.setUnbounded(options.disabled)}}if(!0===options.active){rippleFoundation.activate()}else if(!1===options.active){rippleFoundation.deactivate()}}),mwc_ripple_css_style=lit_element.c`<style>@keyframes mdc-ripple-fg-radius-in{from{animation-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transform:translate(var(--mdc-ripple-fg-translate-start, 0)) scale(1)}to{transform:translate(var(--mdc-ripple-fg-translate-end, 0)) scale(var(--mdc-ripple-fg-scale, 1))}}@keyframes mdc-ripple-fg-opacity-in{from{animation-timing-function:linear;opacity:0}to{opacity:var(--mdc-ripple-fg-opacity, 0)}}@keyframes mdc-ripple-fg-opacity-out{from{animation-timing-function:linear;opacity:var(--mdc-ripple-fg-opacity, 0)}to{opacity:0}}.mdc-ripple-surface--test-edge-var-bug{--mdc-ripple-surface-test-edge-var: 1px solid #000;visibility:hidden}.mdc-ripple-surface--test-edge-var-bug::before{border:var(--mdc-ripple-surface-test-edge-var)}.mdc-ripple-surface{--mdc-ripple-fg-size: 0;--mdc-ripple-left: 0;--mdc-ripple-top: 0;--mdc-ripple-fg-scale: 1;--mdc-ripple-fg-translate-end: 0;--mdc-ripple-fg-translate-start: 0;-webkit-tap-highlight-color:rgba(0,0,0,0);will-change:transform,opacity;position:relative;outline:none;overflow:hidden}.mdc-ripple-surface::before,.mdc-ripple-surface::after{position:absolute;border-radius:50%;opacity:0;pointer-events:none;content:""}.mdc-ripple-surface::before{transition:opacity 15ms linear;z-index:1}.mdc-ripple-surface.mdc-ripple-upgraded::before{transform:scale(var(--mdc-ripple-fg-scale, 1))}.mdc-ripple-surface.mdc-ripple-upgraded::after{top:0;left:0;transform:scale(0);transform-origin:center center}.mdc-ripple-surface.mdc-ripple-upgraded--unbounded::after{top:var(--mdc-ripple-top, 0);left:var(--mdc-ripple-left, 0)}.mdc-ripple-surface.mdc-ripple-upgraded--foreground-activation::after{animation:225ms mdc-ripple-fg-radius-in forwards,75ms mdc-ripple-fg-opacity-in forwards}.mdc-ripple-surface.mdc-ripple-upgraded--foreground-deactivation::after{animation:150ms mdc-ripple-fg-opacity-out;transform:translate(var(--mdc-ripple-fg-translate-end, 0)) scale(var(--mdc-ripple-fg-scale, 1))}.mdc-ripple-surface::before,.mdc-ripple-surface::after{background-color:#000}.mdc-ripple-surface:hover::before{opacity:.04}.mdc-ripple-surface:not(.mdc-ripple-upgraded):focus::before,.mdc-ripple-surface.mdc-ripple-upgraded--background-focused::before{transition-duration:75ms;opacity:.12}.mdc-ripple-surface:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:.16}.mdc-ripple-surface.mdc-ripple-upgraded{--mdc-ripple-fg-opacity: 0.16}.mdc-ripple-surface::before,.mdc-ripple-surface::after{top:calc(50% - 100%);left:calc(50% - 100%);width:200%;height:200%}.mdc-ripple-surface.mdc-ripple-upgraded::after{width:var(--mdc-ripple-fg-size, 100%);height:var(--mdc-ripple-fg-size, 100%)}.mdc-ripple-surface[data-mdc-ripple-is-unbounded]{overflow:visible}.mdc-ripple-surface[data-mdc-ripple-is-unbounded]::before,.mdc-ripple-surface[data-mdc-ripple-is-unbounded]::after{top:calc(50% - 50%);left:calc(50% - 50%);width:100%;height:100%}.mdc-ripple-surface[data-mdc-ripple-is-unbounded].mdc-ripple-upgraded::before,.mdc-ripple-surface[data-mdc-ripple-is-unbounded].mdc-ripple-upgraded::after{top:var(--mdc-ripple-top, calc(50% - 50%));left:var(--mdc-ripple-left, calc(50% - 50%));width:var(--mdc-ripple-fg-size, 100%);height:var(--mdc-ripple-fg-size, 100%)}.mdc-ripple-surface[data-mdc-ripple-is-unbounded].mdc-ripple-upgraded::after{width:var(--mdc-ripple-fg-size, 100%);height:var(--mdc-ripple-fg-size, 100%)}.mdc-ripple-surface--primary::before,.mdc-ripple-surface--primary::after{background-color:#6200ee}@supports not (-ms-ime-align: auto){.mdc-ripple-surface--primary::before,.mdc-ripple-surface--primary::after{background-color:var(--mdc-theme-primary, #6200ee)}}.mdc-ripple-surface--primary:hover::before{opacity:.04}.mdc-ripple-surface--primary:not(.mdc-ripple-upgraded):focus::before,.mdc-ripple-surface--primary.mdc-ripple-upgraded--background-focused::before{transition-duration:75ms;opacity:.12}.mdc-ripple-surface--primary:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--primary:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:.16}.mdc-ripple-surface--primary.mdc-ripple-upgraded{--mdc-ripple-fg-opacity: 0.16}.mdc-ripple-surface--accent::before,.mdc-ripple-surface--accent::after{background-color:#018786}@supports not (-ms-ime-align: auto){.mdc-ripple-surface--accent::before,.mdc-ripple-surface--accent::after{background-color:var(--mdc-theme-secondary, #018786)}}.mdc-ripple-surface--accent:hover::before{opacity:.04}.mdc-ripple-surface--accent:not(.mdc-ripple-upgraded):focus::before,.mdc-ripple-surface--accent.mdc-ripple-upgraded--background-focused::before{transition-duration:75ms;opacity:.12}.mdc-ripple-surface--accent:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-ripple-surface--accent:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:.16}.mdc-ripple-surface--accent.mdc-ripple-upgraded{--mdc-ripple-fg-opacity: 0.16}.mdc-ripple-surface{pointer-events:none;position:absolute;top:0;right:0;bottom:0;left:0}</style>`;/**
@license
Copyright 2018 Google Inc. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/var __decorate=void 0||function(decorators,target,key,desc){var c=arguments.length,r=3>c?target:null===desc?desc=Object.getOwnPropertyDescriptor(target,key):desc,d;if("object"===typeof Reflect&&"function"===typeof Reflect.decorate)r=Reflect.decorate(decorators,target,key,desc);else for(var i=decorators.length-1;0<=i;i--)if(d=decorators[i])r=(3>c?d(r):3<c?d(target,key,r):d(target,key))||r;return 3<c&&r&&Object.defineProperty(target,key,r),r};/**
@license
Copyright 2018 Google Inc. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/let mwc_ripple_Ripple=class extends lit_element.a{constructor(){super(...arguments);this.primary=!1;this.accent=!1;this.unbounded=!1;this.disabled=!1;this.interactionNode=this}renderStyle(){return mwc_ripple_css_style}connectedCallback(){this.interactionNode=this.parentNode}render(){const classes={"mdc-ripple-surface--primary":this.primary,"mdc-ripple-surface--accent":this.accent},{disabled,unbounded,active,interactionNode}=this,rippleOptions={disabled,unbounded,interactionNode};if(active!==void 0){rippleOptions.active=active}return lit_element.c`
      ${this.renderStyle()}
      <div .ripple="${ripple(rippleOptions)}"
          class="mdc-ripple-surface ${Object(classMap.a)(classes)}"></div>`}};__decorate([Object(lit_element.d)({type:Boolean})],mwc_ripple_Ripple.prototype,"primary",void 0);__decorate([Object(lit_element.d)({type:Boolean})],mwc_ripple_Ripple.prototype,"active",void 0);__decorate([Object(lit_element.d)({type:Boolean})],mwc_ripple_Ripple.prototype,"accent",void 0);__decorate([Object(lit_element.d)({type:Boolean})],mwc_ripple_Ripple.prototype,"unbounded",void 0);__decorate([Object(lit_element.d)({type:Boolean})],mwc_ripple_Ripple.prototype,"disabled",void 0);__decorate([Object(lit_element.d)()],mwc_ripple_Ripple.prototype,"interactionNode",void 0);mwc_ripple_Ripple=__decorate([Object(lit_element.b)("mwc-ripple")],mwc_ripple_Ripple);const isTouch="ontouchstart"in window||0<navigator.maxTouchPoints||0<navigator.msMaxTouchPoints;class LongPress extends HTMLElement{constructor(){super();this.holdTime=500;this.ripple=document.createElement("mwc-ripple");this.timer=void 0;this.held=!1;this.cooldownStart=!1;this.cooldownEnd=!1}connectedCallback(){Object.assign(this.style,{position:"absolute",width:isTouch?"100px":"50px",height:isTouch?"100px":"50px",transform:"translate(-50%, -50%)",pointerEvents:"none"});this.appendChild(this.ripple);this.ripple.primary=!0;["touchcancel","mouseout","mouseup","touchmove","mousewheel","wheel","scroll"].forEach(ev=>{document.addEventListener(ev,()=>{clearTimeout(this.timer);this.stopAnimation();this.timer=void 0},{passive:!0})})}bind(element){if(element.longPress){return}element.longPress=!0;element.addEventListener("contextmenu",ev=>{const e=ev||window.event;if(e.preventDefault){e.preventDefault()}if(e.stopPropagation){e.stopPropagation()}e.cancelBubble=!0;e.returnValue=!1;return!1});const clickStart=ev=>{if(this.cooldownStart){return}this.held=!1;let x,y;if(ev.touches){x=ev.touches[0].pageX;y=ev.touches[0].pageY}else{x=ev.pageX;y=ev.pageY}this.timer=window.setTimeout(()=>{this.startAnimation(x,y);this.held=!0},this.holdTime);this.cooldownStart=!0;window.setTimeout(()=>this.cooldownStart=!1,100)},clickEnd=ev=>{if(this.cooldownEnd||["touchend","touchcancel"].includes(ev.type)&&this.timer===void 0){return}clearTimeout(this.timer);this.stopAnimation();this.timer=void 0;if(this.held){element.dispatchEvent(new Event("ha-hold"))}else{element.dispatchEvent(new Event("ha-click"))}this.cooldownEnd=!0;window.setTimeout(()=>this.cooldownEnd=!1,100)};element.addEventListener("touchstart",clickStart,{passive:!0});element.addEventListener("touchend",clickEnd);element.addEventListener("touchcancel",clickEnd);element.addEventListener("mousedown",clickStart,{passive:!0});element.addEventListener("click",clickEnd)}startAnimation(x,y){Object.assign(this.style,{left:`${x}px`,top:`${y}px`,display:null});this.ripple.disabled=!1;this.ripple.active=!0;this.ripple.unbounded=!0}stopAnimation(){this.ripple.active=!1;this.ripple.disabled=!0;this.style.display="none"}}customElements.define("long-press",LongPress);const getLongPress=()=>{const body=document.body;if(body.querySelector("long-press")){return body.querySelector("long-press")}const longpress=document.createElement("long-press");body.appendChild(longpress);return longpress},longPressBind=element=>{const longpress=getLongPress();if(!longpress){return}longpress.bind(element)},longPress=()=>Object(lit_html.f)(part=>{longPressBind(part.committer.element)});var common_navigate=__webpack_require__(119),common_const=__webpack_require__(80),compute_domain=__webpack_require__(157);const turnOnOffEntity=(hass,entityId,turnOn=!0)=>{const stateDomain=Object(compute_domain.a)(entityId),serviceDomain="group"===stateDomain?"homeassistant":stateDomain;let service;switch(stateDomain){case"lock":service=turnOn?"unlock":"lock";break;case"cover":service=turnOn?"open_cover":"close_cover";break;default:service=turnOn?"turn_on":"turn_off";}return hass.callService(serviceDomain,service,{entity_id:entityId})},toggleEntity=(hass,entityId)=>{const turnOn=common_const.i.includes(hass.states[entityId].state);return turnOnOffEntity(hass,entityId,turnOn)},handleClick=(node,hass,config,hold)=>{let actionConfig;if(hold&&config.hold_action){actionConfig=config.hold_action}else if(!hold&&config.tap_action){actionConfig=config.tap_action}if(!actionConfig){actionConfig={action:"more-info"}}switch(actionConfig.action){case"more-info":if(config.entity||config.camera_image){Object(fire_event.a)(node,"hass-more-info",{entityId:config.entity?config.entity:config.camera_image})}break;case"navigate":if(actionConfig.navigation_path){Object(common_navigate.a)(node,actionConfig.navigation_path)}break;case"toggle":if(config.entity){toggleEntity(hass,config.entity)}break;case"call-service":{if(!actionConfig.service){return}const[domain,service]=actionConfig.service.split(".",2);hass.callService(domain,service,actionConfig.service_data)}}};class hui_entity_button_card_HuiEntityButtonCard extends Object(lit_localize_mixin.a)(lit_element.a){static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(9),__webpack_require__.e(67)]).then(__webpack_require__.bind(null,733));return document.createElement("hui-entity-button-card-editor")}static getStubConfig(){return{tap_action:{action:"more-info"},hold_action:{action:"none"}}}static get properties(){return{hass:{},_config:{}}}getCardSize(){return 2}setConfig(config){if(!Object(valid_entity_id.a)(config.entity)){throw new Error("Invalid Entity")}this._config=Object.assign({theme:"default"},config)}shouldUpdate(changedProps){if(changedProps.has("_config")){return!0}const oldHass=changedProps.get("hass");if(oldHass){return oldHass.states[this._config.entity]!==this.hass.states[this._config.entity]}return!0}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];return lit_element.c`
      ${this.renderStyle()}
      <ha-card
        @ha-click="${this._handleTap}"
        @ha-hold="${this._handleHold}"
        .longPress="${longPress()}"
      >
        ${!stateObj?lit_element.c`
                <div class="not-found">
                  Entity not available: ${this._config.entity}
                </div>
              `:lit_element.c`
                <paper-button>
                  <div>
                    <ha-icon
                      data-domain="${Object(compute_state_domain.a)(stateObj)}"
                      data-state="${stateObj.state}"
                      .icon="${this._config.icon||Object(state_icon.a)(stateObj)}"
                      style="${styleMap({filter:this._computeBrightness(stateObj),color:this._computeColor(stateObj)})}"
                    ></ha-icon>
                    <span>
                      ${this._config.name||Object(compute_state_name.a)(stateObj)}
                    </span>
                  </div>
                </paper-button>
              `}
      </ha-card>
    `}updated(changedProps){super.updated(changedProps);if(!this._config||!this.hass){return}const oldHass=changedProps.get("hass");if(!oldHass||oldHass.themes!==this.hass.themes){Object(apply_themes_on_element.a)(this,this.hass.themes,this._config.theme)}}renderStyle(){return lit_element.c`
      <style>
        ha-icon {
          display: flex;
          margin: auto;
          width: 40%;
          height: 40%;
          color: var(--paper-item-icon-color, #44739e);
        }
        ha-icon[data-domain="light"][data-state="on"],
        ha-icon[data-domain="switch"][data-state="on"],
        ha-icon[data-domain="binary_sensor"][data-state="on"],
        ha-icon[data-domain="fan"][data-state="on"],
        ha-icon[data-domain="sun"][data-state="above_horizon"] {
          color: var(--paper-item-icon-active-color, #fdd835);
        }
        ha-icon[data-state="unavailable"] {
          color: var(--state-icon-unavailable-color);
        }
        state-badge {
          display: flex;
          margin: auto;
          width: 40%;
          height: 40%;
        }
        paper-button {
          display: flex;
          margin: auto;
          text-align: center;
        }
        .not-found {
          flex: 1;
          background-color: yellow;
          padding: 8px;
        }
      </style>
    `}_computeBrightness(stateObj){if(!stateObj.attributes.brightness){return""}const brightness=stateObj.attributes.brightness;return`brightness(${(brightness+245)/5}%)`}_computeColor(stateObj){if(!stateObj.attributes.hs_color){return""}const{hue,sat}=stateObj.attributes.hs_color;if(10>=sat){return""}return`hsl(${hue}, 100%, ${100-sat/2}%)`}_handleTap(){handleClick(this,this.hass,this._config,!1)}_handleHold(){handleClick(this,this.hass,this._config,!0)}}customElements.define("hui-entity-button-card",hui_entity_button_card_HuiEntityButtonCard);var polymer_element=__webpack_require__(10),process_config_entities=__webpack_require__(257);function getEntities(hass,filterState,entities){return entities.filter(entityConf=>{const stateObj=hass.states[entityConf.entity];return stateObj&&filterState.includes(stateObj.state)})}class hui_entity_filter_card_HuiEntitiesCard extends polymer_element.a{static get properties(){return{hass:{type:Object,observer:"_hassChanged"}}}getCardSize(){return this.lastChild?this.lastChild.getCardSize():1}setConfig(config){if(!config.state_filter||!Array.isArray(config.state_filter)){throw new Error("Incorrect filter config.")}this._config=config;this._configEntities=Object(process_config_entities.a)(config.entities);if(this.lastChild){this.removeChild(this.lastChild);this._element=null}const card="card"in config?Object.assign({},config.card):{};if(!card.type)card.type="entities";card.entities=[];const element=createCardElement(card);element._filterRawConfig=card;this._updateCardConfig(element);this._element=element}_hassChanged(){this._updateCardConfig(this._element)}_updateCardConfig(element){if(!element||"HUI-ERROR-CARD"===element.tagName||!this.hass)return;const entitiesList=getEntities(this.hass,this._config.state_filter,this._configEntities);if(0===entitiesList.length&&!1===this._config.show_empty){this.style.display="none";return}this.style.display="block";element.setConfig(Object.assign({},element._filterRawConfig,{entities:entitiesList}));element.isPanel=this.isPanel;element.hass=this.hass;if(!this.lastChild)this.appendChild(element)}}customElements.define("hui-entity-filter-card",hui_entity_filter_card_HuiEntitiesCard);var compute_state_display=__webpack_require__(190),state_badge=__webpack_require__(161),ha_icon=__webpack_require__(159);class hui_glance_card_HuiGlanceCard extends Object(lit_localize_mixin.a)(lit_element.a){static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(109),__webpack_require__.e(68)]).then(__webpack_require__.bind(null,734));return document.createElement("hui-glance-card-editor")}static getStubConfig(){return{entities:[]}}static get properties(){return{hass:{},_config:{}}}getCardSize(){return(this._config.title?1:0)+Math.ceil(this._configEntities.length/5)}setConfig(config){this._config=Object.assign({theme:"default"},config);const entities=Object(process_config_entities.a)(config.entities);for(const entity of entities){if(entity.tap_action&&"call-service"===entity.tap_action.action&&!entity.tap_action.service||entity.hold_action&&"call-service"===entity.hold_action.action&&!entity.hold_action.service){throw new Error("Missing required property \"service\" when tap_action or hold_action is call-service")}}const columns=config.columns||_Mathmin(config.entities.length,5);this.style.setProperty("--glance-column-width",`${100/columns}%`);this._configEntities=entities;if(this.hass){this.requestUpdate()}}shouldUpdate(changedProps){if(changedProps.has("_config")){return!0}const oldHass=changedProps.get("hass");if(oldHass&&this._configEntities){for(const entity of this._configEntities){if(oldHass.states[entity.entity]!==this.hass.states[entity.entity]){return!0}}return!1}return!0}render(){if(!this._config||!this.hass){return lit_element.c``}const{title}=this._config;return lit_element.c`
      ${this.renderStyle()}
      <ha-card .header="${title}">
        <div class="entities ${Object(classMap.a)({"no-header":!title})}">
          ${this._configEntities.map(entityConf=>this.renderEntity(entityConf))}
        </div>
      </ha-card>
    `}updated(changedProperties){super.updated(changedProperties);if(!this._config||!this.hass){return}const oldHass=changedProperties.get("hass");if(!oldHass||oldHass.themes!==this.hass.themes){Object(apply_themes_on_element.a)(this,this.hass.themes,this._config.theme)}}renderStyle(){return lit_element.c`
      <style>
        .entities {
          display: flex;
          padding: 0 16px 4px;
          flex-wrap: wrap;
        }
        .entities.no-header {
          padding-top: 16px;
        }
        .entity {
          box-sizing: border-box;
          padding: 0 4px;
          display: flex;
          flex-direction: column;
          align-items: center;
          cursor: pointer;
          margin-bottom: 12px;
          width: var(--glance-column-width, 20%);
        }
        .entity div {
          width: 100%;
          text-align: center;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .name {
          min-height: var(--paper-font-body1_-_line-height, 20px);
        }
        state-badge {
          margin: 8px 0;
        }
        .not-found {
          background-color: yellow;
          text-align: center;
        }
      </style>
    `}renderEntity(entityConf){const stateObj=this.hass.states[entityConf.entity];if(!stateObj){return lit_element.c`
        <div class="entity not-found">
          <div class="name">${entityConf.entity}</div>
          Entity Not Available
        </div>
      `}return lit_element.c`
      <div
        class="entity"
        .entityConf="${entityConf}"
        @ha-click="${this._handleTap}"
        @ha-hold="${this._handleHold}"
        .longPress="${longPress()}"
      >
        ${!1!==this._config.show_name?lit_element.c`
                <div class="name">
                  ${"name"in entityConf?entityConf.name:Object(compute_state_name.a)(stateObj)}
                </div>
              `:""}
        <state-badge
          .stateObj="${stateObj}"
          .overrideIcon="${entityConf.icon}"
        ></state-badge>
        ${!1!==this._config.show_state?lit_element.c`
                <div>
                  ${Object(compute_state_display.a)(this.localize,stateObj,this.hass.language)}
                </div>
              `:""}
      </div>
    `}_handleTap(ev){const config=ev.currentTarget.entityConf;handleClick(this,this.hass,config,!1)}_handleHold(ev){const config=ev.currentTarget.entityConf;handleClick(this,this.hass,config,!0)}}customElements.define("hui-glance-card",hui_glance_card_HuiGlanceCard);var html_tag=__webpack_require__(1),state_history_charts=__webpack_require__(225),ha_state_history_data=__webpack_require__(226);class hui_history_graph_card_HuiHistoryGraphCard extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        ha-card {
          padding: 16px;
        }
        ha-card[header] {
          padding-top: 0;
        }
      </style>

      <ha-card header$="[[_config.title]]">
        <ha-state-history-data
          hass="[[hass]]"
          filter-type="recent-entity"
          entity-id="[[_entities]]"
          data="{{_stateHistory}}"
          is-loading="{{_stateHistoryLoading}}"
          cache-config="[[_cacheConfig]]"
        ></ha-state-history-data>
        <state-history-charts
          hass="[[hass]]"
          history-data="[[_stateHistory]]"
          is-loading-data="[[_stateHistoryLoading]]"
          names="[[_names]]"
          up-to-now
          no-single
        ></state-history-charts>
      </ha-card>
    `}static get properties(){return{hass:Object,_config:Object,_names:Object,_entities:Array,_stateHistory:Object,_stateHistoryLoading:Boolean,_cacheConfig:Object}}getCardSize(){return 4}setConfig(config){const entities=Object(process_config_entities.a)(config.entities);this._config=config;const _entities=[],_names={};for(const entity of entities){_entities.push(entity.entity);if(entity.name){_names[entity.entity]=entity.name}}this.setProperties({_cacheConfig:{cacheKey:_entities.sort().join(),hoursToShow:config.hours_to_show||24,refresh:config.refresh_interval||0},_entities,_names})}}customElements.define("hui-history-graph-card",hui_history_graph_card_HuiHistoryGraphCard);class hui_stack_card_HuiStackCard extends lit_element.a{static get properties(){return{_config:{}}}set hass(hass){this._hass=hass;if(!this._cards){return}for(const element of this._cards){element.hass=this._hass}}setConfig(config){if(!config||!config.cards||!Array.isArray(config.cards)){throw new Error("Card config incorrect")}this._config=config;this._cards=config.cards.map(card=>{const element=createCardElement(card);if(this._hass){element.hass=this._hass}return element})}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <div id="root">${this._cards}</div>
    `}}customElements.define("hui-horizontal-stack-card",class extends hui_stack_card_HuiStackCard{getCardSize(){let totalSize=0;if(this._cards){for(const element of this._cards){const elementSize=Object(compute_card_size.a)(element);totalSize=elementSize>totalSize?elementSize:totalSize}}return totalSize}renderStyle(){return lit_element.c`
      <style>
        #root {
          display: flex;
        }
        #root > * {
          flex: 1 1 0;
          margin: 0 4px;
          min-width: 0;
        }
        #root > *:first-child {
          margin-left: 0;
        }
        #root > *:last-child {
          margin-right: 0;
        }
      </style>
    `}});class hui_iframe_card_HuiIframeCard extends lit_element.a{static async getConfigElement(){await __webpack_require__.e(70).then(__webpack_require__.bind(null,736));return document.createElement("hui-iframe-card-editor")}static getStubConfig(){return{url:"https://www.home-assistant.io",aspect_ratio:"50%"}}static get properties(){return{_config:{}}}getCardSize(){return 1+this.offsetHeight/50}setConfig(config){if(!config.url){throw new Error("URL required")}this._config=config}render(){if(!this._config){return lit_element.c``}const aspectRatio=this._config.aspect_ratio||"50%";return lit_element.c`
      ${this.renderStyle()}
      <ha-card .header="${this._config.title}">
        <div
          id="root"
          style="${styleMap({"padding-top":aspectRatio})}"
        >
          <iframe src="${this._config.url}"></iframe>
        </div>
      </ha-card>
    `}renderStyle(){return lit_element.c`
      <style>
        ha-card {
          overflow: hidden;
        }
        #root {
          width: 100%;
          position: relative;
          padding-top: ${this._config.aspect_ratio||"50%"};
        }
        iframe {
          position: absolute;
          border: none;
          width: 100%;
          height: 100%;
          top: 0;
          left: 0;
        }
      </style>
    `}}customElements.define("hui-iframe-card",hui_iframe_card_HuiIframeCard);function hasConfigOrEntityChanged(element,changedProps){if(changedProps.has("_config")){return!0}const oldHass=changedProps.get("hass");if(oldHass){return oldHass.states[element._config.entity]!==element.hass.states[element._config.entity]}return!0}let jquery_roundslider_ondemand_loaded;const loadRoundslider=async()=>{if(!jquery_roundslider_ondemand_loaded){jquery_roundslider_ondemand_loaded=Promise.all([__webpack_require__.e(118),__webpack_require__.e(72)]).then(__webpack_require__.bind(null,765))}return jquery_roundslider_ondemand_loaded},lightConfig={radius:80,step:1,circleShape:"pie",startAngle:315,width:5,min:1,max:100,sliderType:"min-range",lineCap:"round",handleSize:"+12",showTooltip:!1,animation:!1};class hui_light_card_HuiLightCard extends Object(lit_localize_mixin.a)(lit_element.a){static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(110),__webpack_require__.e(71)]).then(__webpack_require__.bind(null,737));return document.createElement("hui-light-card-editor")}static getStubConfig(){return{}}static get properties(){return{hass:{},_config:{},roundSliderStyle:{},_jQuery:{}}}getCardSize(){return 2}setConfig(config){if(!config.entity||"light"!==config.entity.split(".")[0]){throw new Error("Specify an entity from within the light domain.")}this._config=Object.assign({theme:"default"},config)}render(){if(!this.hass||!this._config){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];return lit_element.c`
      ${this.renderStyle()}
      <ha-card>
        ${!stateObj?lit_element.c`
                <div class="not-found">
                  Entity not available: ${this._config.entity}
                </div>
              `:lit_element.c`
                <div id="light"></div>
                <div id="tooltip">
                  <div class="icon-state">
                    <ha-icon
                      data-state="${stateObj.state}"
                      .icon="${Object(state_icon.a)(stateObj)}"
                      style="${styleMap({filter:this._computeBrightness(stateObj),color:this._computeColor(stateObj)})}"
                      @ha-click="${this._handleTap}"
                      @ha-hold="${this._handleHold}"
                      .longPress="${longPress()}"
                    ></ha-icon>
                    <div
                      class="brightness"
                      @ha-click="${this._handleTap}"
                      @ha-hold="${this._handleHold}"
                      .longPress="${longPress()}"
                    ></div>
                    <div class="name">
                      ${this._config.name||Object(compute_state_name.a)(stateObj)}
                    </div>
                  </div>
                </div>
              `}
      </ha-card>
    `}shouldUpdate(changedProps){return hasConfigOrEntityChanged(this,changedProps)}async firstUpdated(){const loaded=await loadRoundslider();this._roundSliderStyle=loaded.roundSliderStyle;this._jQuery=loaded.jQuery;const stateObj=this.hass.states[this._config.entity];if(!stateObj){return}const brightness=stateObj.attributes.brightness||0;this._jQuery("#light",this.shadowRoot).roundSlider(Object.assign({},lightConfig,{change:value=>this._setBrightness(value),drag:value=>this._dragEvent(value),start:()=>this._showBrightness(),stop:()=>this._hideBrightness()}));this.shadowRoot.querySelector(".brightness").innerHTML=(_Mathround3(100*(brightness/254))||0)+"%"}updated(changedProps){super.updated(changedProps);if(!this._config||!this.hass||!this._jQuery){return}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return}const attrs=stateObj.attributes;this._jQuery("#light",this.shadowRoot).roundSlider({value:_Mathround3(100*(attrs.brightness/254))||0});const oldHass=changedProps.get("hass");if(!oldHass||oldHass.themes!==this.hass.themes){Object(apply_themes_on_element.a)(this,this.hass.themes,this._config.theme)}}renderStyle(){return lit_element.c`
      ${this._roundSliderStyle}
      <style>
        :host {
          display: block;
        }
        ha-card {
          position: relative;
          overflow: hidden;
          --brightness-font-color: white;
          --brightness-font-text-shadow: -1px -1px 0 #000, 1px -1px 0 #000,
            -1px 1px 0 #000, 1px 1px 0 #000;
          --name-font-size: 1.2rem;
          --brightness-font-size: 1.2rem;
          --rail-border-color: transparent;
        }
        #tooltip {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 100%;
          text-align: center;
          z-index: 15;
        }
        .icon-state {
          display: block;
          margin: auto;
          width: 100%;
          height: 100%;
          transform: translate(0, 25%);
        }
        #light {
          margin: 0 auto;
          padding-top: 16px;
          padding-bottom: 16px;
        }
        #light .rs-bar.rs-transition.rs-first,
        .rs-bar.rs-transition.rs-second {
          z-index: 20 !important;
        }
        #light .rs-range-color {
          background-color: var(--primary-color);
        }
        #light .rs-path-color {
          background-color: var(--disabled-text-color);
        }
        #light .rs-handle {
          background-color: var(--paper-card-background-color, white);
          padding: 7px;
          border: 2px solid var(--disabled-text-color);
        }
        #light .rs-handle.rs-focus {
          border-color: var(--primary-color);
        }
        #light .rs-handle:after {
          border-color: var(--primary-color);
          background-color: var(--primary-color);
        }
        #light .rs-border {
          border-color: var(--rail-border-color);
        }
        #light .rs-inner.rs-bg-color.rs-border,
        #light .rs-overlay.rs-transition.rs-bg-color {
          background-color: var(--paper-card-background-color, white);
        }
        ha-icon {
          margin: auto;
          width: 76px;
          height: 76px;
          color: var(--paper-item-icon-color, #44739e);
          cursor: pointer;
        }
        ha-icon[data-state="on"] {
          color: var(--paper-item-icon-active-color, #fdd835);
        }
        ha-icon[data-state="unavailable"] {
          color: var(--state-icon-unavailable-color);
        }
        .name {
          padding-top: 40px;
          font-size: var(--name-font-size);
        }
        .brightness {
          font-size: var(--brightness-font-size);
          position: absolute;
          margin: 0 auto;
          left: 50%;
          top: 10%;
          transform: translate(-50%);
          opacity: 0;
          transition: opacity 0.5s ease-in-out;
          -moz-transition: opacity 0.5s ease-in-out;
          -webkit-transition: opacity 0.5s ease-in-out;
          cursor: pointer;
          color: var(--brightness-font-color);
          text-shadow: var(--brightness-font-text-shadow);
        }
        .show_brightness {
          opacity: 1;
        }
        .not-found {
          flex: 1;
          background-color: yellow;
          padding: 8px;
        }
      </style>
    `}_dragEvent(e){this.shadowRoot.querySelector(".brightness").innerHTML=e.value+"%"}_showBrightness(){clearTimeout(this._brightnessTimout);this.shadowRoot.querySelector(".brightness").classList.add("show_brightness")}_hideBrightness(){this._brightnessTimout=window.setTimeout(()=>{this.shadowRoot.querySelector(".brightness").classList.remove("show_brightness")},500)}_setBrightness(e){this.hass.callService("light","turn_on",{entity_id:this._config.entity,brightness_pct:e.value})}_computeBrightness(stateObj){if(!stateObj.attributes.brightness){return""}const brightness=stateObj.attributes.brightness;return`brightness(${(brightness+245)/5}%)`}_computeColor(stateObj){if(!stateObj.attributes.hs_color){return""}const[hue,sat]=stateObj.attributes.hs_color;if(10>=sat){return""}return`hsl(${hue}, 100%, ${100-sat/2}%)`}_handleTap(){toggleEntity(this.hass,this._config.entity)}_handleHold(){Object(fire_event.a)(this,"hass-more-info",{entityId:this._config.entity})}}customElements.define("hui-light-card",hui_light_card_HuiLightCard);var paper_icon_button=__webpack_require__(99),ha_entity_marker=__webpack_require__(328),setup_leaflet_map=__webpack_require__(329),debounce=__webpack_require__(376);const parseOrThrow=num=>{const parsed=parseFloat(num);if(isNaN(parsed)){throw new Error(`${num} is not a number`)}return parsed};function parseAspectRatio(input){if(!input){return null}try{if(input.endsWith("%")){return{w:100,h:parseOrThrow(input.substr(0,input.length-1))}}const arr=input.replace(":","x").split("x");if(0===arr.length){return null}return 1===arr.length?{w:parseOrThrow(arr[0]),h:1}:{w:parseOrThrow(arr[0]),h:parseOrThrow(arr[1])}}catch(err){}return null}class hui_map_card_HuiMapCard extends polymer_element.a{static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(111),__webpack_require__.e(73)]).then(__webpack_require__.bind(null,738));return document.createElement("hui-map-card-editor")}static getStubConfig(){return{entities:[]}}static get template(){return html_tag.a`
      <style>
        :host([is-panel]) ha-card {
          left: 0;
          top: 0;
          width: 100%;
          /**
           * In panel mode we want a full height map. Since parent #view
           * only sets min-height, we need absolute positioning here
           */
          height: 100%;
          position: absolute;
        }

        ha-card {
          overflow: hidden;
        }

        #map {
          z-index: 0;
          border: none;
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }

        paper-icon-button {
          position: absolute;
          top: 75px;
          left: 7px;
        }

        #root {
          position: relative;
        }

        :host([is-panel]) #root {
          height: 100%;
        }
      </style>

      <ha-card id="card" header="[[_config.title]]">
        <div id="root">
          <div id="map"></div>
          <paper-icon-button
            on-click="_fitMap"
            icon="hass:image-filter-center-focus"
            title="Reset focus"
          ></paper-icon-button>
        </div>
      </ha-card>
    `}static get properties(){return{hass:{type:Object,observer:"_drawEntities"},_config:Object,isPanel:{type:Boolean,reflectToAttribute:!0}}}constructor(){super();this._debouncedResizeListener=Object(debounce.a)(this._resetMap.bind(this),100)}ready(){super.ready();if(!this._config||this.isPanel){return}const ratio=parseAspectRatio(this._config.aspect_ratio);if(ratio&&0<ratio.w&&0<ratio.h){this.$.root.style.paddingBottom=`${(100*ratio.h/ratio.w).toFixed(2)}%`}else{this.$.root.style.paddingBottom="100%"}}setConfig(config){if(!config){throw new Error("Error in card configuration.")}if(!config.entities&&!config.geo_location_sources){throw new Error("Either entities or geo_location_sources must be defined")}if(config.entities&&!Array.isArray(config.entities)){throw new Error("Entities need to be an array")}if(config.geo_location_sources&&!Array.isArray(config.geo_location_sources)){throw new Error("Geo_location_sources needs to be an array")}this._config=config;this._configGeoLocationSources=config.geo_location_sources;this._configEntities=config.entities}getCardSize(){const ratio=parseAspectRatio(this._config.aspect_ratio);let ar;if(ratio&&0<ratio.w&&0<ratio.h){ar=`${(100*ratio.h/ratio.w).toFixed(2)}`}else{ar="100"}return 1+_Mathfloor3(ar/25)||3}connectedCallback(){super.connectedCallback();if("function"===typeof ResizeObserver){this._resizeObserver=new ResizeObserver(()=>this._debouncedResizeListener());this._resizeObserver.observe(this.$.map)}else{window.addEventListener("resize",this._debouncedResizeListener)}this.loadMap()}async loadMap(){[this._map,this.Leaflet]=await Object(setup_leaflet_map.a)(this.$.map);this._drawEntities(this.hass);this._map.invalidateSize();this._fitMap()}disconnectedCallback(){super.disconnectedCallback();if(this._map){this._map.remove()}if(this._resizeObserver){this._resizeObserver.unobserve(this.$.map)}else{window.removeEventListener("resize",this._debouncedResizeListener)}}_resetMap(){if(!this._map){return}this._map.invalidateSize()}_fitMap(){const zoom=this._config.default_zoom;if(0===this._mapItems.length){this._map.setView(new this.Leaflet.LatLng(this.hass.config.latitude,this.hass.config.longitude),zoom||14);return}const bounds=new this.Leaflet.latLngBounds(this._mapItems.map(item=>item.getLatLng()));this._map.fitBounds(bounds.pad(.5));if(zoom&&this._map.getZoom()>zoom){this._map.setZoom(zoom)}}_drawEntities(hass){const map=this._map;if(!map){return}if(this._mapItems){this._mapItems.forEach(marker=>marker.remove())}const mapItems=this._mapItems=[];let allEntities=[];if(this._configEntities){allEntities=allEntities.concat(this._configEntities)}if(this._configGeoLocationSources){Object.keys(this.hass.states).forEach(entityId=>{const stateObj=this.hass.states[entityId];if("geo_location"===Object(compute_state_domain.a)(stateObj)&&this._configGeoLocationSources.includes(stateObj.attributes.source)){allEntities.push(entityId)}})}allEntities=Object(process_config_entities.a)(allEntities);allEntities.forEach(entity=>{const entityId=entity.entity;if(!(entityId in hass.states)){return}const stateObj=hass.states[entityId],title=Object(compute_state_name.a)(stateObj),{latitude,longitude,passive,icon,radius,entity_picture:entityPicture,gps_accuracy:gpsAccuracy}=stateObj.attributes;if(!(latitude&&longitude)){return}let markerIcon,iconHTML,el;if("zone"===Object(compute_state_domain.a)(stateObj)){if(passive)return;if(icon){el=document.createElement("ha-icon");el.setAttribute("icon",icon);iconHTML=el.outerHTML}else{iconHTML=title}markerIcon=this.Leaflet.divIcon({html:iconHTML,iconSize:[24,24],className:""});mapItems.push(this.Leaflet.marker([latitude,longitude],{icon:markerIcon,interactive:!1,title:title}).addTo(map));mapItems.push(this.Leaflet.circle([latitude,longitude],{interactive:!1,color:"#FF9800",radius:radius}).addTo(map));return}const entityName=title.split(" ").map(part=>part[0]).join("").substr(0,3);el=document.createElement("ha-entity-marker");el.setAttribute("entity-id",entityId);el.setAttribute("entity-name",entityName);el.setAttribute("entity-picture",entityPicture||"");markerIcon=this.Leaflet.divIcon({html:el.outerHTML,iconSize:[48,48],className:""});mapItems.push(this.Leaflet.marker([latitude,longitude],{icon:markerIcon,title:Object(compute_state_name.a)(stateObj)}).addTo(map));if(gpsAccuracy){mapItems.push(this.Leaflet.circle([latitude,longitude],{interactive:!1,color:"#0288D1",radius:gpsAccuracy}).addTo(map))}})}}customElements.define("hui-map-card",hui_map_card_HuiMapCard);__webpack_require__(201);class hui_markdown_card_HuiMarkdownCard extends lit_element.a{static async getConfigElement(){await Promise.all([__webpack_require__.e(106),__webpack_require__.e(74)]).then(__webpack_require__.bind(null,739));return document.createElement("hui-markdown-card-editor")}static getStubConfig(){return{content:" "}}static get properties(){return{_config:{}}}getCardSize(){return this._config.content.split("\n").length}setConfig(config){if(!config.content){throw new Error("Invalid Configuration: Content Required")}this._config=config}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <ha-card .header="${this._config.title}">
        <ha-markdown
          class="markdown ${Object(classMap.a)({"no-header":!this._config.title})}"
          .content="${this._config.content}"
        ></ha-markdown>
      </ha-card>
    `}renderStyle(){return lit_element.c`
      <style>
        :host {
          @apply --paper-font-body1;
        }
        ha-markdown {
          display: block;
          padding: 0 16px 16px;
          -ms-user-select: initial;
          -webkit-user-select: initial;
          -moz-user-select: initial;
        }
        .markdown.no-header {
          padding-top: 16px;
        }
        ha-markdown > *:first-child {
          margin-top: 0;
        }
        ha-markdown > *:last-child {
          margin-bottom: 0;
        }
        ha-markdown a {
          color: var(--primary-color);
        }
        ha-markdown img {
          max-width: 100%;
        }
      </style>
    `}}customElements.define("hui-markdown-card",hui_markdown_card_HuiMarkdownCard);__webpack_require__(268);class hui_legacy_wrapper_card_LegacyWrapperCard extends HTMLElement{constructor(tag,domain){super();this._tag=tag.toUpperCase();this._domain=domain;this._element=null}getCardSize(){return 3}setConfig(config){if(!config.entity){throw new Error("No entity specified")}if(Object(compute_domain.a)(config.entity)!==this._domain){throw new Error(`Specified entity needs to be of domain ${this._domain}.`)}this._config=config}set hass(hass){const entityId=this._config.entity;if(entityId in hass.states){this._ensureElement(this._tag);this.lastChild.hass=hass;this.lastChild.stateObj=hass.states[entityId];this.lastChild.config=this._config}else{this._ensureElement("HUI-ERROR-CARD");this.lastChild.setConfig(Object(hui_error_card.a)(`No state available for ${entityId}`,this._config))}}_ensureElement(tag){if(this.lastChild&&this.lastChild.tagName===tag)return;if(this.lastChild){this.removeChild(this.lastChild)}this.appendChild(document.createElement(tag))}}customElements.define("hui-media-control-card",class extends hui_legacy_wrapper_card_LegacyWrapperCard{static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(112),__webpack_require__.e(75)]).then(__webpack_require__.bind(null,740));return document.createElement("hui-media-control-card-editor")}static getStubConfig(){return{}}constructor(){super("ha-media_player-card","media_player")}});class hui_picture_card_HuiPictureCard extends lit_element.a{static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(9),__webpack_require__.e(76)]).then(__webpack_require__.bind(null,741));return document.createElement("hui-picture-card-editor")}static getStubConfig(){return{image:"https://www.home-assistant.io/images/merchandise/shirt-frontpage.png",tap_action:{action:"none"},hold_action:{action:"none"}}}static get properties(){return{_config:{}}}getCardSize(){return 3}setConfig(config){if(!config||!config.image){throw new Error("Invalid Configuration: 'image' required")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <ha-card
        @ha-click="${this._handleTap}"
        @ha-hold="${this._handleHold}"
        .longPress="${longPress()}"
        class="${Object(classMap.a)({clickable:!!(this._config.tap_action||this._config.hold_action)})}"
      >
        <img src="${this._config.image}" />
      </ha-card>
    `}renderStyle(){return lit_element.c`
      <style>
        ha-card {
          overflow: hidden;
        }
        ha-card.clickable {
          cursor: pointer;
        }
        img {
          display: block;
          width: 100%;
        }
      </style>
    `}_handleTap(){handleClick(this,this.hass,this._config,!1)}_handleHold(){handleClick(this,this.hass,this._config,!0)}}customElements.define("hui-picture-card",hui_picture_card_HuiPictureCard);const computeTooltip=(hass,config)=>{if(config.title){return config.title}let stateName="",tooltip="";if(config.entity){stateName=config.entity in hass.states?Object(compute_state_name.a)(hass.states[config.entity]):config.entity}const tapTooltip=config.tap_action?computeActionTooltip(stateName,config.tap_action,!1):"",holdTooltip=config.hold_action?computeActionTooltip(stateName,config.hold_action,!0):"",newline=tapTooltip&&holdTooltip?"\n":"";tooltip=tapTooltip+newline+holdTooltip;return tooltip};function computeActionTooltip(state,config,isHold){if(!config||!config.action||"none"===config.action){return""}let tooltip=isHold?"Hold: ":"Tap: ";switch(config.action){case"navigate":tooltip+=`Navigate to ${config.navigation_path}`;break;case"toggle":tooltip+=`Toggle ${state}`;break;case"call-service":tooltip+=`Call service ${config.service}`;break;case"more-info":tooltip+=`Show more-info: ${state}`;break;}return tooltip}class hui_icon_element_HuiIconElement extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config.icon){throw Error("Invalid Configuration: 'icon' required")}this._config=config}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <ha-icon
        .icon="${this._config.icon}"
        .title="${computeTooltip(this.hass,this._config)}"
        @ha-click="${this._handleTap}"
        @ha-hold="${this._handleHold}"
        .longPress="${longPress()}"
      ></ha-icon>
    `}_handleTap(){handleClick(this,this.hass,this._config,!1)}_handleHold(){handleClick(this,this.hass,this._config,!0)}renderStyle(){return lit_element.c`
      <style>
        :host {
          cursor: pointer;
        }
      </style>
    `}}customElements.define("hui-icon-element",hui_icon_element_HuiIconElement);var paper_toggle_button=__webpack_require__(187),localize_mixin=__webpack_require__(71);class hui_image_HuiImage extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      ${this.styleTemplate}
      <div id="wrapper">
        <img
          id="image"
          src="[[_imageSrc]]"
          on-error="_onImageError"
          on-load="_onImageLoad"
        />
        <div id="brokenImage"></div>
      </div>
    `}static get styleTemplate(){return html_tag.a`
      <style>
        img {
          display: block;
          height: auto;
          transition: filter 0.2s linear;
          width: 100%;
        }

        .error {
          text-align: center;
        }

        .hidden {
          display: none;
        }

        .ratio {
          position: relative;
          width: 100%;
          height: 0;
        }

        .ratio img,
        .ratio div {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }

        #brokenImage {
          background: grey url("/static/images/image-broken.svg") center/36px
            no-repeat;
        }
      </style>
    `}static get properties(){return{hass:{type:Object,observer:"_hassChanged"},entity:String,image:String,stateImage:Object,cameraImage:String,aspectRatio:String,filter:String,stateFilter:Object,_imageSrc:String}}static get observers(){return["_configChanged(image, stateImage, cameraImage, aspectRatio)"]}connectedCallback(){super.connectedCallback();if(this.cameraImage){this.timer=setInterval(()=>this._updateCameraImageSrc(),1e4)}}disconnectedCallback(){super.disconnectedCallback();clearInterval(this.timer)}_configChanged(image,stateImage,cameraImage,aspectRatio){const ratio=parseAspectRatio(aspectRatio);if(ratio&&0<ratio.w&&0<ratio.h){this.$.wrapper.style.paddingBottom=`${(100*ratio.h/ratio.w).toFixed(2)}%`;this.$.wrapper.classList.add("ratio")}if(cameraImage){this._updateCameraImageSrc()}else if(image&&!stateImage){this._imageSrc=image}}_onImageError(){this._imageSrc=null;this.$.image.classList.add("hidden");if(!this.$.wrapper.classList.contains("ratio")){this.$.brokenImage.style.setProperty("height",`${this._lastImageHeight||"100"}px`)}this.$.brokenImage.classList.remove("hidden")}_onImageLoad(){this.$.image.classList.remove("hidden");this.$.brokenImage.classList.add("hidden");if(!this.$.wrapper.classList.contains("ratio")){this._lastImageHeight=this.$.image.offsetHeight}}_hassChanged(hass){if(this.cameraImage||!this.entity){return}const stateObj=hass.states[this.entity],newState=!stateObj?"unavailable":stateObj.state;if(newState===this._currentState)return;this._currentState=newState;this._updateStateImage();this._updateStateFilter(stateObj)}_updateStateImage(){if(!this.stateImage){this._imageFallback=!0;return}const stateImg=this.stateImage[this._currentState];this._imageSrc=stateImg||this.image;this._imageFallback=!stateImg}_updateStateFilter(stateObj){let filter;if(!this.stateFilter){filter=this.filter}else{filter=this.stateFilter[this._currentState]||this.filter}const isOff=!stateObj||common_const.i.includes(stateObj.state);this.$.image.style.filter=filter||isOff&&this._imageFallback&&"grayscale(100%)"||""}async _updateCameraImageSrc(){try{const{content_type:contentType,content}=await this.hass.callWS({type:"camera_thumbnail",entity_id:this.cameraImage});this._imageSrc=`data:${contentType};base64, ${content}`;this._onImageLoad()}catch(err){this._onImageError()}}}customElements.define("hui-image",hui_image_HuiImage);class hui_image_element_HuiImageElement extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw Error("Error in element configuration")}this.classList.toggle("clickable",config.tap_action&&"none"!==config.tap_action.action);this._config=config}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <hui-image
        .hass="${this.hass}"
        .entity="${this._config.entity}"
        .image="${this._config.image}"
        .stateImage="${this._config.state_image}"
        .cameraImage="${this._config.camera_image}"
        .filter="${this._config.filter}"
        .stateFilter="${this._config.state_filter}"
        .title="${computeTooltip(this.hass,this._config)}"
        .aspectRatio="${this._config.aspect_ratio}"
        @ha-click="${this._handleTap}"
        @ha-hold="${this._handleHold}"
        .longPress="${longPress()}"
      ></hui-image>
    `}renderStyle(){return lit_element.c`
      <style>
        :host(.clickable) {
          cursor: pointer;
          overflow: hidden;
          -webkit-touch-callout: none !important;
        }
        hui-image {
          -webkit-user-select: none !important;
        }
      </style>
    `}_handleTap(){handleClick(this,this.hass,this._config,!1)}_handleHold(){handleClick(this,this.hass,this._config,!0)}}customElements.define("hui-image-element",hui_image_element_HuiImageElement);__webpack_require__(206);class hui_service_button_element_HuiServiceButtonElement extends lit_element.a{static get properties(){return{_config:{}}}setConfig(config){if(!config||!config.service){throw Error("Invalid Configuration: 'service' required")}[this._domain,this._service]=config.service.split(".",2);if(!this._domain){throw Error("Invalid Configuration: 'service' does not have a domain")}if(!this._service){throw Error("Invalid Configuration: 'service' does not have a service name")}this._config=config}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <ha-call-service-button
        .hass="${this.hass}"
        .domain="${this._domain}"
        .service="${this._service}"
        .serviceData="${this._config.service_data}"
        >${this._config.title}</ha-call-service-button
      >
    `}renderStyle(){return lit_element.c`
      <style>
        ha-call-service-button {
          color: var(--primary-color);
          white-space: nowrap;
        }
      </style>
    `}}customElements.define("hui-service-button-element",hui_service_button_element_HuiServiceButtonElement);__webpack_require__(244);class hui_state_badge_element_HuiStateBadgeElement extends lit_element.a{static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config.entity){throw Error("Invalid Configuration: 'entity' required")}this._config=config}render(){if(!this._config||!this.hass||!this.hass.states[this._config.entity]){return lit_element.c``}const state=this.hass.states[this._config.entity];return lit_element.c`
      <ha-state-label-badge
        .hass="${this.hass}"
        .state="${state}"
        .title="${Object(compute_state_name.a)(state)}"
      ></ha-state-label-badge>
    `}}customElements.define("hui-state-badge-element",hui_state_badge_element_HuiStateBadgeElement);class hui_state_icon_element_HuiStateIconElement extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config.entity){throw Error("Invalid Configuration: 'entity' required")}this._config=config}render(){if(!this._config||!this.hass||!this.hass.states[this._config.entity]){return lit_element.c``}const state=this.hass.states[this._config.entity];return lit_element.c`
      ${this.renderStyle()}
      <state-badge
        .stateObj="${state}"
        .title="${computeTooltip(this.hass,this._config)}"
        @ha-click="${this._handleClick}"
        @ha-hold="${this._handleHold}"
        .longPress="${longPress()}"
      ></state-badge>
    `}renderStyle(){return lit_element.c`
      <style>
        :host {
          cursor: pointer;
        }
      </style>
    `}_handleClick(){handleClick(this,this.hass,this._config,!1)}_handleHold(){handleClick(this,this.hass,this._config,!0)}}customElements.define("hui-state-icon-element",hui_state_icon_element_HuiStateIconElement);class hui_state_label_element_HuiStateLabelElement extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config.entity){throw Error("Invalid Configuration: 'entity' required")}this._config=config}render(){if(!this._config){return lit_element.c``}const state=this.hass.states[this._config.entity];return lit_element.c`
      ${this.renderStyle()}
      <div
        .title="${computeTooltip(this.hass,this._config)}"
        @ha-click="${this._handleTap}"
        @ha-hold="${this._handleHold}"
        .longPress="${longPress()}"
      >
        ${this._config.prefix}${state?Object(compute_state_display.a)(this.localize,state,this.hass.language):"-"}${this._config.suffix}
      </div>
    `}_handleTap(){handleClick(this,this.hass,this._config,!1)}_handleHold(){handleClick(this,this.hass,this._config,!0)}renderStyle(){return lit_element.c`
      <style>
        :host {
          cursor: pointer;
        }
        div {
          padding: 8px;
          white-space: nowrap;
        }
      </style>
    `}}customElements.define("hui-state-label-element",hui_state_label_element_HuiStateLabelElement);const CUSTOM_TYPE_PREFIX="custom:",ELEMENT_TYPES=new Set(["icon","image","service-button","state-badge","state-icon","state-label"]),_createElement=(tag,config)=>{const element=document.createElement(tag);try{element.setConfig(config)}catch(err){console.error(tag,err);return _createErrorElement(err.message,config)}return element},_createErrorElement=(error,config)=>Object(hui_error_card.b)(Object(hui_error_card.a)(error,config));function _hideErrorElement(element){element.style.display="None";return window.setTimeout(()=>{element.style.display=""},2e3)}const createHuiElement=config=>{if(!config||"object"!==typeof config||!config.type){return _createErrorElement("No element type configured.",config)}if(config.type.startsWith(CUSTOM_TYPE_PREFIX)){const tag=config.type.substr(CUSTOM_TYPE_PREFIX.length);if(customElements.get(tag)){return _createElement(tag,config)}const element=_createErrorElement(`Custom element doesn't exist: ${tag}.`,config),timer=_hideErrorElement(element);customElements.whenDefined(tag).then(()=>{clearTimeout(timer);Object(fire_event.a)(element,"rebuild-view")});return element}if(!ELEMENT_TYPES.has(config.type)){return _createErrorElement(`Unknown element type encountered: ${config.type}.`,config)}return _createElement(`hui-${config.type}-element`,config)};class hui_picture_elements_card_HuiPictureElementsCard extends lit_element.a{static get properties(){return{_config:{}}}set hass(hass){this._hass=hass;for(const el of this.shadowRoot.querySelectorAll("#root > *")){el.hass=this._hass}}getCardSize(){return 4}setConfig(config){if(!config){throw new Error("Invalid Configuration")}else if(!(config.image||config.camera_image||config.state_image)||config.state_image&&!config.entity){throw new Error("Invalid Configuration: image required")}else if(!Array.isArray(config.elements)){throw new Error("Invalid Configuration: elements required")}this._config=config}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <ha-card .header="${this._config.title}">
        <div id="root">
          <hui-image
            .hass="${this._hass}"
            .image="${this._config.image}"
            .stateImage="${this._config.state_image}"
            .cameraImage="${this._config.camera_image}"
            .entity="${this._config.entity}"
            .aspectRatio="${this._config.aspect_ratio}"
          ></hui-image>
          ${this._config.elements.map(elementConfig=>this._createHuiElement(elementConfig))}
        </div>
      </ha-card>
    `}renderStyle(){return lit_element.c`
      <style>
        #root {
          position: relative;
          overflow: hidden;
        }
        .element {
          position: absolute;
          transform: translate(-50%, -50%);
        }
      </style>
    `}_createHuiElement(elementConfig){const element=createHuiElement(elementConfig);element.hass=this._hass;element.classList.add("element");Object.keys(elementConfig.style).forEach(prop=>{element.style.setProperty(prop,elementConfig.style[prop])});return element}}customElements.define("hui-picture-elements-card",hui_picture_elements_card_HuiPictureElementsCard);class hui_picture_entity_card_HuiPictureEntityCard extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}getCardSize(){return 3}setConfig(config){if(!config||!config.entity){throw new Error("Invalid Configuration: 'entity' required")}if("camera"!==Object(compute_domain.a)(config.entity)&&!config.image&&!config.state_image&&!config.camera_image){throw new Error("No image source configured.")}this._config=Object.assign({show_name:!0,show_state:!0},config)}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        ${Object(hui_error_card.b)(Object(hui_error_card.a)(`Entity not found: ${this._config.entity}`,this._config))}
      `}const name=this._config.name||Object(compute_state_name.a)(stateObj),state=Object(compute_state_display.a)(this.localize,stateObj,this.hass.language);let footer="";if(this._config.show_name&&this._config.show_state){footer=lit_element.c`
        <div class="footer both">
          <div>${name}</div>
          <div>${state}</div>
        </div>
      `}else if(this._config.show_name){footer=lit_element.c`
        <div class="footer">${name}</div>
      `}else if(this._config.show_state){footer=lit_element.c`
        <div class="footer state">${state}</div>
      `}return lit_element.c`
      ${this.renderStyle()}
      <ha-card>
        <hui-image
          .hass="${this.hass}"
          .image="${this._config.image}"
          .stateImage="${this._config.state_image}"
          .cameraImage="${"camera"===Object(compute_domain.a)(this._config.entity)?this._config.entity:this._config.camera_image}"
          .entity="${this._config.entity}"
          .aspectRatio="${this._config.aspect_ratio}"
          @ha-click="${this._handleTap}"
          @ha-hold="${this._handleHold}"
          .longPress="${longPress()}"
          class="${Object(classMap.a)({clickable:stateObj.state!=="unavailable"})}"
        ></hui-image>
        ${footer}
      </ha-card>
    `}renderStyle(){return lit_element.c`
      <style>
        ha-card {
          min-height: 75px;
          overflow: hidden;
          position: relative;
        }
        hui-image.clickable {
          cursor: pointer;
        }
        .footer {
          @apply --paper-font-common-nowrap;
          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;
          background-color: rgba(0, 0, 0, 0.3);
          padding: 16px;
          font-size: 16px;
          line-height: 16px;
          color: white;
        }
        .both {
          display: flex;
          justify-content: space-between;
        }
        .state {
          text-align: right;
        }
      </style>
    `}_handleTap(){handleClick(this,this.hass,this._config,!1)}_handleHold(){handleClick(this,this.hass,this._config,!0)}}customElements.define("hui-picture-entity-card",hui_picture_entity_card_HuiPictureEntityCard);const STATES_OFF=new Set(["closed","locked","not_home","off"]);class hui_picture_glance_card_HuiPictureGlanceCard extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}getCardSize(){return 3}setConfig(config){if(!config||!config.entities||!Array.isArray(config.entities)||!(config.image||config.camera_image||config.state_image)||config.state_image&&!config.entity){throw new Error("Invalid card configuration")}const entities=Object(process_config_entities.a)(config.entities);this._entitiesDialog=[];this._entitiesToggle=[];entities.forEach(item=>{if(config.force_dialog||!common_const.f.has(Object(compute_domain.a)(item.entity))){this._entitiesDialog.push(item)}else{this._entitiesToggle.push(item)}});this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <ha-card>
        <hui-image
          class="${Object(classMap.a)({clickable:!!(this._config.tap_action||this._config.hold_action||this._config.camera_image)})}"
          @ha-click="${this._handleTap}"
          @ha-hold="${this._handleHold}"
          .longPress="${longPress()}"
          .hass="${this.hass}"
          .image="${this._config.image}"
          .stateImage="${this._config.state_image}"
          .cameraImage="${this._config.camera_image}"
          .entity="${this._config.entity}"
          .aspectRatio="${this._config.aspect_ratio}"
        ></hui-image>
        <div class="box">
          ${this._config.title?lit_element.c`
                  <div class="title">${this._config.title}</div>
                `:""}
          <div>
            ${this._entitiesDialog.map(entityConf=>this.renderEntity(entityConf,!0))}
          </div>
          <div>
            ${this._entitiesToggle.map(entityConf=>this.renderEntity(entityConf,!1))}
          </div>
        </div>
      </ha-card>
    `}renderEntity(entityConf,dialog){const stateObj=this.hass.states[entityConf.entity];if(!stateObj){return lit_element.c``}return lit_element.c`
      <ha-icon
        .entity="${stateObj.entity_id}"
        @click="${dialog?this._openDialog:this._callService}"
        class="${Object(classMap.a)({"state-on":!STATES_OFF.has(stateObj.state)})}"
        .icon="${entityConf.icon||Object(state_icon.a)(stateObj)}"
        title="${`
            ${Object(compute_state_name.a)(stateObj)} : ${Object(compute_state_display.a)(this.localize,stateObj,this.hass.language)}
          `}"
      ></ha-icon>
    `}_handleTap(){handleClick(this,this.hass,this._config,!1)}_handleHold(){handleClick(this,this.hass,this._config,!0)}_openDialog(ev){Object(fire_event.a)(this,"hass-more-info",{entityId:ev.target.entity})}_callService(ev){toggleEntity(this.hass,ev.target.entity)}renderStyle(){return lit_element.c`
      <style>
        ha-card {
          position: relative;
          min-height: 48px;
          overflow: hidden;
        }
        hui-image.clickable {
          cursor: pointer;
        }
        .box {
          @apply --paper-font-common-nowrap;
          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;
          background-color: rgba(0, 0, 0, 0.3);
          padding: 4px 8px;
          font-size: 16px;
          line-height: 40px;
          color: white;
          display: flex;
          justify-content: space-between;
        }
        .box .title {
          font-weight: 500;
          margin-left: 8px;
        }
        ha-icon {
          cursor: pointer;
          padding: 8px;
          color: #a9a9a9;
        }
        ha-icon.state-on {
          color: white;
        }
      </style>
    `}}customElements.define("hui-picture-glance-card",hui_picture_glance_card_HuiPictureGlanceCard);__webpack_require__(269);customElements.define("hui-plant-status-card",class extends hui_legacy_wrapper_card_LegacyWrapperCard{static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(113),__webpack_require__.e(77)]).then(__webpack_require__.bind(null,742));return document.createElement("hui-plant-status-card-editor")}static getStubConfig(){return{}}constructor(){super("ha-plant-card","plant")}});var paper_spinner=__webpack_require__(111),data_history=__webpack_require__(203);const midPoint=(_Ax,_Ay,_Bx,_By)=>{return[(_Ax-_Bx)/2+_Bx,(_Ay-_By)/2+_By]},getPath=coords=>{let next,Z;const X=0,Y=1;let path="",last=coords.filter(Boolean)[0];path+=`M ${last[X]},${last[Y]}`;for(const coord of coords){next=coord;Z=midPoint(last[X],last[Y],next[X],next[Y]);path+=` ${Z[X]},${Z[Y]}`;path+=` Q${next[X]},${next[Y]}`;last=next}path+=` ${next[X]},${next[Y]}`;return path},calcPoints=(history,hours,width,detail,min,max)=>{const coords=[],margin=5,height=80;width-=10;let yRatio=(max-min)/height;yRatio=0!==yRatio?yRatio:height;let xRatio=width/(hours-(1===detail?1:0));xRatio=isFinite(xRatio)?xRatio:width;const getCoords=(item,i,offset=0,depth=1)=>{if(1<depth){return item.forEach((subItem,index)=>getCoords(subItem,i,index,depth-1))}const average=item.reduce((sum,entry)=>sum+parseFloat(entry.state),0)/item.length,x=xRatio*(i+offset/6)+margin,y=height-(average-min)/yRatio+2*margin;return coords.push([x,y])};history.forEach((item,i)=>getCoords(item,i,0,detail));if(1===coords.length){coords[1]=[width+margin,coords[0][1]]}coords.push([width+margin,coords[coords.length-1][1]]);return coords},coordinates=(history,hours,width,detail)=>{history.forEach(item=>item.state=+item.state);history=history.filter(item=>!Number.isNaN(item.state));const min=_Mathmin.apply(Math,history.map(item=>item.state)),max=_Mathmax3.apply(Math,history.map(item=>item.state)),now=new Date().getTime(),reduce=(res,item,point)=>{const age=now-new Date(item.last_changed).getTime();let key=Math.abs(age/(3600*1e3)-hours);if(point){key=60*(key-_Mathfloor3(key));key=+(10*_Mathround3(key/10)).toString()[0]}else{key=_Mathfloor3(key)}if(!res[key]){res[key]=[]}res[key].push(item);return res};history=history.reduce((res,item)=>reduce(res,item,!1),[]);if(1<detail){history=history.map(entry=>entry.reduce((res,item)=>reduce(res,item,!0),[]))}return calcPoints(history,hours,width,detail,min,max)};class hui_sensor_card_HuiSensorCard extends lit_element.a{static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(114),__webpack_require__.e(78)]).then(__webpack_require__.bind(null,743));return document.createElement("hui-sensor-card-editor")}static getStubConfig(){return{}}static get properties(){return{hass:{},_config:{},_history:{}}}setConfig(config){if(!config.entity||"sensor"!==config.entity.split(".")[0]){throw new Error("Specify an entity from within the sensor domain.")}const cardConfig=Object.assign({detail:1,theme:"default",hours_to_show:24},config);cardConfig.hours_to_show=+cardConfig.hours_to_show;cardConfig.detail=1===cardConfig.detail||2===cardConfig.detail?cardConfig.detail:1;this._config=cardConfig}getCardSize(){return 3}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];let graph;if("line"===this._config.graph){if(!stateObj.attributes.unit_of_measurement){graph=lit_element.c`
          <div class="not-found">
            Entity: ${this._config.entity} - Has no Unit of Measurement and
            therefore can not display a line graph.
          </div>
        `}else if(!this._history){graph=lit_element.e`
          <svg width="100%" height="100%" viewBox="0 0 500 100"></svg>
        `}else{graph=lit_element.e`
          <svg width="100%" height="100%" viewBox="0 0 500 100">
            <path
              d="${this._history}"
              fill="none"
              stroke="var(--accent-color)"
              stroke-width="5"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        `}}else{graph=""}return lit_element.c`
      ${this.renderStyle()}
      <ha-card @click="${this._handleClick}">
        ${!stateObj?lit_element.c`
                <div class="not-found">
                  Entity not available: ${this._config.entity}
                </div>
              `:lit_element.c`
                <div class="flex">
                  <div class="icon">
                    <ha-icon
                      .icon="${this._config.icon||Object(state_icon.a)(stateObj)}"
                    ></ha-icon>
                  </div>
                  <div class="header">
                    <span class="name"
                      >${this._config.name||Object(compute_state_name.a)(stateObj)}</span
                    >
                  </div>
                </div>
                <div class="flex info">
                  <span id="value">${stateObj.state}</span>
                  <span id="measurement"
                    >${this._config.unit||stateObj.attributes.unit_of_measurement}</span
                  >
                </div>
                <div class="graph"><div>${graph}</div></div>
              `}
      </ha-card>
    `}firstUpdated(){this._date=new Date}updated(changedProps){super.updated(changedProps);if(!this._config||"line"!==this._config.graph||!this.hass){return}const oldHass=changedProps.get("hass");if(!oldHass||oldHass.themes!==this.hass.themes){Object(apply_themes_on_element.a)(this,this.hass.themes,this._config.theme)}if(changedProps.has("_config")){this._getHistory()}else if(Date.now()-this._date.getTime()>=6e4){this._getHistory()}}_handleClick(){Object(fire_event.a)(this,"hass-more-info",{entityId:this._config.entity})}async _getHistory(){const endTime=new Date,startTime=new Date;startTime.setHours(endTime.getHours()-this._config.hours_to_show);const stateHistory=await Object(data_history.c)(this.hass,this._config.entity,startTime,endTime);if(1>stateHistory[0].length){return}const coords=coordinates(stateHistory[0],this._config.hours_to_show,500,this._config.detail);this._history=getPath(coords);this._date=new Date}renderStyle(){return lit_element.c`
      <style>
        :host {
          display: flex;
          flex-direction: column;
        }
        ha-card {
          display: flex;
          flex-direction: column;
          flex: 1;
          padding: 16px;
          position: relative;
          cursor: pointer;
        }
        .flex {
          display: flex;
        }
        .header {
          align-items: center;
          display: flex;
          min-width: 0;
          opacity: 0.8;
          position: relative;
        }
        .name {
          display: block;
          display: -webkit-box;
          font-size: 1.2rem;
          font-weight: 500;
          max-height: 1.4rem;
          margin-top: 2px;
          opacity: 0.8;
          overflow: hidden;
          text-overflow: ellipsis;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          word-wrap: break-word;
          word-break: break-all;
        }
        .icon {
          color: var(--paper-item-icon-color, #44739e);
          display: inline-block;
          flex: 0 0 40px;
          line-height: 40px;
          position: relative;
          text-align: center;
          width: 40px;
        }
        .info {
          flex-wrap: wrap;
          margin: 16px 0 16px 8px;
        }
        #value {
          display: inline-block;
          font-size: 2rem;
          font-weight: 400;
          line-height: 1em;
          margin-right: 4px;
        }
        #measurement {
          align-self: flex-end;
          display: inline-block;
          font-size: 1.3rem;
          line-height: 1.2em;
          margin-top: 0.1em;
          opacity: 0.6;
          vertical-align: bottom;
        }
        .graph {
          align-self: flex-end;
          margin: auto;
          margin-bottom: 0px;
          position: relative;
          width: 100%;
        }
        .graph > div {
          align-self: flex-end;
          margin: auto 8px;
        }
        .not-found {
          flex: 1;
          background-color: yellow;
          padding: 8px;
        }
      </style>
    `}}customElements.define("hui-sensor-card",hui_sensor_card_HuiSensorCard);customElements.define("hui-vertical-stack-card",class extends hui_stack_card_HuiStackCard{getCardSize(){let totalSize=0;if(!this._cards){return totalSize}for(const element of this._cards){totalSize+=Object(compute_card_size.a)(element)}return totalSize}renderStyle(){return lit_element.c`
      <style>
        #root {
          display: flex;
          flex-direction: column;
        }
        #root > * {
          margin: 4px 0 4px 0;
        }
        #root > *:first-child {
          margin-top: 0;
        }
        #root > *:last-child {
          margin-bottom: 0;
        }
      </style>
    `}});var repeat=__webpack_require__(302),paper_checkbox=__webpack_require__(134);const fetchItems=hass=>hass.callWS({type:"shopping_list/items"}),updateItem=(hass,itemId,item)=>hass.callWS(Object.assign({type:"shopping_list/items/update",item_id:itemId},item)),clearItems=hass=>hass.callWS({type:"shopping_list/items/clear"}),addItem=(hass,name)=>hass.callWS({type:"shopping_list/items/add",name});class hui_shopping_list_card_HuiShoppingListCard extends Object(lit_localize_mixin.a)(lit_element.a){static async getConfigElement(){await __webpack_require__.e(79).then(__webpack_require__.bind(null,744));return document.createElement("hui-shopping-list-card-editor")}static getStubConfig(){return{}}static get properties(){return{hass:{},_config:{},_uncheckedItems:{},_checkedItems:{}}}getCardSize(){return(this._config?this._config.title?1:0:0)+3}setConfig(config){this._config=config;this._uncheckedItems=[];this._checkedItems=[];this._fetchData()}connectedCallback(){super.connectedCallback();if(this.hass){this._unsubEvents=this.hass.connection.subscribeEvents(()=>this._fetchData(),"shopping_list_updated");this._fetchData()}}disconnectedCallback(){super.disconnectedCallback();if(this._unsubEvents){this._unsubEvents.then(unsub=>unsub())}}render(){if(!this._config||!this.hass){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <ha-card .header="${this._config.title}">
        <div class="addRow">
          <ha-icon
            class="addButton"
            @click="${this._addItem}"
            icon="hass:plus"
            .title="${this.localize("ui.panel.lovelace.cards.shopping-list.add_item")}"
          >
          </ha-icon>
          <paper-item-body>
            <paper-input
              no-label-float
              class="addBox"
              placeholder="${this.localize("ui.panel.lovelace.cards.shopping-list.add_item")}"
              @keydown="${this._addKeyPress}"
            ></paper-input>
          </paper-item-body>
        </div>
        ${Object(repeat.a)(this._uncheckedItems,item=>item.id,(item,index)=>lit_element.c`
                <div class="editRow">
                  <paper-checkbox
                    slot="item-icon"
                    id="${index}"
                    ?checked="${item.complete}"
                    .itemId="${item.id}"
                    @click="${this._completeItem}"
                    tabindex="0"
                  ></paper-checkbox>
                  <paper-item-body>
                    <paper-input
                      no-label-float
                      .value="${item.name}"
                      .itemId="${item.id}"
                      @change="${this._saveEdit}"
                    ></paper-input>
                  </paper-item-body>
                </div>
              `)}
        ${0<this._checkedItems.length?lit_element.c`
                <div class="divider"></div>
                <div class="checked">
                  <span class="label">
                    ${this.localize("ui.panel.lovelace.cards.shopping-list.checked_items")}
                  </span>
                  <ha-icon
                    class="clearall"
                    @click="${this._clearItems}"
                    icon="hass:notification-clear-all"
                    .title="${this.localize("ui.panel.lovelace.cards.shopping-list.clear_items")}"
                  >
                  </ha-icon>
                </div>
                ${Object(repeat.a)(this._checkedItems,item=>item.id,(item,index)=>lit_element.c`
                        <div class="editRow">
                          <paper-checkbox
                            slot="item-icon"
                            id="${index}"
                            ?checked="${item.complete}"
                            .itemId="${item.id}"
                            @click="${this._completeItem}"
                            tabindex="0"
                          ></paper-checkbox>
                          <paper-item-body>
                            <paper-input
                              no-label-float
                              .value="${item.name}"
                              .itemId="${item.id}"
                              @change="${this._saveEdit}"
                            ></paper-input>
                          </paper-item-body>
                        </div>
                      `)}
              `:""}
      </ha-card>
    `}renderStyle(){return lit_element.c`
      <style>
        .editRow,
        .addRow {
          display: flex;
          flex-direction: row;
        }
        .addButton {
          padding: 9px 15px 11px 15px;
          cursor: pointer;
        }
        paper-checkbox {
          padding: 11px 11px 11px 18px;
        }
        paper-input {
          --paper-input-container-underline: {
            display: none;
          }
          --paper-input-container-underline-focus: {
            display: none;
          }
          --paper-input-container-underline-disabled: {
            display: none;
          }
          position: relative;
          top: 1px;
        }
        .checked {
          margin-left: 17px;
          margin-bottom: 11px;
          margin-top: 11px;
        }
        .label {
          color: var(--primary-color);
        }
        .divider {
          height: 1px;
          background-color: var(--divider-color);
          margin: 10px;
        }
        .clearall {
          cursor: pointer;
          margin-bottom: 3px;
          float: right;
          padding-right: 10px;
        }
        .addRow > ha-icon {
          color: var(--secondary-text-color);
        }
      </style>
    `}async _fetchData(){if(this.hass){const checkedItems=[],uncheckedItems=[],items=await fetchItems(this.hass);for(const key in items){if(items[key].complete){checkedItems.push(items[key])}else{uncheckedItems.push(items[key])}}this._checkedItems=checkedItems;this._uncheckedItems=uncheckedItems}}_completeItem(ev){updateItem(this.hass,ev.target.itemId,{complete:ev.target.checked}).catch(()=>this._fetchData())}_saveEdit(ev){updateItem(this.hass,ev.target.itemId,{name:ev.target.value}).catch(()=>this._fetchData());ev.target.blur()}_clearItems(){if(this.hass){clearItems(this.hass).catch(()=>this._fetchData())}}get _newItem(){return this.shadowRoot.querySelector(".addBox")}_addItem(ev){const newItem=this._newItem;if(0<newItem.value.length){addItem(this.hass,newItem.value).catch(()=>this._fetchData())}newItem.value="";if(ev){newItem.focus()}}_addKeyPress(ev){if(13===ev.keyCode){this._addItem(null)}}}customElements.define("hui-shopping-list-card",hui_shopping_list_card_HuiShoppingListCard);var render_status=__webpack_require__(377);const thermostatConfig={radius:150,circleShape:"pie",startAngle:315,width:5,lineCap:"round",handleSize:"+10",showTooltip:!1,animation:!1},modeIcons={auto:"hass:autorenew",manual:"hass:cursor-pointer",heat:"hass:fire",cool:"hass:snowflake",off:"hass:power",fan_only:"hass:fan",eco:"hass:leaf",dry:"hass:water-percent",idle:"hass:power-sleep"};function formatTemp(temps){return temps.filter(Boolean).join("-")}function computeTemperatureStepSize(hass,config){const stateObj=hass.states[config.entity];if(stateObj.attributes.target_temp_step){return stateObj.attributes.target_temp_step}return hass.config.unit_system.temperature===common_const.k?1:.5}class hui_thermostat_card_HuiThermostatCard extends Object(lit_localize_mixin.a)(lit_element.a){static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(115),__webpack_require__.e(80)]).then(__webpack_require__.bind(null,745));return document.createElement("hui-thermostat-card-editor")}static getStubConfig(){return{entity:""}}static get properties(){return{hass:{},_config:{},roundSliderStyle:{},_jQuery:{}}}getCardSize(){return 4}setConfig(config){if(!config.entity||"climate"!==config.entity.split(".")[0]){throw new Error("Specify an entity from within the climate domain.")}this._config=Object.assign({theme:"default"},config)}render(){if(!this.hass||!this._config){return lit_element.c``}const stateObj=this.hass.states[this._config.entity],mode=modeIcons[stateObj.attributes.operation_mode||""]?stateObj.attributes.operation_mode:"unknown-mode";return lit_element.c`
      ${this.renderStyle()}
      <ha-card
        class="${Object(classMap.a)({[mode]:!0,large:this._broadCard,small:!this._broadCard})}">
        <div id="root">
          <div id="thermostat"></div>
          <div id="tooltip">
            <div class="title">${this._config.name||Object(compute_state_name.a)(stateObj)}</div>
            <div class="current-temperature">
              <span class="current-temperature-text">
                ${stateObj.attributes.current_temperature}
                ${stateObj.attributes.current_temperature?lit_element.c`
                        <span class="uom"
                          >${this.hass.config.unit_system.temperature}</span
                        >
                      `:""}
              </span>
            </div>
            <div class="climate-info">
            <div id="set-temperature"></div>
            <div class="current-mode">${this.localize(`state.climate.${stateObj.state}`)}</div>
            <div class="modes">
              ${(stateObj.attributes.operation_list||[]).map(modeItem=>this._renderIcon(modeItem,mode))}
            </div>
          </div>
        </div>
      </ha-card>
    `}shouldUpdate(changedProps){return hasConfigOrEntityChanged(this,changedProps)}firstUpdated(){this._initialLoad()}updated(changedProps){super.updated(changedProps);if(!this._config||!this.hass||!changedProps.has("hass")){return}const oldHass=changedProps.get("hass");if(!oldHass||oldHass.themes!==this.hass.themes){Object(apply_themes_on_element.a)(this,this.hass.themes,this._config.theme)}const stateObj=this.hass.states[this._config.entity];if(this._jQuery&&!changedProps.has("_jQuery")&&(!oldHass||oldHass.states[this._config.entity]!==stateObj)){const[sliderValue,uiValue]=this._genSliderValue(stateObj);this._jQuery("#thermostat",this.shadowRoot).roundSlider({value:sliderValue});this._updateSetTemp(uiValue)}}async _initialLoad(){const radius=this.clientWidth/3;this._broadCard=390<this.clientWidth;this.shadowRoot.querySelector("#thermostat").style.minHeight=2*radius+"px";const loaded=await loadRoundslider();await new Promise(resolve=>Object(render_status.a)(resolve));this._roundSliderStyle=loaded.roundSliderStyle;this._jQuery=loaded.jQuery;const stateObj=this.hass.states[this._config.entity],_sliderType=stateObj.attributes.target_temp_low&&stateObj.attributes.target_temp_high?"range":"min-range",[sliderValue,uiValue]=this._genSliderValue(stateObj),step=computeTemperatureStepSize(this.hass,this._config);this._jQuery("#thermostat",this.shadowRoot).roundSlider(Object.assign({},thermostatConfig,{radius,min:stateObj.attributes.min_temp,max:stateObj.attributes.max_temp,sliderType:_sliderType,create:()=>this._loaded(),change:value=>this._setTemperature(value),drag:value=>this._dragEvent(value),value:sliderValue,step}));this._updateSetTemp(uiValue)}_genSliderValue(stateObj){let sliderValue,uiValue;if(stateObj.attributes.target_temp_low&&stateObj.attributes.target_temp_high){sliderValue=`${stateObj.attributes.target_temp_low}, ${stateObj.attributes.target_temp_high}`;uiValue=formatTemp([stateObj.attributes.target_temp_low+"",stateObj.attributes.target_temp_high+""])}else{sliderValue=stateObj.attributes.temperature;uiValue=""+stateObj.attributes.temperature}return[sliderValue,uiValue]}_loaded(){this.shadowRoot.querySelector("#thermostat").style.minHeight=null}_updateSetTemp(value){this.shadowRoot.querySelector("#set-temperature").innerHTML=value}_dragEvent(e){this._updateSetTemp(formatTemp((e.value+"").split(",")))}_setTemperature(e){const stateObj=this.hass.states[this._config.entity];if(stateObj.attributes.target_temp_low&&stateObj.attributes.target_temp_high){if(1===e.handle.index){this.hass.callService("climate","set_temperature",{entity_id:this._config.entity,target_temp_low:e.handle.value,target_temp_high:stateObj.attributes.target_temp_high})}else{this.hass.callService("climate","set_temperature",{entity_id:this._config.entity,target_temp_low:stateObj.attributes.target_temp_low,target_temp_high:e.handle.value})}}else{this.hass.callService("climate","set_temperature",{entity_id:this._config.entity,temperature:e.value})}}_renderIcon(mode,currentMode){if(!modeIcons[mode]){return lit_element.c``}return lit_element.c`
      <ha-icon
        class="${Object(classMap.a)({"selected-icon":currentMode===mode})}"
        .mode="${mode}"
        .icon="${modeIcons[mode]}"
        @click="${this._handleModeClick}"
      ></ha-icon>
    `}_handleModeClick(e){this.hass.callService("climate","set_operation_mode",{entity_id:this._config.entity,operation_mode:e.currentTarget.mode})}renderStyle(){return lit_element.c`
      ${this._roundSliderStyle}
      <style>
        :host {
          display: block;
        }
        ha-card {
          overflow: hidden;
          --rail-border-color: transparent;
          --auto-color: green;
          --eco-color: springgreen;
          --cool-color: #2b9af9;
          --heat-color: #ff8100;
          --manual-color: #44739e;
          --off-color: #8a8a8a;
          --fan_only-color: #8a8a8a;
          --dry-color: #efbd07;
          --idle-color: #8a8a8a;
          --unknown-color: #bac;
        }
        #root {
          position: relative;
          overflow: hidden;
        }
        .auto {
          --mode-color: var(--auto-color);
        }
        .cool {
          --mode-color: var(--cool-color);
        }
        .heat {
          --mode-color: var(--heat-color);
        }
        .manual {
          --mode-color: var(--manual-color);
        }
        .off {
          --mode-color: var(--off-color);
        }
        .fan_only {
          --mode-color: var(--fan_only-color);
        }
        .eco {
          --mode-color: var(--eco-color);
        }
        .dry {
          --mode-color: var(--dry-color);
        }
        .idle {
          --mode-color: var(--idle-color);
        }
        .unknown-mode {
          --mode-color: var(--unknown-color);
        }
        .no-title {
          --title-margin-top: 33% !important;
        }
        .large {
          --thermostat-padding-top: 25px;
          --thermostat-margin-bottom: 25px;
          --title-font-size: 28px;
          --title-margin-top: 20%;
          --climate-info-margin-top: 17%;
          --modes-margin-top: 2%;
          --set-temperature-font-size: 25px;
          --current-temperature-font-size: 71px;
          --current-temperature-margin-top: 10%;
          --current-temperature-text-padding-left: 15px;
          --uom-font-size: 20px;
          --uom-margin-left: -18px;
          --current-mode-font-size: 18px;
          --set-temperature-padding-bottom: 5px;
        }
        .small {
          --thermostat-padding-top: 15px;
          --thermostat-margin-bottom: 15px;
          --title-font-size: 18px;
          --title-margin-top: 20%;
          --climate-info-margin-top: 7.5%;
          --modes-margin-top: 1%;
          --set-temperature-font-size: 16px;
          --current-temperature-font-size: 25px;
          --current-temperature-margin-top: 5%;
          --current-temperature-text-padding-left: 7px;
          --uom-font-size: 12px;
          --uom-margin-left: -5px;
          --current-mode-font-size: 14px;
          --set-temperature-padding-bottom: 0px;
        }
        #thermostat {
          margin: 0 auto var(--thermostat-margin-bottom);
          padding-top: var(--thermostat-padding-top);
        }
        #thermostat .rs-range-color {
          background-color: var(--mode-color, var(--disabled-text-color));
        }
        #thermostat .rs-path-color {
          background-color: var(--disabled-text-color);
        }
        #thermostat .rs-handle {
          background-color: var(--paper-card-background-color, white);
          padding: 7px;
          border: 2px solid var(--disabled-text-color);
        }
        #thermostat .rs-handle.rs-focus {
          border-color: var(--mode-color, var(--disabled-text-color));
        }
        #thermostat .rs-handle:after {
          border-color: var(--mode-color, var(--disabled-text-color));
          background-color: var(--mode-color, var(--disabled-text-color));
        }
        #thermostat .rs-border {
          border-color: var(--rail-border-color);
        }
        #thermostat .rs-bar.rs-transition.rs-first,
        .rs-bar.rs-transition.rs-second {
          z-index: 20 !important;
        }
        #thermostat .rs-inner.rs-bg-color.rs-border,
        #thermostat .rs-overlay.rs-transition.rs-bg-color {
          background-color: var(--paper-card-background-color, white);
        }
        #tooltip {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 100%;
          text-align: center;
          z-index: 15;
          color: var(--primary-text-color);
        }
        #set-temperature {
          font-size: var(--set-temperature-font-size);
          padding-bottom: var(--set-temperature-padding-bottom);
        }
        .title {
          font-size: var(--title-font-size);
          margin-top: var(--title-margin-top);
        }
        .climate-info {
          margin-top: var(--climate-info-margin-top);
        }
        .current-mode {
          font-size: var(--current-mode-font-size);
          color: var(--secondary-text-color);
        }
        .modes {
          margin-top: var(--modes-margin-top);
        }
        .modes ha-icon {
          color: var(--disabled-text-color);
          cursor: pointer;
          display: inline-block;
          margin: 0 10px;
        }
        .modes ha-icon.selected-icon {
          color: var(--mode-color);
        }
        .current-temperature {
          margin-top: var(--current-temperature-margin-top);
          font-size: var(--current-temperature-font-size);
        }
        .current-temperature-text {
          padding-left: var(--current-temperature-text-padding-left);
        }
        .uom {
          font-size: var(--uom-font-size);
          vertical-align: top;
          margin-left: var(--uom-margin-left);
        }
      </style>
    `}}customElements.define("hui-thermostat-card",hui_thermostat_card_HuiThermostatCard);__webpack_require__(270);customElements.define("hui-weather-forecast-card",class extends hui_legacy_wrapper_card_LegacyWrapperCard{static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(116),__webpack_require__.e(81)]).then(__webpack_require__.bind(null,746));return document.createElement("hui-weather-forecast-card-editor")}static getStubConfig(){return{}}constructor(){super("ha-weather-card","weather")}getCardSize(){return 4}});const severityMap={red:"var(--label-badge-red)",green:"var(--label-badge-green)",yellow:"var(--label-badge-yellow)",normal:"var(--label-badge-blue)"};class hui_gauge_card_HuiGaugeCard extends lit_element.a{static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(117),__webpack_require__.e(82)]).then(__webpack_require__.bind(null,747));return document.createElement("hui-gauge-card-editor")}static getStubConfig(){return{}}static get properties(){return{hass:{},_config:{}}}getCardSize(){return 2}setConfig(config){if(!config||!config.entity){throw new Error("Invalid card configuration")}if(!Object(valid_entity_id.a)(config.entity)){throw new Error("Invalid Entity")}this._config=Object.assign({min:0,max:100,theme:"default"},config)}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];let state,error;if(!stateObj){error="Entity not available: "+this._config.entity}else{state=+stateObj.state;if(isNaN(state)){error="Entity is non-numeric: "+this._config.entity}}if(error){return lit_element.c`
        ${Object(hui_error_card.b)(Object(hui_error_card.a)(error,this._config))}
      `}return lit_element.c`
      ${this.renderStyle()}
      <ha-card @click="${this._handleClick}">
        ${error?lit_element.c`
                <div class="not-found">${error}</div>
              `:lit_element.c`
                <div class="container">
                  <div class="gauge-a"></div>
                  <div class="gauge-b"></div>
                  <div
                    class="gauge-c"
                    style="${styleMap({transform:`rotate(${this._translateTurn(state)}turn)`,"background-color":this._computeSeverity(state)})}"
                  ></div>
                  <div class="gauge-data">
                    <div id="percent">
                      ${stateObj.state}
                      ${this._config.unit||stateObj.attributes.unit_of_measurement||""}
                    </div>
                    <div id="name">
                      ${this._config.name||Object(compute_state_name.a)(stateObj)}
                    </div>
                  </div>
                </div>
              `}
      </ha-card>
    `}shouldUpdate(changedProps){return hasConfigOrEntityChanged(this,changedProps)}firstUpdated(){this.shadowRoot.querySelector("ha-card").style.setProperty("--base-unit",this._computeBaseUnit())}updated(changedProps){super.updated(changedProps);if(!this._config||!this.hass){return}const oldHass=changedProps.get("hass");if(!oldHass||oldHass.themes!==this.hass.themes){Object(apply_themes_on_element.a)(this,this.hass.themes,this._config.theme)}}_computeSeverity(numberValue){const sections=this._config.severity;if(!sections){return severityMap.normal}const sectionsArray=Object.keys(sections),sortable=sectionsArray.map(severity=>[severity,sections[severity]]);for(const severity of sortable){if(null==severityMap[severity[0]]||isNaN(severity[1])){return severityMap.normal}}sortable.sort((a,b)=>a[1]-b[1]);if(numberValue>=sortable[0][1]&&numberValue<sortable[1][1]){return severityMap[sortable[0][0]]}if(numberValue>=sortable[1][1]&&numberValue<sortable[2][1]){return severityMap[sortable[1][0]]}if(numberValue>=sortable[2][1]){return severityMap[sortable[2][0]]}return severityMap.normal}_translateTurn(value){const{min,max}=this._config,maxTurnValue=_Mathmin(_Mathmax3(value,min),max);return 5*(maxTurnValue-min)/(max-min)/10}_computeBaseUnit(){return 200>this.clientWidth?this.clientWidth/5+"px":"50px"}_handleClick(){Object(fire_event.a)(this,"hass-more-info",{entityId:this._config.entity})}renderStyle(){return lit_element.c`
      <style>
        ha-card {
          --base-unit: 50px;
          height: calc(var(--base-unit) * 3);
          position: relative;
          cursor: pointer;
        }
        .container {
          width: calc(var(--base-unit) * 4);
          height: calc(var(--base-unit) * 2);
          position: absolute;
          top: calc(var(--base-unit) * 1.5);
          left: 50%;
          overflow: hidden;
          text-align: center;
          transform: translate(-50%, -50%);
        }
        .gauge-a {
          z-index: 1;
          position: absolute;
          background-color: var(--primary-background-color);
          width: calc(var(--base-unit) * 4);
          height: calc(var(--base-unit) * 2);
          top: 0%;
          border-radius: calc(var(--base-unit) * 2.5)
            calc(var(--base-unit) * 2.5) 0px 0px;
        }
        .gauge-b {
          z-index: 3;
          position: absolute;
          background-color: var(--paper-card-background-color);
          width: calc(var(--base-unit) * 2.5);
          height: calc(var(--base-unit) * 1.25);
          top: calc(var(--base-unit) * 0.75);
          margin-left: calc(var(--base-unit) * 0.75);
          margin-right: auto;
          border-radius: calc(var(--base-unit) * 2.5)
            calc(var(--base-unit) * 2.5) 0px 0px;
        }
        .gauge-c {
          z-index: 2;
          position: absolute;
          background-color: var(--label-badge-blue);
          width: calc(var(--base-unit) * 4);
          height: calc(var(--base-unit) * 2);
          top: calc(var(--base-unit) * 2);
          margin-left: auto;
          margin-right: auto;
          border-radius: 0px 0px calc(var(--base-unit) * 2)
            calc(var(--base-unit) * 2);
          transform-origin: center top;
          transition: all 1.3s ease-in-out;
        }
        .gauge-data {
          z-index: 4;
          color: var(--primary-text-color);
          line-height: calc(var(--base-unit) * 0.3);
          position: absolute;
          width: calc(var(--base-unit) * 4);
          height: calc(var(--base-unit) * 2.1);
          top: calc(var(--base-unit) * 1.2);
          margin-left: auto;
          margin-right: auto;
          transition: all 1s ease-out;
        }
        .gauge-data #percent {
          font-size: calc(var(--base-unit) * 0.55);
        }
        .gauge-data #name {
          padding-top: calc(var(--base-unit) * 0.15);
          font-size: calc(var(--base-unit) * 0.3);
        }
        .not-found {
          flex: 1;
          background-color: yellow;
          padding: 8px;
        }
      </style>
    `}}customElements.define("hui-gauge-card",hui_gauge_card_HuiGaugeCard);__webpack_require__.d(__webpack_exports__,"a",function(){return createCardElement});const CARD_TYPES=new Set(["alarm-panel","conditional","entities","entity-button","entity-filter","error","gauge","glance","history-graph","horizontal-stack","iframe","light","map","markdown","media-control","picture","picture-elements","picture-entity","picture-glance","plant-status","sensor","shopping-list","thermostat","vertical-stack","weather-forecast"]),create_card_element_CUSTOM_TYPE_PREFIX="custom:",create_card_element_createElement=(tag,config)=>{const element=document.createElement(tag);try{element.setConfig(config)}catch(err){console.error(tag,err);return create_card_element_createErrorElement(err.message,config)}return element},create_card_element_createErrorElement=(error,config)=>Object(hui_error_card.b)(Object(hui_error_card.a)(error,config)),createCardElement=config=>{if(!config||"object"!==typeof config||!config.type){return create_card_element_createErrorElement("No card type configured.",config)}if(config.type.startsWith(create_card_element_CUSTOM_TYPE_PREFIX)){const tag=config.type.substr(create_card_element_CUSTOM_TYPE_PREFIX.length);if(customElements.get(tag)){return create_card_element_createElement(tag,config)}const element=create_card_element_createErrorElement(`Custom element doesn't exist: ${tag}.`,config);element.style.display="None";const timer=window.setTimeout(()=>{element.style.display=""},2e3);customElements.whenDefined(tag).then(()=>{clearTimeout(timer);Object(fire_event.a)(element,"rebuild-view")});return element}if(!CARD_TYPES.has(config.type)){return create_card_element_createErrorElement(`Unknown card type encountered: ${config.type}.`,config)}return create_card_element_createElement(`hui-${config.type}-card`,config)}},327:function(module,__webpack_exports__){"use strict";const validEntityId=/^(\w+)\.(\w+)$/;__webpack_exports__.a=entityId=>validEntityId.test(entityId)},328:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_iron_image_iron_image__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(164),_polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(1),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(10),_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(48);class HaEntityMarker extends Object(_mixins_events_mixin__WEBPACK_IMPORTED_MODULE_3__.a)(_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_2__.a){static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_1__.a`
      <style include="iron-positioning"></style>
      <style>
        .marker {
          vertical-align: top;
          position: relative;
          display: block;
          margin: 0 auto;
          width: 2.5em;
          text-align: center;
          height: 2.5em;
          line-height: 2.5em;
          font-size: 1.5em;
          border-radius: 50%;
          border: 0.1em solid
            var(--ha-marker-color, var(--default-primary-color));
          color: rgb(76, 76, 76);
          background-color: white;
        }
        iron-image {
          border-radius: 50%;
        }
      </style>

      <div class="marker">
        <template is="dom-if" if="[[entityName]]"
          >[[entityName]]</template
        >
        <template is="dom-if" if="[[entityPicture]]">
          <iron-image
            sizing="cover"
            class="fit"
            src="[[entityPicture]]"
          ></iron-image>
        </template>
      </div>
    `}static get properties(){return{hass:{type:Object},entityId:{type:String,value:""},entityName:{type:String,value:null},entityPicture:{type:String,value:null}}}ready(){super.ready();this.addEventListener("click",ev=>this.badgeTap(ev))}badgeTap(ev){ev.stopPropagation();if(this.entityId){this.fire("hass-more-info",{entityId:this.entityId})}}}customElements.define("ha-entity-marker",HaEntityMarker)},329:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return setupLeafletMap});const setupLeafletMap=async mapElement=>{const Leaflet=(await __webpack_require__.e(119).then(__webpack_require__.t.bind(null,438,7))).default;Leaflet.Icon.Default.imagePath="/static/images/leaflet";const map=Leaflet.map(mapElement),style=document.createElement("link");style.setAttribute("href","/static/images/leaflet/leaflet.css");style.setAttribute("rel","stylesheet");mapElement.parentNode.appendChild(style);map.setView([51.505,-.09],13);Leaflet.tileLayer(`https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}${Leaflet.Browser.retina?"@2x.png":".png"}`,{attribution:"&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a>, &copy; <a href=\"https://carto.com/attributions\">CARTO</a>",subdomains:"abcd",minZoom:0,maxZoom:20}).addTo(map);return[map,Leaflet]}},376:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return debounce});function debounce(func,wait,immediate){let timeout;return function(...args){const context=this,callNow=immediate&&!timeout;clearTimeout(timeout);timeout=setTimeout(()=>{timeout=null;if(!immediate)func.apply(context,args)},wait);if(callNow)func.apply(context,args)}}},377:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return afterNextRender});const afterNextRender=cb=>{requestAnimationFrame(()=>setTimeout(cb,0))}},378:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return showEditCardDialog});var _common_dom_fire_event__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(65);let registeredDialog=!1;const dialogShowEvent="show-edit-card",registerEditCardDialog=element=>Object(_common_dom_fire_event__WEBPACK_IMPORTED_MODULE_0__.a)(element,"register-dialog",{dialogShowEvent,dialogTag:"hui-dialog-edit-card",dialogImport:()=>Promise.all([__webpack_require__.e(6),__webpack_require__.e(103),__webpack_require__.e(83)]).then(__webpack_require__.bind(null,703))}),showEditCardDialog=(element,editCardDialogParams)=>{if(!registeredDialog){registeredDialog=!0;registerEditCardDialog(element)}Object(_common_dom_fire_event__WEBPACK_IMPORTED_MODULE_0__.a)(element,dialogShowEvent,editCardDialogParams)}},439:function(module,__webpack_exports__,__webpack_require__){"use strict";var lit_element=__webpack_require__(57),ha_card=__webpack_require__(168),common_const=__webpack_require__(80),compute_domain=__webpack_require__(157);const turnOnOffEntities=(hass,entityIds,turnOn=!0)=>{const domainsToCall={};entityIds.forEach(entityId=>{if(common_const.i.includes(hass.states[entityId].state)===turnOn){const stateDomain=Object(compute_domain.a)(entityId),serviceDomain=["cover","lock"].includes(stateDomain)?stateDomain:"homeassistant";if(!(serviceDomain in domainsToCall)){domainsToCall[serviceDomain]=[]}domainsToCall[serviceDomain].push(entityId)}});Object.keys(domainsToCall).forEach(domain=>{let service;switch(domain){case"lock":service=turnOn?"unlock":"lock";break;case"cover":service=turnOn?"open_cover":"close_cover";break;default:service=turnOn?"turn_on":"turn_off";}const entities=domainsToCall[domain];hass.callService(domain,service,{entity_id:entities})})};class hui_entities_toggle_HuiEntitiesToggle extends lit_element.a{static get properties(){return{hass:{},entities:{},_toggleEntities:{}}}updated(changedProperties){super.updated(changedProperties);if(changedProperties.has("entities")){this._toggleEntities=this.entities.filter(entityId=>entityId in this.hass.states&&common_const.f.has(entityId.split(".",1)[0]))}}render(){if(!this._toggleEntities){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <paper-toggle-button
        ?checked="${this._toggleEntities.some(entityId=>"on"===this.hass.states[entityId].state)}"
        @change="${this._callService}"
      ></paper-toggle-button>
    `}renderStyle(){return lit_element.c`
      <style>
        :host {
          width: 38px;
          display: block;
        }
        paper-toggle-button {
          cursor: pointer;
          --paper-toggle-button-label-spacing: 0;
          padding: 13px 5px;
          margin: -4px -5px;
        }
      </style>
    `}_callService(ev){const turnOn=ev.target.checked;turnOnOffEntities(this.hass,this._toggleEntities,turnOn)}}customElements.define("hui-entities-toggle",hui_entities_toggle_HuiEntitiesToggle);var fire_event=__webpack_require__(65),lit_localize_mixin=__webpack_require__(154),process_config_entities=__webpack_require__(257),hui_error_card=__webpack_require__(233),ha_climate_state=__webpack_require__(245),html_tag=__webpack_require__(1),polymer_element=__webpack_require__(10),state_badge=__webpack_require__(161),ha_relative_time=__webpack_require__(216),ha_icon=__webpack_require__(159),compute_state_name=__webpack_require__(105);class hui_generic_entity_row_HuiGenericEntityRow extends polymer_element.a{static get template(){return html_tag.a`
      ${this.styleTemplate}
      <template is="dom-if" if="[[_stateObj]]">
        ${this.stateBadgeTemplate}
        <div class="flex">${this.infoTemplate} <slot></slot></div>
      </template>
      <template is="dom-if" if="[[!_stateObj]]">
        <div class="not-found">Entity not available: [[config.entity]]</div>
      </template>
    `}static get styleTemplate(){return html_tag.a`
      <style>
        :host {
          display: flex;
          align-items: center;
        }
        .flex {
          flex: 1;
          margin-left: 16px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          min-width: 0;
        }
        .info {
          flex: 1 0 60px;
        }
        .info,
        .info > * {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .flex ::slotted(*) {
          margin-left: 8px;
          min-width: 0;
        }
        .flex ::slotted([slot="secondary"]) {
          margin-left: 0;
        }
        .secondary,
        ha-relative-time {
          display: block;
          color: var(--secondary-text-color);
        }
        .not-found {
          flex: 1;
          background-color: yellow;
          padding: 8px;
        }
        state-badge {
          flex: 0 0 40px;
        }
      </style>
    `}static get stateBadgeTemplate(){return html_tag.a`
      <state-badge
        state-obj="[[_stateObj]]"
        override-icon="[[config.icon]]"
      ></state-badge>
    `}static get infoTemplate(){return html_tag.a`
      <div class="info">
        [[_computeName(config.name, _stateObj)]]
        <div class="secondary">
          <template is="dom-if" if="[[showSecondary]]">
            <template
              is="dom-if"
              if="[[_equals(config.secondary_info, 'entity-id')]]"
            >
              [[_stateObj.entity_id]]
            </template>
            <template
              is="dom-if"
              if="[[_equals(config.secondary_info, 'last-changed')]]"
            >
              <ha-relative-time
                hass="[[hass]]"
                datetime="[[_stateObj.last_changed]]"
              ></ha-relative-time>
            </template>
          </template>
          <template is="dom-if" if="[[!showSecondary]">
            <slot name="secondary"></slot>
          </template>
        </div>
      </div>
    `}static get properties(){return{hass:Object,config:Object,_stateObj:{type:Object,computed:"_computeStateObj(hass.states, config.entity)"},showSecondary:{type:Boolean,value:!0}}}_equals(a,b){return a===b}_computeStateObj(states,entityId){return states&&entityId in states?states[entityId]:null}_computeName(name,stateObj){return name||Object(compute_state_name.a)(stateObj)}}customElements.define("hui-generic-entity-row",hui_generic_entity_row_HuiGenericEntityRow);class hui_climate_entity_row_HuiClimateEntityRow extends lit_element.a{static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config||!config.entity){throw new Error("Invalid Configuration: 'entity' required")}this._config=config}render(){if(!this.hass||!this._config){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        <ha-climate-state
          .hass="${this.hass}"
          .stateObj="${stateObj}"
        ></ha-climate-state>
      </hui-generic-entity-row>
    `}renderStyle(){return lit_element.c`
      <style>
        ha-climate-state {
          text-align: right;
        }
      </style>
    `}}customElements.define("hui-climate-entity-row",hui_climate_entity_row_HuiClimateEntityRow);var ha_cover_controls=__webpack_require__(246),ha_cover_tilt_controls=__webpack_require__(234);class hui_error_entity_row_HuiErrorEntityRow extends lit_element.a{static get properties(){return{error:{},entity:{}}}render(){return lit_element.c`
      ${this.renderStyle()} ${this.error||"Entity not available"}:
      ${this.entity||""}
    `}renderStyle(){return lit_element.c`
      <style>
        :host {
          display: block;
          color: black;
          background-color: yellow;
          padding: 8px;
        }
      </style>
    `}}customElements.define("hui-error-entity-row",hui_error_entity_row_HuiErrorEntityRow);var cover_model=__webpack_require__(198);class hui_cover_entity_row_HuiCoverEntityRow extends lit_element.a{static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        ${Object(cover_model.b)(stateObj)?lit_element.c`
                <ha-cover-tilt-controls
                  .hass="${this.hass}"
                  .stateObj="${stateObj}"
                ></ha-cover-tilt-controls>
              `:lit_element.c`
                <ha-cover-controls
                  .hass="${this.hass}"
                  .stateObj="${stateObj}"
                ></ha-cover-controls>
              `}
      </hui-generic-entity-row>
    `}renderStyle(){return lit_element.c`
      <style>
        ha-cover-controls,
        ha-cover-tilt-controls {
          margin-right: -0.57em;
        }
      </style>
    `}}customElements.define("hui-cover-entity-row",hui_cover_entity_row_HuiCoverEntityRow);var ha_entity_toggle=__webpack_require__(202),compute_state_display=__webpack_require__(190);class hui_group_entity_row_HuiGroupEntityRow extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        ${this._computeCanToggle(stateObj.attributes.entity_id)?lit_element.c`
                <ha-entity-toggle
                  .hass="${this.hass}"
                  .stateObj="${stateObj}"
                ></ha-entity-toggle>
              `:lit_element.c`
                <div>
                  ${Object(compute_state_display.a)(this.localize,stateObj,this.hass.language)}
                </div>
              `}
      </hui-generic-entity-row>
    `}_computeCanToggle(entityIds){return entityIds.some(entityId=>common_const.f.has(entityId.split(".",1)[0]))}}customElements.define("hui-group-entity-row",hui_group_entity_row_HuiGroupEntityRow);var paper_input=__webpack_require__(78),iron_resizable_behavior=__webpack_require__(84),legacy_class=__webpack_require__(62),ha_slider=__webpack_require__(247);class hui_input_number_entity_row_HuiInputNumberEntityRow extends Object(legacy_class.b)([iron_resizable_behavior.a],polymer_element.a){static get template(){return html_tag.a`
      ${this.styleTemplate}
      <hui-generic-entity-row
        hass="[[hass]]"
        config="[[_config]]"
        id="input_number_card"
      >
        ${this.inputNumberControlTemplate}
      </hui-generic-entity-row>
    `}static get styleTemplate(){return html_tag.a`
      <style>
        .flex {
          display: flex;
          align-items: center;
        }
        .state {
          min-width: 45px;
          text-align: center;
        }
        paper-input {
          text-align: right;
        }
      </style>
    `}static get inputNumberControlTemplate(){return html_tag.a`
      <div>
        <template
          is="dom-if"
          if="[[_equals(_stateObj.attributes.mode, 'slider')]]"
        >
          <div class="flex">
            <ha-slider
              min="[[_min]]"
              max="[[_max]]"
              value="{{_value}}"
              step="[[_step]]"
              pin
              on-change="_selectedValueChanged"
              ignore-bar-touch
            ></ha-slider>
            <span class="state"
              >[[_value]] [[_stateObj.attributes.unit_of_measurement]]</span
            >
          </div>
        </template>
        <template
          is="dom-if"
          if="[[_equals(_stateObj.attributes.mode, 'box')]]"
        >
          <paper-input
            no-label-float
            auto-validate
            pattern="[0-9]+([\\.][0-9]+)?"
            step="[[_step]]"
            min="[[_min]]"
            max="[[_max]]"
            value="{{_value}}"
            type="number"
            on-change="_selectedValueChanged"
          ></paper-input>
        </template>
      </div>
    `}static get properties(){return{hass:Object,_config:Object,_stateObj:{type:Object,computed:"_computeStateObj(hass.states, _config.entity)",observer:"_stateObjChanged"},_min:{type:Number,value:0},_max:{type:Number,value:100},_step:Number,_value:Number}}ready(){super.ready();if("function"===typeof ResizeObserver){const ro=new ResizeObserver(entries=>{entries.forEach(()=>{this._hiddenState()})});ro.observe(this.$.input_number_card)}else{this.addEventListener("iron-resize",this._hiddenState)}}_equals(a,b){return a===b}_computeStateObj(states,entityId){return states&&entityId in states?states[entityId]:null}setConfig(config){if(!config||!config.entity){throw new Error("Entity not configured.")}this._config=config}_hiddenState(){if(!this.$||!this._stateObj||"slider"!==this._stateObj.attributes.mode)return;const width=this.$.input_number_card.offsetWidth,stateEl=this.shadowRoot.querySelector(".state");if(!stateEl)return;stateEl.hidden=350>=width}_stateObjChanged(stateObj,oldStateObj){if(!stateObj)return;this.setProperties({_min:+stateObj.attributes.min,_max:+stateObj.attributes.max,_step:+stateObj.attributes.step,_value:+stateObj.state});if(oldStateObj&&"slider"===stateObj.attributes.mode&&"slider"!==oldStateObj.attributes.mode){this._hiddenState()}}_selectedValueChanged(){if(this._value===+this._stateObj.state)return;this.hass.callService("input_number","set_value",{value:this._value,entity_id:this._stateObj.entity_id})}}customElements.define("hui-input-number-entity-row",hui_input_number_entity_row_HuiInputNumberEntityRow);var repeat=__webpack_require__(302),paper_dropdown_menu=__webpack_require__(129),paper_item=__webpack_require__(126),paper_listbox=__webpack_require__(128);const setOption=(hass,entity,option)=>hass.callService("input_select","select_option",{option,entity_id:entity});class hui_input_select_entity_row_HuiInputSelectEntityRow extends lit_element.a{static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config||!config.entity){throw new Error("Invalid Configuration: 'entity' required")}this._config=config}render(){if(!this.hass||!this._config){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <state-badge .stateObj="${stateObj}"></state-badge>
      <paper-dropdown-menu
        selected-item-label="${stateObj.state}"
        @selected-item-label-changed="${this._selectedChanged}"
        label="${this._config.name||Object(compute_state_name.a)(stateObj)}"
      >
        <paper-listbox
          slot="dropdown-content"
          selected="${stateObj.attributes.options.indexOf(stateObj.state)}"
        >
          ${Object(repeat.a)(stateObj.attributes.options,option=>lit_element.c`
                  <paper-item>${option}</paper-item>
                `)}
        </paper-listbox>
      </paper-dropdown-menu>
    `}renderStyle(){return lit_element.c`
      <style>
        :host {
          display: flex;
          align-items: center;
        }
        paper-dropdown-menu {
          margin-left: 16px;
          flex: 1;
        }
      </style>
    `}_selectedChanged(ev){const stateObj=this.hass.states[this._config.entity];if(!ev.target.selectedItem||""===ev.target.selectedItem.innerText||ev.target.selectedItem.innerText===stateObj.state){return}setOption(this.hass,stateObj.entity_id,ev.target.selectedItem.innerText)}}customElements.define("hui-input-select-entity-row",hui_input_select_entity_row_HuiInputSelectEntityRow);const setValue=(hass,entity,value)=>hass.callService("input_text","set_value",{value,entity_id:entity});class hui_input_text_entity_row_HuiInputTextEntityRow extends lit_element.a{static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        <paper-input
          no-label-float
          .value="${stateObj.state}"
          .minlength="${stateObj.attributes.min}"
          .maxlength="${stateObj.attributes.max}"
          .autoValidate="${stateObj.attributes.pattern}"
          .pattern="${stateObj.attributes.pattern}"
          .type="${stateObj.attributes.mode}"
          @change="${this._selectedValueChanged}"
          placeholder="(empty value)"
        ></paper-input>
      </hui-generic-entity-row>
    `}get _inputEl(){return this.shadowRoot.querySelector("paper-input")}_selectedValueChanged(ev){const element=this._inputEl,stateObj=this.hass.states[this._config.entity];if(element.value!==stateObj.state){setValue(this.hass,stateObj.entity_id,element.value)}ev.target.blur()}}customElements.define("hui-input-text-entity-row",hui_input_text_entity_row_HuiInputTextEntityRow);class hui_lock_entity_row_HuiLockEntityRow extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        <paper-button @click="${this._callService}">
          ${"locked"===stateObj.state?this.localize("ui.card.lock.unlock"):this.localize("ui.card.lock.lock")}
        </paper-button>
      </hui-generic-entity-row>
    `}renderStyle(){return lit_element.c`
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          margin-right: -0.57em;
        }
      </style>
    `}_callService(ev){ev.stopPropagation();const stateObj=this.hass.states[this._config.entity];this.hass.callService("lock","locked"===stateObj.state?"unlock":"lock",{entity_id:stateObj.entity_id})}}customElements.define("hui-lock-entity-row",hui_lock_entity_row_HuiLockEntityRow);var paper_icon_button=__webpack_require__(99),supports_feature=__webpack_require__(193);const OFF_STATES=["off","idle"];class hui_media_player_entity_row_HuiMediaPlayerEntityRow extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config||!config.entity){throw new Error("Invalid Configuration: 'entity' required")}this._config=config}render(){if(!this.hass||!this._config){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <hui-generic-entity-row
        .hass="${this.hass}"
        .config="${this._config}"
        .showSecondary="false"
      >
        ${OFF_STATES.includes(stateObj.state)?lit_element.c`
                <div>
                  ${this.localize(`state.media_player.${stateObj.state}`)||this.localize(`state.default.${stateObj.state}`)||stateObj.state}
                </div>
              `:lit_element.c`
                <div class="controls">
                  ${"playing"!==stateObj.state&&!Object(supports_feature.a)(stateObj,16384)?"":lit_element.c`
                          <paper-icon-button
                            icon="${this._computeControlIcon(stateObj)}"
                            @click="${this._playPause}"
                          ></paper-icon-button>
                        `}
                  ${Object(supports_feature.a)(stateObj,32)?lit_element.c`
                          <paper-icon-button
                            icon="hass:skip-next"
                            @click="${this._nextTrack}"
                          ></paper-icon-button>
                        `:""}
                </div>
                <div slot="secondary">${this._computeMediaTitle(stateObj)}</div>
              `}
      </hui-generic-entity-row>
    `}renderStyle(){return lit_element.c`
      <style>
        .controls {
          white-space: nowrap;
        }
      </style>
    `}_computeControlIcon(stateObj){if("playing"!==stateObj.state){return"hass:play"}return Object(supports_feature.a)(stateObj,1)?"hass:pause":"hass:stop"}_computeMediaTitle(stateObj){let prefix,suffix;switch(stateObj.attributes.media_content_type){case"music":prefix=stateObj.attributes.media_artist;suffix=stateObj.attributes.media_title;break;case"tvshow":prefix=stateObj.attributes.media_series_title;suffix=stateObj.attributes.media_title;break;default:prefix=stateObj.attributes.media_title||stateObj.attributes.app_name||stateObj.state;suffix="";}return prefix&&suffix?`${prefix}: ${suffix}`:prefix||suffix||""}_playPause(ev){ev.stopPropagation();this.hass.callService("media_player","media_play_pause",{entity_id:this._config.entity})}_nextTrack(ev){ev.stopPropagation();this.hass.callService("media_player","media_next_track",{entity_id:this._config.entity})}}customElements.define("hui-media-player-entity-row",hui_media_player_entity_row_HuiMediaPlayerEntityRow);class hui_scene_entity_row_HuiSceneEntityRow extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        ${stateObj.attributes.can_cancel?lit_element.c`
                <ha-entity-toggle
                  .hass="${this.hass}"
                  .stateObj="${stateObj}"
                ></ha-entity-toggle>
              `:lit_element.c`
                <paper-button @click="${this._callService}">
                  ${this.localize("ui.card.scene.activate")}
                </paper-button>
              `}
      </hui-generic-entity-row>
    `}renderStyle(){return lit_element.c`
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          margin-right: -0.57em;
        }
      </style>
    `}_callService(ev){ev.stopPropagation();this.hass.callService("scene","turn_on",{entity_id:this._config.entity})}}customElements.define("hui-scene-entity-row",hui_scene_entity_row_HuiSceneEntityRow);class hui_script_entity_row_HuiScriptEntityRow extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        ${stateObj.attributes.can_cancel?lit_element.c`
                <ha-entity-toggle
                  .hass="${this.hass}"
                  .stateObj="${stateObj}"
                ></ha-entity-toggle>
              `:lit_element.c`
                <paper-button @click="${this._callService}">
                  ${this.localize("ui.card.script.execute")}
                </paper-button>
              `}
      </hui-generic-entity-row>
    `}renderStyle(){return lit_element.c`
      <style>
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          margin-right: -0.57em;
        }
      </style>
    `}_callService(ev){ev.stopPropagation();this.hass.callService("script","turn_on",{entity_id:this._config.entity})}}customElements.define("hui-script-entity-row",hui_script_entity_row_HuiScriptEntityRow);var format_date=__webpack_require__(208),format_date_time=__webpack_require__(173),format_time=__webpack_require__(188),relative_time=__webpack_require__(231);const FORMATS={date:format_date.a,datetime:format_date_time.a,time:format_time.a},INTERVAL_FORMAT=["relative","total"];class hui_timestamp_display_HuiTimestampDisplay extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{ts:{},hass:{},format:{},_relative:{}}}connectedCallback(){super.connectedCallback();this._connected=!0;this._startInterval()}disconnectedCallback(){super.disconnectedCallback();this._connected=!1;this._clearInterval()}render(){if(!this.ts||!this.hass){return lit_element.c``}if(isNaN(this.ts.getTime())){return lit_element.c`
        Invalid date
      `}const format=this._format;if(INTERVAL_FORMAT.includes(format)){return lit_element.c`
        ${this._relative}
      `}else if(format in FORMATS){return lit_element.c`
        ${FORMATS[format](this.ts,this.hass.language)}
      `}else{return lit_element.c`
        Invalid format
      `}}updated(changedProperties){super.updated(changedProperties);if(!changedProperties.has("format")||!this._connected){return}if(INTERVAL_FORMAT.includes("relative")){this._startInterval()}else{this._clearInterval()}}get _format(){return this.format||"relative"}_startInterval(){this._clearInterval();if(this._connected&&INTERVAL_FORMAT.includes(this._format)){this._updateRelative();this._interval=window.setInterval(()=>this._updateRelative(),1e3)}}_clearInterval(){if(this._interval){clearInterval(this._interval);this._interval=void 0}}_updateRelative(){if(this.ts&&this.localize){this._relative="relative"===this._format?Object(relative_time.a)(this.ts,this.localize):this._relative=Object(relative_time.a)(new Date,this.localize,{compareTime:this.ts,includeTense:!1})}}}customElements.define("hui-timestamp-display",hui_timestamp_display_HuiTimestampDisplay);class hui_sensor_entity_row_HuiSensorEntityRow extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        <div>
          ${"timestamp"===stateObj.attributes.device_class?lit_element.c`
                  <hui-timestamp-display
                    .hass="${this.hass}"
                    .ts="${new Date(stateObj.state)}"
                    .format="${this._config.format}"
                  ></hui-timestamp-display>
                `:Object(compute_state_display.a)(this.localize,stateObj,this.hass.language)}
        </div>
      </hui-generic-entity-row>
    `}renderStyle(){return lit_element.c`
      <style>
        div {
          text-align: right;
        }
      </style>
    `}}customElements.define("hui-sensor-entity-row",hui_sensor_entity_row_HuiSensorEntityRow);class hui_text_entity_row_HuiTextEntityRow extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      ${this.renderStyle()}
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        <div>
          ${Object(compute_state_display.a)(this.localize,stateObj,this.hass.language)}
        </div>
      </hui-generic-entity-row>
    `}renderStyle(){return lit_element.c`
      <style>
        div {
          text-align: right;
        }
      </style>
    `}}customElements.define("hui-text-entity-row",hui_text_entity_row_HuiTextEntityRow);var timer_time_remaining=__webpack_require__(227),seconds_to_duration=__webpack_require__(219);class hui_timer_entity_row_HuiTimerEntityRow extends polymer_element.a{static get template(){return html_tag.a`
      <hui-generic-entity-row hass="[[hass]]" config="[[_config]]">
        ${this.timerControlTemplate}
      </hui-generic-entity-row>
    `}static get timerControlTemplate(){return html_tag.a`
      <div>[[_computeDisplay(_stateObj, _timeRemaining)]]</div>
    `}static get properties(){return{hass:Object,_config:Object,_stateObj:{type:Object,computed:"_computeStateObj(hass.states, _config.entity)",observer:"_stateObjChanged"},_timeRemaining:Number}}disconnectedCallback(){super.disconnectedCallback();this._clearInterval()}_stateObjChanged(stateObj){if(stateObj){this._startInterval(stateObj)}else{this._clearInterval()}}_clearInterval(){if(this._updateRemaining){clearInterval(this._updateRemaining);this._updateRemaining=null}}_startInterval(stateObj){this._clearInterval();this._calculateRemaining(stateObj);if("active"===stateObj.state){this._updateRemaining=setInterval(()=>this._calculateRemaining(this._stateObj),1e3)}}_calculateRemaining(stateObj){this._timeRemaining=Object(timer_time_remaining.a)(stateObj)}_computeDisplay(stateObj,time){if(!stateObj)return null;if("idle"===stateObj.state||0===time)return stateObj.state;let display=Object(seconds_to_duration.a)(time);if("paused"===stateObj.state){display+=" (paused)"}return display}_computeStateObj(states,entityId){return states&&entityId in states?states[entityId]:null}setConfig(config){if(!config||!config.entity){throw new Error("Entity not configured.")}this._config=config}}customElements.define("hui-timer-entity-row",hui_timer_entity_row_HuiTimerEntityRow);class hui_toggle_entity_row_HuiToggleEntityRow extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config){throw new Error("Configuration error")}this._config=config}render(){if(!this._config||!this.hass){return lit_element.c``}const stateObj=this.hass.states[this._config.entity];if(!stateObj){return lit_element.c`
        <hui-error-entity-row
          .entity="${this._config.entity}"
        ></hui-error-entity-row>
      `}return lit_element.c`
      <hui-generic-entity-row .hass="${this.hass}" .config="${this._config}">
        ${"on"===stateObj.state||"off"===stateObj.state?lit_element.c`
                <ha-entity-toggle
                  .hass="${this.hass}"
                  .stateObj="${stateObj}"
                ></ha-entity-toggle>
              `:lit_element.c`
                <div>
                  ${Object(compute_state_display.a)(this.localize,stateObj,this.hass.language)}
                </div>
              `}
      </hui-generic-entity-row>
    `}}customElements.define("hui-toggle-entity-row",hui_toggle_entity_row_HuiToggleEntityRow);__webpack_require__(72);const callService=(config,hass)=>{const entityId=config.entity,[domain,service]=config.service.split(".",2),serviceData=Object.assign({entity_id:entityId},config.service_data);hass.callService(domain,service,serviceData)};class hui_call_service_row_HuiCallServiceRow extends lit_element.a{static get properties(){return{hass:{},_config:{}}}setConfig(config){if(!config||!config.name||!config.service){throw new Error("Error in card configuration.")}this._config=Object.assign({icon:"hass:remote",action_name:"Run"},config)}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <ha-icon .icon="${this._config.icon}"></ha-icon>
      <div class="flex">
        <div>${this._config.name}</div>
        <paper-button @click="${this._callService}"
          >${this._config.action_name}</paper-button
        >
      </div>
    `}renderStyle(){return lit_element.c`
      <style>
        :host {
          display: flex;
          align-items: center;
        }
        ha-icon {
          padding: 8px;
          color: var(--paper-item-icon-color);
        }
        .flex {
          flex: 1;
          overflow: hidden;
          margin-left: 16px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .flex div {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        paper-button {
          color: var(--primary-color);
          font-weight: 500;
          margin-right: -0.57em;
        }
      </style>
    `}_callService(){callService(this._config,this.hass)}}customElements.define("hui-call-service-row",hui_call_service_row_HuiCallServiceRow);class hui_divider_row_HuiDividerRow extends lit_element.a{static get properties(){return{_config:{}}}setConfig(config){if(!config){throw new Error("Error in card configuration.")}this._config=Object.assign({style:{height:"1px","background-color":"var(--secondary-text-color)"}},config)}render(){if(!this._config){return lit_element.c``}const el=document.createElement("div");Object.keys(this._config.style).forEach(prop=>{el.style.setProperty(prop,this._config.style[prop])});return lit_element.c`
      ${el}
    `}}customElements.define("hui-divider-row",hui_divider_row_HuiDividerRow);class hui_section_row_HuiSectionRow extends lit_element.a{static get properties(){return{_config:{}}}setConfig(config){if(!config){throw new Error("Error in card configuration.")}this._config=config}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <div class="divider"></div>
      ${this._config.label?lit_element.c`
              <div class="label">${this._config.label}</div>
            `:lit_element.c``}
    `}renderStyle(){return lit_element.c`
      <style>
        .label {
          color: var(--primary-color);
          margin-left: 8px;
          margin-bottom: 16px;
          margin-top: 16px;
        }
        .divider {
          height: 1px;
          background-color: var(--secondary-text-color);
          opacity: 0.25;
          margin-left: -16px;
          margin-right: -16px;
          margin-top: 8px;
        }
      </style>
    `}}customElements.define("hui-section-row",hui_section_row_HuiSectionRow);class hui_weblink_row_HuiWeblinkRow extends lit_element.a{static get properties(){return{_config:{}}}setConfig(config){if(!config||!config.url){throw new Error("Invalid Configuration: 'url' required")}this._config=Object.assign({icon:"hass:link",name:config.url},config)}render(){if(!this._config){return lit_element.c``}return lit_element.c`
      ${this.renderStyle()}
      <a href="${this._config.url}" target="_blank">
        <ha-icon .icon="${this._config.icon}"></ha-icon>
        <div>${this._config.name}</div>
      </a>
    `}renderStyle(){return lit_element.c`
      <style>
        a {
          display: flex;
          align-items: center;
          color: var(--primary-color);
        }
        ha-icon {
          padding: 8px;
          color: var(--paper-item-icon-color);
        }
        div {
          flex: 1;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          margin-left: 16px;
        }
      </style>
    `}}customElements.define("hui-weblink-row",hui_weblink_row_HuiWeblinkRow);const CUSTOM_TYPE_PREFIX="custom:",SPECIAL_TYPES=new Set(["call-service","divider","section","weblink"]),DOMAIN_TO_ELEMENT_TYPE={alert:"toggle",automation:"toggle",climate:"climate",cover:"cover",fan:"toggle",group:"group",input_boolean:"toggle",input_number:"input-number",input_select:"input-select",input_text:"input-text",light:"toggle",media_player:"media-player",lock:"lock",scene:"scene",script:"script",sensor:"sensor",timer:"timer",switch:"toggle",vacuum:"toggle"},_createElement=(tag,config)=>{const element=document.createElement(tag);try{element.setConfig(config)}catch(err){console.error(tag,err);return _createErrorElement(err.message,config)}return element},_createErrorElement=(error,config)=>Object(hui_error_card.b)(Object(hui_error_card.a)(error,config)),_hideErrorElement=element=>{element.style.display="None";return window.setTimeout(()=>{element.style.display=""},2e3)},createRowElement=config=>{let tag;if(!config||"object"!==typeof config||!config.entity&&!config.type){return _createErrorElement("Invalid config given.",config)}const type=config.type||"default";if(SPECIAL_TYPES.has(type)){return _createElement(`hui-${type}-row`,config)}if(type.startsWith(CUSTOM_TYPE_PREFIX)){tag=type.substr(CUSTOM_TYPE_PREFIX.length);if(customElements.get(tag)){return _createElement(tag,config)}const element=_createErrorElement(`Custom element doesn't exist: ${tag}.`,config),timer=_hideErrorElement(element);customElements.whenDefined(tag).then(()=>{clearTimeout(timer);Object(fire_event.a)(element,"rebuild-view")});return element}const domain=config.entity.split(".",1)[0];tag=`hui-${DOMAIN_TO_ELEMENT_TYPE[domain]||"text"}-entity-row`;return _createElement(tag,config)};var apply_themes_on_element=__webpack_require__(114);class hui_entities_card_HuiEntitiesCard extends Object(lit_localize_mixin.a)(lit_element.a){static async getConfigElement(){await Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(108),__webpack_require__.e(66)]).then(__webpack_require__.bind(null,732));return document.createElement("hui-entities-card-editor")}static getStubConfig(){return{entities:[]}}set hass(hass){this._hass=hass;this.shadowRoot.querySelectorAll("#states > div > *").forEach(element=>{element.hass=hass});const entitiesToggle=this.shadowRoot.querySelector("hui-entities-toggle");if(entitiesToggle){entitiesToggle.hass=hass}}static get properties(){return{_config:{}}}getCardSize(){if(!this._config){return 0}return(this._config.title?1:0)+this._config.entities.length}setConfig(config){const entities=Object(process_config_entities.a)(config.entities);this._config=Object.assign({theme:"default"},config);this._configEntities=entities}updated(changedProperties){super.updated(changedProperties);if(this._hass&&this._config){Object(apply_themes_on_element.a)(this,this._hass.themes,this._config.theme)}}render(){if(!this._config||!this._hass){return lit_element.c``}const{show_header_toggle,title}=this._config;return lit_element.c`
      ${this.renderStyle()}
      <ha-card>
        ${!title&&!show_header_toggle?lit_element.c``:lit_element.c`
                <div class="header">
                  <div class="name">${title}</div>
                  ${!1===show_header_toggle?lit_element.c``:lit_element.c`
                          <hui-entities-toggle
                            .hass="${this._hass}"
                            .entities="${this._configEntities.map(conf=>conf.entity)}"
                          ></hui-entities-toggle>
                        `}
                </div>
              `}
        <div id="states">
          ${this._configEntities.map(entityConf=>this.renderEntity(entityConf))}
        </div>
      </ha-card>
    `}renderStyle(){return lit_element.c`
      <style>
        ha-card {
          padding: 16px;
        }
        #states {
          margin: -4px 0;
        }
        #states > * {
          margin: 8px 0;
        }
        #states > div > * {
          overflow: hidden;
        }
        .header {
          @apply --paper-font-headline;
          /* overwriting line-height +8 because entity-toggle can be 40px height,
            compensating this with reduced padding */
          line-height: 40px;
          color: var(--primary-text-color);
          padding: 4px 0 12px;
          display: flex;
          justify-content: space-between;
        }
        .header .name {
          @apply --paper-font-common-nowrap;
        }
        .state-card-dialog {
          cursor: pointer;
        }
      </style>
    `}renderEntity(entityConf){const element=createRowElement(entityConf);if(this._hass){element.hass=this._hass}if(entityConf.entity&&!common_const.d.includes(Object(compute_domain.a)(entityConf.entity))){element.classList.add("state-card-dialog");element.addEventListener("click",()=>this._handleClick(entityConf))}return lit_element.c`
      <div>${element}</div>
    `}_handleClick(entityConf){const entityId=entityConf.entity;Object(fire_event.a)(this,"hass-more-info",{entityId})}}customElements.define("hui-entities-card",hui_entities_card_HuiEntitiesCard)},756:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.r(__webpack_exports__);__webpack_require__(72);const fetchConfig=(hass,force)=>hass.callWS({type:"lovelace/config",force}),saveConfig=(hass,config)=>hass.callWS({type:"lovelace/config/save",config});var hass_loading_screen=__webpack_require__(142),hass_error_screen=__webpack_require__(139),lit_element=__webpack_require__(57),classMap=__webpack_require__(192),app_header_layout=__webpack_require__(178),app_header=__webpack_require__(172),waterfall=__webpack_require__(267),app_toolbar=__webpack_require__(108),app_route=__webpack_require__(98),paper_icon_button=__webpack_require__(99),paper_item=__webpack_require__(126),paper_listbox=__webpack_require__(128),paper_menu_button=__webpack_require__(130),paper_tab=__webpack_require__(213),paper_tabs=__webpack_require__(239);function scrollToTarget(element,target){var top=0,scroller=target,easingFn=function(t,b,c,d){t/=d;return-c*t*(t-2)+b},animationId=Math.random(),duration=200,startTime=Date.now(),currentScrollTop=scroller.scrollTop;element._currentAnimationId=animationId;(function updateFrame(){var now=Date.now(),elapsedTime=now-startTime;if(elapsedTime>duration){scroller.scrollTop=top}else if(element._currentAnimationId===animationId){scroller.scrollTop=easingFn(elapsedTime,currentScrollTop,top-currentScrollTop,duration);requestAnimationFrame(updateFrame.bind(element))}}).call(element)}var ha_app_layout=__webpack_require__(200),ha_start_voice_button=__webpack_require__(242),ha_icon=__webpack_require__(159),load_resource=__webpack_require__(77),haws_es=__webpack_require__(17);const fetchNotifications=conn=>conn.sendMessagePromise({type:"persistent_notification/get"}),subscribeUpdates=(conn,store)=>conn.subscribeEvents(()=>fetchNotifications(conn).then(ntf=>store.setState(ntf,!0)),"persistent_notifications_updated"),subscribeNotifications=(conn,onChange)=>Object(haws_es.d)("_ntf",fetchNotifications,subscribeUpdates,conn,onChange);var debounce=__webpack_require__(376),lit_localize_mixin=__webpack_require__(154),common_navigate=__webpack_require__(119),fire_event=__webpack_require__(65),compute_domain=__webpack_require__(157);const computeNotifications=states=>{return Object.keys(states).filter(entityId=>"configurator"===Object(compute_domain.a)(entityId)).map(entityId=>states[entityId])};var html_tag=__webpack_require__(1),polymer_element=__webpack_require__(10),ha_card=__webpack_require__(168);class hui_notification_item_template_HuiNotificationItemTemplate extends polymer_element.a{static get template(){return html_tag.a`
      <style>
        .contents {
          padding: 16px;
        }

        ha-card .header {
          @apply --paper-font-headline;
          color: var(--primary-text-color);
          padding: 16px 16px 0;
        }

        .actions {
          border-top: 1px solid #e8e8e8;
          padding: 5px 16px;
        }

        ::slotted(.primary) {
          color: var(--primary-color);
        }
      </style>
      <ha-card>
        <div class="header"><slot name="header"></slot></div>
        <div class="contents"><slot></slot></div>
        <div class="actions"><slot name="actions"></slot></div>
      </ha-card>
    `}}customElements.define("hui-notification-item-template",hui_notification_item_template_HuiNotificationItemTemplate);var events_mixin=__webpack_require__(48),localize_mixin=__webpack_require__(71);class hui_configurator_notification_item_HuiConfiguratorNotificationItem extends Object(events_mixin.a)(Object(localize_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
      <hui-notification-item-template>
        <span slot="header">[[localize('domain.configurator')]]</span>

        <div>[[_getMessage(notification)]]</div>

        <paper-button slot="actions" class="primary" on-click="_handleClick"
          >[[_localizeState(notification.state)]]</paper-button
        >
      </hui-notification-item-template>
    `}static get properties(){return{hass:Object,notification:Object}}_handleClick(){this.fire("hass-more-info",{entityId:this.notification.entity_id})}_localizeState(state){return this.localize(`state.configurator.${state}`)}_getMessage(notification){const friendlyName=notification.attributes.friendly_name;return this.localize("ui.notification_drawer.click_to_configure","entity",friendlyName)}}customElements.define("hui-configurator-notification-item",hui_configurator_notification_item_HuiConfiguratorNotificationItem);var paper_tooltip=__webpack_require__(243),ha_relative_time=__webpack_require__(216),ha_markdown=__webpack_require__(201);class hui_persistent_notification_item_HuiPersistentNotificationItem extends Object(localize_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        .time {
          display: flex;
          justify-content: flex-end;
          margin-top: 6px;
        }
        ha-relative-time {
          color: var(--secondary-text-color);
        }
        a {
          color: var(--primary-color);
        }
      </style>
      <hui-notification-item-template>
        <span slot="header">[[_computeTitle(notification)]]</span>

        <ha-markdown content="[[notification.message]]"></ha-markdown>

        <div class="time">
          <span>
            <ha-relative-time
              hass="[[hass]]"
              datetime="[[notification.created_at]]"
            ></ha-relative-time>
            <paper-tooltip
              >[[_computeTooltip(hass, notification)]]</paper-tooltip
            >
          </span>
        </div>

        <paper-button slot="actions" class="primary" on-click="_handleDismiss"
          >[[localize('ui.card.persistent_notification.dismiss')]]</paper-button
        >
      </hui-notification-item-template>
    `}static get properties(){return{hass:Object,notification:Object}}_handleDismiss(){this.hass.callService("persistent_notification","dismiss",{notification_id:this.notification.notification_id})}_computeTitle(notification){return notification.title||notification.notification_id}_computeTooltip(hass,notification){if(!hass||!notification)return null;const d=new Date(notification.created_at);return d.toLocaleDateString(hass.language,{year:"numeric",month:"short",day:"numeric",minute:"numeric",hour:"numeric"})}}customElements.define("hui-persistent_notification-notification-item",hui_persistent_notification_item_HuiPersistentNotificationItem);class hui_notification_item_HuiNotificationItem extends polymer_element.a{static get properties(){return{hass:Object,notification:{type:Object,observer:"_stateChanged"}}}_stateChanged(notification){if(this.lastChild){this.removeChild(this.lastChild)}if(!notification)return;const domain=notification.entity_id?Object(compute_domain.a)(notification.entity_id):"persistent_notification",tag=`hui-${domain}-notification-item`,el=document.createElement(tag);el.hass=this.hass;el.notification=notification;this.appendChild(el)}}customElements.define("hui-notification-item",hui_notification_item_HuiNotificationItem);class hui_notification_drawer_HuiNotificationDrawer extends Object(events_mixin.a)(Object(localize_mixin.a)(polymer_element.a)){static get template(){return html_tag.a`
    <style include="paper-material-styles">
      :host {
        bottom: 0;
        left: 0;
        position: absolute;
        right: 0;
        top: 0;
      }

      :host([hidden]) {
        display: none;
      }

      .container {
        align-items: stretch;
        background: var(--sidebar-background-color, var(--primary-background-color));
        bottom: 0;
        box-shadow: var(--paper-material-elevation-1_-_box-shadow);
        display: flex;
        flex-direction: column;
        overflow-y: hidden;
        position: fixed;
        top: 0;
        transition: right .2s ease-in;
        width: 500px;
        z-index: 10;
      }

      :host(:not(narrow)) .container {
        right: -500px;
      }

      :host([narrow]) .container {
        right: -100%;
        width: 100%;
      }

      :host(.open) .container,
      :host(.open[narrow]) .container {
        right: 0;
      }

      app-toolbar {
        color: var(--primary-text-color);
        border-bottom: 1px solid var(--divider-color);
        background-color: var(--primary-background-color);
        min-height: 64px;
        width: calc(100% - 32px);
        z-index: 11;
      }

      .overlay {
        display: none;
      }

      :host(.open) .overlay {
        bottom: 0;
        display: block;
        left: 0;
        position: absolute;
        right: 0;
        top: 0;
        z-index: 5;
      }

      .notifications {
        overflow-y: auto;
        padding-top: 16px;
      }

      .notification {
        padding: 0 16px 16px;
      }

      .empty {
        padding: 16px;
        text-align: center;
      }
    </style>
    <div class="overlay" on-click="_closeDrawer"></div>
    <div class="container">
      <app-toolbar>
        <div main-title>[[localize('ui.notification_drawer.title')]]</div>
        <paper-icon-button icon="hass:chevron-right" on-click="_closeDrawer"></paper-icon-button>
      </app-toolbar>
      <div class="notifications">
        <template is="dom-if" if="[[!_empty(notifications)]]">
          <dom-repeat items="[[notifications]]">
            <template>
              <div class="notification">
                <hui-notification-item hass="[[hass]]" notification="[[item]]"></hui-notification-item>
              </div>
            </template>
          </dom-repeat>
        </template>
        <template is="dom-if" if="[[_empty(notifications)]]">
          <div class="empty">[[localize('ui.notification_drawer.empty')]]<div>
        </template>
      </div>
    </div>
    `}static get properties(){return{hass:Object,narrow:{type:Boolean,reflectToAttribute:!0},open:{type:Boolean,notify:!0,observer:"_openChanged"},hidden:{type:Boolean,value:!0,reflectToAttribute:!0},notifications:{type:Array,value:[]}}}_closeDrawer(ev){ev.stopPropagation();this.open=!1}_empty(notifications){return 0===notifications.length}_openChanged(open){clearTimeout(this._openTimer);if(open){this.hidden=!1;this._openTimer=setTimeout(()=>{this.classList.add("open")},50)}else{this.classList.remove("open");this._openTimer=setTimeout(()=>{this.hidden=!0},250)}}}customElements.define("hui-notification-drawer",hui_notification_drawer_HuiNotificationDrawer);class hui_notifications_button_HuiNotificationsButton extends Object(events_mixin.a)(polymer_element.a){static get template(){return html_tag.a`
      <style>
        :host {
          position: relative;
        }

        .indicator {
          position: absolute;
          top: 10px;
          right: 10px;
          width: 10px;
          height: 10px;
          border-radius: 50%;
          background: var(--accent-color);
          pointer-events: none;
        }

        .indicator[hidden] {
          display: none;
        }
      </style>
      <paper-icon-button
        icon="hass:bell"
        on-click="_clicked"
      ></paper-icon-button>
      <span
        class="indicator"
        hidden$="[[!_hasNotifications(notifications)]]"
      ></span>
    `}static get properties(){return{open:{type:Boolean,notify:!0},notifications:{type:Array,value:[]}}}_clicked(){this.open=!0}_hasNotifications(notifications){return 0<notifications.length}}customElements.define("hui-notifications-button",hui_notifications_button_HuiNotificationsButton);var ha_state_label_badge=__webpack_require__(244),apply_themes_on_element=__webpack_require__(114),create_card_element=__webpack_require__(322),compute_card_size=__webpack_require__(301),show_edit_card_dialog=__webpack_require__(378);let editCodeLoaded=!1;const getColumnIndex=(columnEntityCount,size)=>{let minIndex=0;for(let i=0;i<columnEntityCount.length;i++){if(5>columnEntityCount[i]){minIndex=i;break}if(columnEntityCount[i]<columnEntityCount[minIndex]){minIndex=i}}columnEntityCount[minIndex]+=size;return minIndex};class hui_view_HUIView extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},lovelace:{},columns:{},index:{},_cards:{},_badges:{}}}constructor(){super();this._cards=[];this._badges=[]}render(){return lit_element.c`
      ${this.renderStyles()}
      <div id="badges"></div>
      <div id="columns"></div>
      ${this.lovelace.editMode?lit_element.c`
              <paper-fab
                elevated="2"
                icon="hass:plus"
                title="${this.localize("ui.panel.lovelace.editor.edit_card.add")}"
                @click="${this._addCard}"
              ></paper-fab>
            `:""}
    `}renderStyles(){return lit_element.c`
      <style>
        :host {
          display: block;
          padding: 4px 4px 0;
          transform: translateZ(0);
          position: relative;
          min-height: calc(100vh - 155px);
        }

        #badges {
          margin: 8px 16px;
          font-size: 85%;
          text-align: center;
        }

        #columns {
          display: flex;
          flex-direction: row;
          justify-content: center;
        }

        .column {
          flex-basis: 0;
          flex-grow: 1;
          max-width: 500px;
          overflow-x: hidden;
        }

        .column > * {
          display: block;
          margin: 4px 4px 8px;
        }

        paper-fab {
          position: sticky;
          float: right;
          bottom: 16px;
          right: 16px;
          z-index: 1;
        }

        @media (max-width: 500px) {
          :host {
            padding-left: 0;
            padding-right: 0;
          }

          .column > * {
            margin-left: 0;
            margin-right: 0;
          }
        }

        @media (max-width: 599px) {
          .column {
            max-width: 600px;
          }
        }
      </style>
    `}updated(changedProperties){super.updated(changedProperties);const lovelace=this.lovelace;if(lovelace.editMode&&!editCodeLoaded){editCodeLoaded=!0;__webpack_require__.e(64).then(__webpack_require__.bind(null,758))}let editModeChanged=!1,configChanged=!1;if(changedProperties.has("lovelace")){const oldLovelace=changedProperties.get("lovelace");editModeChanged=!oldLovelace||lovelace.editMode!==oldLovelace.editMode;configChanged=!oldLovelace||lovelace.config!==oldLovelace.config}if(configChanged){this._createBadges(lovelace.config.views[this.index])}else if(changedProperties.has("hass")){this._badges.forEach(badge=>{const{element,entityId}=badge;element.hass=this.hass;element.state=this.hass.states[entityId]})}if(configChanged||editModeChanged||changedProperties.has("columns")){this._createCards(lovelace.config.views[this.index])}else if(changedProperties.has("hass")){this._cards.forEach(element=>{element.hass=this.hass})}}_addCard(){Object(show_edit_card_dialog.a)(this,{lovelace:this.lovelace,path:[this.index]})}_createBadges(config){const root=this.shadowRoot.getElementById("badges");while(root.lastChild){root.removeChild(root.lastChild)}if(!config||!config.badges||!Array.isArray(config.badges)){root.style.display="none";this._badges=[];return}const elements=[];for(const entityId of config.badges){const element=document.createElement("ha-state-label-badge");element.hass=this.hass;element.state=this.hass.states[entityId];elements.push({element,entityId});root.appendChild(element)}this._badges=elements;root.style.display=0<elements.length?"block":"none"}_createCards(config){const root=this.shadowRoot.getElementById("columns");while(root.lastChild){root.removeChild(root.lastChild)}if(!config||!config.cards||!Array.isArray(config.cards)){this._cards=[];return}const elements=[],elementsToAppend=[];config.cards.forEach((cardConfig,cardIndex)=>{const element=Object(create_card_element.a)(cardConfig);element.hass=this.hass;elements.push(element);if(!this.lovelace.editMode){elementsToAppend.push(element);return}const wrapper=document.createElement("hui-card-options");wrapper.hass=this.hass;wrapper.lovelace=this.lovelace;wrapper.path=[this.index,cardIndex];wrapper.appendChild(element);elementsToAppend.push(wrapper)});let columns=[];const columnEntityCount=[];for(let i=0;i<this.columns;i++){columns.push([]);columnEntityCount.push(0)}elements.forEach((el,index)=>{const cardSize=Object(compute_card_size.a)(el);columns[getColumnIndex(columnEntityCount,cardSize)].push(elementsToAppend[index])});columns=columns.filter(val=>0<val.length);columns.forEach(column=>{const columnEl=document.createElement("div");columnEl.classList.add("column");column.forEach(el=>columnEl.appendChild(el));root.appendChild(columnEl)});this._cards=elements;if("theme"in config){Object(apply_themes_on_element.a)(root,this.hass.themes,config.theme)}}}customElements.define("hui-view",hui_view_HUIView);let registeredDialog=!1;const dialogShowEvent="show-edit-view",registerEditViewDialog=element=>Object(fire_event.a)(element,"register-dialog",{dialogShowEvent,dialogTag:"hui-dialog-edit-view",dialogImport:()=>Promise.all([__webpack_require__.e(1),__webpack_require__.e(3),__webpack_require__.e(84)]).then(__webpack_require__.bind(null,760))}),showEditViewDialog=(element,editViewDialogParams)=>{if(!registeredDialog){registeredDialog=!0;registerEditViewDialog(element)}Object(fire_event.a)(element,dialogShowEvent,editViewDialogParams)};let show_edit_lovelace_dialog_registeredDialog=!1;const show_edit_lovelace_dialog_dialogShowEvent="show-edit-lovelace",registerEditLovelaceDialog=element=>Object(fire_event.a)(element,"register-dialog",{dialogShowEvent:show_edit_lovelace_dialog_dialogShowEvent,dialogTag:"hui-dialog-edit-lovelace",dialogImport:()=>__webpack_require__.e(85).then(__webpack_require__.bind(null,764))}),showEditLovelaceDialog=(element,lovelace)=>{if(!show_edit_lovelace_dialog_registeredDialog){show_edit_lovelace_dialog_registeredDialog=!0;registerEditLovelaceDialog(element)}Object(fire_event.a)(element,show_edit_lovelace_dialog_dialogShowEvent,lovelace)};var render_status=__webpack_require__(377);const CSS_CACHE={},JS_CACHE={};let loadedUnusedEntities=!1;class hui_root_HUIRoot extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{narrow:{},showMenu:{},hass:{},lovelace:{},columns:{},route:{},_routeData:{},_curView:{},_notificationsOpen:{},_persistentNotifications:{}}}constructor(){super();this._notificationsOpen=!1;this._debouncedConfigChanged=Object(debounce.a)(()=>this._selectView(this._curView,!0),100)}connectedCallback(){super.connectedCallback();this._unsubNotifications=subscribeNotifications(this.hass.connection,notifications=>{this._persistentNotifications=notifications})}disconnectedCallback(){super.disconnectedCallback();if(this._unsubNotifications){this._unsubNotifications()}}render(){return lit_element.c`
    ${this.renderStyle()}
    <app-route .route="${this.route}" pattern="/:view" data="${this._routeData}" @data-changed="${this._routeDataChanged}"></app-route>
    <hui-notification-drawer
      .hass="${this.hass}"
      .notifications="${this._notifications}"
      .open="${this._notificationsOpen}"
      @open-changed="${this._handleNotificationsOpenChanged}"
      .narrow="${this.narrow}"
    ></hui-notification-drawer>
    <ha-app-layout id="layout">
      <app-header slot="header" effects="waterfall" class="${Object(classMap.a)({"edit-mode":this._editMode})}" fixed condenses>
        ${this._editMode?lit_element.c`
                <app-toolbar class="edit-mode">
                  <paper-icon-button
                    icon="hass:close"
                    @click="${this._editModeDisable}"
                  ></paper-icon-button>
                  <div main-title>
                    ${this.config.title||this.localize("ui.panel.lovelace.editor.header")}
                    <paper-icon-button
                      icon="hass:pencil"
                      class="edit-icon"
                      @click="${this._editLovelace}"
                    ></paper-icon-button>
                  </div>
                  <paper-icon-button
                    icon="hass:help-circle"
                    title="Help"
                    @click="${this._handleHelp}"
                  ></paper-icon-button>
                  <paper-menu-button
                    no-animations
                    horizontal-align="right"
                    horizontal-offset="-5"
                  >
                    <paper-icon-button
                      icon="hass:dots-vertical"
                      slot="dropdown-trigger"
                    ></paper-icon-button>
                    <paper-listbox
                      @iron-select="${this._deselect}"
                      slot="dropdown-content"
                    >
                      <paper-item @click="${this.lovelace.enableFullEditMode}"
                        >Raw config editor</paper-item
                      >
                    </paper-listbox>
                  </paper-menu-button>
                </app-toolbar>
              `:lit_element.c`
                <app-toolbar>
                  <ha-menu-button
                    .narrow="${this.narrow}"
                    .showMenu="${this.showMenu}"
                  ></ha-menu-button>
                  <div main-title>${this.config.title||"Home Assistant"}</div>
                  <hui-notifications-button
                    .hass="${this.hass}"
                    .open="${this._notificationsOpen}"
                    @open-changed="${this._handleNotificationsOpenChanged}"
                    .notifications="${this._notifications}"
                  ></hui-notifications-button>
                  <ha-start-voice-button
                    .hass="${this.hass}"
                  ></ha-start-voice-button>
                  <paper-menu-button
                    no-animations
                    horizontal-align="right"
                    horizontal-offset="-5"
                  >
                    <paper-icon-button
                      icon="hass:dots-vertical"
                      slot="dropdown-trigger"
                    ></paper-icon-button>
                    <paper-listbox
                      @iron-select="${this._deselect}"
                      slot="dropdown-content"
                    >
                      ${this._yamlMode?lit_element.c`
                              <paper-item @click="${this._handleRefresh}"
                                >Refresh</paper-item
                              >
                            `:""}
                      <paper-item @click="${this._handleUnusedEntities}"
                        >Unused entities</paper-item
                      >
                      <paper-item @click="${this._editModeEnable}"
                        >${this.localize("ui.panel.lovelace.editor.configure_ui")}</paper-item
                      >
                      <paper-item @click="${this._handleHelp}">Help</paper-item>
                    </paper-listbox>
                  </paper-menu-button>
                </app-toolbar>
              `}

        ${1<this.lovelace.config.views.length||this._editMode?lit_element.c`
                <div sticky>
                  <paper-tabs
                    scrollable
                    .selected="${this._curView}"
                    @iron-activate="${this._handleViewSelected}"
                  >
                    ${this.lovelace.config.views.map(view=>lit_element.c`
                          <paper-tab>
                            ${view.icon?lit_element.c`
                                    <ha-icon
                                      title="${view.title}"
                                      .icon="${view.icon}"
                                    ></ha-icon>
                                  `:view.title||"Unnamed view"}
                            ${this._editMode?lit_element.c`
                                    <ha-icon
                                      class="edit-icon view"
                                      @click="${this._editView}"
                                      icon="hass:pencil"
                                    ></ha-icon>
                                  `:""}
                          </paper-tab>
                        `)}
                    ${this._editMode?lit_element.c`
                            <paper-button
                              id="add-view"
                              @click="${this._addView}"
                            >
                              <ha-icon
                                title="${this.localize("ui.panel.lovelace.editor.edit_view.add")}"
                                icon="hass:plus"
                              ></ha-icon>
                            </paper-button>
                          `:""}
                  </paper-tabs>
                </div>
              `:""}
      </app-header>
      <div id='view' class="${Object(classMap.a)({"tabs-hidden":2>this.lovelace.config.views.length})}" @rebuild-view='${this._debouncedConfigChanged}'></div>
    </app-header-layout>
    `}renderStyle(){if(!this._haStyle){this._haStyle=document.importNode(document.getElementById("ha-style").children[0].content,!0)}return lit_element.c`
      ${this._haStyle}
      <style include="ha-style">
        :host {
          -ms-user-select: none;
          -webkit-user-select: none;
          -moz-user-select: none;
          --dark-color: #455a64;
          --text-dark-color: #fff;
        }

        ha-app-layout {
          min-height: 100%;
        }
        paper-tabs {
          margin-left: 12px;
          --paper-tabs-selection-bar-color: var(--text-primary-color, #fff);
          text-transform: uppercase;
        }
        .edit-mode {
          background-color: var(--dark-color, #455a64);
          color: var(--text-dark-color);
        }
        .edit-mode div[main-title] {
          pointer-events: auto;
        }
        paper-tab.iron-selected .edit-icon {
          display: inline-flex;
        }
        .edit-icon {
          color: var(--accent-color);
          padding-left: 8px;
        }
        .edit-icon.view {
          display: none;
        }
        #add-view {
          position: absolute;
          height: 44px;
        }
        #add-view ha-icon {
          background-color: var(--accent-color);
          border-radius: 5px;
          margin-top: 4px;
        }
        app-toolbar a {
          color: var(--text-primary-color, white);
        }
        paper-button.warning:not([disabled]) {
          color: var(--google-red-500);
        }
        #view {
          min-height: calc(100vh - 112px);
          /**
         * Since we only set min-height, if child nodes need percentage
         * heights they must use absolute positioning so we need relative
         * positioning here.
         *
         * https://www.w3.org/TR/CSS2/visudet.html#the-height-property
         */
          position: relative;
        }
        #view.tabs-hidden {
          min-height: calc(100vh - 64px);
        }
        paper-item {
          cursor: pointer;
        }
      </style>
    `}updated(changedProperties){super.updated(changedProperties);const view=this._viewRoot,huiView=view.lastChild;if(changedProperties.has("columns")&&huiView){huiView.columns=this.columns}if(changedProperties.has("hass")&&huiView){huiView.hass=this.hass}let newSelectView,force=!1;if(changedProperties.has("route")){const views=this.config&&this.config.views;if(""===this.route.path&&"/lovelace"===this.route.prefix&&views){Object(common_navigate.a)(this,`/lovelace/${views[0].path||0}`,!0)}else if("hass-unused-entities"===this._routeData.view){newSelectView="hass-unused-entities"}else if(this._routeData.view){const selectedView=this._routeData.view,selectedViewInt=parseInt(selectedView,10);let index=0;for(let i=0;i<views.length;i++){if(views[i].path===selectedView||i===selectedViewInt){index=i;break}}newSelectView=index}}if(changedProperties.has("lovelace")){const oldLovelace=changedProperties.get("lovelace");if(!oldLovelace||oldLovelace.config!==this.lovelace.config){this._loadResources(this.lovelace.config.resources||[]);force=!0}if(!oldLovelace||oldLovelace.editMode!==this.lovelace.editMode){force=!0}}if(newSelectView!==void 0||force){if(force&&newSelectView===void 0){newSelectView=this._curView}this._selectView(newSelectView,force)}}get _notifications(){return this._updateNotifications(this.hass.states,this._persistentNotifications||[])}get config(){return this.lovelace.config}get _yamlMode(){return"yaml"===this.lovelace.mode}get _editMode(){return this.lovelace.editMode}get _layout(){return this.shadowRoot.getElementById("layout")}get _viewRoot(){return this.shadowRoot.getElementById("view")}_routeDataChanged(ev){this._routeData=ev.detail.value}_handleNotificationsOpenChanged(ev){this._notificationsOpen=ev.detail.value}_updateNotifications(states,persistent){const configurator=computeNotifications(states);return persistent.concat(configurator)}_handleRefresh(){Object(fire_event.a)(this,"config-refresh")}_handleUnusedEntities(){Object(common_navigate.a)(this,`/lovelace/hass-unused-entities`)}_deselect(ev){ev.target.selected=null}_handleHelp(){window.open("https://www.home-assistant.io/lovelace/","_blank")}_editModeEnable(){if(this._yamlMode){window.alert("The edit UI is not available when in YAML mode.");return}this.lovelace.setEditMode(!0);if(2>this.config.views.length){Object(fire_event.a)(this,"iron-resize")}}_editModeDisable(){this.lovelace.setEditMode(!1);if(2>this.config.views.length){Object(fire_event.a)(this,"iron-resize")}}_editLovelace(){showEditLovelaceDialog(this,this.lovelace)}_editView(){showEditViewDialog(this,{lovelace:this.lovelace,viewIndex:this._curView})}_addView(){showEditViewDialog(this,{lovelace:this.lovelace})}_handleViewSelected(ev){const viewIndex=ev.detail.selected;if(viewIndex!==this._curView){const path=this.config.views[viewIndex].path||viewIndex;Object(common_navigate.a)(this,`/lovelace/${path}`)}scrollToTarget(this,this._layout.header.scrollTarget)}async _selectView(viewIndex,force){if(!force&&this._curView===viewIndex){return}viewIndex=viewIndex===void 0?0:viewIndex;this._curView=viewIndex;if(force){this._viewCache={}}const root=this._viewRoot;if(root.lastChild){root.removeChild(root.lastChild)}if("hass-unused-entities"===viewIndex){if(!loadedUnusedEntities){loadedUnusedEntities=!0;await __webpack_require__.e(62).then(__webpack_require__.bind(null,763))}const unusedEntities=document.createElement("hui-unused-entities");unusedEntities.setConfig(this.config);unusedEntities.hass=this.hass;root.style.background=this.config.background||"";root.appendChild(unusedEntities);return}let view;const viewConfig=this.config.views[viewIndex];if(!viewConfig){this._editModeEnable();return}if(!force&&this._viewCache[viewIndex]){view=this._viewCache[viewIndex]}else{await new Promise(resolve=>Object(render_status.a)(resolve));if(viewConfig.panel&&viewConfig.cards&&0<viewConfig.cards.length){view=Object(create_card_element.a)(viewConfig.cards[0]);view.isPanel=!0}else{view=document.createElement("hui-view");view.lovelace=this.lovelace;view.columns=this.columns;view.index=viewIndex}this._viewCache[viewIndex]=view}view.hass=this.hass;root.style.background=viewConfig.background||this.config.background||"";root.appendChild(view)}_loadResources(resources){resources.forEach(resource=>{switch(resource.type){case"css":if(resource.url in CSS_CACHE){break}CSS_CACHE[resource.url]=Object(load_resource.a)(resource.url);break;case"js":if(resource.url in JS_CACHE){break}JS_CACHE[resource.url]=Object(load_resource.b)(resource.url);break;case"module":Object(load_resource.c)(resource.url);break;case"html":Promise.resolve().then(__webpack_require__.bind(null,297)).then(({importHref})=>importHref(resource.url));break;default:console.warn(`Unknown resource type specified: ${resource.type}`);}})}}customElements.define("hui-root",hui_root_HUIRoot);const show_save_config_dialog_dialogShowEvent="show-save-config";let show_save_config_dialog_registeredDialog=!1;const showSaveDialog=(element,saveDialogParams)=>{if(!show_save_config_dialog_registeredDialog){show_save_config_dialog_registeredDialog=!0;Object(fire_event.a)(element,"register-dialog",{dialogShowEvent:show_save_config_dialog_dialogShowEvent,dialogTag:"hui-dialog-save-config",dialogImport:()=>__webpack_require__.e(86).then(__webpack_require__.bind(null,748))})}Object(fire_event.a)(element,show_save_config_dialog_dialogShowEvent,saveDialogParams)};var extract_views=__webpack_require__(271),get_view_entities=__webpack_require__(272),compute_state_name=__webpack_require__(105),split_by_groups=__webpack_require__(273),compute_object_id=__webpack_require__(116),compute_state_domain=__webpack_require__(153);const DOMAINS_BADGES=["binary_sensor","device_tracker","mailbox","sensor","sun","timer"],HIDE_DOMAIN=new Set(["persistent_notification","configurator"]),computeCards=(title,states)=>{const cards=[],entities=[];for(const[entityId,stateObj]of states){const domain=Object(compute_domain.a)(entityId);if("alarm_control_panel"===domain){cards.push({type:"alarm-panel",entity:entityId})}else if("camera"===domain){cards.push({type:"picture-entity",entity:entityId})}else if("climate"===domain){cards.push({type:"thermostat",entity:entityId})}else if("media_player"===domain){cards.push({type:"media-control",entity:entityId})}else if("plant"===domain){cards.push({type:"plant-status",entity:entityId})}else if("weather"===domain){cards.push({type:"weather-forecast",entity:entityId})}else if("weblink"===domain){const conf={type:"weblink",url:stateObj.state,name:Object(compute_state_name.a)(stateObj)};if("icon"in stateObj.attributes){conf.icon=stateObj.attributes.icon}entities.push(conf)}else{entities.push(entityId)}}if(0<entities.length){cards.unshift({title,type:"entities",entities})}return cards},computeDefaultViewStates=hass=>{const states={};Object.keys(hass.states).forEach(entityId=>{const stateObj=hass.states[entityId];if(!stateObj.attributes.hidden&&!HIDE_DOMAIN.has(Object(compute_state_domain.a)(stateObj))){states[entityId]=hass.states[entityId]}});return states},generateViewConfig=(localize,path,title,icon,entities,groupOrders)=>{const splitted=Object(split_by_groups.a)(entities);splitted.groups.sort((gr1,gr2)=>groupOrders[gr1.entity_id]-groupOrders[gr2.entity_id]);const badgeEntities={},ungroupedEntitites={};Object.keys(splitted.ungrouped).forEach(entityId=>{const state=splitted.ungrouped[entityId],domain=Object(compute_state_domain.a)(state),coll=DOMAINS_BADGES.includes(domain)?badgeEntities:ungroupedEntitites;if(!(domain in coll)){coll[domain]=[]}coll[domain].push(state.entity_id)});let badges=[];DOMAINS_BADGES.forEach(domain=>{if(domain in badgeEntities){badges=badges.concat(badgeEntities[domain])}});let cards=[];splitted.groups.forEach(groupEntity=>{cards=cards.concat(computeCards(Object(compute_state_name.a)(groupEntity),groupEntity.attributes.entity_id.map(entityId=>[entityId,entities[entityId]])))});Object.keys(ungroupedEntitites).sort().forEach(domain=>{cards=cards.concat(computeCards(localize(`domain.${domain}`),ungroupedEntitites[domain].map(entityId=>[entityId,entities[entityId]])))});return{path,title,icon,badges,cards}},generateLovelaceConfig=(hass,localize)=>{const viewEntities=Object(extract_views.a)(hass.states),views=viewEntities.map(viewEntity=>{const states=Object(get_view_entities.a)(hass.states,viewEntity),groupOrders={};Object.keys(states).forEach((entityId,idx)=>{groupOrders[entityId]=idx});return generateViewConfig(localize,Object(compute_object_id.a)(viewEntity.entity_id),Object(compute_state_name.a)(viewEntity),viewEntity.attributes.icon,states,groupOrders)});let title=hass.config.location_name;if(0===viewEntities.length||viewEntities[0].entity_id!=="group.default_view"){const states=computeDefaultViewStates(hass),groupOrders={};Object.keys(states).forEach(entityId=>{const stateObj=states[entityId];if(stateObj.attributes.order){groupOrders[entityId]=stateObj.attributes.order}});views.unshift(generateViewConfig(localize,"default_view","Home",void 0,states,groupOrders));if(1<views.length&&"Home"===title){title="Home Assistant"}}return{title,views}};let editorLoaded=!1;class ha_panel_lovelace_LovelacePanel extends Object(lit_localize_mixin.a)(lit_element.a){static get properties(){return{hass:{},lovelace:{},narrow:{type:Boolean,value:!1},showMenu:{type:Boolean,value:!1},route:{},_columns:{type:Number,value:1},_state:{type:String,value:"loading"},_errorMsg:String,_config:{type:{},value:null}}}constructor(){super();this._closeEditor=this._closeEditor.bind(this)}render(){const state=this._state;if("loaded"===state){return lit_element.c`
        <hui-root
          .narrow="${this.narrow}"
          .showMenu="${this.showMenu}"
          .hass="${this.hass}"
          .lovelace="${this.lovelace}"
          .route="${this.route}"
          .columns="${this._columns}"
          @config-refresh="${this._forceFetchConfig}"
        ></hui-root>
      `}if("error"===state){return lit_element.c`
        <style>
          paper-button {
            color: var(--primary-color);
            font-weight: 500;
          }
        </style>
        <hass-error-screen
          title="Lovelace"
          .error="${this._errorMsg}"
          .narrow="${this.narrow}"
          .showMenu="${this.showMenu}"
        >
          <paper-button on-click="_forceFetchConfig"
            >Reload Lovelace</paper-button
          >
        </hass-error-screen>
      `}if("yaml-editor"===state){return lit_element.c`
        <hui-editor
          .lovelace="${this.lovelace}"
          .closeEditor="${this._closeEditor}"
        ></hui-editor>
      `}return lit_element.c`
      <hass-loading-screen
        .narrow="${this.narrow}"
        .showMenu="${this.showMenu}"
      ></hass-loading-screen>
    `}updated(changedProps){super.updated(changedProps);if(changedProps.has("narrow")||changedProps.has("showMenu")){this._updateColumns()}}firstUpdated(){this._fetchConfig(!1);this._updateColumns=this._updateColumns.bind(this);this.mqls=[300,600,900,1200].map(width=>{const mql=matchMedia(`(min-width: ${width}px)`);mql.addListener(this._updateColumns);return mql});this._updateColumns()}_closeEditor(){this._state="loaded"}_updateColumns(){const matchColumns=this.mqls.reduce((cols,mql)=>cols+ +mql.matches,0);this._columns=Math.max(1,matchColumns-+(!this.narrow&&this.showMenu))}_forceFetchConfig(){this._fetchConfig(!0)}async _fetchConfig(force){let conf,confMode=this.panel.config.mode;try{conf=await fetchConfig(this.hass,force)}catch(err){if("config_not_found"!==err.code){console.log(err);this._state="error";this._errorMsg=err.message;return}conf=generateLovelaceConfig(this.hass,this.localize);confMode="generated"}this._state="loaded";this.lovelace={config:conf,editMode:this.lovelace?this.lovelace.editMode:!1,mode:confMode,enableFullEditMode:()=>{if(!editorLoaded){editorLoaded=!0;Promise.all([__webpack_require__.e(6),__webpack_require__.e(61)]).then(__webpack_require__.bind(null,730))}this._state="yaml-editor"},setEditMode:editMode=>{if(!editMode||"generated"!==this.lovelace.mode){this._updateLovelace({editMode});return}showSaveDialog(this,{lovelace:this.lovelace})},saveConfig:async newConfig=>{const{config,mode}=this.lovelace;try{this._updateLovelace({config:newConfig,mode:"storage"});await saveConfig(this.hass,newConfig)}catch(err){console.error(err);this._updateLovelace({config,mode});throw err}}}}_updateLovelace(props){this.lovelace=Object.assign({},this.lovelace,props)}}customElements.define("ha-panel-lovelace",ha_panel_lovelace_LovelacePanel)},77:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return loadCSS});__webpack_require__.d(__webpack_exports__,"b",function(){return loadJS});__webpack_require__.d(__webpack_exports__,"c",function(){return loadModule});function _load(tag,url,type){return new Promise(function(resolve,reject){const element=document.createElement(tag);let attr="src",parent="body";element.onload=()=>resolve(url);element.onerror=()=>reject(url);switch(tag){case"script":element.async=!0;if(type){element.type=type}break;case"link":element.type="text/css";element.rel="stylesheet";attr="href";parent="head";}element[attr]=url;document[parent].appendChild(element)})}const loadCSS=url=>_load("link",url),loadJS=url=>_load("script",url),loadModule=url=>_load("script",url,"module")},78:function(module,__webpack_exports__,__webpack_require__){"use strict";var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_iron_input_iron_input_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(101),_paper_input_char_counter_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(102),_paper_input_container_js__WEBPACK_IMPORTED_MODULE_3__=__webpack_require__(103),_paper_input_error_js__WEBPACK_IMPORTED_MODULE_4__=__webpack_require__(104),_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__=__webpack_require__(52),_polymer_polymer_lib_elements_dom_module_js__WEBPACK_IMPORTED_MODULE_6__=__webpack_require__(30),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_7__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__=__webpack_require__(1),_paper_input_behavior_js__WEBPACK_IMPORTED_MODULE_9__=__webpack_require__(83);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_7__.a)({is:"paper-input",_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_8__.a`
    <style>
      :host {
        display: block;
      }

      :host([focused]) {
        outline: none;
      }

      :host([hidden]) {
        display: none !important;
      }

      input {
        /* Firefox sets a min-width on the input, which can cause layout issues */
        min-width: 0;
      }

      /* In 1.x, the <input> is distributed to paper-input-container, which styles it.
      In 2.x the <iron-input> is distributed to paper-input-container, which styles
      it, but in order for this to work correctly, we need to reset some
      of the native input's properties to inherit (from the iron-input) */
      iron-input > input {
        @apply --paper-input-container-shared-input-style;
        font-family: inherit;
        font-weight: inherit;
        font-size: inherit;
        letter-spacing: inherit;
        word-spacing: inherit;
        line-height: inherit;
        text-shadow: inherit;
        color: inherit;
        cursor: inherit;
      }

      input:disabled {
        @apply --paper-input-container-input-disabled;
      }

      input::-webkit-outer-spin-button,
      input::-webkit-inner-spin-button {
        @apply --paper-input-container-input-webkit-spinner;
      }

      input::-webkit-clear-button {
        @apply --paper-input-container-input-webkit-clear;
      }

      input::-webkit-calendar-picker-indicator {
        @apply --paper-input-container-input-webkit-calendar-picker-indicator;
      }

      input::-webkit-input-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input:-moz-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input::-moz-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      input::-ms-clear {
        @apply --paper-input-container-ms-clear;
      }

      input::-ms-reveal {
        @apply --paper-input-container-ms-reveal;
      }

      input:-ms-input-placeholder {
        color: var(--paper-input-container-color, var(--secondary-text-color));
      }

      label {
        pointer-events: none;
      }
    </style>

    <paper-input-container id="container" no-label-float="[[noLabelFloat]]" always-float-label="[[_computeAlwaysFloatLabel(alwaysFloatLabel,placeholder)]]" auto-validate\$="[[autoValidate]]" disabled\$="[[disabled]]" invalid="[[invalid]]">

      <slot name="prefix" slot="prefix"></slot>

      <label hidden\$="[[!label]]" aria-hidden="true" for\$="[[_inputId]]" slot="label">[[label]]</label>

      <!-- Need to bind maxlength so that the paper-input-char-counter works correctly -->
      <iron-input bind-value="{{value}}" slot="input" class="input-element" id\$="[[_inputId]]" maxlength\$="[[maxlength]]" allowed-pattern="[[allowedPattern]]" invalid="{{invalid}}" validator="[[validator]]">
        <input aria-labelledby\$="[[_ariaLabelledBy]]" aria-describedby\$="[[_ariaDescribedBy]]" disabled\$="[[disabled]]" title\$="[[title]]" type\$="[[type]]" pattern\$="[[pattern]]" required\$="[[required]]" autocomplete\$="[[autocomplete]]" autofocus\$="[[autofocus]]" inputmode\$="[[inputmode]]" minlength\$="[[minlength]]" maxlength\$="[[maxlength]]" min\$="[[min]]" max\$="[[max]]" step\$="[[step]]" name\$="[[name]]" placeholder\$="[[placeholder]]" readonly\$="[[readonly]]" list\$="[[list]]" size\$="[[size]]" autocapitalize\$="[[autocapitalize]]" autocorrect\$="[[autocorrect]]" on-change="_onChange" tabindex\$="[[tabIndex]]" autosave\$="[[autosave]]" results\$="[[results]]" accept\$="[[accept]]" multiple\$="[[multiple]]">
      </iron-input>

      <slot name="suffix" slot="suffix"></slot>

      <template is="dom-if" if="[[errorMessage]]">
        <paper-input-error aria-live="assertive" slot="add-on">[[errorMessage]]</paper-input-error>
      </template>

      <template is="dom-if" if="[[charCounter]]">
        <paper-input-char-counter slot="add-on"></paper-input-char-counter>
      </template>

    </paper-input-container>
  `,behaviors:[_paper_input_behavior_js__WEBPACK_IMPORTED_MODULE_9__.a,_polymer_iron_form_element_behavior_iron_form_element_behavior_js__WEBPACK_IMPORTED_MODULE_5__.a],properties:{value:{type:String}},get _focusableElement(){return this.inputElement._inputElement},listeners:{"iron-input-ready":"_onIronInputReady"},_onIronInputReady:function(){if(!this.$.nativeInput){this.$.nativeInput=this.$$("input")}if(this.inputElement&&-1!==this._typesThatHaveText.indexOf(this.$.nativeInput.type)){this.alwaysFloatLabel=!0}if(!!this.inputElement.bindValue){this.$.container._handleValueAndAutoValidate(this.inputElement)}}})},81:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return IronA11yAnnouncer});var _polymer_polymer_polymer_legacy_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(3),_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(1);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronA11yAnnouncer=Object(_polymer_polymer_lib_legacy_polymer_fn_js__WEBPACK_IMPORTED_MODULE_1__.a)({_template:_polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_2__.a`
    <style>
      :host {
        display: inline-block;
        position: fixed;
        clip: rect(0px,0px,0px,0px);
      }
    </style>
    <div aria-live\$="[[mode]]">[[_text]]</div>
`,is:"iron-a11y-announcer",properties:{mode:{type:String,value:"polite"},_text:{type:String,value:""}},created:function(){if(!IronA11yAnnouncer.instance){IronA11yAnnouncer.instance=this}document.body.addEventListener("iron-announce",this._onIronAnnounce.bind(this))},announce:function(text){this._text="";this.async(function(){this._text=text},100)},_onIronAnnounce:function(event){if(event.detail&&event.detail.text){this.announce(event.detail.text)}}});IronA11yAnnouncer.instance=null;IronA11yAnnouncer.requestAvailability=function(){if(!IronA11yAnnouncer.instance){IronA11yAnnouncer.instance=document.createElement("iron-a11y-announcer")}document.body.appendChild(IronA11yAnnouncer.instance)}},97:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.d(__webpack_exports__,"a",function(){return IronRangeBehavior});__webpack_require__(3);/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/const IronRangeBehavior={properties:{value:{type:Number,value:0,notify:!0,reflectToAttribute:!0},min:{type:Number,value:0,notify:!0},max:{type:Number,value:100,notify:!0},step:{type:Number,value:1,notify:!0},ratio:{type:Number,value:0,readOnly:!0,notify:!0}},observers:["_update(value, min, max, step)"],_calcRatio:function(value){return(this._clampValue(value)-this.min)/(this.max-this.min)},_clampValue:function(value){return Math.min(this.max,Math.max(this.min,this._calcStep(value)))},_calcStep:function(value){value=parseFloat(value);if(!this.step){return value}var numSteps=Math.round((value-this.min)/this.step);if(1>this.step){return numSteps/(1/this.step)+this.min}else{return numSteps*this.step+this.min}},_validateValue:function(){var v=this._clampValue(this.value);this.value=this.oldValue=isNaN(v)?this.oldValue:v;return this.value!==v},_update:function(){this._validateValue();this._setRatio(100*this._calcRatio(this.value))}}}}]);
//# sourceMappingURL=f472ba3cb4559cb19acc.chunk.js.map